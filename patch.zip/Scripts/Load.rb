class PokemonLoadPanel < SpriteWrapper
  TRAINERNAME_COLOR = [Color.new(240, 72, 88), Color.new(100, 40, 40)]
  LOADINFO_COLOR = [Color.new(232, 232, 232), Color.new(136, 136, 136)]
  LOADINFO_COLOR_ALT = [Color.new(219, 203, 236), Color.new(142, 126, 159)]
  PATCH_COLOR = [Color.new(50, 190, 50), Color.new(40, 90, 40)]
  MAJOR_COLOR = [Color.new(240, 72, 88), Color.new(100, 40, 40)]

  TITLE_OFFSET = [32, 8]
  MAPNAME_OFFSET = [386, 8, 18] # third value : y for mapname2
  TRAINERNAME_OFFSET = [112, 64]
  LOADLABEL_OFFSET = [32, 8]
  LOADINFO_OFFSET = Rejuv ? [230, 112, 32] : [240, 112, 32]

  attr_reader :selected
  attr_reader :ttsText

  def initialize(index, title, id, trainer, framecount, mapid, viewport = nil)
    super(viewport)
    @index = index
    @title = title
    @id = id
    @trainer = trainer
    @totalsec = (framecount || 0) / 40 # Graphics.frame_rate #Because Turbo exists
    @mapid = mapid
    @selected = (index == 0)
    @bgbitmap = AnimatedBitmap.new("Graphics/Pictures/loadPanels")
    @refreshBitmap = true
    @refreshing = false
    refresh
  end

  def dispose
    @bgbitmap.dispose
    self.bitmap.dispose
    super
  end

  def selected=(value)
    if @selected != value
      @selected = value
      @refreshBitmap = true
      refresh
    end
  end

  def pbRefresh
    # Draw contents
    @refreshBitmap = true
    refresh
  end

  def refresh
    return if @refreshing
    return if disposed?

    @refreshing = true
    if !self.bitmap || self.bitmap.disposed?
      self.bitmap = BitmapWrapper.new(@bgbitmap.width, 111 * 2)
      pbSetSystemFont(self.bitmap)
    end
    if !@refreshBitmap
      @refreshing = false
      return
    end

    @refreshBitmap = false
    self.bitmap.clear if self.bitmap
    if @id == :Continue
      self.bitmap.blt(0, 0, @bgbitmap.bitmap, Rect.new(0, (@selected ? 111 * 2 : 0), @bgbitmap.width, 111 * 2))
    else
      self.bitmap.blt(0, 0, @bgbitmap.bitmap, Rect.new(0, 111 * 2 * 2 + (@selected ? 23 * 2 : 0), @bgbitmap.width, 23 * 2))
    end
    textpos = []
    if @id == :Continue
      # Map name and title
      mapname = pbGetMapNameFromId(@mapid)
      mapname.gsub!(/\\PN/, @trainer.name)
      addTitleAndMapName(mapname, textpos)
      # Trainer name
      textpos.push([@trainer.name, TRAINERNAME_OFFSET[0], TRAINERNAME_OFFSET[1], 0, *TRAINERNAME_COLOR])
      # Badges/Legendaries
      if !@trainer.postgame
        textpos.push([getLabels[0], LOADLABEL_OFFSET[0], LOADINFO_OFFSET[1], 0, *LOADINFO_COLOR])
        textpos.push([@trainer.numbadges.to_s, LOADINFO_OFFSET[0], LOADINFO_OFFSET[1], 1, *LOADINFO_COLOR])
#        textpos.push([$game_variables[:LevelCap], LOADINFO_OFFSET[0], LOADINFO_OFFSET[1], 1, *LOADINFO_COLOR])
      else
        textpos.push([getLabels[1], LOADLABEL_OFFSET[0], LOADINFO_OFFSET[1], 0, *LOADINFO_COLOR])
        textpos.push([@trainer.postgame.to_s, LOADINFO_OFFSET[0], LOADINFO_OFFSET[1], 1, *LOADINFO_COLOR])
      end
      # Pokedex
      textpos.push([getLabels[2], LOADLABEL_OFFSET[0], LOADINFO_OFFSET[1] + LOADINFO_OFFSET[2], 0, *LOADINFO_COLOR])
      if @trainer.pokedex && ([true, false].include?(@trainer.pokedex) || !@trainer.pokedex.instance_variable_defined?(:@dexList) ||
          !@trainer.pokedex.instance_variable_get(:@dexList).values[0].is_a?(PokedexListEntry))
        textpos.push([0.to_s, LOADINFO_OFFSET[0], LOADINFO_OFFSET[1] + LOADINFO_OFFSET[2], 1, *LOADINFO_COLOR])
      else
        textpos.push([getPokedexCount(), LOADINFO_OFFSET[0], LOADINFO_OFFSET[1] + LOADINFO_OFFSET[2], 1, *LOADINFO_COLOR])
      end
      # Time
      textpos.push([getLabels[3], LOADLABEL_OFFSET[0], LOADINFO_OFFSET[1] + LOADINFO_OFFSET[2] * 2, 0, *LOADINFO_COLOR])
      hour = @totalsec / 60 / 60
      min = @totalsec / 60 % 60
      if hour > 0
        textpos.push([_INTL("{1}h {2}m", hour, min), LOADINFO_OFFSET[0], LOADINFO_OFFSET[1] + LOADINFO_OFFSET[2] * 2, 1, *LOADINFO_COLOR])
      else
        textpos.push([_INTL("{1}m", min), LOADINFO_OFFSET[0], LOADINFO_OFFSET[1] + LOADINFO_OFFSET[2] * 2, 1, *LOADINFO_COLOR])
      end
    else
      colors = case true
        when @id == :OtherSaves && $game_switches && $game_switches[:A_Fervent_Wish] then LOADINFO_COLOR_ALT
        when @id == :PatchUpdate || @id == :EngineUpdate then PATCH_COLOR
        when @id == :MajorUpdate then MAJOR_COLOR
        else LOADINFO_COLOR
      end
      textpos.push([@title, LOADLABEL_OFFSET[0], LOADLABEL_OFFSET[1], 0, *colors])
    end
    pbDrawTextPositions(self.bitmap, textpos)
    @ttsText = textpos.map{ |i| i[0] }.join("\n") if !@ttsText
    @refreshing = false
  end

  def addTitleAndMapName(mapname, textpos)
    textpos.push([@title, TITLE_OFFSET[0], TITLE_OFFSET[1], 0, *LOADINFO_COLOR])
    mapname2 = ""
    if mapname.length > 24
      splits = mapname.split(/ /, mapname[0, 24].split(/ /).length)
      mapname2 = splits.delete_at(-1)
      mapname = splits.join(" ")
    end
    textpos.push([mapname, MAPNAME_OFFSET[0], MAPNAME_OFFSET[1], 1, *LOADINFO_COLOR])
    textpos.push([mapname2, MAPNAME_OFFSET[0], MAPNAME_OFFSET[2], 1, *LOADINFO_COLOR]) if mapname2 != ""
  end

  def getLabels
    return [_INTL("Level Cap"), _INTL("Legendaries"), _INTL("Pokédex"), _INTL("Time")]
  end

  def getPokedexCount
    return @trainer.pokedex.getOwnedCount.to_s + "/" + @trainer.pokedex.getSeenCount.to_s
  end
end

class PokemonLoadScene
  LOADPANELS_X = 54

  CHAR_X_BASE = 114
  CHAR_Y_BASE = 108
  PARTY_X_BASE = 308
  PARTY_X_OFFSET = 64
  PARTY_Y_BASE = 72
  PARTY_Y_OFFSET = 50

  SaveNameColors = [Color.new(255, 255, 255), Color.new(125, 125, 125)]
  SaveNameColorsAlt = [Color.new(218, 182, 214), Color.new(139, 131, 148)]
  VersionColor = Color.new(55, 55, 55)

  def pbUpdate
    oldi = @sprites["cmdwindow"].index rescue 0
    pbUpdateSpriteHash(@sprites)
    newi = @sprites["cmdwindow"].index rescue 0
    if oldi != newi
      @sprites["panel#{oldi}"].selected = false
      @sprites["panel#{oldi}"].pbRefresh
      @sprites["panel#{newi}"].selected = true
      @sprites["panel#{newi}"].pbRefresh
      while @sprites["panel#{newi}"].y > Graphics.height - 80
        for i in 0...@commands.length
          @sprites["panel#{i}"].y -= 48
        end
        for i in 0...6
          break if !@sprites["party#{i}"]

          @sprites["party#{i}"].y -= 48
        end
        @sprites["player"].y -= 48 if @sprites["player"]
      end
      while @sprites["panel#{newi}"].y < 32
        for i in 0...@commands.length
          @sprites["panel#{i}"].y += 48
        end
        for i in 0...6
          break if !@sprites["party#{i}"]

          @sprites["party#{i}"].y += 48
        end
        @sprites["player"].y += 48 if @sprites["player"]
      end
    end
  end

  def pbStartScene(commands, ids, trainer, framecount, mapid)
    @commands = commands
    @sprites = {}
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99998
    @textviewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @textviewport.z = @viewport.z + 1
    @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @textviewport)
    @sprites["overlay2"] = BitmapSprite.new(Graphics.width, Graphics.height, @textviewport)

    if GAME_VERSION != 'dev'
      version = GAME_VERSION
      # Breaks on 1.5x screen size but we don't have a better option currently.
      @sprites["overlay2"].bitmap.font.name = "PokemonEmerald"
      @sprites["overlay2"].bitmap.font.size = $kirin ? 21 : 15
      @sprites["overlay2"].bitmap.font.bold = true
      textpos = []
      if version.index("-") != nil
        prerelease = version[version.index("-") + 1..]
        version = version[0...version.index("-")]
        textpos.push [version, Graphics.width - 6, Graphics.height - 30, :right, VersionColor]
        textpos.push [prerelease, Graphics.width - 6, Graphics.height - 18, :right, VersionColor]
      else
        textpos.push [version, Graphics.width - 6, Graphics.height - 26, :right, VersionColor]
      end
      pbDrawTextPositions(@sprites["overlay2"].bitmap, textpos)
    end

    addBackgroundOrColoredPlane(@sprites, "background", "loadbg", Color.new(248, 248, 248), @viewport)
    y = 32
    for i in 0...commands.length
      @sprites["panel#{i}"] = PokemonLoadPanel.new(i, commands[i], ids[i], trainer, framecount, mapid, @viewport)
      @sprites["panel#{i}"].pbRefresh
      @sprites["panel#{i}"].x = LOADPANELS_X
      @sprites["panel#{i}"].y = y
      y += ids[i] == :Continue ? 224 : 48
    end
    @sprites["cmdwindow"] = Window_CommandPokemon.new([], tts: false)
    @sprites["cmdwindow"].x = Graphics.width
    @sprites["cmdwindow"].y = 0
    @sprites["cmdwindow"].viewport = @viewport
    @sprites["cmdwindow"].visible = false
  end

  def pbStartScene2
    pbFadeInAndShow(@sprites) { pbUpdate }
  end

  def pbMoveSprites(xoffset)
    @sprites["cmdwindow"].x -= xoffset
    @sprites["player"].x -= xoffset if @sprites["player"]
    for i in 0..6
      @sprites["party#{i}"].x -= xoffset if @sprites["party#{i}"]
    end
    for i in 0..6
      @sprites["panel#{i}"].x -= xoffset if @sprites["panel#{i}"]
    end
  end

  def pbDrawSaveCommands(savefiles)
    @savefiles = savefiles
    textpos = []
    numsavebuttons = [savefiles.length, 9].min
    for i in 0...numsavebuttons
      @sprites["savefile#{i}"] = IconSprite.new(Graphics.width / 2 - 384 / 2, i * 45, @viewport)
      @sprites["savefile#{i}"].setBitmap("Graphics/Pictures/loadsavepanel")
      @sprites["savefile#{i}"].zoom_x = 0.5
      @sprites["savefile#{i}"].zoom_y = 0.5
      Graphics.update
      loop do
        @sprites["savefile#{i}"].zoom_x += 0.5
        @sprites["savefile#{i}"].zoom_y += 0.5
        Graphics.update
        break if @sprites["savefile#{i}"].zoom_x == 1
      end
    end
    pbDrawSaveText(savefiles)
    @sprites["saveselect"] = IconSprite.new(Graphics.width / 2 - 384 / 2, 0, @viewport)
    @sprites["saveselect"].setBitmap("Graphics/Pictures/loadsavepanel_1")
    Graphics.update
    pbToggleSelecting
    tts(@savefiles[0][1])
  end

  def pbRemoveSaveCommands
    @sprites["overlay"].bitmap.clear
    @index = 0 if !@index
    Graphics.update

    pbDisposeSprite(@sprites, "saveselect")
    Graphics.update
    for i in 0...@savefiles.length
      pbDisposeSprite(@sprites, "savefile#{i}")
      Graphics.update
    end
  end

  def pbChooseAutoSubFile(index, arrayindex)
    if !@sprites["autosavefile"]
      @sprites["overlay"].bitmap.clear
      @sprites["newsavefile1"] = IconSprite.new(20, Graphics.height / 3, @viewport)
      @sprites["newsavefile1"].setBitmap("Graphics/Pictures/loadsavepanel")
      @sprites["autosavefile"] = IconSprite.new(300, Graphics.height / 3, @viewport)
      @sprites["autosavefile"].setBitmap("Graphics/Pictures/loadsavepanel")
      @sprites["saveselect"] = IconSprite.new(20, Graphics.height / 3, @viewport)
      @sprites["saveselect"].setBitmap("Graphics/Pictures/loadsavepanel_1")
      @sprites["autosavefile"].zoom_x = 0.5
      @sprites["newsavefile1"].zoom_x = 0.5
      @sprites["newsavefile1"].zoom_y = 1.5
      @sprites["autosavefile"].zoom_y = 1.5
      @sprites["saveselect"].zoom_x = 0.5
      @sprites["saveselect"].zoom_y = 1.5
      @sprites["overlay2"].bitmap.font.size = 22
      textpos = []
      textpos.push([@savefiles[arrayindex][1], Graphics.width / 2 - @savefiles[arrayindex][1].length / 2 * 10, 30, 0, Color.new(0, 0, 0), Color.new(125, 125, 125)])
      textpos.push(["Normal Save", 55, Graphics.height / 3 + 12, 0, Color.new(255, 255, 255), Color.new(125, 125, 125)])
      textpos.push(["Autosave", 350, Graphics.height / 3 + 12, 0, Color.new(255, 255, 255), Color.new(125, 125, 125)])
      textpos.push([@savefiles[arrayindex][4], 30, Graphics.height / 3 + 35, 0, Color.new(255, 255, 255), Color.new(125, 125, 125)])
      textpos.push([@savefiles[arrayindex][5], 315, Graphics.height / 3 + 35, 0, Color.new(255, 255, 255), Color.new(125, 125, 125)])
      pbDrawTextPositions(@sprites["overlay"].bitmap, textpos)
    end
    if index == 0
      @sprites["saveselect"].x = 20
    else
      @sprites["saveselect"].x = 300
    end
  end

  def pbClearOverlay2
    @sprites["overlay2"].bitmap.clear
  end

  def pbDrawCurrentSaveFile(savename = "", auto = nil)
    @sprites["overlay2"].bitmap.clear
    textpos = []
    if auto == nil
      textpos.push([savename, 0, 0, 0, Color.new(255, 255, 255), Color.new(125, 125, 125)])
    else
      textpos.push([savename + " Auto Save", 0, 0, 0, Color.new(255, 255, 255), Color.new(125, 125, 125)])
    end
    pbDrawTextPositions(@sprites["overlay2"].bitmap, textpos)
  end

  def pbDrawSaveText(savefiles, xoffset = 0, yoffset = 0)
    @sprites["overlay"].bitmap.clear
    pbSetSystemFont(@sprites["overlay"].bitmap)
    textpos = []
    # @savefiles=savefiles
    for i in 0...savefiles.length
      y = i * 45 + 8 - yoffset
      next if y < 0 || y + 4 > 9 * 45

      x = Graphics.width / 2
      colors = savefiles[i][1].start_with?("Anna's Wish") ? SaveNameColorsAlt : SaveNameColors
      textpos.push([savefiles[i][1], x, y, 2, *colors])
    end
    pbDrawTextPositions(@sprites["overlay"].bitmap, textpos)
  end

  def pbToggleSelecting
    if @saveselecting
      @saveselecting = !@saveselecting
    else
      @saveselecting = true
    end
  end

  def pbMoveSaveSel(index)
    tts(@savefiles[index][1], true) if @savefiles[index]
    @index = index
    if index <= 7
      @sprites["saveselect"].y = index * 45
      pbDrawSaveText(@savefiles)
    elsif index == @savefiles.length - 1
      @sprites["saveselect"].y = 7 * 45
      pbDrawSaveText(@savefiles, 0, 45 * (index - 7))
    else
      pbDrawSaveText(@savefiles, 0, 45 * (index - 7))
    end
    if index == (@savefiles.length - 1) && @savefiles.length - 1 >= 8
      @sprites["savefile8"].visible = false if @sprites["savefile8"]
    else
      @sprites["savefile8"].visible = true if @sprites["savefile8"]
    end
    Graphics.update
  end

  def pbStartDeleteScene
    @sprites = {}
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99998
    addBackgroundOrColoredPlane(@sprites, "background", "loadbg", Color.new(248, 248, 248), @viewport)
  end

  def pbSetParty(trainer)
    return if !trainer || !trainer.party

    filename = pbGetPlayerCharset(:walk, trainer)
    @sprites["player"] = TrainerWalkingCharSprite.new(filename, @viewport)
    charwidth = @sprites["player"].bitmap.width
    charheight = @sprites["player"].bitmap.height
    @sprites["player"].x = CHAR_X_BASE - charwidth / 8
    @sprites["player"].y = CHAR_Y_BASE - charheight / 4 + 20
    @sprites["player"].src_rect = Rect.new(0, 0, charwidth / 4, charheight / 4)
    for i in 0...trainer.party.length
      @sprites["party#{i}"] = PokemonIconSprite.new(trainer.party[i], @viewport)
      @sprites["party#{i}"].z = 99999
      @sprites["party#{i}"].x = PARTY_X_BASE + PARTY_X_OFFSET * (i & 1)
      @sprites["party#{i}"].y = PARTY_Y_BASE + PARTY_Y_OFFSET * (i / 2)
    end
  end

  def pbChoose(commands)
    @sprites["cmdwindow"].commands = commands
    lastread = nil
    loop do
      Graphics.update
      Input.update
      index = @sprites["cmdwindow"].index
      if index != lastread
        ttsText = @sprites["panel#{index}"].ttsText
        tts(ttsText || commands[index], true)
      end
      lastread = index
      pbUpdate
      if Input.trigger?(Input::C) && (!@saveselecting || @saveselecting == false)
        return index
      end
    end
  end

  def pbEndScene
    pbFadeOutAndHide(@sprites) # { pbUpdate }
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
    @commands = nil
    @textviewport.dispose
  end

  def pbCloseScene
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end
end

class PokemonLoad
  attr_accessor :currentsave

  def initialize(scene)
    @scene = scene
  end

  def pbTryLoadFile(savefile)
    begin
      File.open(savefile, "rb") { |f|
        @currentsave = Marshal.load(f)
      }
      if !@currentsave.is_a?(Hash)
        convertSaveFolder
        File.open(savefile, "rb") { |f|
          @currentsave = Marshal.load(f)
        }
      end
      return
    rescue => e
      @currentsave = nil
      raise sprintf("Corrupted save file:\n%s\n%s: %s", File.realpath(savefile), e.class, e.message)
    end
  end

  def pbStartDeleteScreen
    savefile = RTP.getSaveFileName("Game.rxdata")
    @scene.pbStartDeleteScene
    @scene.pbStartScene2
    if safeExists?(savefile)
      if Kernel.pbConfirmMessageSerious(_INTL("Delete all saved data?"))
        Kernel.pbMessage(_INTL("Once data has been deleted, there is no way to recover it.\1"))
        if Kernel.pbConfirmMessageSerious(_INTL("Delete the saved data anyway?"))
          Kernel.pbMessage(_INTL("Deleting all data.\nDon't turn off the power.\\wtnp[0]"))
          begin; File.delete(savefile); rescue; end
          begin; File.delete(savefile + ".bak"); rescue; end
          Kernel.pbMessage(_INTL("The save file was deleted."))
        end
      end
    else
      Kernel.pbMessage(_INTL("No save file was found."))
    end
    @scene.pbEndScene
    $scene = pbCallTitle
  end

  def pbStartLoadScreen
    $PokemonTemp   = PokemonTemp.new
    $game_temp     = Game_Temp.new
    $game_map      = nil
    Input.text_input = false
    commands      = []
    ids           = []
    trainer        = nil
    savefile       = RTP.getSaveSlotPath($Unidata[:saveslot])

    addCommand = Proc.new { |id, name|
      ids.push(id)
      commands.push(name)
    }

    if safeExists?(savefile)
      begin
        pbTryLoadFile(savefile)
      rescue => e
        dp e.message
      end
      if @currentsave.is_a?(Hash)
        trainer = @currentsave[:Trainer]
        framecount = @currentsave[:playtime]
        $game_system = @currentsave[:system]
        mapid = @currentsave[:map_id]

        addCommand.call(:Continue, _INTL("Save File {1}", $Unidata[:saveslot]))
      end
    end

    Updater.waitForVersionCheck
    versionStatus = nil
    if Updater.shouldUseBuiltInUpdater?
      versionStatus = Updater.getVersionStatus
      if versionStatus == 3
        addCommand.call(:PatchUpdate, _INTL("Update available: {1}", Updater.getAvailableVersion))
      elsif versionStatus == 4
        addCommand.call(:MajorUpdate, _INTL("Major update: {1}", Updater.getAvailableLatest))
      elsif versionStatus == 5
        addCommand.call(:EngineUpdate, _INTL("Engine update available"))
      end
    end

    addCommand.call(:NewGame, _INTL("New Game"))
    addCommand.call(:OtherSaves, _INTL("Other Save Files"))
    if safeExists?(savefile)
      addCommand.call(:DeleteSave, _INTL("Delete This Save File"))
    end
    addCommand.call(:Options, _INTL("Options"))
    addCommand.call(:SaveDir, _INTL("Save Directory"))
    addCommand.call(:Controls, _INTL("Controls"))
    if LANGUAGES.length >= 2
      addCommand.call(:Language, _INTL("Language"))
    end
    # addCommand.call(:Quit, _INTL("Quit Game"))

    ThreadLoader.awaitMainMenuData

    @scene.pbStartScene(commands, ids, trainer, framecount, mapid)
    @scene.pbSetParty(trainer)
    @scene.pbStartScene2

    if $Settings.updatePrompts == 0
      if versionStatus == 3
        unless Updater.handlePatchUpdate(true)
          Kernel.pbMessage(_INTL("Update prompts may be disabled in Options."))
        end
      elsif versionStatus == 4
        unless Updater.handleMajorUpdate
          Kernel.pbMessage(_INTL("Update prompts may be disabled in Options."))
        end
      elsif versionStatus == 5
        unless Updater.handleEngineUpdate(true)
          Kernel.pbMessage(_INTL("Update prompts may be disabled in Options."))
        end
      end
    end

    loop do
      cmd = @scene.pbChoose(commands)
      command = ids[cmd]
      deleting = false
      if command == :DeleteSave
        if Kernel.pbConfirmMessageSerious(_INTL("Are you sure you want to delete this save file?"))
          if Kernel.pbConfirmMessageSerious(_INTL("All data will be lost.  Confirm once more to proceed."))
            begin; File.delete(savefile); rescue; end
            deleting = true
            @scene.pbClearOverlay2
            @scene.pbEndScene
            return
            pbSetUpSystem
            scene = PokemonLoadScene.new
            screen = PokemonLoad.new(scene)
            screen.pbStartLoadScreen
          end
        end
        redo if deleting == false
      elsif command == :Continue
        next if !startPlayingSaveFile(savefile)

        return
      elsif command == :NewGame
        @scene.pbEndScene
        if $game_map && $game_map.events
          for event in $game_map.events.values
            event.clear_starting
          end
        end
        ThreadLoader.awaitRuntimeData
        $game_temp.common_event_id = 0 if $game_temp
        $scene               = Scene_Map.new
        Graphics.frame_count = 0
        Graphics.start_playing = Process.clock_gettime(Process::CLOCK_MONOTONIC)
        $game_system         = Game_System.new
        $game_switches       = Game_Switches.new
        $game_variables      = Game_Variables.new
        $game_self_switches  = Game_SelfSwitches.new
        $game_screen         = Game_Screen.new
        $game_player         = Game_Player.new
        $PokemonMap          = PokemonMapMetadata.new
        $PokemonGlobal       = PokemonGlobalMetadata.new
        $PokemonStorage      = PokemonStorage.new
        $PokemonEncounters   = PokemonEncounters.new
        getNGPData
        $PokemonTemp.begunNewGame = true
        $MapFactory = PokemonMapFactory.new()
        $MapFactory.setup($cache.RXsystem.start_map_id) # calls setMapChanged
        $game_player.moveto($cache.RXsystem.start_x, $cache.RXsystem.start_y)
        $game_player.refresh
        $game_map.autoplay
        $game_map.update

        # find next available slot
        createSaveSlot
        return
      elsif command == :OtherSaves
        # convertSaveFolder
        saveslots = []
        # Finding Other Save Files
        d = Dir.new(RTP.getSaveFolder)
        begin
          d.children.each do |file|
            next if !/^Game_[0-9]+.rxdata$/.match(file) && !/^Game.rxdata$/.match(file)
            next if !safeExists?(d.path + "/" + file)

            t = File.mtime(d.path + "/" + file) rescue pbGetTimeNow
            savetime = t.strftime("%c")
            info = saveinfo(d.path + file)
            savenumber = file.scan(/\d+/)[0].to_i
            savenumber = 1 if savenumber == 0
            slotname = (Reborn ? "" : _INTL("Save File") + " ") + savenumber.to_s + info
            saveslots.push([savenumber, slotname, false, true, savetime, file])
          end
        rescue
          logError($!, display: true)
        ensure
          d.close
        end

        # Specific Anna Smiles code
        anna_saves = []
        if Reborn
          d = Dir.new(RTP.getSaveFolder)
          begin
            d.children.each do |file|
              next if !file.start_with?("Anna's Wish")
              next if !safeExists?(d.path + "/" + file)

              info = saveinfo(d.path + file)
              savenumber = file.scan(/\d+/)[0].to_i
              slotname = "Anna's Wish" + info
              anna_saves.push([savenumber, slotname, false, true, nil, file])
            end
          rescue
            logError($!, display: true)
          ensure
            d.close
          end
          anna_saves.sort_by! { |arr| arr[0] }
          saveslots += anna_saves
        end

        if saveslots.length == 0
          Kernel.pbMessage(_INTL("You don't have any other save files."))
          next
        end
        saveslots.sort_by! { |arr| arr[0] }
        for i in 1..21 # move the commands and other graphics
          @scene.pbMoveSprites(i * 2)
          Graphics.update
        end
        @scene.pbDrawSaveCommands(saveslots)
        # @scene.pbDrawSaveText(saveslots)
        @selected = 0
        loop do
          Input.update
          Graphics.update
          if Input.repeat?(Input::DOWN)
            @selected = (@selected + 1) % saveslots.length
            @scene.pbMoveSaveSel(@selected)
          elsif Input.repeat?(Input::UP)
            @selected = (@selected - 1) % saveslots.length
            @scene.pbMoveSaveSel(@selected)
          elsif Input.repeat?(Input::L)
            @selected = [@selected - 7, 0].max
            @scene.pbMoveSaveSel(@selected)
          elsif Input.repeat?(Input::R)
            @selected = [@selected + 7, saveslots.length - 1].min
            @scene.pbMoveSaveSel(@selected)
          elsif Input.trigger?(Input::B)
            @scene.pbRemoveSaveCommands
            Graphics.update
            for i in 1..21 # move the commands and other graphics
              @scene.pbMoveSprites(i * -2)
              Graphics.update
            end
            @scene.pbToggleSelecting
            break
          elsif Input.trigger?(Input::X)
            Input.text_input = true
            message = _INTL("Jump to saveslot?")
            text = Kernel.pbMessageFreeText(message, "", 999, Graphics.width)
            next if text == ""
            index = nil
            if text.to_i.to_s == text
              index = text.to_i - 1
              index = index.clamp(0, saveslots.length)
            else
              results = []
              valarray = []
              for i in 1...saveslots.length
                if saveslots[i][1].downcase.include?(text.downcase)
                  results.push(saveslots[i][1])
                  valarray.push(i)
                end
              end
              puts(results)
              if results.empty?
                Kernel.pbMessage(_INTL("No matches found."))
              else
                Kernel.pbMessage(_INTL("{1} matches found.", results.length)) if results.length > 1
                text = Kernel.pbShowCommands(nil, results, @selected, 0)
                text = valarray[text]
                unless text < 1 || text > saveslots.length
                  index = [text, 0].max
                end
              end
            end
            if index
              @selected = index
              @scene.pbMoveSaveSel(@selected)
              @scene.instance_variable_get(:@sprites)["saveselect"].y = (index <= 7 ? @selected : 7) * 45
            end
            Input.text_input = false
          elsif Input.trigger?(Input::C)
            @scene.pbRemoveSaveCommands
            tempsave = saveslots[@selected][0]
            savefile = saveslots[@selected][5]
            if savefile.start_with?("Anna's Wish")
              createSaveSlot
              return startPlayingSaveFile(RTP.getSaveFileName(savefile))
            end

            $Unidata[:saveslot] = tempsave
            @scene.pbEndScene
            pbSetUpSystem
            scene = PokemonLoadScene.new
            screen = PokemonLoad.new(scene)
            screen.pbStartLoadScreen
            return
          end
        end
      elsif command == :Options
        scene = PokemonOptionScene.new
        screen = PokemonOption.new(scene)
        pbFadeOutIn(99999) { screen.pbStartScreen }

      elsif command == :Controls
        controlsDialogue
      elsif command == :SaveDir
        folderpath = RTP.getSaveFolder
        if $joiplay || $kirin
          Kernel.pbMessage(wrap_path(File.expand_path('.') + "/" + folderpath))
        elsif System.platform[/Windows/]
          folderpath.gsub!('\\', '\\\\')
          folderpath.gsub!('/', '\\\\')
          system("explorer #{folderpath}")
        elsif System.platform[/macOS/]
          # pathstr = "~\\Library\\Application Support\\#{GAME_TITLE}\\"
          system("open '#{folderpath}'")
        elsif System.platform[/Linux/]
          # System.open(folderpath)
          system("xdg-open '#{folderpath}'")
        end
      elsif command == :Language
        @scene.pbEndScene
        $Settings.language = pbChooseLanguage
        saveSettings
        pbLoadLanguage
        $scene = pbCallTitle
        return
      elsif command == :PatchUpdate
        Updater.handlePatchUpdate
      elsif command == :MajorUpdate
        Updater.handleMajorUpdate
      elsif command == :EngineUpdate
        Updater.handleEngineUpdate
      end
    end
    @scene.pbEndScene
    return
  end

  def startPlayingSaveFile(savefile)
    unless safeExists?(savefile)
      pbPlayBuzzerSE()
      return false
    end
    pbTryLoadFile(savefile) # Needed for Anna's Wish
    startTimer
    @scene.pbEndScene
    $Trainer = @currentsave[:Trainer]
    playtime = @currentsave[:playtime]
    if playtime.bit_length < 31
      Graphics.frame_count  = playtime
      playtime              = 0
    end
    $game_system            = @currentsave[:system]
    $game_switches          = @currentsave[:switches]
    $game_variables         = @currentsave[:variable]
    $game_self_switches     = @currentsave[:self_switches]
    $game_screen            = @currentsave[:game_screen]
    $game_player            = @currentsave[:game_player]
    $PokemonGlobal          = @currentsave[:PokemonGlobal]
    $PokemonMap             = @currentsave[:PokemonMap]
    $PokemonBag             = @currentsave[:PokemonBag]
    $PokemonStorage         = @currentsave[:PokemonStorage]
    map = @currentsave[:Map]

    ThreadLoader.awaitRuntimeData

    if Reborn && $game_screen.regionalWeather.nil?
      $game_screen.regionalWeather = RegionalWeather.new
    end

    if Rejuv && !$game_screen.showingBlessings.nil?
      startBlessingOverlay($game_screen.showingBlessings)
    end

    $MapFactory = PokemonMapFactory.new()
    $MapFactory.setup(@currentsave[:map_id], true)
    if ($DEBUG && (Input.press?(Input::CTRL) || Input.pressex?(:L))) || forceLoadMapConditions?(@currentsave[:map_id])
      # LOAD NEW MAP INSTANCE
    else
      if pbBattleChallenge.pbInChallenge?
        $game_system.newInterp
        $MapFactory.setup(@currentsave[:map_id])
      elsif Rejuv && ($game_variables[974] == 3 && [678, 679].include?(@currentsave[:map_id]))
        $game_variables[974] = 4
        $game_system.newInterp
        $MapFactory.setup(@currentsave[:map_id])
      else
        $MapFactory.loadMap(map)
      end
    end
    $game_map = $MapFactory.map

    Graphics.time_passed = Graphics.frame_count.clone + playtime
    Graphics.start_playing = Process.clock_gettime(Process::CLOCK_MONOTONIC)

    checkConversions
    $Trainer.pokedex.refreshDex # Ensures Pokedex matches loaded Pokemon data
    getNGPData
    $PokemonBag.initTrackerData if !$PokemonBag.itemtracker

    if $PokemonGlobal.safesave
      if pbMapInterpreterRunning?
        pbMapInterpreter.setup(nil, 0)
      end
      $MapFactory.setup($game_map.map_id) # calls setMapChanged
      # $game_player.center($game_player.x, $game_player.y)
    else
      $MapFactory.setMapChanged($game_map.map_id)
    end
    if !$game_map.events # Map wasn't set up
      $game_map = nil
      $scene = nil
      Kernel.pbMessage(_INTL("The map is corrupt. The game cannot continue."))
      return true
    end
    $PokemonMap.updateMap
    $PokemonEncounters = PokemonEncounters.new
    $PokemonEncounters.setup($game_map.map_id)
    pbAutoplayOnSave
    $game_map.update
    if Rejuv
      if $game_map.map_id == 560
        if $game_map.events[83]&.x == 39
          $game_map.events[83].moveto(49,28)
        end
      end
      if $game_variables[974] == 4
        if $game_map.map_id == 678
          pbBGMPlay("Battle - Thorned Crown For a Prince")
        end
        if $game_map.map_id == 679
          pbSEPlay("SFX - Karma")
        end
      end
    end
    # some bullshit, don't worry about it
    if $game_variables[:Some_Bullshit] > 0
      $game_variables[:Some_Bullshit] += 1
      $game_map.need_refresh = true
    end
    if $game_variables[:ItsALuckyNumber] == 3
      $game_variables[:ItsALuckyNumber] = 4
      $game_map.need_refresh = true
      $game_screen.tone.red = -255
      $game_screen.tone.blue = -255
      $game_screen.tone.green = -255
      $game_screen.tone.gray = 0
      $game_mute = true
    end
    if Reborn && $game_switches[:Postgame]
      $Trainer.postgame = $game_variables[569]
    end
    if !$game_screen.shakeX || !$game_screen.shakeY
      $game_screen.initAddedVars
    end
    # end bullshit
    for event in $game_map.events.values
      event.unlock
    end
    $game_switches[:Mid_quicksave] = false
    $game_switches[:Stop_Icycle_Falling] = false
    $game_switches[:Enable_Event_Save] = false
    stopTimer
    $scene = Scene_Map.new
    $game_player.center($game_player.x, $game_player.y)
    Kernel.pbUpdateVehicle
    gameSetup()
    if $game_variables[:BethQuest] == 17
      pbBGMPlay("Music - Route 3")
      $game_variables[:BethQuest] = 18
      if $game_screen.pictures[1]
        $game_screen.pictures[1].erase
      end
      pbZoomMap(1,1)
      $game_map.need_refresh = true
      $game_screen.tone.red = 0
      $game_screen.tone.blue = 0
      $game_screen.tone.green = 0
      $game_screen.tone.gray = 0
    end
    if $cache.mapdata[$game_map.map_id].Outdoor
      $game_screen.setWeather
    end
    return true
  end
end

def saveinfo(savefile)
  begin
    data = nil
    File.open(savefile, "rb") { |f|
      data = Marshal.load(f)
    }
    if data.is_a?(Hash)
      trainer = data[:Trainer]
      if trainer.postgame != nil
        info = _INTL(" - {1} - {2} legendaries", trainer.name, trainer.postgame)
      else
        info = _INTL(" - {1} - {2} badges", trainer.name, trainer.numbadges)
      end
      return info
    else
      info = _INTL(" - legacy save file")
    end
  rescue
    if data.is_a?(Hash)
      info = _INTL(" - save corrupted")
    else
      info = _INTL(" - legacy save file")
    end
  end
  return info
end

# To be defined per game.
def gameSetup(); end

def createSaveSlot
  j = 0
  loop do
    j += 1
    checksave = RTP.getSaveSlotPath(j)
    if !safeExists?(checksave)
      changeCurrentSaveSlot(j)
      break
    end
  end
end

def changeCurrentSaveSlot(savenum)
  $Unidata[:saveslot] = savenum
  saveClientData
end

def restrictOnlineFeatures
  pws = pbActivePasswords
  $game_switches[:No_Online_Randbats] = true if pws.any? { |pw| pw.disablesOnlineRandBats }
  $game_switches[:No_Online_Trades] = true if pws.any? { |pw| pw.disablesOnlineTrading }
end

def tmSanityCheckRejuv
  return false if ($game_switches[:NotPlayerCharacter] && !$game_switches[:InterceptorsWish]) || xenTowerInProgress
  $cache.items.each do |key, item|
    next if !item.checkFlag?(:tm)
    $game_switches[item.item] = false if !$PokemonBag.pbHasItem?(item.item)
  end
end

def checkConversions
  # This method is used for system changes that require saved data to be altered in some way,
  # regardless of whether or not it's game breaking.
  pbUpdateRegionalDexes

  if !$Trainer.pokedex.instance_variable_get(:@dexList).values[0].is_a?(PokedexListEntry)
    convertDexToEntries
  end

  if $Trainer.trainertype.is_a?(Integer)
    enforceTrainerType
  end
    # following bit should be only hit by older files
  if ($game_switches[:NotPlayerCharacter] && !$game_switches[:InterceptorsWish])
    if $game_variables[:PlayerDataBackup][8] == nil
      $game_variables[:PlayerDataBackup][8] = $PokemonStorage
    end
  end

  # Last check through for old temp conversions, most of these methods should be able to be
  # safely removed after a while.
  if !$game_system.game_version || (Reborn && $game_system.game_version == "e19.16")
    # updating storage boxes, can be removed after a while
    if $PokemonStorage && $PokemonStorage.boxes.length < STORAGEBOXES
      $PokemonStorage.upTotalBoxes(STORAGEBOXES)
    end
    tempConvertNatures
    if Rejuv
      $Trainer.achievements = Achievements.new() if !$Trainer.achievements
    end
    $Trainer.pokedex.updateGenderFormEntries # ensure things are updated, remove after a bit ig

    if $game_switches[:Randomized_Challenge]
      Kernel.pbMessage(_INTL("Note: The game has detected you were previously playing a randomizer. Your old randomizer data will no longer function."))
      if Kernel.pbConfirmMessage(_INTL("Would you like to re-randomize your game?"))
        pbFadeOutIn(99999) {
          RandomizerScene.new(RandomizerSettings.new)
          $Randomizer.randomize if $game_switches[:Randomized_Challenge]
        }
      else
        if Kernel.pbConfirmMessageSerious(_INTL("You will still be unable to access any online features. Are you sure you wish to continue without randomizing?"))
          $game_switches[:Disabled_Randomizer] = true
          $game_switches[:Randomized_Challenge] = false
        else
          pbFadeOutIn(99999) {
            RandomizerScene.new(RandomizerSettings.new)
            $Randomizer.randomize if $game_switches[:Randomized_Challenge]
          }
        end
      end
    end
  end

  if !$game_switches[:Disabled_Randomizer] && $game_switches[:Randomized_Challenge]
    $rndcache = nil
    if File.exist?("Randomizer Data/settings.txt")
      str = File.read("Randomizer Data/settings.txt")
      settings = RandomizerSettings.new()
      settings.load(str)
      regenerate = (settings.to_s != $game_variables[:Randomizer_Settings] || settings.random.seed != $game_variables[:Randomizer_Seed])
      $Randomizer = Randomizer.new(settings)
      if regenerate
        settings.load($game_variables[:Randomizer_Settings] + "\n" + $game_variables[:Randomizer_Seed].to_s + "\n" + $game_variables[:Randomizer_Items].to_s)
        Kernel.pbMessage(_INTL("The game will now generate your randomizer files."))
        $Randomizer.randomize
      end
    else
      settings = RandomizerSettings.new()
      str = "#{$game_variables[:Randomizer_Settings]}\n#{$game_variables[:Randomizer_Seed]}\n#{$game_variables[:Randomizer_Items]}"
      settings.load(str)
      $Randomizer = Randomizer.new(settings)
      Kernel.pbMessage(_INTL("The game will now generate your randomizer files."))
      $Randomizer.randomize
    end
    if !$rndcache&.loaded
      $rndcache.load()
    end
  end

  # Restrict online play
  restrictOnlineFeatures

  allpokemon = findAllPokemon

  # Apply pokemon object attribute changes
  allpokemon.each { |pokemon|
    pokemon.removeDeprecatedAttributes
    pokemon.genderflag = [:M, :F, :N][pokemon.genderflag] if pokemon.genderflag.is_a?(Numeric)
  }

  # Change EXPALLOFF back to EXPALL (added Rejuv 13.5, removed Reborn 19.6)
  $PokemonBag.pbChangeItem(:EXPALLOFF, :EXPALL) if $PokemonBag.pbHasItem?(:EXPALLOFF)

  # Resort items to their correct pockets (needed in particular to relocate red/blue orbs from items pocket to crystals pocket in reborn)
  $PokemonBag.rearrange

  # Convert berries to use BerryPlantData
  $PokemonGlobal.eventvars.each do |k, v|
    if v.is_a?(BerryPlantData)
      # Fix half-conversions where it was given an empty value and properly reset it.
      v.reset if v.berry_id.is_a?(Numeric)
      # Fix half-conversions where it was given the correct berry but no data
      v.data = $cache.items[v.berry_id].berry if v.berry_id && !v.data
    end
    # Look for berry data structures
    next unless v.is_a?(Array) && [6, 7].include?(v.length)

    # Old berry data conversion
    if v[1] != 0 && v[1].is_a?(Integer)
      for i in $cache.items.keys
        if $cache.items[i].checkFlag?(:ID) == v[1]
          v[1] = i
          break
        end
      end
    end

    berryData = BerryPlantData.new
    berryData.growth_stage = v[0]
    unless v[1] == 0
      berryData.berry_id = v[1]
      berryData.data = $cache.items[v[1]].berry
    end
    berryData.watered_this_stage = v[2]
    berryData.time_alive = (v[3].to_i / 60) * 60 # accurate to the minute
    berryData.time_last_updated = berryData.time_alive
    berryData.watering_count = v[4]

    $PokemonGlobal.eventvars[k] = berryData
  end

  # Change pokedex sorting mode to be a hash containing values for each pokedex rather than a single value for all pokedexes
  $PokemonGlobal.pokedexMode = {} if $PokemonGlobal.pokedexMode.is_a?(Integer)

  # New conversions based on game version.
  if Reborn
    # Migrate Exp All upgrade
    if $game_switches[:Exp_All_Upgrade] && $PokemonBag.pbHasItem?(:EXPALL)
      $PokemonBag.pbChangeItem(:EXPALL, :EXPALLPLUS)
      if $game_switches[:Exp_All_On]
        $game_switches[:Exp_All_On] = false
        $game_switches[:Exp_All_Plus_On] = true
      end
    end

    # Fix incorrect legacy switches
    # == true is necessary because the switches were accidentally used as non-boolean
    $game_switches[2335] = false unless $game_switches[2335] == true
    $game_switches[2336] = false unless $game_switches[2336] == true

    # Moving tutored move IDs into Trainer tutor list, convert into symbols
    $Trainer.tutorlist = [] if !$Trainer.tutorlist
    if $PokemonGlobal.tutoredMoves && !$PokemonGlobal.tutoredMoves.empty?
      $PokemonGlobal.tutoredMoves.length().times do
        $Trainer.tutorlist.push($PokemonGlobal.tutoredMoves.shift())
      end
    end
    if $Trainer.tutorlist.any? { |i| i.is_a?(Integer) }
      for i in 0...$Trainer.tutorlist.length
        next if !$Trainer.tutorlist[i].is_a?(Integer)

        for j in $cache.moves.keys
          if $cache.moves[j].checkFlag?(:ID) == $Trainer.tutorlist[i]
            $Trainer.tutorlist[i] = $cache.moves[j].move
          end
        end
      end
    end
    $Trainer.tutorlist.uniq!

    # Convert the stored movesets from the Moveset Restorer
    if $PokemonGlobal.storedMovesets && !$PokemonGlobal.storedMovesets.empty?
      for moveset in $PokemonGlobal.storedMovesets
        moveset[:moves].each_with_index { |move, i|
          next if move.is_a?(Hash)

          found = $cache.moves.find { |m, data|
            hasID = data.checkFlag?(:ID) == move.instance_variable_get(:@id) # 19.0.16
            hasmove = m == move.move # 19.5.0-rc.13
            hasID || hasmove
          }

          if found
            movename = found[1].checkFlag?(:ID) == move.instance_variable_get(:@id) ? found[1].move : move.move
            moveset[:moves][i] = { move: movename, ppup: move.ppup }
          end
        }
        $cache.pkmn.each { |mon, data|
          if data[0].dexnum == moveset[:id]
            moveset[:id] = mon
            break
          end
        }
      end
    end

    # Set battle facility current streaks to 0 if higher than max streaks -- this should be the case only for saves older than max streaks impl
    { 775 => 859, 777 => 860, 813 => 861 }.each { |cur, max|
      $game_variables[cur] = 0 if $game_variables[cur] > $game_variables[max]
    }

    # Fix online battle music being set to a filename with extension mp3
    # To be done for the other games as well if they shift to ogg files + use online play
    $Trainer.onlineMusic = nil if $Trainer.onlineMusic.is_a?(String) && $Trainer.onlineMusic.end_with?(".mp3")

    # Turn On NotPlayerCharacter switch and restore attributes if currently playing as Sigmund/Taka/Zero but the switch isn't On (character switching handling was changed in 19.6.0-beta.80)
    player = $cache.metadata[:Players].find { |player| player[:tclass] == $Trainer.trainertype }
    if player && player[:directory].nil? && !$game_switches[:NotPlayerCharacter]
      $Trainer.money = $Trainer.tempmoney
      $Trainer.badges = $Trainer.tempbadges
      $Trainer.id = $Trainer.tempid
      $game_switches[:NotPlayerCharacter] = true
    end
    # Remove attributes not used anymore
    $Trainer.tempmoney = nil
    $Trainer.tempbadges = nil
    $Trainer.tempid = nil

    # Migrate legacy mon data (19.6 changes)
    allpokemon.each { |mon|
      # Snow Warning had to be split into two abilities for Snow implementation
      mon.ability = :HAILWARNING if mon.ability == :SNOWWARNING && Gen < 9
      # Battle Bond Greninja's form number was changed from 1 to 2 to accomodate Mega Greninja
      mon.form = 2 if mon.species == :GRENINJA && mon.form == 1 && mon.ability == :BATTLEBOND
      # Complete Forme Zygarde was made illegal outside battle
      mon.form = 0 if mon.species == :ZYGARDE && mon.form == 2
    }

    # Creates missing data point for Pokedex data validation
    $Trainer.pokedex.storedGen = 7 if !$Trainer.pokedex.storedGen

    # Fixes Pokedex entry list @forms for species with renamed forms from Scripts#658
    convert(:KYOGRE, :GROUDON) do |entry|
      next if entry.forms["Primal Form"] # converted
      entry.forms["Primal Form"] = entry.forms.delete("Primal")
    end
    convert(:SILVALLY) do |entry|
      next if entry.forms["Type: Normal"] # converted
      entry.forms.transform_keys! { |formName| "Type: #{formName}" }
    end
    convert(:MINIOR) do |entry|
      next unless entry.forms["Blue Core"] # converted
      # Rename these first
      entry.forms["Dark Core"] = entry.forms.delete("Violet Core")
      entry.forms["Violet Core"] = entry.forms.delete("Indigo Core")
      entry.forms["Indigo Core"] = entry.forms.delete("Blue Core")
      # Rename and reorder
      entry.forms["Red Core"] = entry.forms.delete("Red Core")
      entry.forms["Indigo Core"] = entry.forms.delete("Indigo Core")
      entry.forms["Green Core"] = entry.forms.delete("Green Core")
      entry.forms["Violet Core"] = entry.forms.delete("Violet Core")
      entry.forms["White Core"] = entry.forms.delete("Orange Core") # Orange to White
      entry.forms["Yellow Core"] = entry.forms.delete("Yellow Core")
      entry.forms["Dark Core"] = entry.forms.delete("Dark Core")
      entry.forms["Meteor Form"] = entry.forms.delete("Meteor Form")
    end
    convert(:NECROZMA, :ETERNATUS, :CALYREX) do |entry|
      next if entry.forms["Normal Form"] # converted
      entry.forms["Normal Form"] = entry.forms.delete($cache.pkmn[entry.species, 0].name)
      entry.forms.keys[0...-1].each { |formName| entry.forms[formName] = entry.forms.delete(formName) }
    end
    convert(:PUMPKABOO, :GOURGEIST) do |entry|
      next if entry.forms["Jumbo Variety"] # converted
      entry.forms["Jumbo Variety"] = entry.forms.delete("Normal Form")
      entry.forms["Small Variety"] = entry.forms.delete("Small")
    end

    # Fix attributes for randomizer data
    if $Randomizer&.randomPokemonAttributes && $game_switches[:Randomized_Challenge] && !$rndcache.pkmn[:BULBASAUR, 0].form
      $rndcache.pkmn.each { |sym, wrapper|
        forms = wrapper.forms.invert
        wrapper.pokemonData.each { |formName, data|
          formNum = forms[formName]
          $rndcache.pkmn[sym, formNum].instance_variable_set(:@form, formNum)
        }
      }
      save_data($rndcache.pkmn, "Randomizer Data/mons.dat")
    end

    # Fix Fossil Restoration being moved to a new map.
    if checkVersionOlderThan("19.6.0-beta.66") && $Randomizer&.seededStatics
      for i in 0...$rndcache.statics.length
        next if $rndcache.statics[i].map != 242
        $rndcache.statics[i].instance_variable_set(:@map, 906)
      end
      save_data($rndcache.statics, "Randomizer Data/statics.dat")
    end

    if checkVersionOlderThan("19.6.0-beta.86")
      convertGenderFormMons(allpokemon)
    end
  end

  if Rejuv
    $game_variables[:LuckMoves] = [$game_variables[:LuckMoves], Random.new(Time.now.to_i)] if $game_variables[:LuckMoves] != 0 && !$game_variables[:LuckMoves].is_a?(Array)
    $game_switches[:Last_Ace_Switch] = false # just frankly this should only be one for specific battles so it shouldn't be on on saveload basically ever
    if $game_variables[543]&.is_a?(Array)
      allpokemon -= $game_variables[543]
      if $game_variables[646] >= 40
        $game_variables[543] = 0
      else
        $game_variables[543].each { |mon| convertMon(mon) if mon.is_a?(PokeBattle_Pokemon) && mon.species.is_a?(Numeric) }
        allpokemon += $game_variables[543]
      end
    end
    if $game_variables[756] > 26 ||  $game_variables[731] > 35
      $game_switches[:Portable_Move_Relearner] = true if !$game_switches[:Portable_Move_Relearner]
    end
    if $game_variables[812] < 2 && $PokemonGlobal.visitedMaps[618]
      $PokemonGlobal.visitedMaps[618] = false
    end
    if checkVersionOlderThan("14.0.0-beta.12")
      $game_switches[:Field_Notes] = true
      $game_switches[2048] = true # city notes
      $game_switches[2038] = true if $game_switches[:RiftDex] # dimensional
      $game_switches[2038] = true if $game_variables[568] > 16 # dragon's den
      $game_variables[960] = rand(3)
      $game_variables[2048] = 0 # because i am fucking stupid
    end
    if checkVersionOlderThan("14.0.0-beta.13")
      $game_variables[971] = rand(3)
    end
    if checkVersionOlderThan("14.0.0-beta.14")
      if !$Unidata[:FinishedV14Story]
        $game_variables[960] = 0
        $Unidata[:EizenTowerSkip] = false
        saveClientData
      end
    end
    if checkVersionOlderThan("14.0.0-beta.15")
      RIFTDATA.each_key { |rift|
        if $game_switches[rift]
          $game_switches[getRiftSpriteSwitch(rift)] = true
          $game_switches[getRiftDefeatedSwitch(rift)] = true
        end
      }
    end
    if checkVersionOlderThan("14.0.0-beta.17")
      RIFTDATA.each_key { |rift|
        $game_switches[getRiftSpriteSwitch(rift)] = true if $game_switches[getRiftDefeatedSwitch(rift)]
      }
    end
    if checkVersionOlderThan("14.0.0-beta.18")
      $game_variables[968] = rand(3) if $game_variables[968] == 0
    end
    if checkVersionOlderThan("14.0.0-beta.24")
      if $game_switches[2110]
        $game_switches[2110] = false
        $game_variables[362] -= 1
      end
    end
    if checkVersionOlderThan("14.0.3")
      if $game_variables[212] > 0
        $game_variables[212] += 1
      end
      if $game_variables[898] > 0 && $game_variables[838] == 0 # accounting for modded files, settnig variables to 0
        $game_variables[898] = 0
      end
    end
    if checkVersionOlderThan("14.0.7")
      completedQuests = getCompletedQuests()
      if completedQuests.include?(:HeroOfSlime)
        $game_variables[617] = 31 if $game_variables[617] == 0
        $game_switches[2209] = false if $game_switches[2209]
      end
      if completedQuests.include?(:MissingChildren)
        $game_variables[429] = 91 if $game_variables[429] == 0
      end

      #$Unidata[:FinishedV14Story] = false if $game_variables[812] < 154
    end
    if checkVersionOlderThan("14.0.9")
      # Fix for Paragon NG++ stuff
      $Unidata[:FinishedV14Story] = true if $PokemonGlobal.visitedMaps[684] && $game_variables[912] == 0
    end
    if checkVersionOlderThan("14.0.10")
      # Fix for Paragon NG++ stuff
      $game_switches[:Omniscience] = false if !pbActivePasswords.include?("omniscience")
    end

    # Fixes Pokedex entry list @forms for species with renamed forms from Scripts#658
    convert(:TAUROS) do |entry|
      next if entry.forms["Paldean Combat Breed"] # converted
      entry.forms["Paldean Combat Breed"] = entry.forms.delete("Combat Breed")
      entry.forms["Paldean Blaze Breed"] = entry.forms.delete("Blaze Breed")
      entry.forms["Paldean Aqua Breed"] = entry.forms.delete("Aqua Breed")
    end
    convert(:MEWTWO) do |entry|
      next if entry.forms["Mega X Form"] # converted
      entry.forms["Mega X Form"] = entry.forms.delete("Mega X")
      entry.forms["Mega Y Form"] = entry.forms.delete("Mega Y")
    end
    convert(:FURFROU) do |entry|
      next if entry.forms["Natural Form"] # converted
      entry.forms["Natural Form"] = entry.forms.delete("Normal Form")
    end
    convert(:SILVALLY) do |entry|
      next if entry.forms["Type: Normal"] # converted
      entry.forms.transform_keys! { |formName| "Type: #{formName}" }
    end
    convert(:MINIOR) do |entry|
      next unless entry.forms["Blue Core"] # converted
      # Rename and reorder
      entry.forms["Red Core"] = entry.forms.delete("Red Core")
      entry.forms["Indigo Core"] = entry.forms.delete("Blue Core") # Blue to Indigo
      entry.forms["Green Core"] = entry.forms.delete("Green Core")
      entry.forms["Violet Core"] = entry.forms.delete("Violet Core")
      entry.forms["White Core"] = entry.forms.delete("White Core")
      entry.forms["Yellow Core"] = entry.forms.delete("Yellow Core")
      entry.forms["Dark Core"] = entry.forms.delete("Dark Core")
      entry.forms["Meteor Form"] = entry.forms.delete("Meteor Form")
    end
    convert(:DIALGA, :PALKIA, :NECROZMA, :ETERNATUS, :CALYREX) do |entry|
      next if entry.forms["Normal Form"] # converted
      entry.forms["Normal Form"] = entry.forms.delete($cache.pkmn[entry.species, 0].name)
      entry.forms.keys[0...-1].each { |formName| entry.forms[formName] = entry.forms.delete(formName) }
    end
    convert(:PUMPKABOO, :GOURGEIST) do |entry|
      next if entry.forms["Jumbo Variety"] # converted
      entry.forms["Jumbo Variety"] = entry.forms.delete("Normal Form")
      entry.forms["Small Variety"] = entry.forms.delete("Small")
    end

    allpokemon.each { |pokemon|
      change = false
      if checkVersionOlderThan("14.0.0-beta.1")
        (pokemon.form = 0; change = true) if pokemon.species == :SNEASLER

        pokemon.moves.map! { |move| move&.move == :HAIL ? PBMove.new(:SNOWSCAPE) : move}
      end
      if checkVersionOlderThan("14.0.0-beta.14")
        (pokemon.form += 1; change = true) if pokemon.species == :ZYGARDE && pokemon.form > 2
      end
      if checkVersionOlderThan("14.0.0-beta.22")
        (pokemon.ability = :SWORNDUTY if pokemon.species == :SNEASLER && pokemon.form == 1 && pokemon.ability == :HOSPITALITY)
      end

      if checkVersionOlderThan("14.0.0-beta.23")
        if [:MEOWSTIC, :INDEEDEE, :BASCULEGION, :OINKOLOGNE].include?(pokemon.species)
          change = true
          form = pokemon.form
          pokemon.form = 0
          pokemon.genderflag = [:M, :F][form % 2] # modulo to ensure form is bound to gender index
        end
      end

      if checkVersionOlderThan("14.0.0-beta.24")
        if pokemon.species == :UNFEZANT && pokemon.form == 2
          change = true
          pokemon.form = 1
          pokemon.makeFemale
        end
      end

      if checkVersionOlderThan("14.0.0-beta.26")
        pokemon.timeReceived = :Glitched if pokemon.timeReceived.is_a?(String)
        pokemon.timeEggHatched = :Glitched if pokemon.timeEggHatched.is_a?(String)
      end
      if checkVersionOlderThan("14.0.10")
        if pokemon.species == :POLTCHAGEIST && pokemon.form == 1
          pokemon.form = 0
          pokemon.ability = :HOSPITALITY
        end
      end

      pokemon.calcStats if change
    }

    if $game_variables[:VirtualGender] == 0 && $game_variables[:VirtualLeagueProgress] > 0 # Check for old gender switch, and convert to new variable
      $game_variables[:VirtualGender] = $game_switches[:VirtualGirl] ? 2 : 1
    end
    if $game_variables[:VirtualLeagueProgress] > 7
      $game_switches[:VirtualGym7] = true if  $game_switches[:VirtualGym7] == false
    end

    tmSanityCheckRejuv # accounting for a TM related bug in 14.0.0 beta
  end

  if Desolation
    # Fixes Pokedex entry list @forms for species with renamed forms from Scripts#658
    convert(:FURFROU) do |entry|
      next if entry.forms["Natural Form"] # converted
      entry.forms["Natural Form"] = entry.forms.delete("Normal Form")
    end
    convert(:SILVALLY) do |entry|
      next if entry.forms["Type: Normal"] # converted
      entry.forms.transform_keys! { |formName| "Type: #{formName}" }
    end
    convert(:MINIOR) do |entry|
      next unless entry.forms["Blue Core"] # converted
      # Rename these first
      entry.forms["Dark Core"] = entry.forms.delete("Violet Core")
      entry.forms["Violet Core"] = entry.forms.delete("Indigo Core")
      entry.forms["Indigo Core"] = entry.forms.delete("Blue Core")
      # Rename and reorder
      entry.forms["Red Core"] = entry.forms.delete("Red Core")
      entry.forms["Indigo Core"] = entry.forms.delete("Indigo Core")
      entry.forms["Green Core"] = entry.forms.delete("Green Core")
      entry.forms["Violet Core"] = entry.forms.delete("Violet Core")
      entry.forms["White Core"] = entry.forms.delete("Orange Core") # Orange to White
      entry.forms["Yellow Core"] = entry.forms.delete("Yellow Core")
      entry.forms["Dark Core"] = entry.forms.delete("Dark Core")
      entry.forms["Meteor Form"] = entry.forms.delete("Meteor Form")
    end
    convert(:TOXTRICITY) do |entry|
      next if entry.forms["Amped Form"] # converted
      entry.forms["Amped Form"] = entry.forms.delete("Amped")
      entry.forms["Low Key Form"] = entry.forms.delete("Low Key")
    end
    convert(:URSALUNA) do |entry|
      next if entry.forms["Bloodmoon"] # converted
      entry.forms["Bloodmoon"] = entry.forms.delete("Blood Moon")
    end
    convert(:DIALGA, :PALKIA, :NECROZMA, :ETERNATUS, :CALYREX) do |entry|
      next if entry.forms["Normal Form"] # converted
      entry.forms["Normal Form"] = entry.forms.delete($cache.pkmn[entry.species, 0].name)
      entry.forms.keys[0...-1].each { |formName| entry.forms[formName] = entry.forms.delete(formName) }
    end
    convert(:PUMPKABOO, :GOURGEIST) do |entry|
      next if entry.forms["Jumbo Variety"] # converted
      entry.forms["Jumbo Variety"] = entry.forms.delete("Normal Form")
      entry.forms["Small Variety"] = entry.forms.delete("Small")
    end

    if checkVersionOlderThan("7.0.0-alpha.0")
      convertGenderFormMons(allpokemon)
    end
  end

  $Trainer.pokedex.refreshDex(true) if $Trainer.pokedex.storedGen != Gen || $Trainer.pokedex[:BULBASAUR][0][:gender].is_a?(Array)
end

def checkVersionOlderThan(version)
  require 'rubygems'

  return false if GAME_VERSION == "dev"
  return false if $game_system.game_version == "dev"
  # If you're running an ancient version that isn't dev, aka Reborn e19 or other
  return true if $game_system.game_version.is_a?(String) && $game_system.game_version.downcase.match?(/[^0-9\.]/)
  # currentVersion = Gem::Version.new(GAME_VERSION)
  checkVersion = Gem::Version.new(version)
  saveVersion = Gem::Version.new($game_system.game_version)

  return saveVersion < checkVersion
end

def wrap_path(path, max_length = 40)
  wrapped = ""

  while path.length > max_length
    last_slash = path.rindex('/', max_length)
    break if last_slash.nil?

    wrapped += path[0..last_slash] + "\n"
    path = path[(last_slash + 1)..]
  end

  wrapped + path
end

def convert(*speciesList)
  for species in speciesList
    entry = $Trainer.pokedex.dexList[species]
    next unless entry # Species not in dexList (Reborn Gen8+ Pokemon in Gen 7)
    yield(entry)
  end
end

def convertGenderFormMons(mons)
  mons.each { |pokemon|
    if [:MEOWSTIC, :INDEEDEE, :BASCULEGION, :OINKOLOGNE].include?(pokemon.species)
      form = pokemon.form
      pokemon.form = 0
      pokemon.genderflag = [:M, :F][form % 2] # modulo to ensure form is bound to gender index
      pokemon.calcStats
    end
  }
end

def forceLoadMapConditions?(mapid = nil)
  if Rejuv
    return true if $game_variables[810] <= 55 && mapid == 629
  end
  return false
end
