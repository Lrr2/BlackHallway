module PBDebug
  def PBDebug.logonerr
    begin
      yield
    rescue
      PBDebug.close # close log file before crashing (also transfers any leftover logs from buffer to file)
      logError($!, display: true)
    end
  end

  @@foldername = RTP.getSaveFolder + "Battle Debug Logs/" # debug battle logs
  @@foldername2 = RTP.getSaveFolder + "Battle Logs/" # non-debug battle logs
  @@logfile = nil # debug battle logs
  @@logfile2 = nil # non-debug battle logs
  @@filename = ""
  @@logstring = "" # stores non-debug battle log text till it's written in the file (debug battle log text is written immediately without any storage)
  @@maxlogs = Rejuv ? 1000 : 5 # for debug battle logs only

  def PBDebug.foldername
    return @@foldername
  end

  def PBDebug.filename
    return @@filename
  end

  def PBDebug.setup(filename, battleseed)
    PBDebug.reset
    return if !$INTERNAL || filename.nil? # Wild battles pass filename as nil

    PBDebug.open(filename) # opens log file, which is left open till end of battle (this is to avoid inefficiency with opening and closing the file again and again)

    PBDebug.log("#{GAME_TITLE} #{GAME_VERSION} - #{filename}")
    PBDebug.log(_INTL("Battle seed: {1}", battleseed) + "\n")
  end

  def PBDebug.open(filename)
    @@filename = "#{filename}.txt"

    Dir.mkdir(@@foldername) unless File.exist?(@@foldername)
    i = 1
    Dir.glob("#{@@foldername.gsub('\\', '/')}*.txt").grep(/\/\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2} - /).sort { |a, b|
      File.mtime(b) <=> File.mtime(a)
    }.each do |file|
      i += 1
      next unless i > @@maxlogs
      # The file may still be opened by another instance of the game.
      begin
        File.delete(file)
      rescue Errno::EACCES => e
        puts "Permission denied: #{e.message}"
      end
    end
    @@logfile = File.open(@@foldername + @@filename, "a+b")

    if $Settings.exportBattleLogs == 2
      Dir.mkdir(@@foldername2) unless File.exist?(@@foldername2)
      @@logfile2 = File.open(@@foldername2 + @@filename, "a+b")
    end
  end

  def PBDebug.log(msg, debugonly: false)
    return unless @@logfile

    msg += "\n"
    @@logfile.write(msg)
    return if debugonly

    @@logfile2 ? @@logfile2.write(msg) : @@logstring += msg
  end

  def PBDebug.dblog(msg)
    PBDebug.log(msg, debugonly: true)
  end

  def PBDebug.flush
    return unless @@logfile

    @@logfile.flush
    @@logfile2.flush if @@logfile2
  end

  def PBDebug.close(endofbattle: false)
    return unless @@logfile

    if $Settings.exportBattleLogs == 1 && endofbattle
      Dir.mkdir(@@foldername2) unless File.exist?(@@foldername2)
      File.open(@@foldername2 + @@filename, "w") { |f| f.write(@@logstring) }
      @@logstring = ""
    end
    PBDebug.flush
    PBDebug.reset
  end

  def PBDebug.reset
    @@logfile.close if @@logfile
    @@logfile2.close if @@logfile2
    @@logfile = nil
    @@logfile2 = nil
    @@filename = ""
  end
end
