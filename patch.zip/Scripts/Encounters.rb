module EncounterTypes
  Land         = 0
  Cave         = 1
  Water        = 2
  RockSmash    = 3
  OldRod       = 4
  GoodRod      = 5
  SuperRod     = 6
  Headbutt     = 7
  LandMorning  = 8
  LandDay      = 9
  LandNight    = 10
  BugContest   = 11
  Lava         = 12
  Names = [
    "Land",
    "Cave",
    "Water",
    "RockSmash",
    "OldRod",
    "GoodRod",
    "SuperRod",
    "Headbutt",
    "LandMorning",
    "LandDay",
    "LandNight",
    "BugContest",
    "Lava"
  ]
  EnctypeChances = [
    [20, 15, 12, 10, 10, 10, 5, 5, 5, 4, 2, 2],
    [20, 15, 12, 10, 10, 10, 5, 5, 5, 4, 2, 2],
    [50, 25, 15, 7, 3],
    [50, 25, 15, 7, 3],
    [70, 30],
    [60, 20, 20],
    [40, 35, 15, 7, 3],
    [30, 25, 20, 10, 5, 5, 4, 1],
    [20, 15, 12, 10, 10, 10, 5, 5, 5, 4, 2, 2],
    [20, 15, 12, 10, 10, 10, 5, 5, 5, 4, 2, 2],
    [20, 15, 12, 10, 10, 10, 5, 5, 5, 4, 2, 2],
    [20, 15, 12, 10, 10, 10, 5, 5, 5, 4, 2, 2],
    [50, 25, 15, 7, 3],
  ]
  EnctypeDensities = [25, 10, 10, 0, 0, 0, 0, 0, 0, 25, 25, 25, 25]
  EnctypeCompileDens = [1, 2, 3, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1]
end

class PokemonEncounters
  def initialize
    @enctypes = []
    @density = nil
  end

  def stepcount
    return @stepcount
  end

  def clearStepCount
    @stepcount = 0
  end

  def hasEncounter?(enc)
    return false if @density == nil || enc < 0

    return @enctypes[enc] ? true : false
  end

  def isCave?
    return false if @density == nil

    return @enctypes[EncounterTypes::Cave] ? true : false
  end

  def isGrass?
    return false if @density == nil

    return (@enctypes[EncounterTypes::Land] ||
            @enctypes[EncounterTypes::LandMorning] ||
            @enctypes[EncounterTypes::LandDay] ||
            @enctypes[EncounterTypes::LandNight] ||
            @enctypes[EncounterTypes::BugContest]) ? true : false
  end

  def isRegularGrass?
    return false if @density == nil

    return (@enctypes[EncounterTypes::Land] ||
            @enctypes[EncounterTypes::LandMorning] ||
            @enctypes[EncounterTypes::LandDay] ||
            @enctypes[EncounterTypes::LandNight]) ? true : false
  end

  def isWater?
    return false if @density == nil

    return @enctypes[EncounterTypes::Water] ? true : false
  end

  def pbEncounterType
    if $PokemonGlobal&.surfing
      return EncounterTypes::Water
    elsif $PokemonGlobal&.lavasurfing
      return EncounterTypes::Lava
    elsif self.isCave?
      return EncounterTypes::Cave
    elsif self.isGrass?
      time = pbGetTimeNow
      enctype = EncounterTypes::Land
      enctype = EncounterTypes::LandNight if self.hasEncounter?(EncounterTypes::LandNight) && PBDayNight.isNight?(time)
      enctype = EncounterTypes::LandDay if self.hasEncounter?(EncounterTypes::LandDay) && PBDayNight.isDay?(time)
      enctype = EncounterTypes::LandMorning if self.hasEncounter?(EncounterTypes::LandMorning) && PBDayNight.isMorning?(time)
      return enctype
    end

    return -1
  end

  def isEncounterPossibleHere?
    currentTag = pbGetTerrainTag($game_player)
    if currentTag == PBTerrain::Waterfall || currentTag == PBTerrain::WaterfallCrest
      return false
    elsif $PokemonGlobal&.surfing
      return true
    elsif $PokemonGlobal&.lavasurfing
      return true
    elsif currentTag == PBTerrain::Ice
      return false
    elsif self.isCave?
      return true
    elsif self.isGrass?
      return pbIsGrassTag?(currentTag)
    end

    return false
  end

  def setup(mapID)
    mapdata = $cache.mapdata[mapID]
    @density = nil
    @stepcount = 0
    @enctypes = []
    return unless mapdata
    begin
      landrate = (mapdata.landrate.nil? ? 0 : mapdata.landrate) * ($game_switches[:WildBattles] ? 0 : 1)
      waterrate = (mapdata.waterrate.nil? ? 0 : mapdata.waterrate) * ($game_switches[:WildBattles] ? 0 : 1)
      caverate = (mapdata.caverate.nil? ? 0 : mapdata.caverate) * ($game_switches[:WildBattles] ? 0 : 1)
      lavarate = (mapdata.lavarate.nil? ? 0 : mapdata.lavarate) * ($game_switches[:WildBattles] ? 0 : 1)
      @density = [
        landrate, caverate, waterrate, caverate, waterrate, waterrate, waterrate,
        landrate, landrate, landrate, landrate, landrate, lavarate
      ]
      @enctypes = [
        mapdata.Land,
        mapdata.Cave,
        mapdata.Water,
        mapdata.RockSmash,
        mapdata.OldRod,
        mapdata.GoodRod,
        mapdata.SuperRod,
        mapdata.Headbutt,
        mapdata.LandMorning,
        mapdata.LandDay,
        mapdata.LandNight,
        mapdata.BugContest,
        mapdata.Lava
      ]
    rescue
      @density = nil
      @enctypes = []
    end
  end

  def pbDetermineForm(form)
    return 0 if form.nil?
    return form if form.is_a?(Integer)
    form = form.to_a if form.is_a?(Range)
    if form.is_a?(Array) && $Trainer.party[0].item == :MIRRORLURE
     form = form.select {|monform| monform == $Trainer.party[0].form}
     return form[0]
    end
    return form.sample if form.is_a?(Array)
    if form == :Time
      return 2 if PBDayNight.isDusk?(pbGetTimeNow)
      return 1 if PBDayNight.isNight?(pbGetTimeNow)
      return 0
    end
    if form == :Season
      return (pbGetTimeNow.month - 1) % 4
    end
    if form == :Cloak
      field = determineFieldLayers[-1]
      return 2 if $cache.FEData[field].burmyCloak == :TRASHCLOAK
      return 0 if $cache.FEData[field].burmyCloak == :PLANTCLOAK
      return 1 if $cache.FEData[field].burmyCloak == :SANDYCLOAK
      return 1 if [:Sand, :Rock, :Cave].include?(pbGetEnvironment) # Sandy Cloak
      return 2 if $cache.mapdata[$game_map.map_id].Outdoor # Trash Cloak
      return 0 # Plant Cloak
    end
    raise "unknown form #{form.inspect}"
  end

  def pbEncounteredPokemon(enctype, tries = 1)
    if enctype < 0 || enctype > EncounterTypes::EnctypeChances.length
      raise ArgumentError.new(_INTL("Encounter type out of range"))
    end
    return nil if @enctypes[enctype] == nil
    encounters = []
    chances    = []
    @enctypes[enctype].each do |key, x|
      x.each { |y|
        encounters.push([key, y[1], y[2]])
        chances.push(y[0])
      }
    end
    # Should we force encountering uncaptured mons?
    forcedEncounter = pbForceEncounterUncapturedPkmn(encounters, chances)
    return forcedEncounter if forcedEncounter
    # Proceed with the normal mode instead
    user = fieldAbilityUser
    if !user.egg? && rand(2) == 0
      type = -1
      case user.ability
        when :STATIC, :LIGHTNINGROD then type = :ELECTRIC
        when :MAGNETPULL then type = :STEEL
        when :FLASHFIRE then type = :FIRE
        when :HARVEST then type = :GRASS
        when :STORMDRAIN then type = :WATER
      end
      if type != -1
        newencs = []; newchances = []
        for i in 0...encounters.length
          species = encounters[i][0]
          if species.is_a?(Array)
            form = pbDetermineForm(species[1])
            species = species[0]
          else
            form = 0
          end
          t1 = $cache.pkmn[species, form].Type1
          t2 = $cache.pkmn[species, form].Type2
          if t1 == type || t2 == type
            newencs.push(encounters[i])
            newchances.push(chances[i])
          end
        end
        if newencs.length > 0
          encounters = newencs
          chances    = newchances
        end
      end
    end
    chancetotal = 0
    chances.each { |a| chancetotal += a }
    rnd = 0
    tries.times do
      r = rand(chancetotal)
      rnd = r if rnd < r
    end
    chosenpkmn = 0
    chance = 0
    for i in 0...chances.length
      chance += chances[i]
      if rnd < chance
        chosenpkmn = i
        break
      end
    end
    encounter = encounters[chosenpkmn]
    return nil if !encounter

    level = pbGetEncounterLevel(encounter)
    species = encounter[0]
    if species.is_a?(Array)
      return [species[0], species[1], level]
    end
    return [species, nil, level]
  end

  def pbForceEncounterUncapturedPkmn(encounters, chances)
    return nil if !pbShouldFilterKnownPkmnFromEncounter? && !pbShouldFilterOtherPkmnFromEncounter?

    # return nil if !encounters
    # return nil if !chances
    if pbShouldFilterKnownPkmnFromEncounter?
      encounter = pbFilterKnownPkmnFromEncounter(chances, encounters)
    elsif pbShouldFilterOtherPkmnFromEncounter?
      encounter = pbFilterOtherPkmnFromEncounter(chances, encounters)
    end
    return nil if !encounter

    species = encounter[0]
    level = pbGetEncounterLevel(encounter)
    if species.is_a?(Array)
      return [species[0], species[1], level]
    end
    return [species, nil, level]
  end

  def pbFilterOtherPkmnFromEncounter(chances, encounters)
    uncaptured = []
    for i in 0...encounters.length
      # First, filter out the mons that have no chance of spawning
      # Just in case...
      next if !chances[i]
      next if chances[i] <= 0

      # Then filter out all captured mons
      enc = encounters[i]
      next if !enc

      species = enc[0]
      if species.is_a?(Array)
        if species[1].is_a?(Range)
          next if !(species[0] == $Trainer.party[0].species && species[1].include?($Trainer.party[0].form))
        else
          next if !(species[0] == $Trainer.party[0].species && species[1] == $Trainer.party[0].form)
        end
      else
        next if species != $Trainer.party[0].species
        next if $Trainer.party[0].form != 0
      end

      uncaptured.push(enc)
    end
    return nil if uncaptured.length <= 0

    randId = rand(uncaptured.length)
    return uncaptured[randId]
  end

  def pbGetEncounterLevel(encounter)
    # UPDATE 11/19/2013
    # pressure, hustle and vital spirit will now have a 150% chance of
    # finding higher leveled pokemon in encounters
    user = fieldAbilityUser
    if !user.egg? && [:PRESSURE, :HUSTLE, :VITALSPIRIT].include?(user.ability) && rand(2) == 0
      # increase the lower bound to half way in-between lower and upper
      encounter[1] += (encounter[2] - encounter[1]) / 2
    end
    # end of update
    level = encounter[1] + rand(1 + encounter[2] - encounter[1])
    return level
  end

  def pbFilterKnownPkmnFromEncounter(chances, encounters)
    uncaptured = []
    for i in 0...encounters.length
      # First, filter out the mons that have no chance of spawning
      # Just in case...
      next if !chances[i]
      next if chances[i] <= 0

      # Then filter out all captured mons
      enc = encounters[i]
      next if !enc

      species = enc[0].is_a?(Array) ? enc[0][0] : enc[0]
      encform = enc[0].is_a?(Array) ? enc[0][1] : 0
      encform = pbDetermineForm(encform) if encform.is_a?(Symbol)
      encforms = Array(encform) # Get array of possible forms by converting Integer/Range/Array to array
      next if $Trainer.pokedex.meaningful_owned?(species, encforms)

      uncaptured.push(enc)
    end
    return nil if uncaptured.length <= 0

    randId = rand(uncaptured.length)
    return uncaptured[randId]
  end

  def pbShouldFilterKnownPkmnFromEncounter?
    # Should also check for $Trainer.party[0].hp > 0 by logic, but then
    #  it wouldn't be in line with the other overworld party leader checks
    return false if $Trainer.party[0].egg?
    return true if $Trainer.party[0].item == :MAGNETICLURE

    return false
  end

  def pbShouldFilterOtherPkmnFromEncounter?
    # Should also check for $Trainer.party[0].hp > 0 by logic, but then
    #  it wouldn't be in line with the other overworld party leader checks
    return false if $Trainer.party[0].egg?
    return true if $Trainer.party[0].item == :MIRRORLURE

    return false
  end

  def pbCanEncounter?(encounter)
    return false if $game_system.encounter_disabled
    return false if !encounter || !$Trainer
    return false if $DEBUG && Input.press?(Input::CTRL)
    return true if defined?(pbPokeRadarOnShakingGrass) && pbPokeRadarOnShakingGrass
    return false if $PokemonGlobal.repel > 0 && $Trainer.ablePokemonCount > 0 && encounter[2] < $Trainer.ablePokemonParty[0].level
    return true
  end

  def pbGenerateEncounter(enctype)
    if enctype < 0 || enctype > EncounterTypes::EnctypeChances.length
      raise ArgumentError.new(_INTL("Encounter type out of range"))
    end
    return nil if @density == nil
    return nil if @density[enctype] == 0 || !@density[enctype]
    return nil if @enctypes[enctype] == nil

    @stepcount += 1
    return nil if @stepcount <= 10 && $game_variables[:EncounterRateModifier] <= 1 && !m2hell # Check three steps after battle ends
    return nil if @stepcount <= 2 && m2hell

    encount = $game_switches[:FirstUse] ? $game_variables[:EncounterRateModifier] : 1
    encount *= @density[enctype] * 16
    if $PokemonGlobal.bicycle
      encount *= 0.8
    end
    if $PokemonMap.blackFluteUsed
      encount /= 2
    end
    if $PokemonMap.whiteFluteUsed
      encount *= 1.5
    end
    encount = 0 if $game_switches[:No_Encounters]
    if $Trainer.party.length > 0
      user = fieldAbilityUser
      unless user.isEgg?
        case user.ability
          when :STENCH, :WHITESMOKE, :QUICKFEET, :INFILTRATOR then encount /= 2
          when :SNOWCLOAK then encount /= 2 if [:Snow, :Hail, :Blizzard].include?($game_screen.weather_type)
          when :SANDVEIL then encount /= 2 if $game_screen.weather_type == :Sandstorm
          when :SWARM then encount *= 1.5 # custom effect
          when :ILLUMINATE, :ARENATRAP, :NOGUARD then encount *= 2
          else
            # Item doesn't stack with ability
            encount *= 2.0 / 3 if [:CLEANSETAG, :PUREINCENSE].include?(user.item)
        end
      end
    end
    if Rejuv
      if m2hell
        encount = 10000000000000000000
      end
    end
    return nil if rand(250 * 16) >= encount
    encpoke = pbEncounteredPokemon(enctype)
    if $Trainer.party.length > 0
      user = fieldAbilityUser
      if !user.isEgg? && encpoke &&
         [:INTIMIDATE, :KEENEYE].include?(user.ability) &&
         encpoke[2] <= user.level - 5 && rand(2) == 0
        encpoke = nil
      end
    end
    return encpoke
  end
end

def getRelevantEncounterMaps(regions)
  maps = []
  for mapid in 1...$cache.mapdata.length
    next if $cache.mapinfos[mapid].nil? || $cache.mapdata[mapid].nil?
    next if $cache.mapinfos[mapid].name.start_with?("REMOVED")
    next unless $PokemonGlobal.visitedMaps[mapid]
    next if $cache.mapdata[mapid].Switches&.any? { |switch, value| $game_switches[switch] != value }
    next if $cache.mapdata[mapid].Variables&.any? { |variable, values| !values.include?($game_variables[variable]) }

    mappos = $cache.mapdata[mapid].MapPosition
    mapregion = mappos ? mappos[0] : 0
    next unless regions.include?(mapregion)

    maps.push(mapid)
  end
  return maps
end

class Window_EncounterDetails < Window_CommandPokemonWhiteArrow
  # Disables scrolling with Q/W because those are used to change Pokemon in Pokedex
  def update
    super(false)
  end

  def tts_cur_item(*args)
    super
    text = @commands[self.index]
    ttsEncTypeIconsInText(text)
  end
end

def encounterDetailsWindow(encounters, viewport, x, y, width, height, selectedmap: nil)
  # Can't change the 'encounters' array in-place
  commands = encounters.uniq { |mapid, mapname, enctype, encchance|
    [mapname, enctype, encchance]
  }

  commands.sort_by! { |mapid, mapname, enctype, encchance|
    enctypeorder = [:LandMorning, :LandDay, :LandNight, :Land]
    [mapname, enctypeorder.index(enctype) || -1, encchance]
  }

  defaultIndex = selectedmap.nil? ? 0 : (commands.find_index{ |mapid, mapname, enctype, encchance| mapid == selectedmap } || 0)

  commands.map! { |mapid, mapname, enctype, encchance|
    next encTypeIcon(enctype, mapid) + " " + encchance.to_s.rjust(3, "\u2007") + "%" + " " + "\u2007" + mapname
  }

  window = Window_EncounterDetails.newWithSize(commands, x, y, width, height, viewport, defaultIndex: defaultIndex)
  return window
end

def encTypeIcon(enctype, mapid)
  name = enctype.to_s
  name += "Underwater" if $cache.mapdata[mapid].BattleBack == "Underwater" && [:Land, :LandMorning, :LandDay, :LandNight, :Cave].include?(enctype)
  return "<icon=Encounters/#{name}>"
end

def ttsEncTypeIconsInText(text)
  icons = text.scan(/<icon=Encounters\/([^>]+)>/)
  names = icons.flatten.map! { |icon| {
    "Land"           => _INTL("Grass"),
    "LandMorning"    => _INTL("Grass Morning"),
    "LandDay"        => _INTL("Grass Day"),
    "LandNight"      => _INTL("Grass Night"),
    "LandUnderwater" => _INTL("Grass Underwater"),
    "Cave"           => _INTL("Open Area"),
    "CaveUnderwater" => _INTL("Open Area Underwater"),
    "RockSmash"      => _INTL("Rock Smash"),
    "Headbutt"       => _INTL("Headbutt"),
    "OldRod"         => _INTL("Old Rod"),
    "GoodRod"        => _INTL("Good Rod"),
    "SuperRod"       => _INTL("Super Rod"),
    "Water"          => _INTL("Water Surface"),
    "Lava"           => _INTL("Lava Surface"),
  }[icon] }
  tts(names.join(" "))
end
