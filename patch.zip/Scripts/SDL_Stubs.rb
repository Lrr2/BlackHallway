raise "Don't load this file, it only exists for IDEs to not report false positive errors"

class Rect
  def initialize(x, y, width, height)
  end
end

class Color
  def initialize(red, green, blue, alpha)
  end
end

class Bitmap
  def initialize(fileOrWidth, height = nil)
  end
end
