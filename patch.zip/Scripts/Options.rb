class Window_PokemonOption < Window_DrawableCommand
  attr_reader :mustUpdateOptions
  attr_accessor :options

  NAME_COLOR = :Orange2
  SEL_COLOR = :Red2
  BACK_COLOR = :Gray2
  HEAD_COLOR = :ShardBlue

  def initialize(options, x, y, width, height)
    @options = options
    @optvalues = []
    @mustUpdateOptions = false
    for i in 0...@options.length
      @optvalues[i] = 0
    end
    super(x, y, width, height)
  end

  def [](i)
    return @optvalues[i]
  end

  def []=(i, value)
    @optvalues[i] = value
    refresh
  end

  def itemCount
    return @options.length
  end

  def atSectionHeader?
    return @options[self.index].is_a?(String) && self.index != @options.length - 1
  end

  def drawItem(index, count, rect)
    colorarrays = isDarkWindowskin(self.windowskin) ? ColorArrays : LightColorArrays
    rect = drawCursor(index, rect)
    if @options[index].is_a?(String) # Headers and 'Back'
      colors = index == @options.length - 1 ? colorarrays[BACK_COLOR] : colorarrays[HEAD_COLOR]
      optionname = @options[index]
      startX = rect.x
      optionwidth = Graphics.width
    else
      colors = colorarrays[NAME_COLOR]
      optionname = @options[index].name
      offset = 8
      startX = rect.x + offset
      optionwidth = ((rect.width - offset) * 9.5 / 20)
    end
    pbDrawShadowText(self.contents, startX, rect.y, optionwidth, rect.height, optionname, *colors)
    self.contents.draw_text(startX, rect.y, optionwidth, rect.height, optionname)
    return if @options[index].is_a?(String)

    sel_colors = colorarrays[SEL_COLOR]
    if @options[index].is_a?(EnumOption)
      if @options[index].values.length > 1
        totalwidth = 0
        for value in @options[index].values
          totalwidth += self.contents.text_size(value).width
        end
        spacing = (optionwidth - totalwidth) / (@options[index].values.length - 1)
        spacing = 0 if spacing < 0
        xpos = optionwidth + startX
        ivalue = 0
        for value in @options[index].values
          colors = ivalue == self[index] ? sel_colors : [self.baseColor, self.shadowColor]
          pbDrawShadowText(self.contents, xpos, rect.y, optionwidth, rect.height, value, *colors)
          self.contents.draw_text(xpos, rect.y, optionwidth, rect.height, value)
          xpos += self.contents.text_size(value).width
          xpos += spacing
          ivalue += 1
        end
      else
        colors = [self.baseColor, self.shadowColor]
        pbDrawShadowText(self.contents, startX + optionwidth, rect.y, optionwidth, rect.height, optionname, *colors)
      end
    elsif @options[index].is_a?(NumberOption)
      value = @options[index].format.call(@options[index].optstart + self[index])
      xpos = optionwidth + startX
      pbDrawShadowText(self.contents, xpos, rect.y, optionwidth, rect.height, value, *sel_colors)
    else
      value = @options[index].values[self[index]]
      xpos = optionwidth + startX
      pbDrawShadowText(self.contents, xpos, rect.y, optionwidth, rect.height, value, *sel_colors)
      self.contents.draw_text(xpos, rect.y, optionwidth, rect.height, value)
    end
  end

  def update
    oldindex = self.index

    if Input.repeat?(Input::DOWN)
      self.index += 1
      self.index += 1 while atSectionHeader?
      self.index = 0 if self.index > @options.length - 1
      self.index += 1 while atSectionHeader?
    elsif Input.repeat?(Input::UP)
      self.index -= 1
      self.index -= 1 while atSectionHeader?
      self.index = @options.length - 1 if self.index < 0
      self.index -= 1 while atSectionHeader?
    elsif Input.repeat?(Input::R)
      self.index += 8 # page size
      self.index -= 1 while atSectionHeader? || self.index > @options.length - 1
    elsif Input.repeat?(Input::L)
      self.index -= 8 # page size
      self.index += 1 while atSectionHeader? || self.index < 0
    end

    dorefresh = self.index != oldindex

    if self.active && !@options[self.index].is_a?(String)
      if Input.repeat?(Input::LEFT) || Input.repeat?(Input::RIGHT)
        oldvalue = @options[self.index].get
        self[self.index] = Input.repeat?(Input::LEFT) ?
          @options[self.index].prev(self[self.index]) :
          @options[self.index].next(self[self.index])
        newvalue = @options[self.index].get
        dorefresh = true if oldvalue != newvalue
      end
    end

    @mustUpdateOptions = dorefresh
    if dorefresh
      pbPlayCursorSE()
      refresh
    end
  end
end

module PropertyMixin
  def get
    @getProc ? @getProc.call() : nil
  end

  def set(value)
    @setProc.call(value) if @setProc
  end
end

class EnumOption
  include PropertyMixin
  attr_reader :values
  attr_reader :name
  attr_reader :description

  def initialize(name, options, getProc, setProc, description = "")
    @values = options
    @name = name
    @getProc = getProc
    @setProc = setProc
    @description = description
  end

  def next(current)
    index = current + 1
    index = @values.length - 1 if index > @values.length - 1
    tts(@values[index], true)
    self.set(index)
    return index
  end

  def prev(current)
    index = current - 1
    index = 0 if index < 0
    tts(@values[index], true)
    self.set(index)
    return index
  end

  def current(index)
    tts(@values[index])
  end
end

class NumberOption
  include PropertyMixin
  attr_reader :name
  attr_reader :format
  attr_reader :optstart
  attr_reader :optinc
  attr_reader :description

  def initialize(name, format, optstart, optend, optinc, getProc, setProc, description = "")
    @name = name
    @format = format
    @optstart = optstart
    @optend = optend
    @optinc = optinc
    @getProc = getProc
    @setProc = setProc
    @description = description
  end

  def next(current)
    index = current + @optstart
    index += @optinc
    if index > @optend
      index = @optstart
    end
    tts(index.to_s, true)
    self.set(index - @optstart)
    return index - @optstart
  end

  def prev(current)
    index = current + @optstart
    index -= @optinc
    if index < @optstart
      index = @optend
    end
    tts(index.to_s, true)
    self.set(index - @optstart)
    return index - @optstart
  end

  def current(index)
    tts((index + @optstart).to_s)
  end
end

def pbSettingToTextSpeed(speed)
  return 2 if speed == 0
  return 1 if speed == 1
  return -2 if speed == 2
  return MessageConfig::TextSpeed if MessageConfig::TextSpeed

  return Graphics.frame_rate > 40 ? -2 : 1
end

module MessageConfig
  def self.pbDefaultSystemFrame
    return pbResolveBitmap(TextFrames[$Settings.frame]) || ""
  end

  def self.pbDefaultSpeechFrame
    return pbResolveBitmap("Graphics/Windowskins/" + SpeechFrames[$Settings.textskin]) || ""
  end

  def self.pbDefaultSystemFontName
    return MessageConfig.pbTryFonts(VersionStyles[0][0], "Arial Narrow", "Arial")
  end

  def self.pbDefaultTextSpeed
    return pbSettingToTextSpeed($Settings.textspeed)
  end

  def pbGetSystemTextSpeed
    return $Settings.textspeed
  end
end

class PokemonOptions
  attr_accessor :textspeed
  attr_accessor :textskipwait
  attr_accessor :volume
  attr_accessor :bgsvolume
  attr_accessor :sevolume
  attr_accessor :bagsorttype
  attr_accessor :battlescene
  attr_accessor :battlestyle
  attr_accessor :nicknames
  attr_accessor :frame
  attr_accessor :textskin
  attr_accessor :font
  attr_accessor :screensize
  attr_accessor :language
  attr_accessor :border
  attr_accessor :backup
  attr_accessor :maxBackup
  attr_accessor :field_effects_highlights
  attr_accessor :remember_commands
  attr_accessor :photosensitive
  attr_accessor :autosave
  attr_accessor :autorunning
  attr_accessor :bike_and_surf_music
  attr_accessor :streamermode
  attr_accessor :unrealTimeDiverge
  attr_accessor :unrealTimeClock
  attr_accessor :unrealTimeTimeScale
  attr_accessor :audiotype
  attr_accessor :turboSpeedMultiplier
  attr_accessor :discordRPC
  attr_accessor :frameskip
  attr_accessor :keyboard
  attr_accessor :performanceMode
  attr_accessor :dynamicTextbox
  attr_accessor :updatePrompts
  attr_accessor :exportBattleLogs
  attr_accessor :fullAutoHeal

  def initialize
    fixMissingValues
  end

  def fixMissingValues
    @textspeed      = 1 if @textspeed.nil? # Text speed (0=slow, 1=mid, 2=fast)
    @textskipwait   = 0 if @textskipwait.nil? # Wait for text skip (0 is on, 1 is off)
    @volume              = 100 if @volume.nil? # Volume (0 - 100)
    @bgsvolume           = 100 if @bgsvolume.nil? # Volume (0 - 100)
    @sevolume            = 100 if @sevolume.nil? # Volume (0 - 100)
    @audiotype   = 0 if @audiotype.nil? # Stereo / Mono audio (0 / 1)
    @battlescene = 0 if @battlescene.nil? # Battle scene (animations) (0=on, 1=off)
    @battlestyle = 0 if @battlestyle.nil? # Battle style (0=shift, 1=set)
    @nicknames   = 0 if @nicknames.nil? # Give nicknames (0=on, 1=off)
    @frame       = 0 if @frame.nil? # Default window frame (see also TextFrames)
    @textskin    = 0 if @textskin.nil? # Speech frame
    @font        = 0 if @font.nil? # Font (see also VersionStyles)
    @screensize  = DEFAULTSCREENZOOM.floor.to_i if @screensize.nil? # 0=half size, 1=full size, 2=double size
    @border      = 0 if @border.nil? # Screen border (0=off, 1=on)
    @language    = 0 if @language.nil? # Language (changed from load screen rather than options menu)
    @backup      = 0 if @backup.nil? # Backup on/off
    @maxBackup   = 50 if @maxBackup.nil?
    @field_effects_highlights = 0 if @field_effects_highlights.nil? # Field effect UI highlights on/off
    @remember_commands        = 0 if @remember_commands.nil?
    @photosensitive           = 0 if @photosensitive.nil? # a mode that disables flashes and shakes (0=off, 1=on)
    @autorunning              = 0 if @autorunning.nil? # 0 is on, 1 is off
    @bike_and_surf_music      = 0 if @bike_and_surf_music.nil? # 0 is off, 1 is on
    @streamermode             = 0 if @streamermode.nil?
    @unrealTimeDiverge        = 1 if @unrealTimeDiverge.nil? # Unreal Time (0=off, 1=on)
    @unrealTimeClock          = 1 if @unrealTimeClock.nil? # Unreal Time Clock (0=always, 1=pause menu, 2=pokegear only)
    @unrealTimeClock          = 1 if Reborn && @unrealTimeClock != 1 # 1 = pause menu, Reborn has a custom clock that is always displayed in pause menu
    @unrealTimeTimeScale      = 30 if @unrealTimeTimeScale.nil? # Unreal Time Timescale (default 30x real time)
    @turboSpeedMultiplier     = 3.0 if @turboSpeedMultiplier.nil? # Game speed multiplier in turbo mode
    @discordRPC               = 1 if @discordRPC.nil? # Controls Discord rich presence updates (0=off, 1=on)
    @frameskip                = 0 if @frameskip.nil? # mkxp-z frameskip feature (0=off, 1=on)
    @keyboard                 = 0 if @keyboard.nil? # 0 is on, 1 is off
    @performanceMode          = 1 if @performanceMode.nil? # 0 is on, 1 is off
    @dynamicTextbox           = 0 if @dynamicTextbox.nil? # textbox height adjusts to text (0=off, 1=on)
    @updatePrompts            = 0 if @updatePrompts.nil? # 0 is on, 1 is off
    @exportBattleLogs         = 0 if @exportBattleLogs.nil? # 0 = off, 1 = finished battles, 2 = all battles
    @fullAutoHeal             = 0 if @fullAutoHeal.nil? # 0 is party, 1 is pokemon
  end

  def useKeyboard?
    return $Settings.keyboard == 0
  end
end

class PokemonOptionScene
  def initOptions
    optionList = []

    # Gameplay
    optionList.push _INTL("Gameplay")
    optionList.push EnumOption.new(
      _INTL("Autorunning"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.autorunning },
      proc { |value| $Settings.autorunning = value },
      _INTL("Choose to have your character run automatically.")
    )
    optionList.push EnumOption.new(
      _INTL("Text Speed"), [_INTL("Normal"), _INTL("Fast"), _INTL("Max")],
      proc { $Settings.textspeed },
      proc { |value|
        $Settings.textspeed = value
        MessageConfig.pbSetTextSpeed(pbSettingToTextSpeed(value))
      },
      _INTL("Choose from three different text speeds.")
    )
    optionList.push EnumOption.new(
      _INTL("Text Skip Wait"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.textskipwait },
      proc { |value| $Settings.textskipwait = value },
      _INTL("Enables a delay before text skipping begins.")
    )
    optionList.push EnumOption.new(
      _INTL("Dynamic Textbox"), [_INTL("Off"), _INTL("On")],
      proc { $Settings.dynamicTextbox },
      proc { |value| $Settings.dynamicTextbox = value },
      _INTL("Adjusts dialogue box height according to the text.")
    )
    optionList.push EnumOption.new(
      _INTL("Use Keyboard"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.keyboard },
      proc { |value| $Settings.keyboard = value },
      _INTL("Choose whether to use the device's built-in keyboard for entering text.")
    )
    optionList.push EnumOption.new(
      _INTL("Give Nicknames"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.nicknames },
      proc { |value| $Settings.nicknames = value },
      _INTL("Choose whether to be prompted to give a nickname to a Pokémon when you obtain it.")
    )
    optionList.push EnumOption.new(
      _INTL("Photosensitivity"), [_INTL("Off"), _INTL("On")],
      proc { $Settings.photosensitive },
      proc { |value|
        valuebefore = $Settings.photosensitive
        $Settings.photosensitive = value
        if value != valuebefore && value == 1 && $Settings.battlescene == 0 # Photosensitivity turned On while battle animations are On
          Kernel.pbMessage(_INTL("Please note that flashes and shakes are also used by certain battle animations.\nConsider disabling them under Battle Options according to your requirements."))
        end
      },
      _INTL("Disables screen flashes and shakes for photosensitivity.")
    )
    optionList.push EnumOption.new(
      _INTL("Auto-Heal Mode"), [_INTL("Party"), _INTL("Pokémon")],
      proc { $Settings.fullAutoHeal },
      proc { |value| $Settings.fullAutoHeal = value },
      _INTL("Choose whether auto-healing should apply to the whole party or to the currently| selected Pokémon only.")
    )

    # Battle
    optionList.push _INTL("Battle")
    optionList.push EnumOption.new(
      _INTL("Battle Animations"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.battlescene },
      proc { |value|
        valuebefore = $Settings.battlescene
        $Settings.battlescene = value
        if value != valuebefore && value == 0 && $Settings.photosensitive == 1 # Battle animations turned On while photosensitivity is On
          Kernel.pbMessage(_INTL("Please note that certain battle animations also use flashes and shakes.\nConsider disabling them according to your photosensitivity requirements."))
        end
      },
      _INTL("Show animations during battle.")
    )
    optionList.push EnumOption.new(
      _INTL("Field UI Highlights"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.field_effects_highlights },
      proc { |value| $Settings.field_effects_highlights = value },
      _INTL("Shows boxes around moves in battle if boosted or nerfed by the field effect.")
    )
    optionList.push EnumOption.new(
      _INTL("Battle Cursor"), [_INTL("Fight"), _INTL("Last Used")],
      proc { $Settings.remember_commands },
      proc { |value| $Settings.remember_commands = value },
      _INTL("Sets the default position of the battle command menu cursor.")
    )
    optionList.push EnumOption.new(
      _INTL("Export Battle Logs"), [_INTL("Off"), _INTL("Finished"), _INTL("All")],
      proc { $Settings.exportBattleLogs },
      proc { |value| $Settings.exportBattleLogs = value },
      proc { next [
        _INTL("Don't export battle logs."),
        _INTL("Export battle logs to the save directory for battles that get finished."),
        _INTL("Export battle logs to the save directory for all battles, including reset ones."),
      ][$Settings.exportBattleLogs] }
    )

    # Audio
    optionList.push _INTL("Audio")
    optionList.push NumberOption.new(
      _INTL("BGM Volume"), proc { |value| _ISPRINTF("{1:d}", value) }, 0, 100, 1,
      proc { $Settings.volume },
      proc { |value|
        $Settings.volume = value
        if $game_map && $game_system.playing_bgm
          bgm_new_volume = $game_system.playing_bgm
          bgm_new_volume.volume = $Settings.volume
          $game_system.bgm_play_internal(bgm_new_volume, $game_system.bgm_position)
        end
      },
      _INTL("Volume of Background Music.")
    )
    optionList.push NumberOption.new(
      _INTL("SE Volume"), proc { |value| _ISPRINTF("{1:d}", value) }, 0, 100, 1,
      proc { $Settings.sevolume },
      proc { |value| $Settings.sevolume = value },
      _INTL("Volume of Sound Effects.")
    )
    optionList.push NumberOption.new(
      _INTL("BGS Volume"), proc { |value| _ISPRINTF("{1:d}", value) }, 0, 100, 1,
      proc { $Settings.bgsvolume },
      proc { |value|
        $Settings.bgsvolume = value
        if $game_map && $game_system.playing_bgs
          bgs_new_volume = $game_system.playing_bgs
          bgs_new_volume.volume = $Settings.bgsvolume
          $game_system.bgs_play(bgs_new_volume)
        end
      },
      _INTL("Volume of Background Sounds such as weather sounds.")
    )
    optionList.push EnumOption.new(
      _INTL("Sound"), [_INTL("Stereo"), _INTL("Mono")],
      proc { $Settings.audiotype },
      proc { |value| $Settings.audiotype = value },
      _INTL("Choose whether audio may be different in both ears or the same.")
    )
    optionList.push EnumOption.new(
      _INTL("Bike and Surf Music"), [_INTL("Off"), _INTL("On")],
      proc { $Settings.bike_and_surf_music },
      proc { |value| $Settings.bike_and_surf_music = value },
      _INTL("Enables bike and surf music to play.")
    )

    # Speed and Performance
    optionList.push _INTL("Speed and Performance")
    unless $joiplay
      optionList.push EnumOption.new(
        _INTL("Frame Skip"), [_INTL("Off"), _INTL("On")],
        proc { $Settings.frameskip },
        proc { |value|
          $Settings.frameskip = value
          Graphics.frameskip = value == 1
        },
        _INTL("Allows Speed Up to go beyond refresh rate by skipping frames.")
      )
    end
    optionList.push NumberOption.new(
      _INTL("Speed Up Multiplier"), proc { |value| _ISPRINTF("{1:.1f}x", value) }, 1, 10, 0.1,
      proc { $Settings.turboSpeedMultiplier - 1 },
      proc { |value|
        $Settings.turboSpeedMultiplier = value + 1
        if $speed_up
          # Intentionally calling it twice to apply the change without toggling turbo
          Graphics.toggleTurbo
          Graphics.toggleTurbo
        end
      },
      _INTL("Game speed multiplier while in Turbo Mode. Higher values require Frame Skip to work.")
    )
    if $joiplay
      optionList.push EnumOption.new(
        _INTL("Performance Mode"), [_INTL("On"), _INTL("Off")],
        proc { $Settings.performanceMode },
        proc { |value| $Settings.performanceMode = value },
        _INTL("Disables animated tiles and day/night tint to prevent lag. Requires a reload to| take effect.")
      )
    end

    # Customization
    optionList.push _INTL("Customization")
    optionList.push NumberOption.new(
      _INTL("Speech Frame"), proc { |value| _ISPRINTF("{1:d}", value) }, 1, SpeechFrames.length, 1,
      proc { $Settings.textskin },
      proc { |value|
        $Settings.textskin = value
        MessageConfig.pbSetSpeechFrame(
          "Graphics/Windowskins/" + SpeechFrames[value]
        )
        # Update description window
        @sprites["textbox"].setSkin(MessageConfig.pbGetSpeechFrame())
        @sprites["textbox"].setDefaultTextColors
        @sprites["textbox"].width = @sprites["textbox"].width # Necessary evil
        pbSetSystemFont(@sprites["textbox"].contents)
      },
      proc { _INTL("Speech frame {1}.", 1 + $Settings.textskin) }
    )
    optionList.push NumberOption.new(
      _INTL("Menu Frame"), proc { |value| _ISPRINTF("{1:d}", value) }, 1, TextFrames.length, 1,
      proc { $Settings.frame },
      proc { |value|
        $Settings.frame = value
        MessageConfig.pbSetSystemFrame(TextFrames[value])
        # Update options window
        @sprites["option"].setSkin(MessageConfig.pbGetSystemFrame())
        @sprites["option"].setDefaultTextColors
      },
      proc { _INTL("Menu frame {1}.", 1 + $Settings.frame) }
    )
    unless $joiplay || $kirin
      # Limited by the clamp in mkxp-z Graphics::setScale() function. We can increase it there if we ever need to scale it up further.
      optionList.push NumberOption.new(
        _INTL("Screen Size"), proc { |value| value == 0.0 ? _INTL("Fullscreen") : _ISPRINTF("{1:.1f}x", value) }, 0.0, 4.0, 0.5,
        proc { $Settings.screensize },
        proc { |value|
          oldvalue = $Settings.screensize
          $Settings.screensize = value
          if value != oldvalue
            pbSetResizeFactor($Settings.screensize)
          end
        },
        _INTL("Choose the screen size.")
      )
      unless Desolation
        optionList.push EnumOption.new(
          _INTL("Screen Border"), [_INTL("Off"), _INTL("On")],
          proc { $Settings.border },
          proc { |value|
            oldvalue = $Settings.border
            $Settings.border = value
            if value != oldvalue
              pbSetResizeFactor($Settings.screensize)
            end
          },
          _INTL("Choose to show the screen border.")
        )
      end
    end

    # Saving
    optionList.push _INTL("Saving")
    optionList.push EnumOption.new(
      _INTL("Backup Saves"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.backup },
      proc { |value| $Settings.backup = value },
      _INTL("Preserves overwritten files in each save slot for later recovery.")
    )
    optionList.push NumberOption.new(
      _INTL("Max Backup Number"), proc { |value| _ISPRINTF("{1:d}", value) }, 1, 101, 1,
      proc { $Settings.maxBackup == 999_999 ? 100 : $Settings.maxBackup },
      proc { |value| $Settings.maxBackup = value == 100 ? 999_999 : value }, # +1
      _INTL("The maximum number of backup save files to keep per save slot. (101 is infinite)")
    )
    unless $joiplay || $kirin # JoiPlay and Kirin versions are always in Portable mode
      optionList.push EnumOption.new(
        _INTL("Portable Mode"), [_INTL("Off"), _INTL("On")],
        proc { RTP.isPortable ? 1 : 0 },
        proc { |value|
          value == 1 ? RTP.makePortable : RTP.makeNonPortable
        },
        _INTL("Keeps save data in the game EXE folder.")
      )
    end

    # Network
    optionList.push _INTL("Network")
    # options currently running every time the user accesses the options menu and does anything
    if defined?(DiscordAppID) && DiscordAppID && !$joiplay && !$kirin
      optionList.push EnumOption.new(
        _INTL("Discord Activity"), [_INTL("Off"), _INTL("On")],
        proc { $Settings.discordRPC },
        proc { |value| $Settings.discordRPC = value },
        _INTL("Controls Discord rich presence.\nIf On, shows game info on Discord.")
      )
    end
    optionList.push EnumOption.new(
      _INTL("Streamer Mode"), [_INTL("Off"), _INTL("On")],
      proc { $Settings.streamermode },
      proc { |value| $Settings.streamermode = value },
      _INTL("Hides private information for safety and compatibility.")
    )
    optionList.push EnumOption.new(
      _INTL("Update Prompts"), [_INTL("On"), _INTL("Off")],
      proc { $Settings.updatePrompts },
      proc { |value| $Settings.updatePrompts = value },
      _INTL("Choose whether to be prompted about version updates on startup.")
    )

    # Unreal Time
    if $game_switches && $game_switches[:Unreal_Time]
      optionList.push _INTL("Unreal Time")
      unless Reborn # Reborn has a custom clock that is always displayed in pause menu
        optionList.push EnumOption.new(
          _INTL("Show Clock"), [_INTL("Always"), _INTL("Menu")],
          proc { $Settings.unrealTimeClock },
          proc { |value| $Settings.unrealTimeClock = value },
          _INTL("Shows an in-game clock that displays the current time.")
        )
      end
      optionList.push EnumOption.new(
        _INTL("Unreal Time"), [_INTL("Off"), _INTL("On")],
        proc { $Settings.unrealTimeDiverge },
        proc { |value| $Settings.unrealTimeDiverge = value },
        _INTL("Uses in-game time instead of computer clock.")
      )
      optionList.push NumberOption.new(
        _INTL("Unreal Time Scale"), proc { |value| _ISPRINTF("{1:d}x", value) }, 1, 60, 1,
        proc { $Settings.unrealTimeTimeScale - 1 },
        proc { |value| $Settings.unrealTimeTimeScale = value + 1 },
        _INTL("Sets the rate at which unreal time passes.")
      )
    end

    optionList.push _INTL("Back")
    return optionList
  end

  def pbUpdate
    pbUpdateSpriteHash(@sprites)
  end

  def pbStartScene
    @optionList = initOptions
    @sprites = {}
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites["textbox"] = Kernel.pbCreateMessageWindow
    @sprites["textbox"].letterbyletter = false
    @sprites["textbox"].setDefaultTextColors
    # @sprites["textbox"].text=_INTL("Speech frame {1}.",1+$Settings.textskin)
    @sprites["option"] = Window_PokemonOption.new(
      @optionList, 0, 0, Graphics.width, Graphics.height - @sprites["textbox"].height
    )
    @sprites["option"].index += 1 while @sprites["option"].atSectionHeader?
    pbUpdateOptions
    @sprites["option"].viewport = @viewport
    @sprites["option"].visible = true
    # Get the values of each option
    for i in 0...@optionList.length
      @sprites["option"][i] = @optionList[i].is_a?(String) ? nil : @optionList[i].get
    end
    pbDeactivateWindows(@sprites)
    pbFadeInAndShow(@sprites) { pbUpdate }
  end

  def pbOptions
    pbActivateWindow(@sprites, "option") {
      loop do
        Graphics.update
        Input.update
        pbUpdate
        pbUpdateOptions if @sprites["option"].mustUpdateOptions
        if Input.trigger?(Input::C) && !@optionList[@sprites["option"].index].is_a?(String)
          desc = pbGetDesc
          if desc.include?("|")
            desc = "..." + desc.split("|")[1].lstrip
            Kernel.pbMessage(desc) # Show full desc
          end
        end
        if Input.trigger?(Input::B) || (Input.trigger?(Input::C) && @sprites["option"].index == @optionList.length - 1)
          saveClientData
          saveSettings

          if defined?(DiscordRPC) && !$joiplay && !$kirin
            if $Settings.discordRPC == 0
              DiscordRPC.end
            elsif $Settings.discordRPC == 1
              DiscordRPC.start
            end
          end

          break
        end
      end
    }
  end

  def pbUpdateOptions
    optindex = @sprites["option"].index
    opt = @optionList[optindex]
    name = opt.is_a?(String) ? opt : opt.name

    # Update desc
    desc = pbGetDesc
    desc = desc.split("|")[0] + "..." if desc.include?("|")
    @sprites["textbox"].text = desc # Show trimmed-to-fit desc

    return if name == @lastread

    # tts
    tts(name, true)
    opt.current(@sprites["option"][optindex]) unless opt.is_a?(String)
    tts(@sprites["textbox"].text)
    @lastread = name
  end

  def pbGetDesc
    optindex = @sprites["option"].index
    opt = @optionList[optindex]
    if opt.is_a?(String)
      return optindex == @optionList.length - 1 ? _INTL("Close the Options menu.") : ""
    end

    desc = opt.description
    desc = desc.call if desc.is_a?(Proc)
    return desc
  end

  def pbEndScene
    pbFadeOutAndHide(@sprites) { pbUpdate }
    Kernel.pbDisposeMessageWindow(@sprites["textbox"])
    pbDisposeSpriteHash(@sprites)
    pbRefreshSceneMap
    @viewport.dispose
  end
end

class PokemonOption
  def initialize(scene)
    @scene = scene
  end

  def pbStartScreen
    @scene.pbStartScene
    @scene.pbOptions
    @scene.pbEndScene
  end
end
