MAPCONNECTIONSHASH = {
  496 => { # REMOVED
    :connections => [
      [496, 0, 9, 495, 143, 0], # to Decompression Lab
    ],
  },
  498 => { # Darchlight Caves
    :connections => [
      [498, 60, 0, 501, 0, 9], # to REMOVED
    ],
  },
  374 => { # Hiyoshi Pass
    :connections => [
      [374, 0, 3, 407, 80, 0], # to Rejuvenation Co.
    ],
  },
  567 => { # REMOVED
    :connections => [
      [567, 0, 0, 566, 32, 0], # to REMOVED
    ],
  },
  562 => { # REMOVED
    :connections => [
      [562, 0, 0, 561, 0, 25], # to REMOVED
      [562, 66, 0, 567, 0, 25], # to REMOVED
      [562, 34, 0, 566, 0, 25], # to REMOVED
    ],
  },
  564 => { # Seaforge Edge
    :connections => [
      [564, 66, 0, 567, 0, 42], # to REMOVED
      [564, 0, 0, 562, 0, 17], # to REMOVED
    ],
  },
  595 => { # Evergreen Trench
    :connections => [
      [595, 0, 65, 594, 0, 0], # to Evergreen Trench
    ],
  },
  596 => { # Evergreen Trench
    :connections => [
      [596, 0, 0, 594, 60, 0], # to Evergreen Trench
      [596, 0, 0, 595, 60, 65], # to Evergreen Trench
    ],
  },
  597 => { # Evergreen Trench
    :connections => [
      [597, 0, 0, 595, 60, 15], # to Evergreen Trench
      [597, 0, 50, 596, 0, 0], # to Evergreen Trench
      [597, 0, 50, 594, 60, 0], # to Evergreen Trench
    ],
  },
  237 => { # Amberette Town
    :connections => [
      [237, 0, 45, 236, 0, 0], # to Route 3
    ],
  },
  234 => { # Kugearen City
    :connections => [
      [234, 0, 0, 236, 0, 66], # to Route 3
    ],
  },
  69 => { # Route 3
    :connections => [
      [69, 0, 0, 71, 0, -47], # to Route 3
    ],
  },
  67 => { # Route 3
    :connections => [
      [67, 0, 0, 69, 0, -34], # to Route 3
    ],
  },
  3 => { # Route 11
    :connections => [
      [3, 0, 0, 13, 76, 10], # to Akuwa Town
    ],
  },
  75 => { # Evergreen Island
    :connections => [
      [75, 0, 0, 13, 76, -55], # to Akuwa Town
      [75, 0, 0, 3, 0, -65], # to Route 11
      [75, 0, 0, 100, -60, -65], # to Route 11
      [75, 0, 0, 473, -60, -15], # to Route 11
    ],
  },
  100 => { # Route 11
    :connections => [
      [100, 0, 0, 3, 60, 0], # to Route 11
    ],
  },
  473 => { # Route 11
    :connections => [
      [473, 0, 0, 3, 60, -50], # to Route 11
      [473, 0, 0, 100, 0, -50], # to Route 11
    ],
  },
}
