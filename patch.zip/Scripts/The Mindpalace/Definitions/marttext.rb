# Refer to Mart.rb for documentation on syntax

MARTHASH = {
  :DEFAULT => {
    :Messages => {
      :welcome => "Welcome!\nHow may I serve you?",
      :goodbye => "Please come again!",
      :anything_else => "Is there anything else I can help you with?",
      :nothing_to_buy => "You've bought me out of that!",

      :no_money => "You don't have enough money.",
      :no_puppet => "You don't have enough Puppet Coins.",
      :no_coins => "You don't have enough Coins.",
      :no_ap => "You don't have enough AP.",
      :no_bp => "I'm afraid you don't have the BP for that!",
      :no_re => "You don't have enough Red Essence.",
      :no_items => "You don't have enough {1}.",

      :cannot_sell => "{1}? Oh, no.\nI can't buy that.",
      :sell_quantity => "{1}?\nHow many would you like to sell?",
      :sell_confirm => "I can pay {1}.\nWould that be OK?",
      :sell_success => "Turned over {1}\nand received {2}.",

      :purchase_confirm_single => "Certainly. You want {1}.\nThat will be {2}. OK?",
      :choose_quantity => "{1}? Certainly.\nHow many would you like?",
      :purchase_confirm_multiple => "{1}, and you want {2}.\nThat will be {3}. OK?",

      :full_puppet => "Sorry, but you're too full of coins.",
      :full_coins => "Sorry, but your Coin Case is full.",
      :full_item => "Sorry, but you have no more room in the Bag.",

      :success_money => "Here you are!\nThank you!",
      :success_coins => "Here you are!\nThank you!",
      :success_puppet => "Here you are!\nThank you!",
      :success_ap => "Here you are!\nThank you!",
      :success_re => "Here you are!\nThank you!",
      :success_bp => "Here you are!\nThank you!",
      :success_items => "Here you are!\nThank you!",

      :premier_one => "I'll throw in a Premier Ball, too.",
      :premier_many => "I'll throw in {1} Premier Balls, too.",
    },
    :Inventory => [],
  },

  :ChapterOne => {
    :Messages => {
      :welcome => "Buy something, my family is dying.",
      :goodbye => "Okay.",

      :no_money => "What the hell man, what are you buying?",
    },

    :Inventory => {

      "Berries" => [
        ItemStock.of(:ORANBERRY),
        ItemStock.of(:CHESTOBERRY),
        ItemStock.of(:PECHABERRY),
        ItemStock.of(:RAWSTBERRY),
        ItemStock.of(:CHERIBERRY),
        ItemStock.of(:PERSIMBERRY),
      ],
      "Held Items" => [
        ItemStock.of(:MUSCLEBAND),
        ItemStock.of(:WISEGLASSES),
      ],
      "TMs" => [
        ItemStock.of(:TM01, 1).properties(conditions: ['!searchItem(self.item)']), # Cut
        ItemStock.of(:TM02, 1).properties(conditions: ['!searchItem(self.item)']), # Covet
        ItemStock.of(:TM03, 1).properties(conditions: ['!searchItem(self.item)']), # Bind
        ItemStock.of(:TM00, 1).properties(conditions: ['!searchItem(self.item)']), # Brutal Swing
      ],
      "Rare Purchases" => [
        ItemStock.of(:RARECANDY, 1).costs(500).limit().properties(conditions: ['$game_switches[2181] == false'],
          on_purchase: [
            '$game_switches[2181] = true',
          ]),        
      ],
    },
  },

  #
  :ChapterTwo => {
    :Messages => {
      :welcome => "Buy something, my family is dying.",
      :goodbye => "Okay.",

      :no_money => "What the hell man, what are you buying?",
    },

    :Inventory => {

      "Berries" => [
        ItemStock.of(:ORANBERRY),
        ItemStock.of(:CHESTOBERRY),
        ItemStock.of(:PECHABERRY),
        ItemStock.of(:RAWSTBERRY),
        ItemStock.of(:CHERIBERRY),
        ItemStock.of(:PERSIMBERRY),
      ],
      "Held Items" => [
        ItemStock.of(:MUSCLEBAND),
        ItemStock.of(:WISEGLASSES),
        ItemStock.of(:STICKYBARB),
        ItemStock.of(:LAGGINGTAIL),
        ItemStock.of(:BINDINGBAND),
        ItemStock.of(:GRIPCLAW),
      ],
      "Consumables" => [
        ItemStock.of(:WHITEHERB),
      ],
      "TMs" => [
        ItemStock.of(:TM01, 1).properties(conditions: ['!searchItem(self.item)']), # Cut
        ItemStock.of(:TM02, 1).properties(conditions: ['!searchItem(self.item)']), # Covet
        ItemStock.of(:TM03, 1).properties(conditions: ['!searchItem(self.item)']), # Bind
        ItemStock.of(:TM04, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Smash
        ItemStock.of(:TM08, 1).properties(conditions: ['!searchItem(self.item)']), # Aerial Ace
        ItemStock.of(:TM09, 1).properties(conditions: ['!searchItem(self.item)']), # Shockwave
        ItemStock.of(:TM10, 1).properties(conditions: ['!searchItem(self.item)']), # Water Pulse
        ItemStock.of(:TM11, 1).properties(conditions: ['!searchItem(self.item)']), # Incinerate
        ItemStock.of(:TM12, 1).properties(conditions: ['!searchItem(self.item)']), # Thunder Fang
        ItemStock.of(:TM13, 1).properties(conditions: ['!searchItem(self.item)']), # Fire Fang
        ItemStock.of(:TM14, 1).properties(conditions: ['!searchItem(self.item)']), # Ice Fang
        ItemStock.of(:TM00, 1).properties(conditions: ['!searchItem(self.item)']), # Brutal Swing
      ],    
      "Rare Purchases" => [
        ItemStock.of(:RARECANDY, 1).costs(500).limit().properties(conditions: ['$game_variables[899] == 0'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),        
        ItemStock.of(:RARECANDY, 1).costs(1000).limit().properties(conditions: ['$game_variables[899] == 1'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:BERRYJUICE, 2).costs(500).limit().properties(conditions: ['$game_switches[2212] == false'],
          on_purchase: [
            '$game_switches[2212] = true',
        ]),
      ],
    },
  },

 :ChapterThree => {
    :Messages => {
      :welcome => "Buy something, my family is dying.",
      :goodbye => "Okay.",

      :no_money => "What the hell man, what are you buying?",
    },

    :Inventory => {

      "Berries" => [
        ItemStock.of(:ORANBERRY),
        ItemStock.of(:CHESTOBERRY),
        ItemStock.of(:PECHABERRY),
        ItemStock.of(:RAWSTBERRY),
        ItemStock.of(:CHERIBERRY),
        ItemStock.of(:PERSIMBERRY),
        ItemStock.of(:BERRYJUICE),
      ],
      "Held Items" => [
        ItemStock.of(:MUSCLEBAND),
        ItemStock.of(:WISEGLASSES),
        ItemStock.of(:STICKYBARB),
        ItemStock.of(:LAGGINGTAIL),
        ItemStock.of(:BINDINGBAND),
        ItemStock.of(:GRIPCLAW),
        ItemStock.of(:EVIOLITE),
        ItemStock.of(:PROTECTIVEPADS),
        ItemStock.of(:SHELLBELL),
      ],
      "Consumables" => [
        ItemStock.of(:ABSORBBULB),
        ItemStock.of(:SNOWBALL),
        ItemStock.of(:CELLBATTERY),
        ItemStock.of(:WHITEHERB),
      ],
      "TMs" => [
        ItemStock.of(:TM01, 1).properties(conditions: ['!searchItem(self.item)']), # Cut
        ItemStock.of(:TM02, 1).properties(conditions: ['!searchItem(self.item)']), # Covet
        ItemStock.of(:TM03, 1).properties(conditions: ['!searchItem(self.item)']), # Bind
        ItemStock.of(:TM04, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Smash
        ItemStock.of(:TM05, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Tomb
        ItemStock.of(:TM06, 1).properties(conditions: ['!searchItem(self.item)']), # Bulldoze
        ItemStock.of(:TM07, 1).properties(conditions: ['!searchItem(self.item)']), # Poison Sweep
        ItemStock.of(:TM08, 1).properties(conditions: ['!searchItem(self.item)']), # Aerial Ace
        ItemStock.of(:TM09, 1).properties(conditions: ['!searchItem(self.item)']), # Shockwave
        ItemStock.of(:TM10, 1).properties(conditions: ['!searchItem(self.item)']), # Water Pulse
        ItemStock.of(:TM11, 1).properties(conditions: ['!searchItem(self.item)']), # Incinerate
        ItemStock.of(:TM12, 1).properties(conditions: ['!searchItem(self.item)']), # Thunder Fang
        ItemStock.of(:TM13, 1).properties(conditions: ['!searchItem(self.item)']), # Fire Fang
        ItemStock.of(:TM14, 1).properties(conditions: ['!searchItem(self.item)']), # Ice Fang
        ItemStock.of(:TM00, 1).properties(conditions: ['!searchItem(self.item)']), # Brutal Swing
      ],    
      "Rare Purchases" => [
        ItemStock.of(:RARECANDY, 1).costs(500).limit().properties(conditions: ['$game_variables[899] == 0'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),        
        ItemStock.of(:RARECANDY, 1).costs(1000).limit().properties(conditions: ['$game_variables[899] == 1'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 2'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:BERRYJUICE, 2).costs(500).limit().properties(conditions: ['$game_switches[2212] == false'],
          on_purchase: [
            '$game_switches[2212] = true',
        ]),
        ItemStock.of(:ADRENALINEORB, 1).costs(500).limit().properties(conditions: ['$game_switches[2214] == false'],
          on_purchase: [
            '$game_switches[2214] = true',
        ]),
      ],
    },
  },

 :ChapterFour => {
    :Messages => {
      :welcome => "Buy something, my family is dying.",
      :goodbye => "Okay.",

      :no_money => "What the hell man, what are you buying?",
    },

    :Inventory => {

      "Berries" => [
        ItemStock.of(:ORANBERRY),
        ItemStock.of(:CHESTOBERRY),
        ItemStock.of(:PECHABERRY),
        ItemStock.of(:RAWSTBERRY),
        ItemStock.of(:CHERIBERRY),
        ItemStock.of(:PERSIMBERRY),
        ItemStock.of(:BERRYJUICE),
      ],
      "Held Items" => [
        ItemStock.of(:MUSCLEBAND),
        ItemStock.of(:WISEGLASSES),
        ItemStock.of(:STICKYBARB),
        ItemStock.of(:LAGGINGTAIL),
        ItemStock.of(:BINDINGBAND),
        ItemStock.of(:GRIPCLAW),
        ItemStock.of(:EVIOLITE),
        ItemStock.of(:PROTECTIVEPADS),
        ItemStock.of(:SHELLBELL),
        ItemStock.of(:BIGROOT),
      ],
      "Type Boosters" => [
        ItemStock.of(:SILKSCARF),
        ItemStock.of(:CHARCOAL),
        ItemStock.of(:MYSTICWATER),
        ItemStock.of(:MIRACLESEED),
        ItemStock.of(:MAGNET),
        ItemStock.of(:NEVERMELTICE),
        ItemStock.of(:BLACKBELT),
        ItemStock.of(:POISONBARB),
        ItemStock.of(:SOFTSAND),
        ItemStock.of(:SHARPBEAK),
        ItemStock.of(:TWISTEDSPOON),
        ItemStock.of(:SILVERPOWDER),
        ItemStock.of(:HARDSTONE),
        ItemStock.of(:SPELLTAG),
        ItemStock.of(:DRAGONFANG),
        ItemStock.of(:BLACKGLASSES),
        ItemStock.of(:METALCOAT),
        ItemStock.of(:PIXIEDUST),
      ],
      "Consumables" => [
        ItemStock.of(:ABSORBBULB),
        ItemStock.of(:SNOWBALL),
        ItemStock.of(:CELLBATTERY),
        ItemStock.of(:WHITEHERB),
      ],
      "TMs" => [
        ItemStock.of(:TM00, 1).properties(conditions: ['!searchItem(self.item)']), # Brutal Swing
        ItemStock.of(:TM01, 1).properties(conditions: ['!searchItem(self.item)']), # Cut
        ItemStock.of(:TM02, 1).properties(conditions: ['!searchItem(self.item)']), # Covet
        ItemStock.of(:TM03, 1).properties(conditions: ['!searchItem(self.item)']), # Bind
        ItemStock.of(:TM04, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Smash
        ItemStock.of(:TM05, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Tomb
        ItemStock.of(:TM06, 1).properties(conditions: ['!searchItem(self.item)']), # Bulldoze
        ItemStock.of(:TM07, 1).properties(conditions: ['!searchItem(self.item)']), # Poison Sweep
        ItemStock.of(:TM08, 1).properties(conditions: ['!searchItem(self.item)']), # Aerial Ace
        ItemStock.of(:TM09, 1).properties(conditions: ['!searchItem(self.item)']), # Shockwave
        ItemStock.of(:TM10, 1).properties(conditions: ['!searchItem(self.item)']), # Water Pulse
        ItemStock.of(:TM11, 1).properties(conditions: ['!searchItem(self.item)']), # Incinerate
        ItemStock.of(:TM12, 1).properties(conditions: ['!searchItem(self.item)']), # Thunder Fang
        ItemStock.of(:TM13, 1).properties(conditions: ['!searchItem(self.item)']), # Fire Fang
        ItemStock.of(:TM14, 1).properties(conditions: ['!searchItem(self.item)']), # Ice Fang
        ItemStock.of(:TM15, 1).properties(conditions: ['!searchItem(self.item)']), # Helping Hand
        ItemStock.of(:TM101, 1).properties(conditions: ['!searchItem(self.item)']), # Gravity
      ],    
      "Rare Purchases" => [
        ItemStock.of(:RARECANDY, 1).costs(500).limit().properties(conditions: ['$game_variables[899] == 0'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),        
        ItemStock.of(:RARECANDY, 1).costs(1000).limit().properties(conditions: ['$game_variables[899] == 1'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 2 || $game_variables[899] == 2'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:BERRYJUICE, 2).costs(500).limit().properties(conditions: ['$game_switches[2212] == false'],
          on_purchase: [
            '$game_switches[2212] = true',
        ]),
        ItemStock.of(:ADRENALINEORB, 1).costs(1000).limit().properties(conditions: ['$game_switches[2214] == false'],
          on_purchase: [
            '$game_switches[2214] = true',
        ]),
        ItemStock.of(:EJECTBUTTON, 1).costs(2500).limit().properties(conditions: ['$game_switches[2213] == false'],
          on_purchase: [
            '$game_switches[2213] = true',
        ]),
      ],
    },
  },


 :ChapterFive => {
    :Messages => {
      :welcome => "Buy something, my family is dying.",
      :goodbye => "Okay.",

      :no_money => "What the hell man, what are you buying?",
    },

    :Inventory => {

      "Berries" => [
        ItemStock.of(:ORANBERRY),
        ItemStock.of(:CHESTOBERRY),
        ItemStock.of(:PECHABERRY),
        ItemStock.of(:RAWSTBERRY),
        ItemStock.of(:CHERIBERRY),
        ItemStock.of(:PERSIMBERRY),
        ItemStock.of(:BERRYJUICE),
      ],
      "Held Items" => [
        ItemStock.of(:MUSCLEBAND),
        ItemStock.of(:WISEGLASSES),
        ItemStock.of(:STICKYBARB),
        ItemStock.of(:LAGGINGTAIL),
        ItemStock.of(:BINDINGBAND),
        ItemStock.of(:GRIPCLAW),
        ItemStock.of(:EVIOLITE),
        ItemStock.of(:PROTECTIVEPADS),
        ItemStock.of(:SHELLBELL),
        ItemStock.of(:BIGROOT),
        ItemStock.of(:STICK),
      ],
      "Type Boosters" => [
        ItemStock.of(:SILKSCARF),
        ItemStock.of(:CHARCOAL),
        ItemStock.of(:MYSTICWATER),
        ItemStock.of(:MIRACLESEED),
        ItemStock.of(:MAGNET),
        ItemStock.of(:NEVERMELTICE),
        ItemStock.of(:BLACKBELT),
        ItemStock.of(:POISONBARB),
        ItemStock.of(:SOFTSAND),
        ItemStock.of(:SHARPBEAK),
        ItemStock.of(:TWISTEDSPOON),
        ItemStock.of(:SILVERPOWDER),
        ItemStock.of(:HARDSTONE),
        ItemStock.of(:SPELLTAG),
        ItemStock.of(:DRAGONFANG),
        ItemStock.of(:BLACKGLASSES),
        ItemStock.of(:METALCOAT),
        ItemStock.of(:PIXIEDUST),
      ],
      "Consumables" => [
        ItemStock.of(:ABSORBBULB),
        ItemStock.of(:SNOWBALL),
        ItemStock.of(:CELLBATTERY),
        ItemStock.of(:WHITEHERB),
      ],
      "TMs" => [
        ItemStock.of(:TM00, 1).properties(conditions: ['!searchItem(self.item)']), # Brutal Swing
        ItemStock.of(:TM01, 1).properties(conditions: ['!searchItem(self.item)']), # Cut
        ItemStock.of(:TM02, 1).properties(conditions: ['!searchItem(self.item)']), # Covet
        ItemStock.of(:TM03, 1).properties(conditions: ['!searchItem(self.item)']), # Bind
        ItemStock.of(:TM04, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Smash
        ItemStock.of(:TM05, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Tomb
        ItemStock.of(:TM06, 1).properties(conditions: ['!searchItem(self.item)']), # Bulldoze
        ItemStock.of(:TM07, 1).properties(conditions: ['!searchItem(self.item)']), # Poison Sweep
        ItemStock.of(:TM08, 1).properties(conditions: ['!searchItem(self.item)']), # Aerial Ace
        ItemStock.of(:TM09, 1).properties(conditions: ['!searchItem(self.item)']), # Shockwave
        ItemStock.of(:TM10, 1).properties(conditions: ['!searchItem(self.item)']), # Water Pulse
        ItemStock.of(:TM11, 1).properties(conditions: ['!searchItem(self.item)']), # Incinerate
        ItemStock.of(:TM12, 1).properties(conditions: ['!searchItem(self.item)']), # Thunder Fang
        ItemStock.of(:TM13, 1).properties(conditions: ['!searchItem(self.item)']), # Fire Fang
        ItemStock.of(:TM14, 1).properties(conditions: ['!searchItem(self.item)']), # Ice Fang
        ItemStock.of(:TM15, 1).properties(conditions: ['!searchItem(self.item)']), # Helping Hand
        ItemStock.of(:TM16, 1).properties(conditions: ['!searchItem(self.item)']), # Nature Power
        ItemStock.of(:TM101, 1).properties(conditions: ['!searchItem(self.item)']), # Gravity
      ],    
      "Rare Purchases" => [
        ItemStock.of(:RARECANDY, 1).costs(500).limit().properties(conditions: ['$game_variables[899] == 0'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),        
        ItemStock.of(:RARECANDY, 1).costs(1000).limit().properties(conditions: ['$game_variables[899] == 1'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 2'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 3'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 4'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:BERRYJUICE, 2).costs(500).limit().properties(conditions: ['$game_switches[2212] == false'],
          on_purchase: [
            '$game_switches[2212] = true',
        ]),
        ItemStock.of(:ADRENALINEORB, 1).costs(1000).limit().properties(conditions: ['$game_switches[2214] == false'],
          on_purchase: [
            '$game_switches[2214] = true',
        ]),
        ItemStock.of(:EJECTBUTTON, 1).costs(2500).limit().properties(conditions: ['$game_switches[2213] == false'],
          on_purchase: [
            '$game_switches[2213] = true',
        ])],
    },
  },
  

  :ChapterSix => {
    :Messages => {
      :welcome => "Buy something, my family is dying.",
      :goodbye => "Okay.",

      :no_money => "What the hell man, what are you buying?",
    },

    :Inventory => {

      "Berries" => [
        ItemStock.of(:ORANBERRY),
        ItemStock.of(:CHESTOBERRY),
        ItemStock.of(:PECHABERRY),
        ItemStock.of(:RAWSTBERRY),
        ItemStock.of(:CHERIBERRY),
        ItemStock.of(:PERSIMBERRY),
        ItemStock.of(:BERRYJUICE),
      ],
      "Held Items" => [
        ItemStock.of(:MUSCLEBAND),
        ItemStock.of(:WISEGLASSES),
        ItemStock.of(:STICKYBARB),
        ItemStock.of(:LAGGINGTAIL),
        ItemStock.of(:BINDINGBAND),
        ItemStock.of(:GRIPCLAW),
        ItemStock.of(:EVIOLITE),
        ItemStock.of(:PROTECTIVEPADS),
        ItemStock.of(:SHELLBELL),
        ItemStock.of(:BIGROOT),
        ItemStock.of(:STICK),
        ItemStock.of(:BLACKSLUDGE),
        ItemStock.of(:METRONOME),
        ItemStock.of(:FOCUSBAND),
        ItemStock.of(:RAZORCLAW),
        ItemStock.of(:RAZORFANG),
        ItemStock.of(:PUNCHINGGLOVE),
        ItemStock.of(:IRONBALL),
        ItemStock.of(:LIGHTBALL),
        ItemStock.of(:SAFETYGOGGLES),
      ],
      "Type Boosters" => [
        ItemStock.of(:SILKSCARF),
        ItemStock.of(:CHARCOAL),
        ItemStock.of(:MYSTICWATER),
        ItemStock.of(:MIRACLESEED),
        ItemStock.of(:MAGNET),
        ItemStock.of(:NEVERMELTICE),
        ItemStock.of(:BLACKBELT),
        ItemStock.of(:POISONBARB),
        ItemStock.of(:SOFTSAND),
        ItemStock.of(:SHARPBEAK),
        ItemStock.of(:TWISTEDSPOON),
        ItemStock.of(:SILVERPOWDER),
        ItemStock.of(:HARDSTONE),
        ItemStock.of(:SPELLTAG),
        ItemStock.of(:DRAGONFANG),
        ItemStock.of(:BLACKGLASSES),
        ItemStock.of(:METALCOAT),
        ItemStock.of(:PIXIEDUST),
      ],
      "Consumables" => [
        ItemStock.of(:ABSORBBULB),
        ItemStock.of(:SNOWBALL),
        ItemStock.of(:CELLBATTERY),
        ItemStock.of(:WHITEHERB),
      ],
      "Gems" => [
        ItemStock.of(:NORMALGEM),
        ItemStock.of(:FIREGEM),
        ItemStock.of(:WATERGEM),
        ItemStock.of(:GRASSGEM),
        ItemStock.of(:ELECTRICGEM),
        ItemStock.of(:ICEGEM),
        ItemStock.of(:FIGHTINGGEM),
        ItemStock.of(:POISONGEM),
        ItemStock.of(:GROUNDGEM),
        ItemStock.of(:FLYINGGEM),
        ItemStock.of(:PSYCHICGEM),
        ItemStock.of(:BUGGEM),
        ItemStock.of(:ROCKGEM),
        ItemStock.of(:GHOSTGEM),
        ItemStock.of(:DRAGONGEM),
        ItemStock.of(:DARKGEM),
        ItemStock.of(:STEELGEM),
        ItemStock.of(:FAIRYGEM),
      ],
      "TMs" => [
        ItemStock.of(:TM00, 1).properties(conditions: ['!searchItem(self.item)']), # Brutal Swing
        ItemStock.of(:TM01, 1).properties(conditions: ['!searchItem(self.item)']), # Cut
        ItemStock.of(:TM02, 1).properties(conditions: ['!searchItem(self.item)']), # Covet
        ItemStock.of(:TM03, 1).properties(conditions: ['!searchItem(self.item)']), # Bind
        ItemStock.of(:TM04, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Smash
        ItemStock.of(:TM05, 1).properties(conditions: ['!searchItem(self.item)']), # Rock Tomb
        ItemStock.of(:TM06, 1).properties(conditions: ['!searchItem(self.item)']), # Bulldoze
        ItemStock.of(:TM07, 1).properties(conditions: ['!searchItem(self.item)']), # Poison Sweep
        ItemStock.of(:TM08, 1).properties(conditions: ['!searchItem(self.item)']), # Aerial Ace
        ItemStock.of(:TM09, 1).properties(conditions: ['!searchItem(self.item)']), # Shockwave
        ItemStock.of(:TM10, 1).properties(conditions: ['!searchItem(self.item)']), # Water Pulse
        ItemStock.of(:TM11, 1).properties(conditions: ['!searchItem(self.item)']), # Incinerate
        ItemStock.of(:TM12, 1).properties(conditions: ['!searchItem(self.item)']), # Thunder Fang
        ItemStock.of(:TM13, 1).properties(conditions: ['!searchItem(self.item)']), # Fire Fang
        ItemStock.of(:TM14, 1).properties(conditions: ['!searchItem(self.item)']), # Ice Fang
        ItemStock.of(:TM15, 1).properties(conditions: ['!searchItem(self.item)']), # Helping Hand
        ItemStock.of(:TM16, 1).properties(conditions: ['!searchItem(self.item)']), # Nature Power
        ItemStock.of(:TM17, 1).properties(conditions: ['!searchItem(self.item)']), # Chilling Water
        ItemStock.of(:TM18, 1).properties(conditions: ['!searchItem(self.item)']), # Thunder Punch
        ItemStock.of(:TM19, 1).properties(conditions: ['!searchItem(self.item)']), # Fire Punch
        ItemStock.of(:TM20, 1).properties(conditions: ['!searchItem(self.item)']), # Ice Punch
        ItemStock.of(:TM101, 1).properties(conditions: ['!searchItem(self.item)']), # Gravity
      ],
      "Rare Purchases" => [
        ItemStock.of(:RARECANDY, 1).costs(500).limit().properties(conditions: ['$game_variables[899] == 0'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),        
        ItemStock.of(:RARECANDY, 1).costs(1000).limit().properties(conditions: ['$game_variables[899] == 1'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 2'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 3'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 4'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:RARECANDY, 1).costs(1500).limit().properties(conditions: ['$game_variables[899] == 5'],
          on_purchase: [
            '$game_variables[899] += 1',
          ]),
        ItemStock.of(:ADRENALINEORB, 1).costs(1000).limit().properties(conditions: ['$game_switches[2214] == false'],
          on_purchase: [
            '$game_switches[2214] = true',
        ]),
        ItemStock.of(:BERRYJUICE, 2).costs(500).limit().properties(conditions: ['$game_switches[2212] == false'],
          on_purchase: [
            '$game_switches[2212] = true',
        ]),
        ItemStock.of(:EJECTBUTTON, 1).costs(2500).limit().properties(conditions: ['$game_switches[2213] == false'],
          on_purchase: [
            '$game_switches[2213] = true',
        ]),
        ItemStock.of(:FOCUSSASH, 1).costs(2500).limit().properties(conditions: ['$game_variables[899] == 0'],
          on_purchase: [
            '$game_variables[898] += 1',
          ]),
      ],
    },
  },

  :LimitedSeeds => {
    :Messages => {
      :welcome => "",
      :goodbye => "",

      :no_money => "What the hell man, what are you buying? Wax candles??",
    },
  
    :Inventory => [
      ItemStock.of(:ELEMENTALSEED, 1).costs(2500).limit().properties(conditions: ['$game_variables[897] > 0'],
        on_purchase: [
        '$game_variables[897] -= 1',
      ]),
      ItemStock.of(:MAGICALSEED, 1).costs(2500).limit().properties(conditions: ['$game_variables[897] > 0'],
        on_purchase: [
        '$game_variables[897] -= 1',
      ]),
      ItemStock.of(:SYNTHETICSEED, 1).costs(2500).limit().properties(conditions: ['$game_variables[897] > 0'],
        on_purchase: [
        '$game_variables[897] -= 1',
      ]),
      ItemStock.of(:TELLURICSEED, 1).costs(2500).limit().properties(conditions: ['$game_variables[897] > 0'],
        on_purchase: [
        '$game_variables[897] -= 1',
      ]),
  ],
  },

  :EarlyItemsChapterSix => {
    :Messages => {
      :welcome => "Sick nasty.",
      :goodbye => "Okay.",

      :no_money => "What the hell man, what are you buying? Wax candles??",
    },
  
    :Inventory => [ItemStock.of(:VICTREEBELITE, 1).costs(2500).limit().properties(conditions: ['$game_switches[2000] == false'],
        on_purchase: [
        '$game_switches[2000] = true',
      ]),
      ItemStock.of(:CHIMECHITE, 1).costs(2500).limit().properties(conditions: ['$game_switches[2001] == false'],
        on_purchase: [
        '$game_switches[2001] = true',
      ]),
      ItemStock.of(:PIDGEOTITE, 1).costs(2500).limit().properties(conditions: ['$game_switches[2002] == false'],
        on_purchase: [
        '$game_switches[2002] = true',
      ]),
  ],
  }

  #end
}