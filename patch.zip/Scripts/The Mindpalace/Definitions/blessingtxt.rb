BLESSINGS = {
  #Saki Blessings
  :SHARPENEDSTEEL => {
    :name => "Sharpened Steel",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeSTEEL",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :STEEL
    },
    :typeBoost => true,
    :group => 1
  },

  :HEATEDANVIL => {
    :name => "Heated Anvil",
    :desc => "@type@ moves have a @statusChance*100@% chance to inflict @status@.",
    :values => {
      :statusChance => [
        0.2,
        0.35,
        0.5
      ],
      :status => :BURN,
      :type => [:STEEL, :ROCK]
    },
    :moveStatusEffect => true,
    :group => 1
  },

  #Valarie Blessings
  :FAVORABLETIDES => {
    :name => "Favorable Tides",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeWATER",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :WATER
    },
    :typeBoost => true,
    :group => 1
  },

  :HERBALBATH => {
    :name => "Herbal Bath",
    :desc => "Gradually restore @healAmount*100@% HP every @turns@ turn(s).",
    :values => {
      :healAmount => [
        0.05,
        0.05,
        0.1
      ],
      :turns => [
        2,
        1,
        1
      ]
    },
    :passiveHP => true,
    :group => 1
  },

  #Adam Blessings
  :OBSIDIANPOINT => {
    :name => "Obsidian Point",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeROCK",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :ROCK
    },
    :typeBoost => true,
    :group => 1
  },

  :ROCKSOLID => {
    :name => "Rock Solid",
    :desc => [
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle. Additionally, gain a @bonusChance*100@% chance to increase @stats@ every turn.",
    ],
    :values => {
      :boostChance => BlessingTables::SwitchBoost,
      :bonusChance => [
        0.0,
        0.0,
        0.33
      ],
      :stats => [PBStats::DEFENSE]
    },
    :entryEffect => true,
    :endOfTurnStatBoost => true,
    :group => 1
  },

  #Amber Blessings
  :FIERYSPIRIT => {
    :name => "Fiery Spirit",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeFIRE",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :FIRE
    },
    :typeBoost => true,
    :group => 2
  },

  :HEATEDRIFLE => {
    :name => "Heated Rifle",
    :desc => "@type@ moves gain +@bonusCrit@ critical-hit ratio.",
    :values => {
      :bonusCrit => [
        1,
        2
      ],
      :type => :FIRE
    },
    :maxRank => 2,
    :modifyCritRate => true,
    :group => 2
  },

  #Venam Blessings
  :ACIDICGRAZE => {
    :name => "Acidic Graze",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypePOISON",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :POISON
    },
    :typeBoost => true,
    :group => 2
  },

  :CHEMICALBURN => {
    :name => "Chemical Burn",
    :desc => "All @type@ moves have a @statusChance*100@% chance to inflict @status@.",
    :values => {
      :statusChance => [
        0.2,
        0.35,
        0.5
      ],
      :status => [:BURN, :POISON],
      :type => [:POISON,:WATER]
    },
    :moveStatusEffect => true,
    :group => 2
  },

  #Ren Blessings
  :COVERTMEDIUM => {
    :name => "Covert Medium",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeDARK",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :DARK
    },
    :typeBoost => true,
    :group => 2
  },

  :TWOFORFLINCHING => {
    :name => "Two-For-Flinching",
    :desc => "Opponents that flinch take @damage*100@% max HP damage.",
    :values => {
      :damage => 0.25
    },
    :maxRank => 1,
    :modifyTryUseMove => true,
    :group => 2
  },

  #Florin Blessings
  :TANGLINGROOTS => {
    :name => "Tangling Roots",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeGRASS",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :GRASS
    },
    :typeBoost => true,
    :group => 3
  },

  :NOURISHINGNUTRIENTS => {
    :name => "Nourishing Nutrients",
    :desc => [
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle. Gain a @bonusChance*100@% chance to instead raise @stats@ to @bonusBoost@.",
    ],
    :icon => "Graphics/Icons/bosstypeGRASS",
    :values => {
      :boostChance => BlessingTables::SwitchBoost,
      :bonusChance => [
        0.0,
        0.0,
        0.33
      ],
      :bonusBoost => 2,
      :stats => [PBStats::SPDEF]
    },
    :entryEffect => true,
    :group => 3
  },

  #Ryland Blessings
  :EARTHSHAKER => {
    :name => "Earth Shaker",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeGROUND",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :GROUND
    },
    :typeBoost => true,
    :group => 3
  },

  :COVERINGTERRAIN => {
    :name => "Covering Terrain",
    :desc => [
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle. Additionally, gain a @bonusChance*100@% chance to increase @stats@ every turn.",
    ],
    :icon => "Graphics/Icons/bosstypeGROUND",
    :values => {
      :boostChance => [
        0.5,
        0.5,
        1.0
      ],
      :bonusChance => [
        0.0,
        0.0,
        0.33
      ],
      :stats => [PBStats::EVASION]
    },
    :entryEffect => true,
    :endOfTurnStatBoost => true,
    :group => 3
  },

  # Talon Blessing
  :GALEFORCE => {
    :name => "Gale Force",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeFLYING",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :FLYING
    },
    :typeBoost => true,
    :group => 3
  },

  :HAWKSEYE => {
    :name => "Hawk's Eye",
    :desc => [
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle. Additionally, gain a @bonusChance*100@% chance to increase @stats@ every turn.",
    ],
    :values => {
      :boostChance => [
        0.5,
        0.5,
        1.0
      ],
      :bonusChance => [
        0.0,
        0.0,
        0.33
      ],
      :stats => [PBStats::ACCURACY]
    },
    :entryEffect => true,
    :endOfTurnStatBoost => true,
    :group => 3
  },

  #Kreiss
  :ARCTICNOBILITY => {
    :name => "Arctic Nobility",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeICE",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :ICE
    },
    :typeBoost => true,
    :group => 4
  },

  :SLIPNSLIDE => {
    :name => "Slip 'n Slide",
    :desc => [
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle. Additionally, gain a @bonusChance*100@% chance to increase @stats@ every turn.",
    ],
    :values => {
      :boostChance => BlessingTables::SwitchBoost,
      :bonusChance => [
        0.0,
        0.0,
        0.33
      ],
      :stats => [PBStats::SPEED]
    },
    :entryEffect => true,
    :endOfTurnStatBoost => true,
    :group => 4
  },

  #Martin
  :ROUTINE => {
    :name => "Routine",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeNORMAL",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :NORMAL
    },
    :typeBoost => true,
    :group => 4
  },

  :POWERTHROUGH => {
    :name => "Power Through",
    :desc => "@type@ moves gain +@bonusCrit@ critical-hit ratio.",
    :values => {
      :bonusCrit => [
        1,
        2
      ],
      :type => :NORMAL
    },
    :maxRank => 2,
    :modifyCritRate => true,
    :group => 4
  },

  #Narcissa
  :GHASTLYAPPLAUSE => {
    :name => "Ghastly Applause",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeGHOST",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :GHOST
    },
    :typeBoost => true,
    :group => 4
  },

  :VENGEFULHEX => {
    :name => "Vengeful Hex",
    :desc => "All moves have a @statusChance*100@% chance to apply a @status@, dealing @damage*100@% max Health every turn.",
    # :rules => [
    #   "Vengeful Hex is a @basedamage@ power @type@ move, damage category is based off the user's stronger attacking stat.",
    #   "Vengeful Hex will not activate when below @healthCost*100@% HP.",
    #   "Vengeful Hex will not activate if any other delayed-damage effect is active on the target."
    # ],
    :icon => "Graphics/Icons/bosstypeSHADOW",
    :values => {
      :statusChance => [
        0.35,
        0.50,
        0.65
      ],
      :damage => [
        0.0625,
        0.125,
        0.25
      ],
      :status => :VENGEFULHEX,
    },
    :moveStatusEffect => true,
    :group => 4
  },

  #Damien
  :DRAGONSWRATH => {
    :name => "Dragon's Wrath",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeDRAGON",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :DRAGON
    },
    :typeBoost => true,
    :group => 5
  },

  :COCKATRICEDEATHSTARE => {
    :name => "Cockatrice Death-stare",
    :desc => "All @type@ moves have a @statusChance*100@% chance to inflict @status@.",
    :values => {
      :statusChance => [
        0.2,
        0.35,
        0.5
      ],
      :status => :PETRIFIED,
      :type => [:DRAGON,:DARK],
    },
    :moveStatusEffect => true,
    :group => 5
  },

  #Allen
  :HEROSSPIRIT => {
    :name => "Hero's Spirit",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeFAIRY",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :FAIRY
    },
    :typeBoost => true,
    :group => 5
  },

  :SLEEPINGBEAUTY => {
    :name => "Sleeping Beauty",
    :desc => "All @type@ moves have a @statusChance*100@% chance to inflict @status@.",
    :values => {
      :statusChance => [
        0.2,
        0.35,
        0.5
      ],
      :status => :SLEEP,
      :type => [:FAIRY]
    },
    :moveStatusEffect => true,
    :group => 5
  },

  #Erick
  :POWERSUPPLY => {
    :name => "Power Supply",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeELECTRIC",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :ELECTRIC
    },
    :typeBoost => true,
    :group => 5
  },

  :BEWILDERINGDUO => {
    :name => "Bewildering Duo",
    :desc => [
      "All moves have a @statusChance*100@% chance to inflict @status@.",
      "All moves have a @statusChance*100@% chance to inflict @status@.",
      "All moves have a @statusChance*100@% chance to inflict @status@. Enemies also gain an additional @hitBonus*100@% chance to hit themselves in Confusion.",
    ],
    :values => {
      :statusChance => [
        0.20,
        0.25,
        0.30
      ],
      :status => :CONFUSION,
      :hitBonus => [
        0.0,
        0.0,
        0.15
      ]
    },
    :moveStatusEffect => true,
    :group => 5
  },

  :SURGINGSTRIKES => {
    :name => "Surging Strikes",
    :desc => [
      "All moves have a @hitChance*100@% chance to strike again at @damageReduction*100@% damage.",
      "All moves have a @hitChance*100@% chance to strike again at @damageReduction*100@% damage.",
      "All moves have a @hitChance*100@% chance to strike again at @damageReduction*100@% damage. Gain an additional @bonusProcChance*100@% chance to strike @bonusProcHits@ more time(s).",
    ],
    :values => {
      :hitChance => [
        0.3,
        0.7,
        1.0
      ],
      :bonusHits => 1,
      :damageReduction => 0.25,
      :bonusProcChance => [
        0.0,
        0.0,
        0.33
      ],
      :bonusProcHits => 2
    },
    :modifyHitCount => true,
    :modifyTotalDamage => true,
    :group => 5
  },

  #Alexandra
  :PACIFISTSPULL => {
    :name => "Pacifist's Pull",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypePSYCHIC",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :PSYCHIC
    },
    :typeBoost => true,
    :group => 6
  },

  :SOULREAD => {
    :name => "Soul Read",
    :desc => "@type@ moves gain +@bonusCrit@ critical-hit ratio.",
    :values => {
      :bonusCrit => [
        1,
        2
      ],
      :type => :PSYCHIC
    },
    :maxRank => 2,
    :modifyCritRate => true,
    :group => 6
  },

  #Crawli
  :BONAFIDEBUGGIES => {
    :name => "Bonafide Buggies",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeBUG",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :BUG
    },
    :typeBoost => true,
    :group => 6
  },

  :DANCEOFTHEFIREFLIES => {
    :name => "Dance of the Fireflies",
    :desc => [
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle. Gain a @bonusChance*100@% chance to instead raise @stats@ to @bonusBoost@.",
    ],
    :values => {
      :boostChance => BlessingTables::SwitchBoost,
      :bonusChance => [
        0.0,
        0.0,
        0.33
      ],
      :bonusBoost => 2,
      :stats => PBStats::SPATK
    },
    :entryEffect => true,
    :group => 6
  },

  #Aelita
  :FRIENDLYSPAR => {
    :name => "Friendly Spar",
    :desc => "Boosts the power of @type@ moves by @amount*100@%.",
    :icon => "Graphics/Icons/bosstypeFIGHTING",
    :values => {
      :amount => BlessingTables::TypeBoost,
      :type => :FIGHTING
    },
    :typeBoost => true,
    :group => 6
  },

  :OFHEARTANDMIND => {
    :name => "Of Heart and Mind",
    :desc => [
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle.",
      "Gain a @boostChance*100@% chance of raising @stats@ when a Pokémon enters a battle. Gain a @bonusChance*100@% chance to instead raise @stats@ to @bonusBoost@.",
    ],
    :values => {
      :boostChance => BlessingTables::SwitchBoost,
      :bonusChance => [
        0.0,
        0.0,
        0.33
      ],
      :bonusBoost => 2,
      :stats => PBStats::ATTACK
    },
    :entryEffect => true,
    :group => 6
  },
}
