TTYPEHASH = {
:CHILDOFLIGHT => {
	:ID => 0,
	:title => "Child of Light",
	:skill => 0,
},

:TRAINER_AEVIS => {
	:ID => 1,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AEVIA => {
	:ID => 2,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_ARIA => {
	:ID => 3,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AXEL => {
	:ID => 4,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 14,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_ALAIN => {
	:ID => 5,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 0,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AERO => {
	:ID => 6,
	:title => "Pokémon Trainer",
	:skill => 150,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:moneymult => 0,
	:player => true
},

:TRAINER_ANA => {
	:ID => 7,
	:title => "Pokémon Trainer",
	:skill => 100,
	:battleBGM => "Battle - Rival.mp3",
	:moneymult => 0,
	:player => true
},

:LOSTHEIR => {
	:ID => 8,
	:title => "Lost Heir",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Bringer of Chaos.mp3",
},

:RESEARCHER => {
	:ID => 9,
	:title => "Researcher",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Researcher.mp3",
},

:COOLTRAINER => {
	:ID => 10,
	:title => "Cooltrainer",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Cool.mp3",
},

:SCIENTIST => {
	:ID => 110,
	:title => "Madman",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Faust.mp3",
},

:DRAGONMASTER => {
	:ID => 186,
	:title => "The Dragon",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Dragon.mp3",
},

:MYSTERY => {
	:ID => 122,
	:title => "Mysterious",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Hunter.mp3",
},

:NINJA => {
	:ID => 309,
	:title => "Ninja",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Rival.mp3",
},

:AGENT => {
	:ID => 111,
	:title => "Agent",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Agent.mp3",
},

:CHILLGUY => {
	:ID => 109,
	:title => "Cooltrainer",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Chill.mp3",
},

:AMNESIAC => {
	:ID => 104,
	:title => "Amnesiac",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Engineer.mp3",
},

:TROUBLEMAKER => {
	:ID => 203,
	:title => "Troublemaker",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Bells.mp3",
},

:VISIONARY => {
	:ID => 202,
	:title => "Visionary",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Fierce.mp3",
},

:RUNAWAY => {
	:ID => 51,
	:title => "Techie",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Run.mp3",
},

:NICEGUY => {
	:ID => 52,
	:title => "Pokemon Trainer",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Nice.mp3",
},

:TEAMMOM => {
	:ID => 135,
	:title => "Team Mom",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Mom.mp3",
},

:RUNEMASTER => {
	:ID => 5,
	:title => "Runemaster",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Reluctance.mp3",
},

:CONMAN => {
	:ID => 20,
	:title => "Ruffian",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - For Whose Sake.mp3",
},

:DETECTIVE => {
	:ID => 21,
	:title => "Detective",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Yeehaw.mp3",
},

:CULTLEADER => {
	:ID => 306,
	:title => "Cult Leader",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Ez.mp3",
},

:DISASTER => {
	:ID => 95,
	:title => "Experiment 359",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Ez.mp3",
},




:TYRANT => {
	:ID =>23,
	:title => "Experiment 612",
	:skill => 105,
	:moneymult => 0,
	:battleBGM => "Battle - Rex.mp3",
},

}