DENHASH = {
  :Den1 => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :ROCKRUFF, :weight => 2.0 },
      { :encounter => :SHIFTRY },
      { :encounter => :REUNICLUS },
      { :encounter => :DUOSION },
      { :encounter => :TROPIUS },
      { :encounter => :SIGILYPH },
      { :encounter => :DHELMISE },
    ])
    .addTable(:Gym_16, [
      { :encounter => :ROCKRUFF, :weight => 2.0 },
      { :encounter => :SHIFTRY },
      { :encounter => :REUNICLUS },
      { :encounter => :DUOSION },
      { :encounter => :TROPIUS },
      { :encounter => :SIGILYPH },
      { :encounter => :DHELMISE },
    ])
    .addTable(:Gym_12, [
      { :encounter => :ROCKRUFF, :weight => 2.0 },
      { :encounter => :SHIFTRY },
      { :encounter => :REUNICLUS },
      { :encounter => :DUOSION },
      { :encounter => :TROPIUS },
      { :encounter => :SIGILYPH },
      { :encounter => :DHELMISE },
    ])
    .addTable(:Gym_8, [
      { :encounter => :GRAVELER, :weight => 2.0 },
      { :encounter => :NUZLEAF },
      { :encounter => :SOLOSIS },
      { :encounter => :DUOSION },
      { :encounter => :TROPIUS },
      { :encounter => :SIGILYPH },
      { :encounter => :DHELMISE },
    ])
    .addTable(:Gym_4, [
      { :encounter => :GRAVELER, :weight => 2.0 },
      { :encounter => :NUZLEAF, :weight => 2.0 },
      { :encounter => :SOLOSIS },
      { :encounter => :TROPIUS },
    ]),

  :Den1Rare => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :RELICANTH },
      { :encounter => :PERSIAN },
      { :encounter => :LUMINEON },
      { :encounter => :SUDOWOODO },
      { :encounter => :LANTURN },
      { :encounter => :MALAMAR },
      { :encounter => :MANECTRIC },
    ])
    .addTable(:Gym_16, [
      { :encounter => :RELICANTH },
      { :encounter => :PERSIAN },
      { :encounter => :LUMINEON },
      { :encounter => :SUDOWOODO },
      { :encounter => :MALAMAR },
      { :encounter => :LANTURN },
      { :encounter => :MANECTRIC },
    ])
    .addTable(:Gym_12, [
      { :encounter => :RELICANTH },
      { :encounter => :PERSIAN },
      { :encounter => :LUMINEON },
      { :encounter => :SUDOWOODO },
      { :encounter => :MALAMAR },
      { :encounter => :CHINCHOU },
      { :encounter => :MANECTRIC },
    ])
    .addTable(:Gym_8, [
      { :encounter => :RELICANTH },
      { :encounter => :PERSIAN },
      { :encounter => :LUMINEON },
      { :encounter => :BONSLY },
      { :encounter => :MANECTRIC },
    ])
    .addTable(:Gym_4, [
      { :encounter => :FINNEON },
      { :encounter => :BONSLY },
      { :encounter => :MEOWTH },
      { :encounter => :ELECTRIKE },
    ]),

  :Den2 => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :UNFEZANT, :weight => 2.0 },
      { :encounter => :OINKOLOGNE },
      { :encounter => :WAILORD },
      { :encounter => :SANDACONDA },
      { :encounter => :NIDORINO, :weight => 2.0 },
      { :encounter => :WHIRLIPEDE },
      { :encounter => :MANDIBUZZ },
      { :encounter => :MASQUERAIN },
      { :encounter => :QUAGSIRE },
      { :encounter => :TOGEDEMARU },
    ])
    .addTable(:Gym_16, [
      { :encounter => :UNFEZANT, :weight => 2.0 },
      { :encounter => :OINKOLOGNE },
      { :encounter => :WAILORD },
      { :encounter => :SANDACONDA },
      { :encounter => :NIDORINO, :weight => 2.0 },
      { :encounter => :WHIRLIPEDE },
      { :encounter => :MANDIBUZZ },
      { :encounter => :MASQUERAIN },
      { :encounter => :QUAGSIRE },
      { :encounter => :TOGEDEMARU },
    ])
    .addTable(:Gym_12, [
      { :encounter => :UNFEZANT, :weight => 2.0 },
      { :encounter => :OINKOLOGNE },
      { :encounter => :WAILORD },
      { :encounter => :SANDACONDA },
      { :encounter => :NIDORINO, :weight => 2.0 },
      { :encounter => :WHIRLIPEDE },
      { :encounter => :MANDIBUZZ },
      { :encounter => :MASQUERAIN },
      { :encounter => :QUAGSIRE },
      { :encounter => :TOGEDEMARU },
    ])
    .addTable(:Gym_8, [
      { :encounter => :UNFEZANT, :weight => 2.0 },
      { :encounter => :OINKOLOGNE },
      { :encounter => :WAILMER },
      { :encounter => :SANDACONDA },
      { :encounter => :NIDORINO, :weight => 2.0 },
      { :encounter => :WHIRLIPEDE },
      { :encounter => :VULLABY },
      { :encounter => :MASQUERAIN },
      { :encounter => :QUAGSIRE },
    ])
    .addTable(:Gym_4, [
      { :encounter => :TRANQUILL, :weight => 2.0 },
      { :encounter => :OINKOLOGNE },
      { :encounter => :WAILMER },
      { :encounter => :SILICOBRA },
      { :encounter => :VULLABY },
    ]),

  :Den2Rare => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :CHATOT },
      { :encounter => :SNORUNT },
      { :encounter => :GLALIE },
      { :encounter => :CACNEA },
      { :encounter => :CACTURNE },
      { :encounter => :CLAYDOL },
      { :encounter => :KLEFKI, :weight => 2.0 },
    ])
    .addTable(:Gym_16, [
      { :encounter => :CHATOT },
      { :encounter => :SNORUNT },
      { :encounter => :GLALIE },
      { :encounter => :CACNEA },
      { :encounter => :CACTURNE },
      { :encounter => :CLAYDOL },
      { :encounter => :KLEFKI, :weight => 2.0 },
    ])
    .addTable(:Gym_12, [
      { :encounter => :CHATOT },
      { :encounter => :SNORUNT },
      { :encounter => :GLALIE },
      { :encounter => :CACNEA },
      { :encounter => :CACTURNE },
      { :encounter => :CLAYDOL },
      { :encounter => :KLEFKI, :weight => 2.0 },
    ])
    .addTable(:Gym_8, [
      { :encounter => :CHATOT, :weight => 2.0 },
      { :encounter => :SNORUNT },
      { :encounter => :GLALIE },
      { :encounter => :CACNEA },
      { :encounter => :CACTURNE },
      { :encounter => :CLAYDOL },
    ])
    .addTable(:Gym_4, [
      { :encounter => :CHATOT },
      { :encounter => :SNORUNT, :weight => 2.0 },
      { :encounter => :CACNEA, :weight => 2.0 },
    ]),

  :Den3 => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :STOUTLAND, :weight => 2.0 },
      { :encounter => :BIBAREL },
      { :encounter => :CRABRAWLER },
      { :encounter => :PACHIRISU },
      { :encounter => :CHIMECHO },
      { :encounter => :GALARSTUNFISK },
      { :encounter => :RABSCA },
      { :encounter => :KADABRA, :weight => 2.0 },
      { :encounter => :PRIMEAPE, :weight => 2.0 },
    ])
    .addTable(:Gym_16, [
      { :encounter => :STOUTLAND, :weight => 2.0 },
      { :encounter => :BIBAREL },
      { :encounter => :CRABRAWLER },
      { :encounter => :PACHIRISU },
      { :encounter => :CHIMECHO },
      { :encounter => :GALARSTUNFISK },
      { :encounter => :RABSCA },
      { :encounter => :KADABRA, :weight => 2.0 },
      { :encounter => :PRIMEAPE, :weight => 2.0 },
    ])
    .addTable(:Gym_12, [
      { :encounter => :STOUTLAND, :weight => 2.0 },
      { :encounter => :BIBAREL },
      { :encounter => :CRABRAWLER },
      { :encounter => :PACHIRISU },
      { :encounter => :CHIMECHO },
      { :encounter => :GALARSTUNFISK },
      { :encounter => :RABSCA },
      { :encounter => :KADABRA, :weight => 2.0 },
      { :encounter => :MANKEY, :weight => 2.0 },
    ])
    .addTable(:Gym_8, [
      { :encounter => :STOUTLAND, :weight => 2.0 },
      { :encounter => :BIBAREL },
      { :encounter => :CRABRAWLER },
      { :encounter => :PACHIRISU },
      { :encounter => :CHIMECHO },
      { :encounter => :GALARSTUNFISK },
      { :encounter => :RABSCA },
      { :encounter => :ABRA },
    ])
    .addTable(:Gym_4, [
      { :encounter => :HERDIER, :weight => 2.0 },
      { :encounter => :BIBAREL },
      { :encounter => :CRABRAWLER },
      { :encounter => :PACHIRISU },
      { :encounter => :CHIMECHO },
    ]),

  :Den3Rare => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :RHYDON },
      { :encounter => :VANILLUXE, :weight => 2.0 },
      { :encounter => :PURUGLY },
      { :encounter => :DITTO, :weight => 2.0 },
      { :encounter => :URSARING },
      { :encounter => :FLYGON },
    ])
    .addTable(:Gym_16, [
      { :encounter => :RHYDON },
      { :encounter => :VANILLUXE, :weight => 2.0 },
      { :encounter => :PURUGLY },
      { :encounter => :DITTO, :weight => 2.0 },
      { :encounter => :URSARING },
      { :encounter => :FLYGON },
    ])
    .addTable(:Gym_12, [
      { :encounter => :RHYDON },
      { :encounter => :VANILLUXE, :weight => 2.0 },
      { :encounter => :PURUGLY },
      { :encounter => :DITTO, :weight => 2.0 },
      { :encounter => :URSARING },
    ])
    .addTable(:Gym_8, [
      { :encounter => :RHYDON },
      { :encounter => :VANILLUXE },
      { :encounter => :VANILLISH },
      { :encounter => :PURUGLY },
      { :encounter => :DITTO },
      { :encounter => :TEDDIURSA },
    ])
    .addTable(:Gym_4, [
      { :encounter => :RHYHORN },
      { :encounter => :VANILLITE, :weight => 2.0 },
      { :encounter => :DITTO },
      { :encounter => :PURUGLY },
    ]),

  :Den4 => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :LOMBRE, :weight => 2.0 },
      { :encounter => :LURANTIS },
      { :encounter => :SALAZZLE },
      { :encounter => :GASTRODON, :weight => 2.0 },
      { :encounter => :DUBWOOL },
      { :encounter => :WUGTRIO },
      { :encounter => :SWANNA, :weight => 2.0 },
      { :encounter => :NOIVERN },
    ])
    .addTable(:Gym_16, [
      { :encounter => :LOMBRE, :weight => 2.0 },
      { :encounter => :LURANTIS },
      { :encounter => :SALAZZLE },
      { :encounter => :GASTRODON, :weight => 2.0 },
      { :encounter => :DUBWOOL },
      { :encounter => :WUGTRIO },
      { :encounter => :SWANNA, :weight => 2.0 },
      { :encounter => :NOIVERN },
    ])
    .addTable(:Gym_12, [
      { :encounter => :LOMBRE, :weight => 2.0 },
      { :encounter => :LURANTIS },
      { :encounter => :SALAZZLE },
      { :encounter => :GASTRODON, :weight => 2.0 },
      { :encounter => :DUBWOOL },
      { :encounter => :WUGTRIO },
      { :encounter => :SWANNA, :weight => 2.0 },
      { :encounter => :NOIVERN },
    ])
    .addTable(:Gym_8, [
      { :encounter => :LOMBRE, :weight => 2.0 },
      { :encounter => :LURANTIS },
      { :encounter => :SALAZZLE },
      { :encounter => :GASTRODON, :weight => 2.0 },
      { :encounter => :DUBWOOL },
      { :encounter => :WUGTRIO },
      { :encounter => :NOIVERN },
    ])
    .addTable(:Gym_4, [
      { :encounter => :LOTAD, :weight => 2.0 },
      { :encounter => :GASTRODON, :weight => 2.0 },
      { :encounter => :DUBWOOL },
      { :encounter => :WIGLETT },
      { :encounter => :NOIBAT },
    ]),

  :Den4Rare => RaidDen.new
    .addTable(:Gym_18, [
      { :encounter => :RAPIDASH, :weight => 2.0 },
      { :encounter => :JELLICENT, :weight => 2.0 },
      { :encounter => :MARILL },
      { :encounter => :TIMBURR },
    ])
    .addTable(:Gym_16, [
      { :encounter => :RAPIDASH, :weight => 2.0 },
      { :encounter => :JELLICENT, :weight => 2.0 },
      { :encounter => :MARILL },
      { :encounter => :TIMBURR },
    ])
    .addTable(:Gym_12, [
      { :encounter => :RAPIDASH, :weight => 2.0 },
      { :encounter => :JELLICENT, :weight => 2.0 },
      { :encounter => :MARILL },
      { :encounter => :TIMBURR },
    ])
    .addTable(:Gym_8, [
      { :encounter => :PONYTA },
      { :encounter => :RAPIDASH },
      { :encounter => :FRILLISH },
      { :encounter => :JELLICENT },
    ])
    .addTable(:Gym_4, [
      { :encounter => :PONYTA, :weight => 2.0 },
      { :encounter => :FRILLISH, :weight => 2.0 },
    ]),

  :Beldum => RaidDen.new.addTable([{ :encounter => :BELDUM }])
}
