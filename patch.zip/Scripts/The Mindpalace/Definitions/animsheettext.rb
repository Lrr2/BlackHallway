ANIMSHEETS = {
  "Graphics/Characters/pkmn_quilava_2" => {
    frameSize: [34, 34],
    frameData: [35, 40]
  },
  "Graphics/Characters/pkmn_quilava_3" => {
    frameSize: [64, 48],
    frameData: [30, 8, 4, 8, 4]
  },
  "Graphics/Characters/pkmn_quilava_4" => {
    frameSize: [72, 64],
    frameData: [3, 6, 2, 2, 2, 2, 2, 2, 2, 2]
  },
  "Graphics/Characters/pkmn_absol_idleoffset" => {
    frameSize: [80, 72],
    frameData: [30, 30]
  }
}
