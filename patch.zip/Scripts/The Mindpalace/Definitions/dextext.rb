POKEDEXHASH = {
  :National => {
    :name => "National Pokédex",
    :default => true,
  },

  :Floria => {
    :name => "Floria Island",
  },

  :Terajuma => {
    :name => "Terajuma Island",
  },

  :Terrial => {
    :name => "Terrial Island",
  },

  :Badlands => {
    :name => "The Badlands",
  },
}
