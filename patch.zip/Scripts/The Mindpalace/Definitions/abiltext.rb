ABILHASH = {
:STENCH => {
	:ID => 1,
	:name => "Stench",
	:desc => "The stench ensures poison from moves.",
	:fullDesc => "The stench guarantees poison from moves that may poion.",
},

:DRIZZLE => {
	:ID => 2,
	:name => "Drizzle",
	:desc => "The Pokémon makes it rain when it enters a battle."
},

:SPEEDBOOST => {
	:ID => 3,
	:name => "Speed Boost",
	:desc => "Its Speed stat is gradually boosted."
},

:BATTLEARMOR => {
	:ID => 4,
	:name => "Battle Armor",
	:desc => "The Pokémon is protected against critical hits."
},

:STURDY => {
	:ID => 5,
	:name => "Sturdy",
	:desc => "It cannot be knocked out with one hit."
},

:DAMP => {
	:ID => 6,
	:name => "Damp",
	:desc => "Blocks a fire move or explosion, then dries out.",
	:fullDesc => "Blocks a fire move or explosion once, then changes to Dry Skin until switched out."
},

:LIMBER => {
	:ID => 7,
	:name => "Limber",
	:desc => "Can't be paralyzed; takes halved damage while switching in."
},

:SANDVEIL => { # lawds - rework of sand veil
	:ID => 8,
	:name => "Sand Veil",
	:desc => "Raises Defense by 50% in a sandstorm."
},

:STATIC => {
	:ID => 9,
	:name => "Static",
	:desc => "After fainting, its replacement becomes charged.",
	:fullDesc => "After it faints, the next Pokemon that switches in on its side becomes charged."
},

:VOLTABSORB => {
	:ID => 10,
	:name => "Volt Absorb",
	:desc => "Restores HP if hit by an Electric-type move."
},

:WATERABSORB => {
	:ID => 11,
	:name => "Water Absorb",
	:desc => "Restores HP if hit by a Water-type move."
},

:OBLIVIOUS => {
	:ID => 12,
	:name => "Oblivious",
	:desc => "Prevents it from becoming infatuated."
},

:CLOUDNINE => {
	:ID => 13,
	:name => "Cloud Nine",
	:desc => "Eliminates the effects of weather."
},

:COMPOUNDEYES => {
	:ID => 14,
	:name => "Compound Eyes",
	:desc => "Moves change category based on what is more effective.",
#	:fullDesc => "The Pokémon's accuracy is boosted by 30%."
},

:INSOMNIA => {
	:ID => 15,
	:name => "Insomnia",
	:desc => "Prevents the Pokémon from falling asleep."
},

:COLORCHANGE => {
	:ID => 16,
	:name => "Color Change",
	:desc => "Changes the Pokémon's type to the foe's move."
},

:IMMUNITY => {
	:ID => 17,
	:name => "Immunity",
	:desc => "Grants immunity to Poison moves and status."
},

:FLASHFIRE => {
	:ID => 18,
	:name => "Flash Fire",
	:desc => "Powers up Fire-type moves if it's hit by one.",
	:fullDesc => "When hit by a Fire-type move, this Pokémon's attacking stats are boosted by 50% when using Fire-type moves."
},

:SHIELDDUST => {
	:ID => 19,
	:name => "Shield Dust",
	:desc => "Blocks the added effects of attacks taken."
},

:OWNTEMPO => {
	:ID => 20,
	:name => "Own Tempo",
	:desc => "Prevents the Pokémon from becoming confused."
},

:SUCTIONCUPS => {
	:ID => 21,
	:name => "Suction Cups",
	:desc => "Negates all moves that force switching out."
},

:INTIMIDATE => {
	:ID => 22,
	:name => "Intimidate",
	:desc => "Lowers the foe's Attack stat."
},

:SHADOWTAG => {
	:ID => 23,
	:name => "Shadow Tag",
	:desc => "Prevents the foe from escaping."
},

:ROUGHSKIN => {
	:ID => 24,
	:name => "Rough Skin",
	:desc => "Inflicts damage to the foe on contact."
},

:WONDERGUARD => {
	:ID => 25,
	:name => "Wonder Guard",
	:desc => "Only super-effective moves will hit."
},

:LEVITATE => {
	:ID => 26,
	:name => "Levitate",
	:desc => "Gives full immunity to all Ground-type moves."
},

:EFFECTSPORE => {
	:ID => 27,
	:name => "Effect Spore",
	:desc => "If KO'd by contact, the attacker becomes confused."
},

:SYNCHRONIZE => {
	:ID => 28,
	:name => "Synchronize",
	:desc => "Passes a burn, poison, or paralysis to the foe."
},

:CLEARBODY => {
	:ID => 29,
	:name => "Clear Body",
	:desc => "Prevents other Pokémon from lowering its stats."
},

:NATURALCURE => {
	:ID => 30,
	:name => "Natural Cure",
	:desc => "All status problems heal when it switches out."
},

:LIGHTNINGROD => {
	:ID => 31,
	:name => "Lightningrod",
	:desc => "Draws in all Electric-type moves to raise Sp. Attack."
},

:SERENEGRACE => {
	:ID => 32,
	:name => "Serene Grace",
	:desc => "Boosts the likelihood of added effects appearing."
},

:SWIFTSWIM => {
	:ID => 33,
	:name => "Swift Swim",
	:desc => "Doubles the Pokémon's Speed in rain."
},

:CHLOROPHYLL => {
	:ID => 34,
	:name => "Chlorophyll",
	:desc => "Doubles the Pokémon's Speed in sunshine."
},

:ILLUMINATE => {
	:ID => 35,
	:name => "Illuminate",
	:desc => "More likely to meet wild Pokémon. Boosts accuracy."
},

:TRACE => {
	:ID => 36,
	:name => "Trace",
	:desc => "The Pokémon copies a foe's Ability.",
	:fullDesc => "The Pokémon copies a foe's Ability. Prioritizes the foe opposite the user.",
},

:HUGEPOWER => {
	:ID => 37,
	:name => "Huge Power",
	:desc => "Doubles the Pokémon's Attack stat."
},

:POISONPOINT => {
	:ID => 38,
	:name => "Poison Point",
	:desc => "If KO'd by contact, the attacker becomes poisoned.",
},

:INNERFOCUS => {
	:ID => 39,
	:name => "Inner Focus",
	:desc => "The Pokemon cannot flinch or be intimidated.",
},

:MAGMAARMOR => {
	:ID => 40,
	:name => "Magma Armor",
	:desc => "Protects from Ground and Rock moves.",
	:fullDesc => "Halves Ground and Rock damage taken. Stats can't be dropped in sun.",
},

:WATERVEIL => {
	:ID => 41,
	:name => "Water Veil",
	:desc => "Gain Aqua Ring on entry. Protects from burn."
},

:MAGNETPULL => {
	:ID => 42,
	:name => "Magnet Pull",
	:desc => "Prevents Steel-type Pokémon from escaping."
},

:SOUNDPROOF => {
	:ID => 43,
	:name => "Soundproof",
	:desc => "Gives full immunity to all sound-based moves."
},

:RAINDISH => {
	:ID => 44,
	:name => "Rain Dish",
	:desc => "The Pokémon gradually regains HP in rain."
},

:SANDSTREAM => {
	:ID => 45,
	:name => "Sand Stream",
	:desc => "The Pokémon summons a sandstorm in battle."
},

:PRESSURE => {
	:ID => 46,
	:name => "Pressure",
	:desc => "The Pokémon raises the foe's PP usage."
},

:THICKFAT => {
	:ID => 47,
	:name => "Thick Fat",
	:desc => "Ups resistance to Fire- and Ice-type moves.",
	:fullDesc => "Increases reistance to Fire- and Ice-type moves by 50%."
},

:EARLYBIRD => {
	:ID => 48,
	:name => "Early Bird",
	:desc => "It's early to fight, skipping charge turns."
},

:FLAMEBODY => {
	:ID => 49,
	:name => "Flame Body",
	:desc => "If KO'd with contact, the attacker becomes flammable.",
},

:RUNAWAY => {
	:ID => 50,
	:name => "Run Away",
	:desc => "The Pokemon is immune to trapping abilities."
},

:KEENEYE => {
	:ID => 51,
	:name => "Keen Eye",
	:desc => "Increases damage for every lowered enemy stat.",
	:fullDesc => "It spots weak points, boosting damage 10% for each lowered enemy stat. Immune to Acc. drops and enemy Evasion."
},

:HYPERCUTTER => {
	:ID => 52,
	:name => "Hyper Cutter",
	:desc => "Prevents other Pokémon from lowering Attack stat."
},

:PICKUP => {
	:ID => 53,
	:name => "Pickup",
	:desc => "The Pokémon may pick up items."
},

:TRUANT => {
	:ID => 54,
	:name => "Truant",
	:desc => "Pokémon can't attack on consecutive turns."
},

:HUSTLE => {
	:ID => 55,
	:name => "Hustle",
	:desc => "Boosts the Attack stat, but lowers defenses.",
	:fullDesc => "Boosts the Attack stat by 50%, but lowers defenses by 25%."
},

:CUTECHARM => {
	:ID => 56,
	:name => "Cute Charm",
	:desc => "Contact with the Pokémon may cause infatuation."
},

:PLUS => {
	:ID => 57,
	:name => "Plus",
	:desc => "Ups Sp. Atk if another Pokémon has Plus or Minus.",
	:fullDesc => "Ups Sp. Attack if another Pokémon has Plus or Minus by 50%. Magnetic Flux raises Defense and Sp. Defense, Gear Up raises Attack and Sp. Attack."
},

:MINUS => {
	:ID => 58,
	:name => "Minus",
	:desc => "Ups Sp. Atk if another Pokémon has Plus or Minus.",
	:fullDesc => "Ups Sp. Attack if another Pokémon has Plus or Minus by 50%. Magnetic Flux raises Defense and Sp. Defense, Gear Up raises Attack and Sp. Attack."
},

:FORECAST => {
	:ID => 59,
	:name => "Forecast",
	:desc => "Castform transforms with the weather."
},

:STICKYHOLD => {
	:ID => 60,
	:name => "Sticky Hold",
	:desc => "Protects the Pokémon from item theft."
},

:SHEDSKIN => {
	:ID => 61,
	:name => "Shed Skin",
	:desc => "It heals status problems after a turn."
},

:GUTS => {
	:ID => 62,
	:name => "Guts",
	:desc => "Boosts Attack if there is a status problem.",
	:fullDesc => "Boosts Attack if there is a status problem by 50%."
},

:MARVELSCALE => {
	:ID => 63,
	:name => "Marvel Scale",
	:desc => "Ups Defense if there is a status problem.",
	:fullDesc => "Ups Defense if there is a status problem by 50%."
},

:LIQUIDOOZE => {
	:ID => 64,
	:name => "Liquid Ooze",
	:desc => "Damages attackers using any draining move.",
	:fullDesc => "Damages attackers using any draining move by that amount instead of healing."
},

:OVERGROW => {
	:ID => 65,
	:name => "Overgrow",
	:desc => "Powers up Grass-type moves in a pinch.",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Grass-type moves."
},

:BLAZE => {
	:ID => 66,
	:name => "Blaze",
	:desc => "Powers up Fire-type moves in a pinch.",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Fire-type moves."
},

:TORRENT => {
	:ID => 67,
	:name => "Torrent",
	:desc => "Powers up Water-type moves in a pinch.",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Water-type moves."
},

:SWARM => {
	:ID => 68,
	:name => "Swarm",
	:desc => "Powers up Bug-type moves in a pinch.",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Bug-type moves."
},

:ROCKHEAD => {
	:ID => 69,
	:name => "Rock Head",
	:desc => "Protects the Pokémon from recoil damage."
},

:DROUGHT => {
	:ID => 70,
	:name => "Drought",
	:desc => "The Pokémon summons harsh sunlight in battle."
},

:ARENATRAP => {
	:ID => 71,
	:name => "Arena Trap",
	:desc => "Prevents the foe from fleeing."
},

:VITALSPIRIT => {
	:ID => 72,
	:name => "Vital Spirit",
	:desc => "Prevents the Pokémon from falling asleep."
},

:WHITESMOKE => {
	:ID => 73,
	:name => "White Smoke",
	:desc => "Prevents other Pokémon from lowering its stats."
},

:PUREPOWER => {
	:ID => 74,
	:name => "Pure Power",
	:desc => "Doubles the Pokémon's Attack stat."
},

:SHELLARMOR => {
	:ID => 75,
	:name => "Shell Armor",
	:desc => "The Pokémon is protected against critical hits."
},

:AIRLOCK => {
	:ID => 76,
	:name => "Air Lock",
	:desc => "Eliminates the effects of weather."
},

:TANGLEDFEET => {
	:ID => 77,
	:name => "Tangled Feet",
	:desc => "Raises Speed if Confusion is induced."
},

:MOTORDRIVE => {
	:ID => 78,
	:name => "Motor Drive",
	:desc => "Raises Speed if hit by an Electric-type move."
},

:RIVALRY => {
	:ID => 79,
	:name => "Rivalry",
	:desc => "Increases DMG for every boosted enemy stat.",
	:fullDesc => "Deal 10% more damage for every stat with stage > 0 the opponent has."
},

:STEADFAST => {
	:ID => 80,
	:name => "Steadfast",
	:desc => "Raises Speed each time the Pokémon flinches."
},

:SNOWCLOAK => { # lawds - rework of snow cloak
	:ID => 81,
	:name => "Snow Cloak",
	:desc => "Raises defenses 20% in a hailstorm."
},

:GLUTTONY => {
	:ID => 82,
	:name => "Gluttony",
	:desc => "Encourages the early use of a held Berry."
},

:ANGERPOINT => {
	:ID => 83,
	:name => "Anger Point",
	:desc => "Raises offenses when crit or disrupted.",
	:fullDesc => "Offenses are boosted +1 when it's taunted/tormented/encored/disabled/takes a crit.",
},

:UNBURDEN => {
	:ID => 84,
	:name => "Unburden",
	:desc => "Doubles Speed if a held item is used."
},

:HEATPROOF => {
	:ID => 85,
	:name => "Heatproof",
	:desc => "Weakens the power of Fire-type moves.",
	:fullDesc => "Halves the damage done by Burn. Reduces damage taken by Fire moves by 90%."
},

:SIMPLE => {
	:ID => 86,
	:name => "Simple",
	:desc => "The Pokémon is prone to wild stat changes."
},

:DRYSKIN => {
	:ID => 87,
	:name => "Dry Skin",
	:desc => "Reduces HP if it is hot. Water restores HP.",
	:fullDesc => "Fire-type moves deal 25% more damage. Water-type moves heal 1/4 max HP. Rain heals by 1/8 max HP. Sun damages for 1/8 max HP."
},

:DOWNLOAD => {
	:ID => 88,
	:name => "Download",
	:desc => "Adjusts power according to a foe's defenses.",
	:fullDesc => "Increase Attack or Special Attack by one stage based on the foe's lower defense stat."
},

:IRONFIST => {
	:ID => 89,
	:name => "Iron Fist",
	:desc => "Boosts the power of punching moves.",
	:fullDesc => "Boosts the power of punching moves by 30%."
},

:POISONHEAL => {
	:ID => 90,
	:name => "Poison Heal",
	:desc => "The Pokemon heals while poisoned. Immune to Poison moves."
},

:ADAPTABILITY => {
	:ID => 91,
	:name => "Adaptability",
	:desc => "Powers up moves of the same type.",
	:fullDesc => "Powers up STAB to an additional 100% rather than 50%."
},

:SKILLLINK => {
	:ID => 92,
	:name => "Skill Link",
	:desc => "Increases the frequency of multi-strike moves."
},

:HYDRATION => {
	:ID => 93,
	:name => "Hydration",
	:desc => "Heals status problems in the rain."
},

:SOLARPOWER => {
	:ID => 94,
	:name => "Solar Power",
	:desc => "Sunshine boosts Sp. Atk but HP decreases.",
	:fullDesc => "In sunshine, Special Attack is boosted by 50%, but HP decreases by 1/8th max HP per turn."
},

:QUICKFEET => {
	:ID => 95,
	:name => "Quick Feet",
	:desc => "Boosts Speed if there is a status problem.",
	:fullDesc => "Boosts Speed if there is a status problem by 50%. Ignores Paralysis Speed drop."
},

:NORMALIZE => {
	:ID => 96,
	:name => "Normalize",
	:desc => "All the user's moves become the Normal type."
},

:SNIPER => {
	:ID => 97,
	:name => "Sniper",
	:desc => "Powers up critical hits.",
	:fullDesc => "Powers up critical hits by 50%."
},

:MAGICGUARD => {
	:ID => 98,
	:name => "Magic Guard",
	:desc => "The Pokémon only takes damage from attacks."
},

:NOGUARD => {
	:ID => 99,
	:name => "No Guard",
	:desc => "Ensures attacks by or against the user land."
},

:STALL => {
	:ID => 100,
	:name => "Stall",
	:desc => "Causes an additional turn to pass."
},

:TECHNICIAN => {
	:ID => 101,
	:name => "Technician",
	:desc => "Powers up the Pokémon's weaker moves.",
	:fullDesc => "Moves with 60 Base Power or less deal 50% more damage."
},

:LEAFGUARD => { # lawds leaf guard
	:ID => 102,
	:name => "Leaf Guard",
	:desc => "In Sun, defenses are 1.2x and Fire is halved.."
},

:KLUTZ => {	# LAWDS klutz rework
	:ID => 103,
	:name => "Klutz",
	:desc => "Making or taking contact has a field effect, once.",
	:fullDesc => "It's so clumsy that it triggers a field effect if contact is made or taken. Mimics Secret Power, except on some fields."
},

:MOLDBREAKER => {
	:ID => 104,
	:name => "Mold Breaker",
	:desc => "Moves can be used regardless of Abilities."
},

:SUPERLUCK => {
	:ID => 105,
	:name => "Super Luck",
	:desc => "High-crit moves always crit.",
	:fullDesc => "Moves with a naturally heightened crit rate will always crit."
},

:AFTERMATH => {
	:ID => 106,
	:name => "Aftermath",
	:desc => "Damages the foe landing the finishing hit.",
	:fullDesc => "When reduced to 0 HP by a contact move, the attacker suffers 1/4th of its max HP. Damp prevents this effect."
},

:ANTICIPATION => {
	:ID => 107,
	:name => "Anticipation",
	:desc => "Reduces damage from SE after shuddering.",
	:fullDesc => "A super-effective move is halved on the first turn after shuddering."
},

:FOREWARN => {
	:ID => 108,
	:name => "Forewarn",
	:desc => "Protects it from unexpected moves.",
	:fullDesc => "It's immune to Sucker Punch, Electroclap, and Thunderclap. Ally is not protected."
},

:UNAWARE => {
	:ID => 109,
	:name => "Unaware",
	:desc => "Ignores any stat changes in other Pokémon."
},

:TINTEDLENS => {
	:ID => 110,
	:name => "Tinted Lens",
	:desc => "Powers up \"not very effective\" moves.",
	:fullDesc => "The damage of \"not very effective\" moves is doubled."
},

:FILTER => {
	:ID => 111,
	:name => "Filter",
	:desc => "Reduces damage from supereffective attacks.",
	:fullDesc => "Reduces damage from supereffective attacks by 25%."
},

:SLOWSTART => {
	:ID => 112,
	:name => "Slow Start",
	:desc => "Temporarily halves Attack and Speed."
},

:SCRAPPY => {
	:ID => 113,
	:name => "Scrappy",
	:desc => "Enables moves to hit Ghost-type Pokémon."
},

:STORMDRAIN => {
	:ID => 114,
	:name => "Storm Drain",
	:desc => "Draws in Water-type moves to up Sp. Attack."
},

:ICEBODY => {
	:ID => 115,
	:name => "Ice Body",
	:desc => "The Pokémon gradually regains HP in hail."
},

:SOLIDROCK => {
	:ID => 116,
	:name => "Solid Rock",
	:desc => "Reduces damage from supereffective attacks.",
	:fullDesc => "Reduces damage from supereffective attacks by 25%."
},

:SNOWWARNING => {
	:ID => 117,
	:name => "Snow Warning",
	:desc => "The Pokémon summons a hailstorm in battle."
},

:HONEYGATHER => {
	:ID => 118,
	:name => "Honey Gather",
	:desc => "The Pokémon may gather Honey from somewhere."
},

:FRISK => {
	:ID => 119,
	:name => "Frisk",
	:desc => "The Pokémon can check a foe's held item."
},

:RECKLESS => {
	:ID => 120,
	:name => "Reckless",
	:desc => "Powers up moves that damage or weaken the user.",
	:fullDesc => "Powers up moves that damage the user or lower their stats."
},

:MULTITYPE => {
	:ID => 121,
	:name => "Multitype",
	:desc => "Changes type to match the held Plate."
},

:FLOWERGIFT => {
	:ID => 122,
	:name => "Flower Gift",
	:desc => "Powers up party Pokémon when it is sunny.",
	:fullDesc => "Increases Attack and Special Defense by 50% for itself and ally Pokémon."
},

:BADDREAMS => {
	:ID => 123,
	:name => "Bad Dreams",
	:desc => "Reduces a sleeping foe's HP.",
	:fullDesc => "Reduces a sleeping foe's HP by 1/8th of its max HP."
},

:PICKPOCKET => {
	:ID => 124,
	:name => "Pickpocket",
	:desc => "Steals an item when hit by another Pokémon."
},

:SHEERFORCE => {
	:ID => 125,
	:name => "Sheer Force",
	:desc => "Removes added effects to increase move damage.",
	:fullDesc => "Removes added effects to increase move damage by 30%."
},

:CONTRARY => {
	:ID => 126,
	:name => "Contrary",
	:desc => "Makes stat changes have an opposite effect."
},

:UNNERVE => {
	:ID => 127,
	:name => "Unnerve",
	:desc => "Makes the foe unable to eat Berries."
},

:DEFIANT => {
	:ID => 128,
	:name => "Defiant",
	:desc => "When a stat is lowered its Attack increases."
},

:DEFEATIST => {
	:ID => 129,
	:name => "Defeatist",
	:desc => "Lowers stats when HP becomes half or less.",
	:fullDesc => "Halves attacking stats when HP becomes half or less."
},

:CURSEDBODY => {
	:ID => 130,
	:name => "Cursed Body",
	:desc => "May disable a move used on the Pokémon."
},

:HEALER => {
	:ID => 131,
	:name => "Healer",
	:desc => "May heal an ally's status conditions."
},

:FRIENDGUARD => {
	:ID => 132,
	:name => "Friend Guard",
	:desc => "Reduces damage done to allies.",
	:fullDesc => "Reduces damage done to allies by 25%, stacking multiplicatively."
},

:WEAKARMOR => {
	:ID => 133,
	:name => "Weak Armor",
	:desc => "Physical attacks lower Def. and sharply raise Spd."
},

:HEAVYMETAL => {
	:ID => 134,
	:name => "Heavy Metal",
	:desc => "Doubles the Pokémon's weight."
},

:LIGHTMETAL => {
	:ID => 135,
	:name => "Light Metal",
	:desc => "Halves the Pokémon's weight."
},

:MULTISCALE => {
	:ID => 136,
	:name => "Multiscale",
	:desc => "Halves damage when HP is full."
},

:TOXICBOOST => {
	:ID => 137,
	:name => "Toxic Boost",
	:desc => "Poison increases Atk. Gains Poison STAB.",
	:fullDesc => "Powers up physical attacks when poisoned by 50%. Gains Poison STAB."
},

:FLAREBOOST => {
	:ID => 138,
	:name => "Flare Boost",
	:desc => "Burn increases SpA. Gains Fire STAB.",
	:fullDesc => "Powers up special moves when burned by 50%. Gains Fire STAB."
},

:HARVEST => {
	:ID => 139,
	:name => "Harvest",
	:desc => "May create another Berry after one is used."
},

:TELEPATHY => {
	:ID => 140,
	:name => "Telepathy",
	:desc => "User and ally foresee and dodge each other's attacks."
},

:MOODY => {
	:ID => 141,
	:name => "Moody",
	:desc => "Nature modifies stats by 30% instead of 10%.",
	:fullDesc => "Nature modifies stats by 30% instead of 10%."
},

:OVERCOAT => {
	:ID => 142,
	:name => "Overcoat",
	:desc => "Protects the Pokémon from damage from weather."
},

:POISONTOUCH => {
	:ID => 143,
	:name => "Poison Touch",
	:desc => "May poison targets upon contact."
},

:REGENERATOR => {
	:ID => 144,
	:name => "Regenerator",
	:desc => "Restores HP when withdrawn from battle.",
	:fullDesc => "Restores HP when withdrawn from battle by 33% max HP."
},

:BIGPECKS => {
	:ID => 145,
	:name => "Big Pecks",
	:desc => "Protects the Pokémon from Defense-lowering."
},

:SANDRUSH => {
	:ID => 146,
	:name => "Sand Rush",
	:desc => "Doubles the Pokémon's Speed in a sandstorm."
},

:WONDERSKIN => {
	:ID => 147,
	:name => "Wonder Skin",
	:desc => "Makes foes' status moves more likely to miss.",
	:fullDesc => "Makes foes' status 50% more likely to miss unless already below 50% accuracy."
},

:ANALYTIC => {
	:ID => 148,
	:name => "Analytic",
	:desc => "Boosts damage when the Pokémon moves after the target.",
	:fullDesc => "Boosts move power by 30% if the Pokémon moves after the target."
},

:ILLUSION => {
	:ID => 149,
	:name => "Illusion",
	:desc => "Comes out disguised as the Pokémon in back."
},

:IMPOSTER => {
	:ID => 150,
	:name => "Imposter",
	:desc => "Transforms itself into the foe it is facing."
},

:INFILTRATOR => {
	:ID => 151,
	:name => "Infiltrator",
	:desc => "Passes through the foe's barrier and strikes."
},

:MUMMY => {
	:ID => 152,
	:name => "Mummy",
	:desc => "Contact with this Pokémon spreads this Ability."
},

:MOXIE => {
	:ID => 153,
	:name => "Moxie",
	:desc => "Boosts Attack after knocking out any Pokémon."
},

:JUSTIFIED => {
	:ID => 154,
	:name => "Justified",
	:desc => "Raises Attack when hit by a Dark-type move."
},

:RATTLED => {
	:ID => 155,
	:name => "Rattled",
	:desc => "Some move types scare it and boost its Speed.",
	:fullDesc => "Bug, Dark, and Ghost type moves that deal damage boost its Speed. Also activates against Intimidate."
},

:MAGICBOUNCE => {
	:ID => 156,
	:name => "Magic Bounce",
	:desc => "Reflects status-changing moves."
},

:SAPSIPPER => {
	:ID => 157,
	:name => "Sap Sipper",
	:desc => "Boosts Attack when hit by a Grass-type move."
},

:PRANKSTER => {
	:ID => 158,
	:name => "Prankster",
	:desc => "Gives priority to a status move."
},

:SANDFORCE => {
	:ID => 159,
	:name => "Sand Force",
	:desc => "Boosts certain moves' power in a sandstorm.",
	:fullDesc => "Boosts Rock, Steel, and Ground type moves by 50% in a sandstorm, and takes no damage from sandstorm."
},

:IRONBARBS => {
	:ID => 160,
	:name => "Iron Barbs",
	:desc => "Inflicts damage to the Pokémon on contact.",
	:fullDesc => "Inflicts damage to the Pokémon on contact equal to 1/8th of its max HP."
},

:ZENMODE => {
	:ID => 161,
	:name => "Zen Mode",
	:desc => "Changes the Pokémon's shape when HP is halved."
},

:VICTORYSTAR => {
	:ID => 162,
	:name => "Victory Star",
	:desc => "Boosts the accuracy of its allies and itself.",
	:fullDesc => "Boosts the accuracy of its allies and itself by 10%. This ability may stack multiplicatively."
},

:TURBOBLAZE => {
	:ID => 163,
	:name => "Turboblaze",
	:desc => "Moves can be used regardless of Abilities."
},

:TERAVOLT => {
	:ID => 164,
	:name => "Teravolt",
	:desc => "Moves can be used regardless of Abilities."
},

:AERILATE => {
	:ID => 165,
	:name => "Aerilate",
	:desc => "Normal-type moves become Flying-type moves.",
	:fullDesc => "Normal-type moves become Flying-type moves and deal 20% more damage."
},

:AROMAVEIL => {
	:ID => 166,
	:name => "Aroma Veil",
	:desc => "Protects allies from moves that effect their mind."
},

:AURABREAK => {
	:ID => 167,
	:name => "Aura Break",
	:desc => "The effects of Aura Abilities are reversed."
},

:BULLETPROOF => {
	:ID => 168,
	:name => "Bulletproof",
	:desc => "Protects the Pokémon from ball and bomb moves."
},

:CHEEKPOUCH => {
	:ID => 169,
	:name => "Cheek Pouch",
	:desc => "Restores HP when the Pokémon eats a Berry.",
	:fullDesc => "Restores 33% of the Pokémon's max HP when it eats a Berry."
},

:COMPETITIVE => {
	:ID => 170,
	:name => "Competitive",
	:desc => "Boosts the Sp. Atk stat when a stat is lowered."
},

:DARKAURA => {
	:ID => 171,
	:name => "Dark Aura",
	:desc => "Powers up each Pokémon's Dark-type moves.",
	:fullDesc => "Powers up each Pokémon's Dark-type moves by 33%."
},

:FAIRYAURA => {
	:ID => 172,
	:name => "Fairy Aura",
	:desc => "Powers up each Pokémon's Fairy-type moves.",
	:fullDesc => "Powers up each Pokémon's Fairy-type moves by 33%."
},

:FLOWERVEIL => {
	:ID => 173,
	:name => "Flower Veil",
	:desc => "Prevents lowering of ally Grass-type stats."
},

:FURCOAT => {
	:ID => 174,
	:name => "Fur Coat",
	:desc => "Halves damage from physical moves."
},

:GALEWINGS => {
	:ID => 175,
	:name => "Gale Wings",
	:desc => "Gives priority to Flying-type moves when HP is full."
},

:GOOEY => {
	:ID => 176,
	:name => "Gooey",
	:desc => "Contact lowers the foe's Speed stat."
},

:GRASSPELT => {
	:ID => 177,
	:name => "Grass Pelt",
	:desc => "Boosts Defense when the terrain is grass."
},

:MAGICIAN => {
	:ID => 178,
	:name => "Magician",
	:desc => "The Pokémon steals the foe's held item on contact."
},

:MEGALAUNCHER => {
	:ID => 179,
	:name => "Mega Launcher",
	:desc => "Powers up aura and pulse moves.",
	:fullDesc => "Powers up aura and pulse moves by 50%. Heal Pulse heals by 75%."
},

:PARENTALBOND => {
	:ID => 180,
	:name => "Parental Bond",
	:desc => "Parent and child attack together.",
	:fullDesc => "Each attack deals an additional 25% damage and rolls effects separately, except for Secret Power."
},

:PIXILATE => {
	:ID => 181,
	:name => "Pixilate",
	:desc => "Normal-type moves become Fairy-type moves.",
	:fullDesc => "Normal-type moves become Fairy-type moves and deal 20% more damage."
},

:PROTEAN => {
	:ID => 182,
	:name => "Protean",
	:desc => "Changes the Pokémon's type to its move used."
},

:REFRIGERATE => {
	:ID => 183,
	:name => "Refrigerate",
	:desc => "Normal-type moves become Ice-type moves.",
	:fullDesc => "Normal-type moves become Ice-type moves and deal 20% more damage."
},

:STANCECHANGE => {
	:ID => 184,
	:name => "Stance Change",
	:desc => "The Pokémon changes form depending on moves."
},

:STRONGJAW => {
	:ID => 185,
	:name => "Strong Jaw",
	:desc => "The power of biting moves is increased.",
	:fullDesc => "The power of biting moves is increased by 50%."
},

:SWEETVEIL => {
	:ID => 186,
	:name => "Sweet Veil",
	:desc => "Prevents ally Pokémon from falling asleep."
},

:SYMBIOSIS => {
	:ID => 187,
	:name => "Symbiosis",
	:desc => "The Pokémon can pass an item to an ally."
},

:TOUGHCLAWS => {
	:ID => 188,
	:name => "Tough Claws",
	:desc => "Powers up moves that make direct contact."
},

:PRIMORDIALSEA => {
	:ID => 189,
	:name => "Primordial Sea",
	:desc => "Summons heavy rain when on the field.",
	:fullDesc => "Summons heavy rain and nullifies any Fire-type attacks while on the field."
},

:DESOLATELAND => {
	:ID => 190,
	:name => "Desolate Land",
	:desc => "Summons extreme sunlight when on the field.",
	:fullDesc => "Summons extremely harsh sunlight and nullifies any Water-type attacks while on the field."
},

:DELTASTREAM => {
	:ID => 191,
	:name => "Delta Stream",
	:desc => "Summons strong winds when on the field.",
	:fullDesc => "Summons strong winds and removes Flying-type weaknesses while on the field."
},

:BATTERY => {
	:ID => 192,
	:name => "Battery",
	:desc => "Powers up ally Pokémon's special moves.",
	:fullDesc => "Increases the power of ally Pokémon's special moves by 30%."
},

:BEASTBOOST => {
	:ID => 193,
	:name => "Beast Boost",
	:desc => "Boosts highest stat after KO'ing a Pokémon."
},

:BERSERK => {
	:ID => 194,
	:name => "Berserk",
	:desc => "Boosts Sp. Atk when a hit drops HP below half."
},

:COMATOSE => {
	:ID => 195,
	:name => "Comatose",
	:desc => "It's always asleep, and attacks without waking up."
},

:CORROSION => {
	:ID => 196,
	:name => "Corrosion",
	:desc => "Poison attacks damage Steel. Can Poison targets of any type.",
},

:DANCER => {
	:ID => 197,
	:name => "Dancer",
	:desc => "Dances with others, duplicating their moves."
},

:DAZZLING => {
	:ID => 198,
	:name => "Dazzling",
	:desc => "Surprises the opponent, preventing priority moves."
},

:ELECTRICSURGE => {
	:ID => 199,
	:name => "Electric Surge",
	:desc => "Electrifies the terrain on entry."
},

:EMERGENCYEXIT => {
	:ID => 200,
	:name => "EmergencyExit",
	:desc => "It retreats when its HP becomes half or less."
},

:FLUFFY => {
	:ID => 201,
	:name => "Fluffy",
	:desc => "Weakens contact moves, but doubles Fire damage."
},

:FULLMETALBODY => {
	:ID => 202,
	:name => "Full Metal Body",
	:desc => "Prevents other Pokémon from lowering its stats."
},

:GALVANIZE => {
	:ID => 203,
	:name => "Galvanize",
	:desc => "Normal-type moves become Electric-type moves.",
	:fullDesc => "Normal-type moves become Electric-type moves and deal 20% more damage."
},

:GRASSYSURGE => {
	:ID => 204,
	:name => "Grassy Surge",
	:desc => "Makes the terrain grassy on entry."
},

:INNARDSOUT => {
	:ID => 205,
	:name => "Innards Out",
	:desc => "Damages the attacker the same amount when fainted."
},

:LIQUIDVOICE => {
	:ID => 206,
	:name => "Liquid Voice",
	:desc => "Sound becomes Water, is 1.2x, & ignores abilities."
},

:LONGREACH => {
	:ID => 207,
	:name => "Long Reach",
	:desc => "This Pokémon's moves do not make contact."
},

:MERCILESS => {
	:ID => 208,
	:name => "Merciless",
	:desc => "Critically hits statused Pokémon without fail."
},

:MISTYSURGE => {
	:ID => 209,
	:name => "Misty Surge",
	:desc => "Makes the terrain misty on entry."
},

:POWEROFALCHEMY => {
	:ID => 210,
	:name => "Alchemy",
	:desc => "The Pokémon copies the Ability of a defeated ally."
},

:PRISMARMOR => {
	:ID => 211,
	:name => "Prism Armor",
	:desc => "Reduces damage from supereffective attacks.",
	:fullDesc => "Reduces damage dealt by super effective moves by 25%. Cannot be ignored by moves or abilities."
},

:PSYCHICSURGE => {
	:ID => 212,
	:name => "Psychic Surge",
	:desc => "Makes the terrain mysterious on entry."
},

:QUEENLYMAJESTY => {
	:ID => 213,
	:name => "Q. Majesty",
	:fullName => "Queenly Majesty",
	:desc => "Pressures the opponent, preventing priority moves."
},

:RECEIVER => {
	:ID => 214,
	:name => "Receiver",
	:desc => "The Pokémon receives the Ability of a defeated ally."
},

:SHADOWSHIELD => {
	:ID => 215,
	:name => "Shadow Shield",
	:desc => "Halves damage when HP is full.",
	:fullDesc => "Halves damage when HP is full."
},

:SLUSHRUSH => {
	:ID => 216,
	:name => "Slush Rush",
	:desc => "Doubles the Pokémon's Speed stat in a hailstorm."
},

:SOULHEART => {
	:ID => 217,
	:name => "Soul-heart",
	:desc => "Boosts its Sp. Atk every time a Pokémon faints."
},

:STAKEOUT => {
	:ID => 218,
	:name => "Stakeout",
	:desc => "Doubles damage to newly switched-in targets."
},

:STAMINA => {
	:ID => 219,
	:name => "Stamina",
	:desc => "Boosts the Defense stat when hit by an attack."
},

:STEELWORKER => {
	:ID => 220,
	:name => "Steelworker",
	:desc => "Powers up Steel-type moves.",
	:fullDesc => "Increases its respective stat by 50% when a Steel-type move is used."
},

:SURGESURFER => {
	:ID => 221,
	:name => "Surge Surfer",
	:desc => "Doubles the Speed stat on Electric Terrain."
},

:TANGLINGHAIR => {
	:ID => 222,
	:name => "Tangling Hair",
	:desc => "Contact lowers the foe's Speed stat."
},

:TRIAGE => {
	:ID => 223,
	:name => "Triage",
	:desc => "Gives priority to a healing move."
},

:WATERBUBBLE => {
	:ID => 224,
	:name => "Water Bubble",
	:desc => "Stops burns, halves Fire damage and boosts Water.",
	:fullDesc => "This Pokémon is immune to burns, takes 50% less damage from Fire-type moves, and deals 50% more damage with Water-type moves."
},

:WATERCOMPACTION => {
	:ID => 225,
	:name => "W. Compaction",
	:fullName => "Water Compaction",
	:desc => "Water moves are halved and sharply raise Defense." # lawds water compaction
},

:WIMPOUT => {
	:ID => 226,
	:name => "Wimp Out",
	:desc => "It wimps out when its HP becomes half or less."
},

:SCHOOLING => {
	:ID => 227,
	:name => "Schooling",
	:desc => "As long as it has high HP, it can form a school."
},

:RKSSYSTEM => {
	:ID => 228,
	:name => "RKS System",
	:desc => "Changes type to match the held memory disc."
},

:SHIELDSDOWN => {
	:ID => 229,
	:name => "Shields Down",
	:desc => "This Pokémon is protected by its shell above half HP."
},

:DISGUISE => {
	:ID => 230,
	:name => "Disguise",
	:desc => "This Pokémon's disguise can protect it from one hit."
},

:POWERCONSTRUCT => {
	:ID => 231,
	:name => "P. Construct",
	:fullName => "Power Construct",
	:desc => "Enters Complete Form when HP is half or less."
},

:BALLFETCH => {
	:ID => 232,
	:name => "Ball Fetch",
	:desc => "Ball and bomb moves hit twice as much at 65% power."
},

:COTTONDOWN => {
	:ID => 233,
	:name => "Cotton Down",
	:desc => "Lowers Speed of adjacent Pokémon when hit."
},

:DAUNTLESSSHIELD => {
	:ID => 234,
	:name => "Dauntless Shield",
	:desc => "Boosts the Pokémon's Defense stat upon entry."
},

:GORILLATACTICS => {
	:ID => 235,
	:name => "Gorilla Tactics",
	:desc => "Boosts attack and may only use one move.",
	:fullDesc => "Boosts the Pokémon's Attack stat by 50% and may only use the first selected move."
},

:GULPMISSILE => {
	:ID => 236,
	:name => "Gulp Missile",
	:desc => "Catches Pokémon with Surf and Dive, spits out when hit."
},

:HUNGERSWITCH => {
	:ID => 237,
	:name => "Hunger Switch",
	:desc => "Switches forms after every turn.",
	:fullDesc => "Changes between Full Belly Mode and Hangry Mode at the end of each turn. Additionally, Aura Wheel becomes Electric and Dark respectively."
},

:ICEFACE => {
	:ID => 238,
	:name => "Ice Face",
	:desc => "Can take a physical attack once.",
	:fullDesc => "Can take a physical attack once. This effect is restored once when it hails."
},

:ICESCALES => {
	:ID => 239,
	:name => "Ice Scales",
	:desc => "Halves the damage taken from special moves."
},

:INTREPIDSWORD => {
	:ID => 240,
	:name => "Intrepid Sword",
	:desc => "Boosts the Pokémon's Attack stat upon entry."
},

:LIBERO => {
	:ID => 241,
	:name => "Libero",
	:desc => "Changes the Pokémon's type to its used move."
},

:MIMICRY => {
	:ID => 242,
	:name => "Mimicry",
	:desc => "The Pokémon changes type to match the terrain."
},

:MIRRORARMOR => {
	:ID => 243,
	:name => "Mirror Armor",
	:desc => "Reflects stat-changing moves."
},

:NEUTRALIZINGGAS => {
	:ID => 244,
	:name => "Neutralizing Gas",
	:desc => "Effects of abilities are nullified or prevented."
},

:PASTELVEIL => {
	:ID => 245,
	:name => "Pastel Veil",
	:desc => "Protects the user and allies from being poisoned."
},

:PERISHBODY => {
	:ID => 246,
	:name => "Perish Body",
	:desc => "Initiates a Perish count when hit by a contact move.",
	:fullDesc => "When hit by a contact move, both this Pokémon and the attacker are placed on a 3 turn Perish count."
},

:POWERSPOT => {
	:ID => 247,
	:name => "Power Spot",
	:desc => "Just being next to the Pokémon powers up moves.",
	:fullDesc => "Ally Pokémon's attacks are boosted by 30%."
},

:PROPELLERTAIL => {
	:ID => 248,
	:name => "Propeller Tail",
	:desc => "Ignores redirection.",
	:fullDesc => "This Pokémon ignores the effects of abilities and moves that would cause its moves to be redirected."
},

:PUNKROCK => {
	:ID => 249,
	:name => "Punk Rock",
	:desc => "Boosts damage of and resists sound based moves.",
	:fullDesc => "Sound-based moves deal 30% more damage and deal 50% less damage to this Pokémon."
},

:RIPEN => {
	:ID => 250,
	:name => "Ripen",
	:desc => "Ripens Berries and doubles their effect."
},

:SANDSPIT => {
	:ID => 251,
	:name => "Sand Spit",
	:desc => "Creates a sandstorm when it's hit by an attack."
},

:SCREENCLEANER => {
	:ID => 252,
	:name => "Screen Cleaner",
	:desc => "Removes own screens to boost stats.",
	:fullDesc => "Removes screens from its own side on switch-in, boosting stats depending on the screens."
},

:STALWART => {
	:ID => 253,
	:name => "Stalwart",
	:desc => "Ignores redirection.",
	:fullDesc => "This Pokémon ignores the effects of abilities and moves that would cause its moves to be redirected."
},

:STEAMENGINE => {
	:ID => 254,
	:name => "Steam Engine",
	:desc => "Fire and Water moves boost Speed drastically."
},

:STEELYSPIRIT => {
	:ID => 255,
	:name => "Steely Spirit",
	:desc => "Powers up self and ally Pokémon's Steel moves.",
	:fullDesc => "Steel-type moves are boosted by 50% when used by itself or allies, multiplicative."
},

:WANDERINGSPIRIT => {
	:ID => 256,
	:name => "W. Spirit",
	:fullName => "Wandering Spirit",
	:desc => "Swaps Abilities when hit by a contact move."
},

:NEUROFORCE => {
	:ID => 257,
	:name => "Neuroforce",
	:desc => "Powers up moves that are super effective.",
	:fullDesc => "Super effective moves deal an additional 25% damage."
},

:QUICKDRAW => {
	:ID => 258,
	:name => "Quick Draw",
	:desc => "The first move deals 30% more damage.",
},

:UNSEENFIST => {
	:ID => 259,
	:name => "Unseen Fist",
	:desc => "Physical contact bypasses Protect and similar."
},

:CURIOUSMEDICINE => {
	:ID => 260,
	:name => "Curious Med.",
	:fullName => "Curious Medicine",
	:desc => "Resets lowered ally stat changes on entry."
},

:TRANSISTOR => {
	:ID => 261,
	:name => "Transistor",
	:desc => "Powers up Electric-type moves.",
	:fullDesc => "Increases its respective stat by 50% when a Electric-type move is used."
},

:DRAGONSMAW => {
	:ID => 262,
	:name => "Dragon's Maw",
	:desc => "Powers up Dragon-type moves.",
	:fullDesc => "Increases its respective stat by 50% when a Dragon-type move is used."
},

:CHILLINGNEIGH => {
	:ID => 263,
	:name => "Chilling Neigh",
	:desc => "Boosts Attack when knocking out an opponent."
},

:GRIMNEIGH => {
	:ID => 264,
	:name => "Grim Neigh",
	:desc => "Boosts Sp. Atk when knocking out an opponent."
},

:ASONE => {
	:ID => 265,
	:name => "As One",
	:desc => "Combines abilities of fused Pokémon."
},

:SHARPNESS => {
	:ID => 266,
	:name => "Sharpness",
	:desc => "Powers up slicing moves.",
	:fullDesc => "Slicing moves deal 50% more damage."
},

:QUARKDRIVE => {
	:ID => 267,
	:name => "Quark Drive",
	:desc => "Boosts highest stat on Electric Terrain.",
	:fullDesc => "Raises the Pokémon's highest stat while on Electric Terrain by 30% (50% if highest stat is speed). Can also be activated with Booster Energy."
},

:REFLECTOR => {
	:ID => 300,
	:name => "Reflector",
	:desc => "Gains the opponent's secondary typing on entry. Reflects status-changing moves back on the user."
},

#:SHIFT => {
#	:ID => 301,
#	:name => "Shift",
#	:desc => "Adjusts the body to adapt to environments."
#},

:TRUESHOT => {
	:ID => 302,
	:name => "True Shot",
	:desc => "Increases the damage of Ball and Bomb moves.",
	:fullDesc => "Increases the damage of all Ball and Bomb moves by 30%."
},

:ACCUMULATION => {
	:ID => 303,
	:name => "Accumulation",
	:desc => "This Pokémon stockpiles every turn."
},

:TEMPORALSHIFT => {
	:ID => 304,
	:name => "Temporal Shift",
	:desc => "Ignores stat drops and uses Hex.",
	:fullDesc => "This Pokémon's stats cannot be lowered. Additionally, Hex is automatically used every turn, dealing damage in 3 turns."
},

:EXECUTION => {
	:ID => 305,
	:name => "Execution",
	:desc => "This Pokémon hits harder the lower the target's health is."
},

:RESUSCITATION => {
	:ID => 306,
	:name => "Resuscitation",
	:desc => "Enters Zombie Form after being knocked out once."
},

:TEMPEST => {
	:ID => 307,
	:name => "Storm 9",
	:desc => "Randomly changes weather at the end of the turn."
},

:SOLARIDOL => {
	:ID => 308,
	:name => "Solar Idol",
	:desc => "The fiery will of the sun empowers this Pokémon.",
	:fullDesc => "Fire-type moves deal 50% more damage, Attack is boosted by 50% in the Sun, and is immune to Ground-type moves."#"STAB Fire moves. 50% ATK boost in Sun. Levitates."
},

:LUNARIDOL => {
	:ID => 309,
	:name => "Lunar Idol",
	:desc => "The icy will of the moon empowers this Pokémon.",
	:fullDesc => "Ice-type moves deal 50% more damage, Special Attack is boosted by 50% in Hail, and is immune to Ground-type moves."
},

:WORLDOFNIGHTMARES => {
	:ID => 310,
	:name => "Waking Nightmare",
	:fullName => "Waking Nightmare",
	:desc => "An all-encompassing nightmare.",
	:fullDesc => "Immune to sleep. Can freely use Nightmare/Dream Eater. Activates Hex for the user. "
},

:INEXORABLE => {
	:ID => 311,
	:name => "Inexorable",
	:desc => "Dragon-type moves are stronger on slower foes.",
	:fullDesc => "Dragon-type moves deal 30% more damage against foes slower than this Pokémon."
},

:STOPPN => {
	:ID => 312,
	:name => "Stop \\PN",
	:desc => "Poison damage lowers Defenses.",
	:fullDesc => "Any Pokémon in battle taking damage from the (Badly) Poisoned status lowers defenses by one stage."
},

:PRISMPOWER => {
	:ID => 313,
	:name => "Prism Power",
	:desc => "Raises stats once per battle.",
	:fullDesc => "Increases the user's Attack, Defense, Sp. Attack, Sp, Defense and Speed one stage upon switching in, once per battle."
},

:NIGHTTERROR => {
	:ID => 318,
	:name => "Night Terror",
	:desc => "Boosts Speed whenever sleep is induced.",
	:fullDesc => "Grants a boost to Speed whenever sleep is induced in any Pokemon other than the user."
},

:GOODASGOLD => {
	:ID => 316,
	:name => "Good as Gold",
	:desc => "Grants full immunity to status moves."
},

:ANGERSHELL => {
	:ID => 314,
	:name => "Anger Shell",
	:desc => "Gets a powerful boost at HP half or less.",
	:fullDesc => "When an attack causes its HP to drop to half or less, the Pokémon gets angry. This lowers its Defenses but boosts its Attack, Sp. Atk, and Speed."
},

:ARMORTAIL => {
	:ID => 315,
	:name => "Armor Tail",
	:desc => "Prevents opponents from using priority moves.",
},

:BEADSOFRUIN => {
	:ID => 316,
	:name => "Beads of Ruin",
	:desc => "Ruinous beads lower the Sp. Def of all Pokémon except the user.",
	:fullDesc => "The power of the Pokémon's ruinous beads lowers the Sp. Def stats of all Pokémon except itself."
},

:COMMANDER => {
	:ID => 317,
	:name => "Commander",
	:desc => "Pairs up and commands with an active Dondozo.",
	:fullDesc => "When the Pokémon enters a battle, it goes inside the mouth of an ally Dondozo if one is on the field. The Pokémon then issues commands from there."
},

:COSTAR => {
	:ID => 318,
	:name => "Costar",
	:desc => "Copies an ally's stat changes on switch-in.",
	:fullDesc => "When the Pokémon enters a battle, it copies an ally's stat changes."
},

:CUDCHEW => {
	:ID => 319,
	:name => "Cud Chew",
	:desc => "Reuses an eaten Berry at the end of the next turn.",
	:fullDesc => "When the Pokémon eats a Berry, it will regurgitate that Berry at the end of the next turn and eat it one more time."
},

:EARTHEATER => {
	:ID => 320,
	:name => "Earth Eater",
	:desc => "Restores HP if hit by a Ground-type move."
},

:ELECTROMORPHOSIS => {
	:ID => 321,
	:name => "Electromorphosis",
	:desc => "Charges Pokémon upon taking damage.",
	:fullDesc => "The Pokémon becomes charged when it takes damage, boosting the power of the next Electric-type move the Pokémon uses."
},

#:GOODASGOLD => {
#	:ID => 322,
#	:name => "Good as Gold",
#	:desc => "The Pokémon becomes immune to status moves...",
#	:fullDesc => "A body of pure, solid gold gives the Pokémon full immunity to other Pokémon's status moves."
#},

:GUARDDOG => {
	:ID => 323,
	:name => "Guard Dog",
	:desc => "Intimidation boosts Atk and stands ground.",
	:fullDesc => "Boosts the Pokémon’s Attack stat if intimidated. Moves and items that would force the Pokémon to switch out also fail to work."
},

:HADRONENGINE => {
	:ID => 324,
	:name => "Hadron Engine",
	:desc => "Summons Electric Terrain and boosts Sp. Atk.",
	:fullDesc => "Turns the ground into Electric Terrain when the Pokémon enters a battle. Also boosts its Sp. Atk stat on Electric Terrain."
},

:LINGERINGAROMA => {
	:ID => 325,
	:name => "Lingering Aroma",
	:desc => "Contact with this Pokémon spreads this Ability.",
	:fullDesc => "Contact with the Pokémon changes the attacker's Ability to Lingering Aroma."
},

:MYCELIUMMIGHT => {
	:ID => 326,
	:name => "Mycelium Might",
	:desc => "Powder moves also deal damage, but can't have priority.",
	:fullDesc => "Powder moves become Special attacks with base power equal to the user's level, that also inflict the effect of the move. They cannot be used with high priority."
},

:OPPORTUNIST => {
	:ID => 327,
	:name => "Opportunist",
	:desc => "Copies an opponent's stat boost during a turn.",
	:fullDesc => "If an opponent's stat is boosted, the Pokémon seizes the opportunity to boost the same stat for itself."
},

:ORICHALCUMPULSE => {
	:ID => 328,
	:name => "Orichalcum Pulse",
	:desc => "Summons harsh sunlight and boosts Attack in sunlight.",
	:fullDesc => "Turns the sunlight harsh when the Pokémon enters a battle. Also boosts its Attack stat in harsh sunlight."
},

:PROTOSYNTHESIS => {
	:ID => 329,
	:name => "Protosynthesis",
	:desc => "Boosts its best stat in harsh sunlight.",
	:fullDesc => "Raises the Pokémon's highest stat while in harsh sunlight by 30% (50% if highest stat is speed). Can also be activated with Booster Energy."
},

:PURIFYINGSALT => {
	:ID => 330,
	:name => "Purifying Salt",
	:desc => "Protects from statuses and Ghost-type moves.",
	:fullDesc => "The Pokémon's pure salt protects it from status conditions and halves the damage taken from Ghost-type moves."
},

#:QUARKDRIVE => {
#	:ID => 331,
#	:name => "Quark Drive",
#	:desc => "Boosts its best stat in Electric Terrain."
#	:fullDesc => ""
#},

:ROCKYPAYLOAD => {
	:ID => 332,
	:name => "Rocky Payload",
	:desc => "Powers up Rock-type moves."
},

:SEEDSOWER => {
	:ID => 333,
	:name => "Seed Sower",
	:desc => "Summons Grassy Terrain upon taking damage."
},

#:SHARPNESS => {
#	:ID => 334,
#	:name => "Sharpness",
#	:desc => "Powers up slicing moves."
#	:fullDesc => ""
#},

:SUPREMEOVERLORD => {
	:ID => 335,
	:name => "Supreme Overlord",
	:desc => "Gains power with every fainted ally.",
	:fullDesc => "Upon entering battle, its Attack and Sp. Atk stats are slightly boosted for each of the allies in its party that have already been defeated."
},

:SWORDOFRUIN => {
	:ID => 336,
	:name => "Sword of Ruin",
	:desc => "A ruinous sword lowers the Defense of all Pokémon except the user.",
	:fullDesc => "The power of the Pokémon's ruinous sword lowers the Defense stats of all Pokémon except itself."
},

:TABLETSOFRUIN => {
	:ID => 337,
	:name => "Tablets of Ruin",
	:desc => "Ruinous tablets lower the Attack of all Pokémon except the user.",
	:fullDesc => "The power of the Pokémon's ruinous wooden tablets lowers the Attack stats of all Pokémon except itself."
},

:THERMALEXCHANGE => {
	:ID => 338,
	:name => "Thermal Exchange",
	:desc => "Boosts Atk from Fire and prevents burns.",
	:fullDesc => "Boosts the Attack stat when the Pokémon is hit by a Fire-type move. The Pokémon also cannot be burned."
},

:TOXICDEBRIS => {
	:ID => 339,
	:name => "Toxic Debris",
	:desc => "Scatters poison spikes on contact."
},

:VESSELOFRUIN => {
	:ID => 340,
	:name => "Vessel of Ruin",
	:desc => "A ruinous vessel lowers the Sp. Atk of all Pokémon except the user.",
	:fullDesc => "The power of the Pokémon's ruinous vessel lowers the Sp. Atk stats of all Pokémon except itself."
},

:WELLBAKEDBODY => {
	:ID => 341,
	:name => "Well-Baked Body",
	:desc => "Sharply raises Defense if hit by an Fire-type move."
},

:WINDPOWER => {
	:ID => 342,
	:name => "Wind Power",
	:desc => "Pokémon becomes charged from Wind-based moves.",
	:fullDesc => "The Pokémon becomes charged when it is hit by a wind move, boosting the power of the next Electric-type move the Pokémon uses."
},

:WINDRIDER => {
	:ID => 343,
	:name => "Wind Rider",
	:desc => "Boosts Attack in Tailwind or from Wind moves.",
	:fullDesc => "Boosts the Pokémon's Attack stat if Tailwind takes effect or if the Pokémon is hit by a wind move. Also takes no damage from wind moves."
},

:ZEROTOHERO => {
	:ID => 344,
	:name => "Zero to Hero",
	:desc => "Transforms into its Hero Form when it switches out."
},

:SUPERSWEETSYRUP => {
	:ID => 345,
	:name => "Supersweet Syrup",
	:desc => "Lowers the opposing side's evasion once per battle.",
	:fullDesc => "A sickly sweet scent spreads across the field the first time the Pokémon enters a battle, lowering the evasiveness of opposing Pokémon."
},

:HOSPITALITY => {
	:ID => 346,
	:name => "Hospitality",
	:desc => "Restores ally's HP a little when entering battle."
},

:TOXICCHAIN => {
	:ID => 347,
	:name => "Toxic Chain",
	:desc => "Attacks always poison the target.",
	:fullDesc => "The power of the Pokémon's toxic chain will poison any target the Pokémon hits with a move."
},

:MINDSEYE => {
	:ID => 348,
	:name => "Mind's Eye",
	:desc => "Ignores Ghost Immunities + Psychic STAB.",
	:fullDesc => "Ignores changes to opponents' evasiveness, its accuracy can't be lowered, and it can hit Ghost types with Normal-and Fighting-type moves, gains Psychic STAB."
},

:EMBODYASPECT => {
	:ID => 349,
	:name => "Embody Aspect",
	:desc => "The user's shining mask raises its Speed stat.",
	:fullDesc => "The Pokémon's heart fills with memories, causing the Teal Mask to shine and the Pokémon's Speed stat to be boosted."
},

:EMBODYASPECT_1 => {
	:ID => 350,
	:name => "Embody Aspect",
	:desc => "The user's shining mask raises its Sp. Def stat.",
	:fullDesc => "The Pokémon's heart fills with memories, causing the Wellspring Mask to shine and the Pokémon's Sp. Def stat to be boosted."
},

:EMBODYASPECT_2 => {
	:ID => 351,
	:name => "Embody Aspect",
	:desc => "The user's shining mask raises its Attack stat.",
	:fullDesc => "The Pokémon's heart fills with memories, causing the Hearthflame Mask to shine and the Pokémon's Attack stat to be boosted."
},

:EMBODYASPECT_3 => {
	:ID => 352,
	:name => "Embody Aspect",
	:desc => "The user's shining mask raises its Defense stat.",
	:fullDesc => "The Pokémon's heart fills with memories, causing the Cornerstone Mask to shine and the Pokémon's Defense stat to be boosted."
},

:TERASHIFT => {
	:ID => 353,
	:name => "Tera Shift",
	:desc => "Transforms upon entering battle.",
	:fullDesc => "When the Pokémon enters a battle, it absorbs the energy around itself and transforms into its Terastal Form."
},

:TERASHELL => {
	:ID => 354,
	:name => "Tera Shell",
	:desc => "Resists all types when HP is full.",
	:fullDesc => "The Pokémon’s shell contains the powers of each type. All damage-dealing moves that hit the Pokémon when its HP is full will not be very effective."
},

:TERAFORMZERO => {
	:ID => 355,
	:name => "Teraform Zero",
	:desc => "Eliminates the effects of weather and terrains.",
	:fullDesc => "When Terapagos changes into its Stellar Form, it uses its hidden powers to eliminate all effects of weather and terrain, reducing them to zero."
},

:POISONPUPPETEER => {
	:ID => 379,
	:name => "Poison Puppeteer",
	:desc => "Poisoning a target will also confuse it."
},

:BADSEEDS => { # Arboliva
	:ID => 380,
	:name => "Bad Seeds",
	:desc => "Engulfs the field in ice-cold hate.",
},

:WATERRETENTION => { # Glimmora
	:ID => 386,
	:name => "Water Retention",
	:desc => "Soaks enemies that make contact.",
},

:SPIRITSENVOY => { # Aurorus
	:ID => 388,
	:name => "Spirit's Envoy",
	:desc => "Draws enemy Ghost moves. Boosts Ghost-type moves.",
},

:EIDOLON => { # Lanturn
	:ID => 389,
	:name => "Eidolon",
	:desc => "Copies the ability of the Pokemon it replaces.",
},

:LITTLEKING => { # Politoed
	:ID => 390,
	:name => "Little King",
	:desc => "Its target takes 30% more damage, 50% from allies.",
	:fullDesc => "When it targets a single enemy, enemy takes 30% more damage from the user and 50% more from the ally, until another single enemy is targeted."
},

:HITANDRUN => {
	:ID => 391,
	:name => "Hit and Run",
	:desc => "It switches out after it KOs using non-priority.",
},

:BATTLEBOND => { # lawds battle bond not for u dingus
	:ID => 392,
	:name => "Battle Bond",
	:desc => "Changes to Battle Bond form.",
},

:ENTOMOPHAGY => {
	:ID => 393,
	:name => "Entomophagy",
	:desc => "Restores HP from Bug-type moves."
},

:JUGGERNAUT => {
	:ID => 394,
	:name => "Juggernaut",
	:desc => "Its moves never weaken or tire it.",
	:fullDesc => "Its moves will not lower its own stats, force it to recharge, or restrict its actions."
},

:SENTINEL => {
	:ID => 395,
	:name => "Sentinel",
	:desc => "Special attacks become physical.",
},

:OUTCRY => {
	:ID => 396,
	:name => "Outcry",
	:desc => "Sound-based attacks confuse targets.",
},

:MEGASOL => {
	:ID => 397,
	:name => "Mega Sol",
	:desc => "Its moves always act as though it's sunny.",
},

:CONDUCTION => {
	:ID => 398,
	:name => "Conduction",
	:desc => "After using an Electric attack, sets Electric Terrain.",
},

:MASTERMIND => {
	:ID => 399,
	:name => "Mastermind",
	:desc => "Doubles the Pokemon's Special Attack.",
},

:PAYDAYABIL => {
	:ID => 400,
	:name => "Pay Day",
	:desc => "Get an extra $250 after battle.",
},

:SECONDSCOOP => {
	:ID => 401,
	:name => "Second Scoop",
	:desc => "After using an Ice attack, sets Hail.",
},

:FLAMESPOUT => {
	:ID => 402,
	:name => "Flame Spout",
	:desc => "Creates harsh sunlight when it's hit by an attack."
},

:GASLEAK => {
	:ID => 403,
	:name => "Gas Leak",
	:desc => "Creates misty terrain when it's hit by an attack."
},

:DOMAINEXPANSION => {
	:ID => 404,
	:name => "Domain Expansion",
	:desc => "After using a Psychic attack, sets Psychic Terrain.",
},

:STORMLORD => {
	:ID => 405,
	:name => "Storm Lord",
	:desc => "After using a Water attack, sets Rain.",
},

##################################
# Lawds Mod - Gmax Abilities
##################################
:DUSTDEVIL => { # Sandaconda
	:ID => 381,
	:name => "Dust Devil",
	:desc => "In sand, Speed is doubled and moves never miss.",
},
:RAMPANTGROWTH => { # Venusaur
	:ID => 382,
	:name => "Rampant Growth",
	:desc => "Grass attacks are stronger and hit both opponents.",
},
:WILDFIRE => {
	:ID => 387,
	:name => "Wildfire",
	:desc => "In Sun, it loses weaknesses of Flying type & moves never miss.",
},
:DREADNOUGHT => { # Blastoise
	:ID => 383,
	:name => "Dreadnought",
	:desc => "Special moves hit twice more for 25% per hit.",
},
:INDUSTRYSTANDARD => { # Duraludon
	:ID => 384,
	:name => "Industry Std.",
	:fullName => "Industry Standard",
	:desc => "Stats cannot be changed by any means.",
},
:SPIRITEATER => { # Gengar
	:ID => 385,
	:name => "Spirit Eater",
	:desc => "Saps enemy HP every turn. Physical moves restore HP.",
},
:SUGARRUSH => {	# Alcremie
	:ID => 314,
	:name => "Sugar Rush",
	:desc => "Lowers its Defense and boosts ally's Speed, once.",
},
}