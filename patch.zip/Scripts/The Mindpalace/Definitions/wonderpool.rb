WONDERPOOL = {
  :COMMON => {
    :VULPIX => [
      { moves: [:FLAMETHROWER, :EXTRASENSORY, :WILLOWISP, :CONFUSERAY], iv: 31 },
    ],
    :PIDGEOTTO => [
      { moves: [:FLY, :TAILWIND, :QUICKATTACK, :FEATHERDANCE], iv: 31 },
    ],
    :FLAAFFY => [
      { moves: [:CHARGEBEAM, :THUNDERWAVE, :ICEPUNCH, :LIGHTSCREEN], iv: 31 },
    ],
    :GRIMER => [
      { moves: [:SLUDGEBOMB, :MINIMIZE, :TOXIC, :MUDSHOT], iv: 31 },
    ],
    :GLIGAR => [
      { moves: [:ACROBATICS, :SLASH, :DIG, :KNOCKOFF], iv: 31 },
    ],
    :FURRET => [
      { moves: [:TIDYUP, :SLAM, :BRICKBREAK, :REST], iv: 31 },
    ],
    :PARASECT => [
      { moves: [:SPORE, :GROWTH, :SLASH, :FURYCUTTER], iv: 31 },
    ],
    :FRILLISH => [
      { moves: [:RECOVER, :WILLOWISP, :HEX, :BRINE], iv: 31 },
    ],
    :GIRAFARIG => [
      { moves: [:PSYBEAM, :AGILITY, :UPROAR, :ASSURANCE], iv: 31 },
    ],
    :LILEEP => [
      { moves: [:GIGADRAIN, :AMNESIA, :BRINE, :CONFUSERAY], iv: 31 },
    ],
    :CORSOLA => [
      { moves: [:NATUREPOWER, :BUBBLEBEAM, :ANCIENTPOWER, :RECOVER], iv: 31 },
    ],
    :SCRAGGY => [
      { moves: [:BRICKBREAK, :PAYBACK, :FAKEOUT, :SANDATTACK], iv: 31 },
    ],
    :MAREANIE => [
      { moves: [:STOCKPILE, :RECOVER, :TOXIC, :LIQUIDATION], iv: 31 },
    ],
    :VANILLISH => [
      { moves: [:ICICLESPEAR, :SELFDESTRUCT, :ICYWIND, :AUTOTOMIZE], iv: 31 },
    ],
    :PINECO => [
      { moves: [:BUGBITE, :EXPLOSION, :SPIKES, :GYROBALL], iv: 31 },
    ],
  },
  :RARE => {
    :AZUMARILL => [
      { moves: [:AMNESIA, :PLAYROUGH, :AQUATAIL, :BOUNCE], iv: 31 },
    ],
    :SCYTHER => [
      { moves: [:WINGATTACK, :BUGBITE, :SLASH, :SWORDSDANCE], iv: 31 },
    ],
    :CLEFABLE => [
      { moves: [:MOONBLAST, :METRONOME, :MOONLIGHT, :PSYCHIC], iv: 31 },
    ],
    :MEDICHAM => [
      { moves: [:HIJUMPKICK, :FAKEOUT, :ACUPRESSURE, :BULLETPUNCH], iv: 31 },
    ],
    :RAICHU => [
      { moves: [:THUNDERBOLT, :SURF, :EXTREMESPEED, :NASTYPLOT], iv: 31 },
    ],
    :HATTREM => [
      { moves: [:PSYCHIC, :DARKPULSE, :LIFEDEW, :PLAYNICE], iv: 31 },
    ],
    :GRAFAIAI => [
      { moves: [:SLASH, :UTURN, :POISONJAB, :PARTINGSHOT], iv: 31 },
    ],
    :GABITE => [
      { moves: [:DIG, :DRAGONCLAW, :SLASH, :BITE], iv: 31 },
    ],
    :MARSHTOMP => [
      { moves: [:MUDSHOT, :MUDDYWATER, :ROCKSLIDE, :ROCKSMASH], iv: 31 },
    ],
    :UNFEZANT => [
      { moves: [:AIRSLASH, :TAUNT, :HYPNOSIS, :FEATHERDANCE], iv: 31 },
    ],
    :ARAQUANID => [
      { ability: :WATERBUBBLE, moves: [:BUBBLEBEAM, :CRUNCH, :LUNGE, :SOAK], iv: 31 },
    ],
    :LINOONE => [
      { form: 1, moves: [:PARTINGSHOT, :HONECLAWS, :DOUBLEEDGE, :PINMISSILE], iv: 31 },
    ],
    :RAPIDASH => [
      { form: 1, moves: [:PSYCHOCUT, :MEGAHORN, :DAZZLINGGLEAM, :AGILITY], iv: 31 },
    ],
    :TORKOAL => [
      { moves: [:LAVAPLUME, :AMNESIA, :IRONDEFENSE, :YAWN], iv: 31 },
    ],
    :CROCALOR => [
      { moves: [:FLAMETHROWER, :YAWN, :SNARL, :SLACKOFF], iv: 31 },
    ],
  },
  :CAVECOMMON => {
    :MEOWTH => [
      { form: 2, moves: [:FAKEOUT, :METALCLAW, :HONECLAWS, :SHADOWCLAW], iv: 31 },
    ],
    :BOLDORE => [
      { moves: [:POWERGEM, :IRONDEFENSE, :HEADBUTT, :EXPLOSION], iv: 31 },
    ],
    :TIRTOUGA => [
      { moves: [:CURSE, :AQUAJET, :ROCKSLIDE, :DIG], iv: 31 },
    ],
    :SHUCKLE => [
      { moves: [:KNOCKOFF, :ROCKSLIDE, :BUGBITE, :REST], iv: 31 },
    ],
    :DUNSPARCE => [
      { moves: [:GLARE, :ANCIENTPOWER, :DRILLRUN, :YAWN], iv: 31 },
    ],
    :GOLBAT => [
      { moves: [:POISONFANG, :AIRCUTTER, :BITE, :LEECHLIFE], iv: 31 },
    ],
    :PSYDUCK => [
      { moves: [:ZENHEADBUTT, :AQUATAIL, :AMNESIA, :SOAK], iv: 31 },
    ],
    :EELEKTRIK => [
      { moves: [:THUNDERWAVE, :CRUNCH, :DISCHARGE, :CHARGEBEAM], iv: 31 },
    ],
    :TIMBURR => [
      { moves: [:LOWKICK, :ROCKSLIDE, :BULKUP, :SLAM], iv: 31 },
    ],
    :MISDREAVUS => [
      { moves: [:PSYBEAM, :HEX, :CONFUSERAY, :CURSE], iv: 31 },
    ],
    :DOTTLER => [
      { moves: [:CONFUSION, :STRUGGLEBUG, :REFLECT, :LIGHTSCREEN], iv: 31 },
    ],
    :SANDSLASH => [
      { moves: [:BULLDOZE, :RAPIDSPIN, :SWORDSDANCE, :FURYCUTTER], iv: 31 },
    ],
    :SANDSLASH => [
      { form: 1, moves: [:BLIZZARD, :IRONHEAD, :SNOWSCAPE, :METALBURST], iv: 31 },
    ],
    :QUAGSIRE => [
      { moves: [:SLAM, :YAWN, :AQUATAIL, :AMNESIA], iv: 31 },
    ],
  },
  :EXTREME => {
    :METANG => [
      { moves: [:EXPLOSION, :PSYCHIC, :BULLETPUNCH, :METEORMASH], iv: 31 },
    ],
    :FRAXURE => [
      { moves: [:DRAGONDANCE, :DRAGONPULSE, :SLASH, :IRONTAIL], iv: 31 },
    ],
    :TALONFLAME => [
      { moves: [:ACROBATICS, :FLAMECHARGE, :FLAREBLITZ, :TAILWIND], iv: 31 },
    ],
    :MILOTIC => [
      { moves: [:RECOVER, :SURF, :MIRRORCOAT, :DRAGONTAIL], iv: 31 },
    ],
    :MEOWSCARADA => [
      { moves: [:FLOWERTRICK, :SUCKERPUNCH, :LEECHSEED, :PLAYROUGH], iv: 31 },
    ],
    :ELECTIVIRE => [
      { moves: [:CROSSCHOP, :THUNDERBOLT, :METRONOME, :FLAMETHROWER], iv: 31 },
    ],
    :SCIZOR => [
      { moves: [:BULLETPUNCH, :SWORDSDANCE, :XSCISSOR, :WINGATTACK], iv: 31 },
    ],
    :WALREIN => [
      { moves: [:SURF, :BLIZZARD, :YAWN, :REST], iv: 31 },
    ],
    :KINGDRA => [
      { moves: [:DRAGONPULSE, :AGILITY, :YAWN, :HYDROPUMP], iv: 31 },
    ],
    :FLORGES => [
      { form: 1, moves: [:MOONBLAST, :GIGADRAIN, :METRONOME, :WISH], iv: 31 },
    ],
    :SCOVILLAIN => [
      { moves: [:FLAMETHROWER, :SEEDBOMB, :CRUNCH, :ZENHEADBUTT], iv: 31 },
    ],
    :GRENINJA => [
      { moves: [:EXTRASENSORY, :WATERSHURIKEN, :SPIKES, :NIGHTSLASH], iv: 31 },
    ],
    :SLOWBRO => [
      { form: 1, moves: [:SHELLSIDEARM, :PSYCHIC, :AMNESIA, :SLACKOFF], iv: 31 },
    ],
    :LUCARIO => [
      { moves: [:SWORDSDANCE, :AURASPHERE, :METEORMASH, :LIFEDEW], iv: 31 },
    ],
  },
}
