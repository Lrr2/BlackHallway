XTPOOL = {
  :common => { #tier
    :SEVIPER => [ # if all ev/iv are same, shorthand definition of integer.
      { level: 50, item: :POISONGEM, nature: :ADAMANT, moves: [:TRAILBLAZE, :CROSSPOISON, :NIGHTSLASH, :FIREFANG], ev: 25, iv: 10, ability: :SHEDSKIN },
      { level: 50, item: :POISONGEM, nature: :IMPISH, moves: [:FLAMETHROWER, :VENOMDRENCH, :KNOCKOFF, :POISONFANG], ev: 25, iv: 10, ability: :SHEDSKIN },
      { level: 50, item: :POISONGEM, nature: :BOLD, moves: [:GLARE, :TOXIC, :POISONJAB, :BULLDOZE], ev: 25, iv: 10, ability: :SHEDSKIN },
    ],
    :LUDICOLO => [
      { level: 50, item: :WATERGEM, nature: :MODEST, moves: [:SURF, :GIGADRAIN, :ICEPUNCH, :RAINDANCE], ev: 25, iv: 10, ability: :SWIFTSWIM },
      { level: 50, item: :GRASSGEM, nature: :CALM, moves: [:LEECHSEED, :GIGADRAIN, :SURF, :PROTECT], ev: 25, iv: 10, ability: :RAINDISH },
      { level: 50, item: :WATERGEM, nature: :TIMID, moves: [:SCALD, :ENERGYBALL, :ICEPUNCH, :SUBSTITUTE], ev: 25, iv: 10, ability: :RAINDISH },
    ],
    :GLIGAR => [
      { level: 50, item: :GROUNDGEM, nature: :IMPISH, moves: [:BULLDOZE, :ROOST, :TOXIC, :KNOCKOFF], ev: 25, iv: 10, ability: :IMMUNITY },
      { level: 50, item: :GROUNDGEM, nature: :JOLLY, moves: [:UTURN, :STEALTHROCK, :BULLDOZE, :ROOST], ev: 25, iv: 10, ability: :IMMUNITY },
      { level: 50, item: :FLYINGGEM, nature: :ADAMANT, moves: [:ACROBATICS, :BULLDOZE, :SWORDSDANCE, :ROOST], ev: 25, iv: 10, ability: :IMMUNITY },
    ],
    :QWILFISH => [
      { level: 50, item: :POISONGEM, nature: :JOLLY, moves: [:TOXICSPIKES, :PAINSPLIT, :PINMISSILE, :POISONJAB], ev: 25, iv: 10, ability: :POISONPOINT },
      { level: 50, item: :WATERGEM, nature: :ADAMANT, moves: [:MINIMIZE, :ROLLOUT, :WATERFALL, :RAINDANCE], ev: 25, iv: 10, ability: :SWIFTSWIM },
      { level: 50, item: :POISONGEM, nature: :CAREFUL, moves: [:THUNDERWAVE, :EXPLOSION, :POISONJAB, :WATERFALL], ev: 25, iv: 10, ability: :INTIMIDATE },
    ],
    :ABSOL => [
      { level: 50, item: :DARKGEM, nature: :JOLLY, moves: [:SUCKERPUNCH, :PLAYROUGH, :SWORDSDANCE, :NIGHTSLASH], ev: 25, iv: 10, ability: :PRESSURE },
      { level: 50, item: :DARKGEM, nature: :ADAMANT, moves: [:SUCKERPUNCH, :NIGHTSLASH, :KNOCKOFF, :PSYCHOCUT], ev: 25, iv: 10, ability: :PRESSURE },
      { level: 50, item: :DARKGEM, nature: :JOLLY, moves: [:SUCKERPUNCH, :SWORDSDANCE, :IRONTAIL, :PLAYROUGH], ev: 25, iv: 10, ability: :PRESSURE },
    ],
    :SABLEYE => [
      { level: 50, item: :DARKGEM, nature: :BOLD, moves: [:WILLOWISP, :KNOCKOFF, :RECOVER, :TAUNT], ev: 25, iv: 10, ability: :PRANKSTER },
      { level: 50, item: :GHOSTGEM, nature: :CAREFUL, moves: [:KNOCKOFF, :TAUNT, :WILLOWISP, :SHADOWSNEAK], ev: 25, iv: 10, ability: :PRANKSTER },
      { level: 50, item: :DARKGEM, nature: :IMPISH, moves: [:KNOCKOFF, :RECOVER, :FOULPLAY, :WILLOWISP], ev: 25, iv: 10, ability: :PRANKSTER },
    ],
    :MAWILE => [
      { level: 50, item: :FAIRYGEM, nature: :JOLLY, moves: [:PLAYROUGH, :METALCLAW, :STEALTHROCK, :FOULPLAY], ev: 25, iv: 10, ability: :INTIMIDATE },
      { level: 50, item: :STEELGEM, nature: :ADAMANT, moves: [:IRONHEAD, :SUCKERPUNCH, :THUNDERPUNCH, :ICEPUNCH], ev: 25, iv: 10, ability: :SHEERFORCE },
      { level: 50, item: :STEELGEM, nature: :MODEST, moves: [:FIREBLAST, :FLASHCANNON, :ICEBEAM, :FOCUSBLAST], ev: 25, iv: 10, ability: :SHEERFORCE },
    ],
    :ZANGOOSE => [
      { level: 50, item: :NORMALGEM, nature: :JOLLY, moves: [:FACADE, :BRICKBREAK, :QUICKATTACK, :SWORDSDANCE], ev: 25, iv: 10, ability: :TOXICBOOST },
      { level: 50, item: :NORMALGEM, nature: :ADAMANT, moves: [:BODYSLAM, :NIGHTSLASH, :BRICKBREAK, :QUICKATTACK], ev: 25, iv: 10, ability: :IMMUNITY },
      { level: 50, item: :NORMALGEM, nature: :JOLLY, moves: [:FINALGAMBIT, :BRICKBREAK, :KNOCKOFF, :QUICKATTACK], ev: 25, iv: 10, ability: :TOXICBOOST }
    ],
    :TROPIUS => [
      { level: 50, item: :GRASSGEM, nature: :ADAMANT, moves: [:RAZORLEAF, :BODYSLAM, :AIRSLASH, :SWEETSCENT], ev: 25, iv: 10, ability: :CHLOROPHYLL },
      { level: 50, item: :FLYINGGEM, nature: :IMPISH, moves: [:AERIALACE, :LEAFBLADE, :PROTECT, :LEECHSEED], ev: 25, iv: 10, ability: :CHLOROPHYLL },
      { level: 50, item: :GRASSGEM, nature: :CALM, moves: [:MAGICALLEAF, :STOMP, :RAZORWIND, :PROTECT], ev: 25, iv: 10, ability: :CHLOROPHYLL }
    ],
    :CASTFORM => [
      { level: 50, item: :ICEGEM, nature: :TIMID, moves: [:SNOWSCAPE, :WEATHERBALL, :FLAMETHROWER, :THUNDERBOLT], ev: 25, iv: 10, ability: :FORECAST },
      { level: 50, item: :FIREGEM, nature: :MODEST, moves: [:SUNNYDAY, :WEATHERBALL, :SOLARBEAM, :ICEBEAM], ev: 25, iv: 10, ability: :FORECAST },
      { level: 50, item: :WATERGEM, nature: :TIMID, moves: [:RAINDANCE, :WEATHERBALL, :THUNDER, :ICYWIND], ev: 25, iv: 10, ability: :FORECAST }
    ],
    :FARFETCHD => [
      { level: 50, item: :STICK, nature: :JOLLY, moves: [:AERIALACE, :LEAFBLADE, :SLASH, :QUICKATTACK], ev: 25, iv: 10, ability: :INNERFOCUS },
      { level: 50, item: :STICK, nature: :ADAMANT, moves: [:FIRSTIMPRESSION, :FINALGAMBIT, :SKYATTACK, :REVENGE], ev: 25, iv: 10, ability: :DEFIANT },
      { level: 50, item: :STICK, nature: :IMPISH, moves: [:SWORDSDANCE, :SLASH, :NIGHTSLASH, :LEAFBLADE], ev: 25, iv: 10, ability: :DEFIANT }
    ],
    :GIRAFARIG => [
      { level: 50, item: :PSYCHICGEM, nature: :MODEST, moves: [:TWINBEAM, :WISH, :HYPERVOICE, :CONFUSERAY], ev: 25, iv: 10, ability: :INNERFOCUS },
      { level: 50, item: :NORMALGEM, nature: :BOLD, moves: [:PSYCHIC, :AGILITY, :BATONPASS, :NASTYPLOT], ev: 25, iv: 10, ability: :SAPSIPPER },
      { level: 50, item: :PSYCHICGEM, nature: :JOLLY, moves: [:THUNDERWAVE, :BODYSLAM, :ZENHEADBUTT, :CRUNCH], ev: 25, iv: 10, ability: :EARLYBIRD }
    ],
    :MASQUERAIN => [
      { level: 50, item: :BUGGEM, nature: :MODEST, moves: [:SILVERWIND, :AIRSLASH, :OMINOUSWIND, :STICKYWEB], ev: 25, iv: 10, ability: :INTIMIDATE },
      { level: 50, item: :FLYINGGEM, nature: :TIMID, moves: [:AIRSLASH, :QUIVERDANCE, :BUBBLEBEAM, :ICYWIND], ev: 25, iv: 10, ability: :INTIMIDATE },
      { level: 50, item: :BUGGEM, nature: :CALM, moves: [:GIGADRAIN, :HURRICANE, :STRUGGLEBUG, :AQUAJET], ev: 25, iv: 10, ability: :INTIMIDATE }
    ],
    :WHISCASH => [
      { level: 50, item: :WATERGEM, nature: :ADAMANT, moves: [:DRAGONDANCE, :MAGNITUDE, :AQUATAIL, :ROCKSLIDE], ev: 25, iv: 10, ability: :OBLIVIOUS },
      { level: 50, item: :GROUNDGEM, nature: :IMPISH, moves: [:EARTHPOWER, :MUDDYWATER, :RAINDANCE, :FUTURESIGHT], ev: 25, iv: 10, ability: :HYDRATION },
      { level: 50, item: :WATERGEM, nature: :BRAVE, moves: [:SURF, :EARTHQUAKE, :AMNESIA, :REST], ev: 25, iv: 10, ability: :OBLIVIOUS }
    ],
    :CHIMECHO => [
      { level: 50, item: :PSYCHICGEM, nature: :MODEST, moves: [:PSYCHICNOISE, :THUNDERWAVE, :KNOCKOFF, :ICYWIND], ev: 25, iv: 10, ability: :LEVITATE },
      { level: 50, item: :PSYCHICGEM, nature: :TIMID, moves: [:DRAININGKISS, :CALMMIND, :YAWN, :EXTRASENSORY], ev: 25, iv: 10, ability: :LEVITATE },
      { level: 50, item: :PSYCHICGEM, nature: :CALM, moves: [:ENERGYBALL, :SHADOWBALL, :HYPERVOICE, :CALMMIND], ev: 25, iv: 10, ability: :LEVITATE }
    ],
    :CAMERUPT => [
      { level: 50, item: :FIREGEM, nature: :QUIET, moves: [:LAVAPLUME, :ANCIENTPOWER, :BULLDOZE, :MUDSHOT], ev: 25, iv: 10, ability: :MAGMAARMOR },
      { level: 50, item: :FIREGEM, nature: :CALM, moves: [:FLAMETHROWER, :YAWN, :ANCIENTPOWER, :EARTHPOWER], ev: 25, iv: 10, ability: :SOLIDROCK },
      { level: 50, item: :FIREGEM, nature: :ADAMANT, moves: [:ROCKSLIDE, :EARTHQUAKE, :WILLOWISP, :CHARM], ev: 25, iv: 10, ability: :SOLIDROCK }
    ],
    :BANETTE => [
      { level: 50, item: :GHOSTGEM, nature: :ADAMANT, moves: [:SHADOWSNEAK, :WILLOWISP, :SUCKERPUNCH, :NIGHTSHADE], ev: 25, iv: 10, ability: :INSOMNIA },
      { level: 50, item: :GHOSTGEM, nature: :BRAVE, moves: [:SHADOWCLAW, :WILLOWISP, :SECRETPOWER, :KNOCKOFF], ev: 25, iv: 10, ability: :CURSEDBODY },
      { level: 50, item: :GHOSTGEM, nature: :MODEST, moves: [:CALMMIND, :THUNDERBOLT, :PSYCHIC, :ICYWIND], ev: 25, iv: 10, ability: :INSOMNIA }
    ],
    :SWALOT => [
      { level: 50, item: :POISONGEM, nature: :CALM, moves: [:TOXIC, :SLUDGEBOMB, :BODYSLAM, :STOCKPILE], ev: 25, iv: 10, ability: :STICKYHOLD },
      { level: 50, item: :POISONGEM, nature: :BOLD, moves: [:ACIDARMOR, :BODYPRESS, :SLUDGEBOMB, :REST], ev: 25, iv: 10, ability: :GLUTTONY },
      { level: 50, item: :POISONGEM, nature: :TIMID, moves: [:ACIDSPRAY, :ICEBEAM, :GIGADRAIN, :YAWN], ev: 25, iv: 10, ability: :LIQUIDOOZE }
    ],
    :ARBOK => [
      { level: 50, item: :POISONGEM, nature: :JOLLY, moves: [:GLARE, :GUNKSHOT, :COIL, :CRUNCH], ev: 25, iv: 10, ability: :INTIMIDATE },
      { level: 50, item: :POISONGEM, nature: :ADAMANT, moves: [:POISONJAB, :AQUATAIL, :GLARE, :SUCKERPUNCH], ev: 25, iv: 10, ability: :SHEDSKIN },
      { level: 50, item: :POISONGEM, nature: :IMPISH, moves: [:WRAP, :TOXIC, :REST, :COIL], ev: 25, iv: 10, ability: :SHEDSKIN },
    ],
    :CRABOMINABLE => [
      { level: 50, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:WORKUP, :SCALD, :CLOSECOMBAT, :ICEPUNCH], ev: 25, iv: 10, ability: :IRONFIST },
      { level: 50, item: :ICEGEM, nature: :BRAVE, moves: [:ICEHAMMER, :BULKUP, :DIZZYPUNCH, :BRUTALSWING], ev: 25, iv: 10, ability: :IRONFIST },
      { level: 50, item: :FIGHTINGGEM, nature: :NAUGHTY, moves: [:DRAINPUNCH, :ICEHAMMER, :SWAGGER, :CRABHAMMER], ev: 25, iv: 10, ability: :IRONFIST },
    ],
    :LEAFEON => [
      { level: 50, item: :GRASSGEM, nature: :JOLLY, moves: [:LEAFBLADE, :KNOCKOFF, :SWORDSDANCE, :BATONPASS], ev: 25, iv: 10, ability: :LEAFGUARD },
      { level: 50, item: :GRASSGEM, nature: :ADAMANT, moves: [:SUNNYDAY, :SOLARBLADE, :LEAFBLADE, :KNOCKOFF], ev: 25, iv: 10, ability: :CHLOROPHYLL },
      { level: 50, item: :GRASSGEM, nature: :IMPISH, moves: [:PROTECT, :TOXIC, :KNOCKOFF, :LEAFBLADE], ev: 25, iv: 10, ability: :LEAFGUARD },
    ],
    :WORMADAM => [
      { level: 50, item: :GRASSGEM, nature: :TIMID, moves: [:QUIVERDANCE, :STRUGGLEBUG, :GIGADRAIN, :PSYCHIC], ev: 25, iv: 10, ability: :OVERCOAT },
      { level: 50, form: 1, item: :GROUNDGEM, nature: :BOLD, moves: [:QUIVERDANCE, :STRUGGLEBUG, :EARTHPOWER, :PSYCHIC], ev: 25, iv: 10, ability: :OVERCOAT },
      { level: 50, form: 2, item: :STEELGEM, nature: :CALM, moves: [:QUIVERDANCE, :STRUGGLEBUG, :MIRRORSHOT, :PSYCHIC], ev: 25, iv: 10, ability: :OVERCOAT },
    ],
    :MAUSHOLD => [
      { level: 50, item: :NORMALGEM, nature: :JOLLY, moves: [:POPULATIONBOMB, :BULLETSEED, :SUPERFANG, :UTURN], ev: 25, iv: 10, ability: :TECHNICIAN },
      { level: 50, item: :NORMALGEM, nature: :JOLLY, moves: [:TIDYUP, :POPULATIONBOMB, :PROTECT, :BEATUP], ev: 25, iv: 10, ability: :FRIENDGUARD },
      { level: 50, item: :NORMALGEM, nature: :ADAMANT, moves: [:ENCORE, :UTURN, :BITE, :POPULATIONBOMB], ev: 25, iv: 10, ability: :TECHNICIAN },
    ],
    :GRUMPIG => [
      { level: 50, item: :PSYCHICGEM, nature: :BOLD, moves: [:PSYSHOCK, :EARTHPOWER, :THUNDERWAVE, :REST], ev: 25, iv: 10, ability: :THICKFAT },
      { level: 50, item: :PSYCHICGEM, nature: :CALM, moves: [:PSYCHICNOISE, :ENCORE, :SUBSTITUTE, :TOXIC], ev: 25, iv: 10, ability: :OWNTEMPO },
      { level: 50, item: :PSYCHICGEM, nature: :MODEST, moves: [:CALMMIND, :FUTURESIGHT, :POWERGEM, :CHARGEBEAM], ev: 25, iv: 10, ability: :THICKFAT },
    ],
    :BEHEEYEM => [
      { level: 50, item: :PSYCHICGEM, nature: :QUIET, moves: [:PSYSHOCK, :SHADOWBALL, :RECOVER, :CALMMIND], ev: 25, iv: 10, ability: :TELEPATHY },
      { level: 50, item: :PSYCHICGEM, nature: :MODEST, moves: [:PSYCHIC, :ENERGYBALL, :CALMMIND, :TRICKROOM], ev: 25, iv: 10, ability: :SYNCHRONIZE },
      { level: 50, item: :PSYCHICGEM, nature: :BOLD, moves: [:BARRIER, :RECOVER, :PSYCHIC, :SHADOWBALL], ev: 25, iv: 10, ability: :TELEPATHY },
    ],
    :THIEVUL => [
      { level: 50, item: :DARKGEM, nature: :TIMID, moves: [:SNARL, :PARTINGSHOT, :NASTYPLOT, :GRASSKNOT], ev: 25, iv: 10, ability: :UNBURDEN },
      { level: 50, item: :DARKGEM, nature: :MODEST, moves: [:DARKPULSE, :HYPERVOICE, :NASTYPLOT, :PROTECT], ev: 25, iv: 10, ability: :UNBURDEN },
      { level: 50, item: :DARKGEM, nature: :CALM, moves: [:YAWN, :TAUNT, :SNARL, :PROTECT], ev: 25, iv: 10, ability: :RUNAWAY },
    ],
    :FLAPPLE => [
      { level: 50, item: :GRASSGEM, nature: :ADAMANT, moves: [:GRAVAPPLE, :ACROBATICS, :DRAGONDANCE, :RECYCLE], ev: 25, iv: 10, ability: :RIPEN },
      { level: 50, item: :GRASSGEM, nature: :JOLLY, moves: [:GRAVAPPLE, :UTURN, :LEECHSEED, :DRAGONRUSH], ev: 25, iv: 10, ability: :HUSTLE },
      { level: 50, item: :GRASSGEM, nature: :NAUGHTY, moves: [:GRAVAPPLE, :GUNKSHOT, :ACROBATICS, :DRAGONDANCE], ev: 25, iv: 10, ability: :RIPEN },
    ],
    :MORGREM => [
      { level: 50, item: :DARKGEM, nature: :IMPISH, moves: [:REFLECT, :LIGHTSCREEN, :SPIRITBREAK, :TAUNT], ev: 25, iv: 10, ability: :PRANKSTER },
      { level: 50, item: :FAIRYGEM, nature: :CAREFUL, moves: [:THUNDERWAVE, :SPIRITBREAK, :SUCKERPUNCH, :ENCORE], ev: 25, iv: 10, ability: :PRANKSTER },
      { level: 50, item: :FAIRYGEM, nature: :BOLD, moves: [:CHARM, :SPIRITBREAK, :THUNDERWAVE, :REST], ev: 25, iv: 10, ability: :PRANKSTER },
    ],
    :SPIDOPS => [
      { level: 50, item: :BUGGEM, nature: :ADAMANT, moves: [:FIRSTIMPRESSION, :LEECHLIFE, :SILKTRAP, :TOXICSPIKES], ev: 25, iv: 10, ability: :INSOMNIA },
      { level: 50, item: :BUGGEM, nature: :CAREFUL, moves: [:CIRCLETHROW, :TOXICSPIKES, :SPIKES, :SKITTERSMACK], ev: 25, iv: 10, ability: :STAKEOUT },
      { level: 50, item: :BUGGEM, nature: :RELAXED, moves: [:SKITTERSMACK, :SUCKERPUNCH, :STICKYWEB, :SILKTRAP], ev: 25, iv: 10, ability: :INSOMNIA },
    ],
    :BASCULIN => [
      { level: 50, item: :WATERGEM, nature: :JOLLY, moves: [:AQUAJET, :CRUNCH, :ICEFANG, :HEADSMASH], ev: 25, iv: 10, ability: :RECKLESS },
      { level: 50, item: :WATERGEM, nature: :ADAMANT, moves: [:WATERFALL, :ICEFANG, :SCARYFACE, :SUPERPOWER], ev: 25, iv: 10, ability: :ADAPTABILITY },
      { level: 50, item: :WATERGEM, nature: :NAUGHTY, moves: [:AQUATAIL, :CRUNCH, :ZENHEADBUTT, :AQUAJET], ev: 25, iv: 10, ability: :ADAPTABILITY },
    ],
  },

  # RARE POOL
  :rare => {
    :KROOKODILE => [
      { level: 75, item: :DARKGEM, nature: :JOLLY, moves: [:KNOCKOFF, :EARTHQUAKE, :STONEEDGE, :TAUNT], ev: 50, iv: 20, ability: :MOXIE },
      { level: 75, item: :GROUNDGEM, nature: :ADAMANT, moves: [:EARTHQUAKE, :CRUNCH, :FIREFANG, :STEALTHROCK], ev: 50, iv: 20, ability: :INTIMIDATE },
      { level: 75, item: :DARKGEM, nature: :NAUGHTY, moves: [:CRUNCH, :OUTRAGE, :EARTHQUAKE, :AQUATAIL], ev: 50, iv: 20, ability: :MOXIE },
    ],
    :PINSIR => [
      { level: 75, item: :BUGGEM, nature: :IMPISH, moves: [:STEALTHROCK, :XSCISSOR, :BODYSLAM, :ROCKSLIDE], ev: 50, iv: 20, ability: :MOLDBREAKER },
      { level: 75, item: :BUGGEM, nature: :JOLLY, moves: [:SWORDSDANCE, :XSCISSOR, :EARTHQUAKE, :STOMP], ev: 50, iv: 20, ability: :MOXIE },
      { level: 75, item: :BUGGEM, nature: :ADAMANT, moves: [:BULKUP, :LUNGE, :REVENGE, :ROCKSLIDE], ev: 50, iv: 20, ability: :MOXIE },
    ],
    :HERACROSS => [
      { level: 75, item: :BUGGEM, nature: :ADAMANT, moves: [:CLOSECOMBAT, :MEGAHORN, :KNOCKOFF, :SWORDSDANCE], ev: 50, iv: 20, ability: :GUTS },
      { level: 75, item: :FIGHTINGGEM, nature: :JOLLY, moves: [:BRICKBREAK, :STONEEDGE, :XSCISSOR, :EARTHQUAKE], ev: 50, iv: 20, ability: :GUTS },
      { level: 75, item: :BUGGEM, nature: :NAIVE, moves: [:PINMISSILE, :NIGHTSLASH, :ROCKBLAST, :BULLETSEED], ev: 50, iv: 20, ability: :MOXIE },
    ],
    :GOODRA => [
      { level: 75, item: :DRAGONGEM, nature: :MODEST, moves: [:DRAGONPULSE, :FLAMETHROWER, :THUNDERBOLT, :SLUDGEBOMB], ev: 50, iv: 20, ability: :SAPSIPPER },
      { level: 75, item: :DRAGONGEM, nature: :CALM, moves: [:TOXIC, :PROTECT, :DRAGONTAIL, :FLAMETHROWER], ev: 50, iv: 20, ability: :SAPSIPPER },
      { level: 75, item: :DRAGONGEM, nature: :BOLD, moves: [:THUNDERWAVE, :DRAGONPULSE, :ACIDSPRAY, :REST], ev: 50, iv: 20, ability: :GOOEY },
    ],
    :ARCANINE => [
      { level: 75, item: :FIREGEM, nature: :ADAMANT, moves: [:FLAREBLITZ, :EXTREMESPEED, :WILLOWISP, :MORNINGSUN], ev: 50, iv: 20, ability: :INTIMIDATE },
      { level: 75, item: :FIREGEM, nature: :JOLLY, moves: [:FLAREBLITZ, :WILDCHARGE, :CLOSECOMBAT, :HOWL], ev: 50, iv: 20, ability: :JUSTIFIED },
      { level: 75, item: :FIREGEM, nature: :IMPISH, moves: [:WILLOWISP, :ROAR, :MORNINGSUN, :FLAMETHROWER], ev: 50, iv: 20, ability: :INTIMIDATE },
    ],
    :DRAGALGE => [
      { level: 75, item: :POISONGEM, nature: :MODEST, moves: [:SLUDGEBOMB, :DRAGONPULSE, :THUNDERBOLT, :FOCUSBLAST], ev: 50, iv: 20, ability: :ADAPTABILITY },
      { level: 75, item: :DRAGONGEM, nature: :CALM, moves: [:TOXIC, :VENOSHOCK, :PROTECT, :SCALD], ev: 50, iv: 20, ability: :ADAPTABILITY },
      { level: 75, item: :POISONGEM, nature: :QUIET, moves: [:SLUDGEWAVE, :HYDROPUMP, :DRAGONTAIL, :HAZE], ev: 50, iv: 20, ability: :ADAPTABILITY },
    ],
    :STARAPTOR => [
      { level: 75, item: :FLYINGGEM, nature: :ADAMANT, moves: [:BRAVEBIRD, :CLOSECOMBAT, :UTURN, :QUICKATTACK], ev: 50, iv: 20, ability: :RECKLESS },
      { level: 75, item: :FLYINGGEM, nature: :JOLLY, moves: [:BRAVEBIRD, :UTURN, :DOUBLEEDGE, :ROOST], ev: 50, iv: 20, ability: :RECKLESS },
      { level: 75, item: :FLYINGGEM, nature: :NAIVE, moves: [:BRAVEBIRD, :FINALGAMBIT, :CLOSECOMBAT, :UTURN], ev: 50, iv: 20, ability: :INTIMIDATE },
    ],
    :GALLADE => [
      { level: 75, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:DRAINPUNCH, :PSYCHOCUT, :KNOCKOFF, :SWORDSDANCE], ev: 50, iv: 20, ability: :STEADFAST },
      { level: 75, item: :PSYCHICGEM, nature: :JOLLY, moves: [:PSYCHOCUT, :LEAFBLADE, :SHADOWSNEAK, :BULKUP], ev: 50, iv: 20, ability: :JUSTIFIED },
      { level: 75, item: :FIGHTINGGEM, nature: :LONELY, moves: [:DRAINPUNCH, :XSCISSOR, :STONEEDGE, :TRICKROOM], ev: 50, iv: 20, ability: :STEADFAST },
    ],
    :BRAVIARY => [
      { level: 75, item: :FLYINGGEM, nature: :ADAMANT, moves: [:BRAVEBIRD, :UTURN, :ROOST, :CRUSHCLAW], ev: 50, iv: 20, ability: :DEFIANT },
      { level: 75, item: :FLYINGGEM, nature: :JOLLY, moves: [:BRAVEBIRD, :CLOSECOMBAT, :TAILWIND, :ROOST], ev: 50, iv: 20, ability: :SHEERFORCE },
      { level: 75, item: :FLYINGGEM, nature: :IMPISH, moves: [:DEFOG, :ROOST, :UTURN, :BRAVEBIRD], ev: 50, iv: 20, ability: :DEFIANT },
    ],
    :TSAREENA => [
      { level: 75, item: :GRASSGEM, nature: :ADAMANT, moves: [:POWERWHIP, :HIJUMPKICK, :UTURN, :RAPIDSPIN], ev: 50, iv: 20, ability: :QUEENLYMAJESTY },
      { level: 75, item: :GRASSGEM, nature: :JOLLY, moves: [:TROPKICK, :KNOCKOFF, :RAPIDSPIN, :PLAYROUGH], ev: 50, iv: 20, ability: :QUEENLYMAJESTY },
      { level: 75, item: :GRASSGEM, nature: :IMPISH, moves: [:TROPKICK, :SYNTHESIS, :LEECHSEED, :PROTECT], ev: 50, iv: 20, ability: :QUEENLYMAJESTY },
    ],
    :TOXTRICITY => [
      { level: 75, item: :ELECTRICGEM, nature: :MODEST, moves: [:OVERDRIVE, :SLUDGEWAVE, :BOOMBURST, :VOLTSWITCH], ev: 50, iv: 20, ability: :PUNKROCK },
      { level: 75, item: :POISONGEM, nature: :TIMID, moves: [:SLUDGEWAVE, :THUNDERBOLT, :SHIFTGEAR, :VENOSHOCK], ev: 50, iv: 20, ability: :PUNKROCK },
      { level: 75, item: :ELECTRICGEM, nature: :NAIVE, moves: [:OVERDRIVE, :SLUDGEBOMB, :ENCORE, :BOOMBURST], ev: 50, iv: 20, ability: :PUNKROCK },
    ],
    :ROSERADE => [
      { level: 75, item: :GRASSGEM, nature: :TIMID, moves: [:ENERGYBALL, :SLUDGEBOMB, :SPIKES, :SLEEPPOWDER], ev: 50, iv: 20, ability: :TECHNICIAN },
      { level: 75, item: :POISONGEM, nature: :MODEST, moves: [:LEAFSTORM, :GIGADRAIN, :SLUDGEBOMB, :SYNTHESIS], ev: 50, iv: 20, ability: :NATURALCURE },
      { level: 75, item: :GRASSGEM, nature: :CALM, moves: [:AROMATHERAPY, :GIGADRAIN, :LEECHSEED, :SLUDGEBOMB], ev: 50, iv: 20, ability: :NATURALCURE },
      { level: 75, form: 1, item: :GROUNDGEM, nature: :TIMID, moves: [:MUDBARRAGE, :VACUUMWAVE, :SPIKES, :SNARL], ev: 50, iv: 20, ability: :TECHNICIAN },
      { level: 75, form: 1, item: :FIGHTINGGEM, nature: :MODEST, moves: [:TORMENT, :POWERGEM, :DARKPULSE, :AURASPHERE], ev: 50, iv: 20, ability: :DRYSKIN },
      { level: 75, form: 1, item: :GROUNDGEM, nature: :CALM, moves: [:SCORCHINGSANDS, :STEALTHROCK, :VACUUMWAVE, :ANCIENTPOWER], ev: 50, iv: 20, ability: :TECHNICIAN },
    ],
    :SALAZZLE => [
      { level: 75, item: :POISONGEM, nature: :TIMID, moves: [:SLUDGEBOMB, :FLAMETHROWER, :TOXIC, :SUBSTITUTE], ev: 50, iv: 20, ability: :CORROSION },
      { level: 75, item: :FIREGEM, nature: :HASTY, moves: [:FLAMETHROWER, :VENOSHOCK, :TOXIC, :PROTECT], ev: 50, iv: 20, ability: :CORROSION },
      { level: 75, item: :POISONGEM, nature: :MODEST, moves: [:SLUDGEWAVE, :NASTYPLOT, :FLAMETHROWER, :SUBSTITUTE], ev: 50, iv: 20, ability: :CORROSION },
    ],
    :CINCCINO => [
      { level: 75, item: :NORMALGEM, nature: :JOLLY, moves: [:TAILSLAP, :BULLETSEED, :ROCKBLAST, :UTURN], ev: 50, iv: 20, ability: :SKILLLINK },
      { level: 75, item: :NORMALGEM, nature: :ADAMANT, moves: [:TAILSLAP, :KNOCKOFF, :UTURN, :SING], ev: 50, iv: 20, ability: :SKILLLINK },
      { level: 75, item: :NORMALGEM, nature: :NAIVE, moves: [:TAILSLAP, :THUNDERWAVE, :ENCORE, :UTURN], ev: 50, iv: 20, ability: :TECHNICIAN },
    ],
    :FLORGES => [
      { level: 75, item: :FAIRYGEM, nature: :CALM, moves: [:MOONBLAST, :WISH, :AROMATHERAPY, :PROTECT], ev: 50, iv: 20, ability: :FLOWERVEIL },
      { level: 75, item: :FAIRYGEM, nature: :BOLD, moves: [:MOONBLAST, :TOXIC, :PROTECT, :WISH], ev: 50, iv: 20, ability: :SYMBIOSIS },
      { level: 75, item: :FAIRYGEM, nature: :MODEST, moves: [:CALMMIND, :MOONBLAST, :ENERGYBALL, :REST], ev: 50, iv: 20, ability: :FLOWERVEIL },
    ],
    :FLYGON => [
      { level: 75, item: :DRAGONGEM, nature: :JOLLY, moves: [:DRAGONCLAW, :EARTHQUAKE, :UTURN, :DEFOG], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, item: :GROUNDGEM, nature: :ADAMANT, moves: [:EARTHQUAKE, :STONEEDGE, :DRAGONCLAW, :ROOST], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, item: :DRAGONGEM, nature: :MODEST, moves: [:DRACOMETEOR, :EARTHPOWER, :FLAMETHROWER, :BOOMBURST], ev: 50, iv: 20, ability: :LEVITATE },
    ],
    :DECIDUEYE => [
      { level: 75, item: :GRASSGEM, nature: :ADAMANT, moves: [:SPIRITSHACKLE, :LEAFBLADE, :SUCKERPUNCH, :ROOST], ev: 50, iv: 20, ability: :OVERGROW },
      { level: 75, item: :GHOSTGEM, nature: :JOLLY, moves: [:SHADOWSNEAK, :UTURN, :LEAFBLADE, :ROOST], ev: 50, iv: 20, ability: :LONGREACH },
      { level: 75, item: :GRASSGEM, nature: :IMPISH, moves: [:LEECHSEED, :PROTECT, :SPIRITSHACKLE, :ROOST], ev: 50, iv: 20, ability: :OVERGROW },
    ],
    :VIKAVOLT => [
      { level: 75, item: :BUGGEM, nature: :MODEST, moves: [:BUGBUZZ, :THUNDERBOLT, :ENERGYBALL, :ROOST], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, item: :ELECTRICGEM, nature: :QUIET, moves: [:THUNDERBOLT, :BUGBUZZ, :AGILITY, :AIRSLASH], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, item: :BUGGEM, nature: :BOLD, moves: [:TOXIC, :BUGBUZZ, :ROOST, :PROTECT], ev: 50, iv: 20, ability: :LEVITATE },
    ],
    :TOEDSCRUEL => [
      { level: 75, item: :GRASSGEM, nature: :CALM, moves: [:SPORE, :LEECHSEED, :GIGADRAIN, :PROTECT], ev: 50, iv: 20, ability: :MYCELIUMMIGHT },
      { level: 75, item: :GRASSGEM, nature: :BOLD, moves: [:REFLECT, :LIGHTSCREEN, :LEAFSTORM, :TOXIC], ev: 50, iv: 20, ability: :MYCELIUMMIGHT },
      { level: 75, item: :GRASSGEM, nature: :TIMID, moves: [:LEAFSTORM, :GIGADRAIN, :EARTHPOWER, :DAZZLINGGLEAM], ev: 50, iv: 20, ability: :MYCELIUMMIGHT },
    ],
    :TOXICROAK => [
      { level: 75, item: :POISONGEM, nature: :JOLLY, moves: [:DRAINPUNCH, :GUNKSHOT, :SUCKERPUNCH, :SWORDSDANCE], ev: 50, iv: 20, ability: :DRYSKIN },
      { level: 75, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:CROSSCHOP, :GUNKSHOT, :ICEPUNCH, :SHADOWCLAW], ev: 50, iv: 20, ability: :ANTICIPATION },
      { level: 75, item: :POISONGEM, nature: :TIMID, moves: [:SLUDGEBOMB, :VACUUMWAVE, :NASTYPLOT, :DARKPULSE], ev: 50, iv: 20, ability: :DRYSKIN },
    ],
    :KLEAVOR => [
      { level: 75, item: :BUGGEM, nature: :JOLLY, moves: [:STONEAXE, :XSCISSOR, :UTURN, :SWORDSDANCE], ev: 50, iv: 20, ability: :SHARPNESS },
      { level: 75, item: :BUGGEM, nature: :ADAMANT, moves: [:STONEAXE, :XSCISSOR, :AERIALACE, :ROOST], ev: 50, iv: 20, ability: :SHEERFORCE },
      { level: 75, item: :BUGGEM, nature: :IMPISH, moves: [:TOXIC, :UTURN, :STONEAXE, :ROOST], ev: 50, iv: 20, ability: :SHARPNESS },
    ],
    :MILTANK => [
      { level: 75, item: :NORMALGEM, nature: :IMPISH, moves: [:BODYSLAM, :MILKDRINK, :TOXIC, :STEALTHROCK], ev: 50, iv: 20, ability: :SCRAPPY },
      { level: 75, item: :NORMALGEM, nature: :JOLLY, moves: [:DOUBLEEDGE, :EARTHQUAKE, :CURSE, :MILKDRINK], ev: 50, iv: 20, ability: :SAPSIPPER },
      { level: 75, item: :NORMALGEM, nature: :ADAMANT, moves: [:RETURN, :FIREPUNCH, :ICEPUNCH, :MILKDRINK], ev: 50, iv: 20, ability: :THICKFAT },
    ],
    :VELUZA => [
      { level: 75, form: 1, item: :FIREGEM, nature: :IMPISH, moves: [:FLAREBLITZ, :FLIPTURN, :EXTREMESPEED, :CRUNCH], ev: 50, iv: 20, ability: :RECKLESS },
      { level: 75, form: 1, item: :NORMALGEM, nature: :JOLLY, moves: [:EXPLOSION, :WAVECRASH, :SUPERCELLSLAM, :ALLYSWITCH], ev: 50, iv: 20, ability: :MOLDBREAKER },
      { level: 75, form: 1, item: :WATERGEM, nature: :ADAMANT, moves: [:WAVECRASH, :UTURN, :DOUBLEEDGE, :TEMPERFLARE], ev: 50, iv: 20, ability: :RECKLESS },
    ],
    :TYRANTRUM => [
      { level: 75, item: :ROCKGEM, nature: :ADAMANT, moves: [:HEADSMASH, :DRAGONCLAW, :EARTHQUAKE, :ICEFANG], ev: 50, iv: 20, ability: :STRONGJAW },
      { level: 75, item: :DRAGONGEM, nature: :JOLLY, moves: [:DRAGONCLAW, :ROCKSLIDE, :CRUNCH, :FIREFANG], ev: 50, iv: 20, ability: :STRONGJAW },
      { level: 75, item: :ROCKGEM, nature: :NAUGHTY, moves: [:HEADSMASH, :OUTRAGE, :FIREFANG, :DRAGONDANCE], ev: 50, iv: 20, ability: :ROCKHEAD },
    ],
    :ROTOM => [
      { level: 75, item: :ELECTRICGEM, nature: :TIMID, moves: [:VOLTSWITCH, :SHADOWBALL, :WILLOWISP, :PAINSPLIT], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, form: 1, item: :FIREGEM, nature: :TIMID, moves: [:VOLTSWITCH, :OVERHEAT, :WILLOWISP, :PAINSPLIT], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, form: 2, item: :WATERGEM, nature: :TIMID, moves: [:VOLTSWITCH, :HYDROPUMP, :WILLOWISP, :PAINSPLIT], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, form: 3, item: :ICEGEM, nature: :TIMID, moves: [:VOLTSWITCH, :BLIZZARD, :WILLOWISP, :PAINSPLIT], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, form: 4, item: :FLYINGGEM, nature: :TIMID, moves: [:VOLTSWITCH, :AIRSLASH, :WILLOWISP, :PAINSPLIT], ev: 50, iv: 20, ability: :LEVITATE },
      { level: 75, form: 5, item: :GRASSGEM, nature: :TIMID, moves: [:VOLTSWITCH, :LEAFSTORM, :WILLOWISP, :PAINSPLIT], ev: 50, iv: 20, ability: :LEVITATE },
    ],
    :ZOROARK => [
      { level: 75, item: :DARKGEM, nature: :NAIVE, moves: [:NIGHTDAZE, :FLAMETHROWER, :UTURN, :SUCKERPUNCH], ev: 50, iv: 20, ability: :ILLUSION },
      { level: 75, item: :DARKGEM, nature: :TIMID, moves: [:DARKPULSE, :NASTYPLOT, :UTURN, :TAUNT], ev: 50, iv: 20, ability: :ILLUSION },
      { level: 75, item: :DARKGEM, nature: :HASTY, moves: [:FOULPLAY, :FLAMETHROWER, :UTURN, :PROTECT], ev: 50, iv: 20, ability: :ILLUSION },
    ],
    :CLODSIRE => [
      { level: 75, item: :POISONGEM, nature: :RELAXED, moves: [:TOXIC, :RECOVER, :EARTHQUAKE, :GUNKSHOT], ev: 50, iv: 20, ability: :WATERABSORB },
      { level: 75, item: :GROUNDGEM, nature: :CALM, moves: [:EARTHQUAKE, :TOXIC, :SPIKES, :RECOVER], ev: 50, iv: 20, ability: :UNAWARE },
      { level: 75, item: :POISONGEM, nature: :BOLD, moves: [:POISONJAB, :MEGAHORN, :YAWN, :PROTECT], ev: 50, iv: 20, ability: :UNAWARE },
    ],
    :SIRFETCHD => [
      { level: 75, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:LEAFBLADE, :BRICKBREAK, :NIGHTSLASH, :FIRSTIMPRESSION], ev: 50, iv: 20, ability: :STEADFAST },
      { level: 75, item: :FIGHTINGGEM, nature: :JOLLY, moves: [:BRAVEBIRD, :SWORDSDANCE, :BRICKBREAK, :UTURN], ev: 50, iv: 20, ability: :STEADFAST },
      { level: 75, item: :FIGHTINGGEM, nature: :IMPISH, moves: [:LEAFBLADE, :BRICKBREAK, :TOXIC, :PROTECT], ev: 50, iv: 20, ability: :STEADFAST },
    ],
    :HAWLUCHA => [
      { level: 75, item: :FLYINGGEM, nature: :ADAMANT, moves: [:ACROBATICS, :HIJUMPKICK, :SWORDSDANCE, :ROOST], ev: 50, iv: 20, ability: :UNBURDEN },
      { level: 75, item: :FIGHTINGGEM, nature: :JOLLY, moves: [:DRAINPUNCH, :ACROBATICS, :SUBSTITUTE, :TOXIC], ev: 50, iv: 20, ability: :UNBURDEN },
      { level: 75, item: :FLYINGGEM, nature: :NAIVE, moves: [:ACROBATICS, :UTURN, :BULKUP, :DRAINPUNCH], ev: 50, iv: 20, ability: :UNBURDEN },
    ],
    :CRABOMINABLE => [
      { level: 75, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:ICEPUNCH, :DRAINPUNCH, :THUNDERPUNCH, :BULKUP], ev: 50, iv: 20, ability: :IRONFIST },
      { level: 75, item: :ICEGEM, nature: :BRAVE, moves: [:ICEHAMMER, :CLOSECOMBAT, :STOMPINGTANTRUM, :STONEEDGE], ev: 50, iv: 20, ability: :IRONFIST },
      { level: 75, item: :FIGHTINGGEM, nature: :NAUGHTY, moves: [:CLOSECOMBAT, :ICEPUNCH, :FIREPUNCH, :BELLYDRUM], ev: 50, iv: 20, ability: :IRONFIST },
    ],
    :TINKATON => [
      { level: 75, item: :FAIRYGEM, nature: :JOLLY, moves: [:KNOCKOFF, :PLAYROUGH, :STEALTHROCK, :FAKEOUT], ev: 50, iv: 20, ability: :MOLDBREAKER },
      { level: 75, item: :STEELGEM, nature: :ADAMANT, moves: [:GIGATONHAMMER, :THUNDERWAVE, :SWORDSDANCE, :ROCKSLIDE], ev: 50, iv: 20, ability: :MOLDBREAKER },
      { level: 75, item: :FAIRYGEM, nature: :IMPISH, moves: [:STEALTHROCK, :KNOCKOFF, :REFLECT, :PLAYROUGH], ev: 50, iv: 20, ability: :MOLDBREAKER },
    ],
    :BRONZONG => [
      { level: 75, form: 1, item: :STEELGEM, nature: :BOLD, moves: [:REFLECT, :LIGHTSCREEN, :MIRRORBEAM, :MIRRORMOVE], ev: 50, iv: 20, ability: :REFLECTOR },
      { level: 75, form: 1, item: :STEELGEM, nature: :MODEST, moves: [:CALMMIND, :MIRRORBEAM, :DAZZLINGGLEAM, :SHADOWBALL], ev: 50, iv: 20, ability: :REFLECTOR },
      { level: 75, form: 1, item: :STEELGEM, nature: :BOLD, moves: [:IRONDEFENSE, :BODYPRESS, :REST, :MIRRORBEAM], ev: 50, iv: 20, ability: :REFLECTOR },
    ],
    :ESPATHRA => [
      { level: 75, item: :PSYCHICGEM, nature: :TIMID, moves: [:LUMINACRASH, :DAZZLINGGLEAM, :CALMMIND, :ROOST], ev: 50, iv: 20, ability: :SPEEDBOOST },
      { level: 75, item: :PSYCHICGEM, nature: :MODEST, moves: [:LUMINACRASH, :PROTECT, :CALMMIND, :ROOST], ev: 50, iv: 20, ability: :OPPORTUNIST },
      { level: 75, item: :PSYCHICGEM, nature: :HASTY, moves: [:LUMINACRASH, :DAZZLINGGLEAM, :UTURN, :ROOST], ev: 50, iv: 20, ability: :SPEEDBOOST },
    ],
  },

  # ULTIMATE POOL
  :ultimate => {
    #:ZAPDOS => [
    #    { level: 90, form: 1, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:THUNDEROUSKICK, :DRILLPECK, :ROOST, :TOXIC], ev: 80, iv: 31, ability: :PRESSURE },
    #    { level: 90, form: 1, item: :FIGHTINGGEM, nature: :IMPISH, moves: [:THUNDERWAVE, :DEFOG, :ROOST, :DISCHARGE], ev: 80, iv: 31, ability: :PRESSURE },
    #    { level: 90, form: 1, item: :FIGHTINGGEM, nature: :JOLLY, moves: [:THUNDER, :ROOST, :FOCUSBLAST, :HURRICANE], ev: 80, iv: 31, ability: :PRESSURE },
    #  ],
    #  :ARTICUNO => [
    #    { level: 90, form: 1, item: :ICEGEM, nature: :BOLD, moves: [:FREEZEDRY, :ROOST, :TOXIC, :HURRICANE], ev: 80, iv: 31, ability: :PRESSURE },
    #    { level: 90, form: 1, item: :ICEGEM, nature: :CALM, moves: [:AURORABEAM, :FREEZEDRY, :HAZE, :HURRICANE], ev: 80, iv: 31, ability: :PRESSURE },
    #    { level: 90, form: 1, item: :ICEGEM, nature: :MODEST, moves: [:ICEBEAM, :HURRICANE, :ROOST, :TOXIC], ev: 80, iv: 31, ability: :PRESSURE },
    #  ],
    #  :MOLTRES => [
    #    { level: 90, form: 1, item: :FIREGEM, nature: :MODEST, moves: [:FLAMETHROWER, :AIRSLASH, :TOXIC, :ROOST], ev: 80, iv: 31, ability: :BLAZE },
    #    { level: 90, form: 1, item: :FIREGEM, nature: :CALM, moves: [:FLAMETHROWER, :HURRICANE, :ROOST, :TOXIC], ev: 80, iv: 31, ability: :BLAZE },
    #    { level: 90, form: 1, item: :FIREGEM, nature: :TIMID, moves: [:FLAMETHROWER, :HURRICANE, :ROOST, :UTURN], ev: 80, iv: 31, ability: :BLAZE },
    #  ],
    :GARCHOMP => [
      { level: 90, item: :GROUNDGEM, nature: :JOLLY, moves: [:OUTRAGE, :EARTHQUAKE, :SWORDSDANCE, :STEALTHROCK], ev: 80, iv: 31, ability: :ROUGHSKIN },
      { level: 90, item: :GROUNDGEM, nature: :ADAMANT, moves: [:SCALESHOT, :EARTHQUAKE, :SWORDSDANCE, :STONEEDGE], ev: 80, iv: 31, ability: :ROUGHSKIN },
      { level: 90, item: :GROUNDGEM, nature: :TIMID, moves: [:DRACOMETEOR, :FIREBLAST, :SURF, :EARTHPOWER], ev: 80, iv: 31, ability: :SANDVEIL },
    ],
    :SALAMENCE => [
      { level: 90, item: :DRAGONGEM, nature: :JOLLY, moves: [:OUTRAGE, :EARTHQUAKE, :FLY, :DRAGONDANCE], ev: 80, iv: 31, ability: :MOXIE },
      { level: 90, item: :DRAGONGEM, nature: :MODEST, moves: [:DRACOMETEOR, :HYDROPUMP, :HURRICANE, :FIREBLAST], ev: 80, iv: 31, ability: :INTIMIDATE },
      { level: 90, item: :DRAGONGEM, nature: :BOLD, moves: [:DRAGONPULSE, :ROOST, :FLAMETHROWER, :TOXIC], ev: 80, iv: 31, ability: :INTIMIDATE },
    ],
    :DRAGONITE => [
      { level: 90, item: :DRAGONGEM, nature: :ADAMANT, moves: [:DRAGONDANCE, :OUTRAGE, :FIREPUNCH, :EARTHQUAKE], ev: 80, iv: 31, ability: :MULTISCALE },
      { level: 90, item: :DRAGONGEM, nature: :JOLLY, moves: [:DRAGONCLAW, :EARTHQUAKE, :ROOST, :WATERFALL], ev: 80, iv: 31, ability: :INNERFOCUS },
      { level: 90, item: :DRAGONGEM, nature: :TIMID, moves: [:RAINDANCE, :THUNDER, :HURRICANE, :SURF], ev: 80, iv: 31, ability: :MULTISCALE },
    ],
    :EXCADRILL => [
      { level: 90, item: :STEELGEM, nature: :JOLLY, moves: [:STEALTHROCK, :EARTHQUAKE, :IRONHEAD, :TOXIC], ev: 80, iv: 31, ability: :MOLDBREAKER },
      { level: 90, item: :GROUNDGEM, nature: :ADAMANT, moves: [:EARTHQUAKE, :IRONHEAD, :SANDSTORM, :SWORDSDANCE], ev: 80, iv: 31, ability: :SANDRUSH },
      { level: 90, item: :GROUNDGEM, nature: :JOLLY, moves: [:STEALTHROCK, :IRONHEAD, :EARTHQUAKE, :RAPIDSPIN], ev: 80, iv: 31, ability: :MOLDBREAKER },
    ],
    :CHARIZARD => [
      { level: 90, item: :FIREGEM, nature: :TIMID, moves: [:FLAMETHROWER, :SOLARBEAM, :AIRSLASH, :SUNNYDAY], ev: 80, iv: 31, ability: :SOLARPOWER },
      { level: 90, item: :FIREGEM, nature: :ADAMANT, moves: [:FLAREBLITZ, :EARTHQUAKE, :DRAGONDANCE, :DRAGONCLAW], ev: 80, iv: 31, ability: :BLAZE },
      { level: 90, item: :FIREGEM, nature: :MODEST, moves: [:HEATWAVE, :SCORCHINGSANDS, :HURRICANE, :WILLOWISP], ev: 80, iv: 31, ability: :BLAZE },
    ],
    :PRIMARINA => [
      { level: 90, item: :WATERGEM, nature: :TIMID, moves: [:HYPERVOICE, :DAZZLINGGLEAM, :ICYWIND, :PROTECT], ev: 80, iv: 31, ability: :LIQUIDVOICE },
      { level: 90, item: :FAIRYGEM, nature: :BOLD, moves: [:CALMMIND, :PSYCHICNOISE, :PSYCHIC, :MOONBLAST], ev: 80, iv: 31, ability: :LIQUIDVOICE },
      { level: 90, item: :WATERGEM, nature: :MODEST, moves: [:MOONBLAST, :HYDROPUMP, :ENCORE, :ENERGYBALL], ev: 80, iv: 31, ability: :TORRENT },
    ],
    :MEOWSCARADA => [
      { level: 90, item: :DARKGEM, nature: :JOLLY, moves: [:SPIKES, :SUCKERPUNCH, :PETALBLIZZARD, :TAUNT], ev: 80, iv: 31, ability: :PROTEAN },
      { level: 90, item: :FAIRYGEM, nature: :ADAMANT, moves: [:ALLYSWITCH, :KNOCKOFF, :PLAYROUGH, :FLOWERTRICK], ev: 80, iv: 31, ability: :PROTEAN },
      { level: 90, item: :GRASSGEM, nature: :JOLLY, moves: [:FLOWERTRICK, :PLAYROUGH, :THROATCHOP, :PROTECT], ev: 80, iv: 31, ability: :OVERGROW },
    ],
    :LUCARIO => [
      { level: 90, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:CLOSECOMBAT, :BULLETPUNCH, :SWORDSDANCE, :ICEPUNCH], ev: 80, iv: 31, ability: :JUSTIFIED },
      { level: 90, item: :FIGHTINGGEM, nature: :JOLLY, moves: [:CLOSECOMBAT, :BULLETPUNCH, :EXTREMESPEED, :STONEEDGE], ev: 80, iv: 31, ability: :JUSTIFIED },
      { level: 90, item: :FIGHTINGGEM, nature: :TIMID, moves: [:DARKPULSE, :AURASPHERE, :NASTYPLOT, :VACUUMWAVE], ev: 80, iv: 31, ability: :JUSTIFIED },
    ],
    :VOLCARONA => [
      { level: 90, item: :BUGGEM, nature: :TIMID, moves: [:FIERYDANCE, :BUGBUZZ, :QUIVERDANCE, :ROOST], ev: 80, iv: 31, ability: :SWARM },
      { level: 90, item: :FIREGEM, nature: :BOLD, moves: [:QUIVERDANCE, :FLAMETHROWER, :ROOST, :PSYCHIC], ev: 80, iv: 31, ability: :FLAMEBODY },
      { level: 90, item: :BUGGEM, nature: :MODEST, moves: [:FIERYDANCE, :QUIVERDANCE, :HURRICANE, :GIGADRAIN], ev: 80, iv: 31, ability: :FLAMEBODY },
    ],
    :ALAKAZAM => [
      { level: 90, item: :PSYCHICGEM, nature: :TIMID, moves: [:PSYCHIC, :FOCUSBLAST, :ENERGYBALL, :SHADOWBALL], ev: 80, iv: 31, ability: :MAGICGUARD },
      { level: 90, item: :PSYCHICGEM, nature: :MODEST, moves: [:PSYCHIC, :ENCORE, :FOULPLAY, :DAZZLINGGLEAM], ev: 80, iv: 31, ability: :SYNCHRONIZE },
      { level: 90, item: :PSYCHICGEM, nature: :TIMID, moves: [:PSYSHOCK, :CALMMIND, :FOCUSBLAST, :DAZZLINGGLEAM], ev: 80, iv: 31, ability: :MAGICGUARD },
    ],
    :DARMANITAN => [
      { level: 90, form: 2, item: :ICEGEM, nature: :ADAMANT, moves: [:BELLYDRUM, :FIREPUNCH, :ICEPUNCH, :ROCKSLIDE], ev: 80, iv: 31, ability: :ZENMODE },
      { level: 90, form: 2, item: :ICEGEM, nature: :JOLLY, moves: [:ICICLECRASH, :SUPERPOWER, :ROCKTOMB, :UTURN], ev: 80, iv: 31, ability: :GORILLATACTICS },
      { level: 90, form: 2, item: :ICEGEM, nature: :ADAMANT, moves: [:FLAREBLITZ, :ICEPUNCH, :WILLOWISP, :EARTHQUAKE], ev: 80, iv: 31, ability: :GORILLATACTICS },
    ],
    :BAXCALIBUR => [
      { level: 90, item: :DRAGONGEM, nature: :JOLLY, moves: [:ICICLESPEAR, :SCALESHOT, :SWORDSDANCE, :ZENHEADBUTT], ev: 80, iv: 31, ability: :THERMALEXCHANGE },
      { level: 90, item: :ICEGEM, nature: :IMPISH, moves: [:BODYPRESS, :ICICLECRASH, :DRAGONCLAW, :PROTECT], ev: 80, iv: 31, ability: :ICEBODY },
      { level: 90, item: :ICEGEM, nature: :ADAMANT, moves: [:GLAIVERUSH, :DRAGONDANCE, :ICESHARD, :EARTHQUAKE], ev: 80, iv: 31, ability: :THERMALEXCHANGE },
    ],
    :ANNIHILAPE => [
      { level: 90, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:RAGEFIST, :OUTRAGE, :STOMPINGTANTRUM, :DRAINPUNCH], ev: 80, iv: 31, ability: :INNERFOCUS },
      { level: 90, item: :FIGHTINGGEM, nature: :CAREFUL, moves: [:RAGEFIST, :REST, :BULKUP, :SLEEPTALK], ev: 80, iv: 31, ability: :DEFIANT },
      { level: 90, item: :FIGHTINGGEM, nature: :ADAMANT, moves: [:PHANTOMFORCE, :CLOSECOMBAT, :UTURN, :POISONJAB], ev: 80, iv: 31, ability: :VITALSPIRIT },
    ],
    :SCIZOR => [
      { level: 90, item: :STEELGEM, nature: :CAREFUL, moves: [:IRONDEFENSE, :ROOST, :BULLETPUNCH, :BUGBITE], ev: 80, iv: 31, ability: :TECHNICIAN },
      { level: 90, item: :BUGGEM, nature: :JOLLY, moves: [:AGILITY, :IRONHEAD, :LUNGE, :CLOSECOMBAT], ev: 80, iv: 31, ability: :SWARM },
      { level: 90, item: :STEELGEM, nature: :ADAMANT, moves: [:SWORDSDANCE, :BULLETPUNCH, :UTURN, :BRICKBREAK], ev: 80, iv: 31, ability: :TECHNICIAN },
    ],
    :GARGANACL => [
      { level: 90, item: :ROCKGEM, nature: :IMPISH, moves: [:CURSE, :ROCKSLIDE, :HEAVYSLAM, :BODYPRESS], ev: 80, iv: 31, ability: :PURIFYINGSALT },
      { level: 90, item: :ROCKGEM, nature: :RELAXED, moves: [:SALTCURE, :RECOVER, :TOXIC, :SANDSTORM], ev: 80, iv: 31, ability: :PURIFYINGSALT },
      { level: 90, item: :ROCKGEM, nature: :ADAMANT, moves: [:STONEEDGE, :EXPLOSION, :EARTHQUAKE, :HAMMERARM], ev: 80, iv: 31, ability: :CLEARBODY },
    ],
    :GLIMMORA => [
      { level: 90, item: :ROCKGEM, nature: :MODEST, moves: [:METEORBEAM, :EARTHPOWER, :ENERGYBALL, :FLASHCANNON], ev: 80, iv: 31, ability: :TOXICDEBRIS },
      { level: 90, item: :ROCKGEM, nature: :BOLD, moves: [:SPIKYSHIELD, :SANDSTORM, :TOXIC, :POWERGEM], ev: 80, iv: 31, ability: :CORROSION },
      { level: 90, item: :POISONGEM, nature: :BOLD, moves: [:STEALTHROCK, :SPIKES, :POWERGEM, :SLUDGEBOMB], ev: 80, iv: 31, ability: :TOXICDEBRIS },
    ],
    :BLISSEY => [
      { level: 90, item: :NORMALGEM, nature: :CALM, moves: [:CALMMIND, :ICEBEAM, :FLAMETHROWER, :THUNDERBOLT], ev: 80, iv: 31, ability: :SERENEGRACE },
      { level: 90, item: :NORMALGEM, nature: :BOLD, moves: [:SEISMICTOSS, :WISH, :TOXIC, :PROTECT], ev: 80, iv: 31, ability: :NATURALCURE },
      { level: 90, item: :NORMALGEM, nature: :MODEST, moves: [:STEALTHROCK, :THUNDERWAVE, :PSYCHIC, :FOCUSBLAST], ev: 80, iv: 31, ability: :NATURALCURE },
    ],
    :ZOROARK => [
      { level: 90, item: :DARKGEM, nature: :NAIVE, moves: [:NIGHTDAZE, :FLAMETHROWER, :UTURN, :SUCKERPUNCH], ev: 50, iv: 20, ability: :ILLUSION },
      { level: 90, item: :DARKGEM, nature: :TIMID, moves: [:DARKPULSE, :NASTYPLOT, :UTURN, :TAUNT], ev: 50, iv: 20, ability: :ILLUSION },
      { level: 90, item: :DARKGEM, nature: :HASTY, moves: [:FOULPLAY, :FLAMETHROWER, :UTURN, :PROTECT], ev: 50, iv: 20, ability: :ILLUSION },
    ],
    :LAPRAS => [
      { level: 90, item: :WATERGEM, nature: :IMPISH, moves: [:ICESHARD, :CURSE, :REST, :WATERFALL], ev: 80, iv: 31, ability: :SHELLARMOR },
      { level: 90, item: :ICEGEM, nature: :BOLD, moves: [:BLIZZARD, :HYDROPUMP, :CHARM, :THUNDER], ev: 80, iv: 31, ability: :WATERABSORB },
      { level: 90, item: :WATERGEM, nature: :MODEST, moves: [:ALLURINGVOICE, :PSYCHICNOISE, :SPARKLINGARIA, :ICYWIND], ev: 80, iv: 31, ability: :WATERABSORB },
      { level: 90, form: 1, item: :ROCKGEM, nature: :MODEST, moves: [:BLIZZARD, :ZAPCANNON, :FOCUSBLAST, :METEORBEAM], ev: 80, iv: 31, ability: :NOGUARD },
      { level: 90, form: 1, item: :PSYCHICGEM, nature: :IMPISH, moves: [:DRAGONDANCE, :ROCKSLIDE, :ZENHEADBUTT, :BODYSLAM], ev: 80, iv: 31, ability: :SOLIDROCK },
      { level: 90, form: 1, item: :ROCKGEM, nature: :ADAMANT, moves: [:SING, :STONEEDGE, :IRONTAIL, :ZENHEADBUTT], ev: 80, iv: 31, ability: :NOGUARD },
    ],
    :STARMIE => [
      { level: 90, item: :WATERGEM, nature: :MODEST, moves: [:HYDROPUMP, :PSYCHIC, :THUNDER, :PROTECT], ev: 80, iv: 31, ability: :ANALYTIC },
      { level: 90, item: :WATERGEM, nature: :MODEST, moves: [:POWERGEM, :PSYSHOCK, :ICEBEAM, :RECOVER], ev: 80, iv: 31, ability: :NATURALCURE },
      { level: 90, item: :WATERGEM, nature: :BOLD, moves: [:SCALD, :ICYWIND, :RECOVER, :REFLECT], ev: 80, iv: 31, ability: :ANALYTIC },
    ],
    :FROSLASS => [
      { level: 90, form: 1, item: :WATERGEM, nature: :MODEST, moves: [:MUDDYWATER, :CONFUSERAY, :TOXIC, :GIGADRAIN], ev: 80, iv: 31, ability: :GOOEY },
      { level: 90, form: 1, item: :WATERGEM, nature: :MODEST, moves: [:WATERSPOUT, :LEAFSTORM, :MUDBARRAGE, :IRRITATION], ev: 80, iv: 31, ability: :ADAPTABILITY },
      { level: 90, form: 1, item: :GRASSGEM, nature: :ADAMANT, moves: [:SLASHANDBURN, :WATERFALL, :ROCKSLIDE, :GUNKSHOT], ev: 80, iv: 31, ability: :ADAPTABILITY },
    ],
    :CHANDELURE => [
      { level: 90, form: 1, item: :GHOSTGEM, nature: :MODEST, moves: [:DISCHARGE, :BURNINGJEALOUSY, :PROTECT, :SHADOWBALL], ev: 80, iv: 31, ability: :LEVITATE },
      { level: 90, form: 1, item: :ELECTRICGEM, nature: :MODEST, moves: [:THUNDERBOLT, :HEX, :WILLOWISP, :CALMMIND], ev: 80, iv: 31, ability: :VOLTABSORB },
      { level: 90, form: 1, item: :GHOSTGEM, nature: :MODEST, moves: [:VOLTSWITCH, :SHADOWBALL, :SIGNALBEAM, :OVERHEAT], ev: 80, iv: 31, ability: :LEVITATE },
    ]
  },
}
