CURRENCYHASH = {
  :Money => {
    :name => "Money",
    :shorthand => "$",
    :shortdisplay => "@s@ @f@",
    :desc => "The main currency used in the Pokémon world.",
  },
  :BP => {
    :name => "Battle Point",
    :plural => "Battle Points",
    :shorthand => "BP",
    :desc => "The main currency used by various Battle Facilities.",
    :type => :Variable,
  },
  :AP => {
    :name => "Achievement Point",
    :plural => "Achievement Points",
    :shorthand => "AP",
    :desc => "Points obtained from reaching certain milestones. Can be exchanged for prizes.",
    :type => :Variable,
  },
  :Coins => {
    :name => "Coin",
    :plural => "Coins",
    :shorthand => "C",
    :desc => "Coins obtained at the Game Corner. Can be exchanged for prizes.",
  },
  :PuppetCoins => {
    :name => "Puppet Coin",
    :plural => "Puppet Coins",
    :shorthand => "PC",
    :desc => "Coins obtained from the Puppet Master. Can be exchanged for a question.",
    :type => :Variable,
  },
  :RedEssence => {
    :name => "Red Essence",
    :shorthand => "RE",
    :desc => "Residue left behind from Shadow Pokémon.",
    :type => :Variable,
  },
  :BLKPRISM => {
    :shorthand => "Prism",
    :shortplural => "Prisms",
    :type => :Item,
  },
  :TINYMUSHROOM => {
    :name => "Tiny Shroom",
    :plural => "Tiny Shrooms",
    :shorthand => "Shroom",
    :shortplural => "Shrooms",
    :type => :Item,
  },
  :BIGMUSHROOM => {
    :shorthand => "Shroom",
    :shortplural => "Shrooms",
    :type => :Item,
  },
  :BALMMUSHROOM => {
    :name => "Balm Shroom",
    :plural => "Balm Shrooms",
    :shorthand => "Shroom",
    :shortplural => "Shrooms",
    :type => :Item,
  },
  :REDSHARD => {
    :shorthand => "Red",
    :type => :Item,
  },
  :BLUESHARD => {
    :shorthand => "Blue",
    :type => :Item,
  },
  :GREENSHARD => {
    :shorthand => "Green",
    :type => :Item,
  },
  :YELLOWSHARD => {
    :shorthand => "Yellow",
    :type => :Item,
  },
  :UMBRALSHARD => {
    :shorthand => "Umbral",
    :type => :Item
  }
}
