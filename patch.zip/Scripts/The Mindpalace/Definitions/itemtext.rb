ITEMHASH = {
  :REPEL => {
    :ID => 1,
    :name => "Repel",
    :desc => "An item that prevents weak wild Pokémon from appearing for 200 steps after its use.",
    :price => 400,
    :overworld => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :SUPERREPEL => {
    :ID => 2,
    :name => "Super Repel",
    :desc => "An item that prevents weak wild Pokémon from appearing for 400 steps after its use.",
    :price => 700,
    :overworld => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :MAXREPEL => {
    :ID => 3,
    :name => "Max Repel",
    :desc => "An item that prevents weak wild Pokémon from appearing for 500 steps after its use.",
    :price => 850,
    :overworld => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :BLACKFLUTE => {
    :ID => 4,
    :name => "Black Flute",
    :desc => "A black flute made from blown glass. Its melody makes wild Pokémon less likely to appear.",
    :price => 400,
    :overworld => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :WHITEFLUTE => {
    :ID => 5,
    :name => "White Flute",
    :desc => "A white flute made from blown glass. Its melody makes wild Pokémon more likely to appear.",
    :price => 500,
    :overworld => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :HONEY => {
    :ID => 6,
    :name => "Honey",
    :unit => "jar of Honey",
    :desc => "A sweet honey with an aroma that attracts wild Pokémon when used in grass, caves or on special trees.",
    :price => 100,
    :overworld => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :ESCAPEROPE => {
    :ID => 7,
    :name => "Escape Rope",
    :desc => "A long, durable rope. Use it to escape instantly from a cave or a dungeon.",
    :price => 550,
    :overworld => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :REDSHARD => {
    :ID => 8,
    :name => "Red Shard",
    :desc => "A small red shard. It appears to be from some sort of implement made long ago.",
    :price => 200,
    :overworld => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :YELLOWSHARD => {
    :ID => 9,
    :name => "Yellow Shard",
    :desc => "A small yellow shard. It appears to be from some sort of implement made long ago.",
    :price => 200,
    :overworld => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :BLUESHARD => {
    :ID => 10,
    :name => "Blue Shard",
    :desc => "A small blue shard. It appears to be from some sort of implement made long ago.",
    :price => 200,
    :overworld => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :GREENSHARD => {
    :ID => 11,
    :name => "Green Shard",
    :desc => "A small green shard. It appears to be from some sort of implement made long ago.",
    :price => 200,
    :overworld => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :FIRESTONE => {
    :ID => 12,
    :name => "Fire Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It is colored orange.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :THUNDERSTONE => {
    :ID => 13,
    :name => "Thunder Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It has a thunderbolt pattern.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :WATERSTONE => {
    :ID => 14,
    :name => "Water Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It is a clear, light blue.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :LEAFSTONE => {
    :ID => 15,
    :name => "Leaf Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It has a leaf pattern.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :MOONSTONE => {
    :ID => 16,
    :name => "Moon Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It is as black as the night sky.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :SUNSTONE => {
    :ID => 17,
    :name => "Sun Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It is as red as the sun.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :DUSKSTONE => {
    :ID => 18,
    :name => "Dusk Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It is as dark as dark can be.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 80,
  },

  :DAWNSTONE => {
    :ID => 19,
    :name => "Dawn Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It sparkles like eyes.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 80,
  },

  :SHINYSTONE => {
    :ID => 20,
    :name => "Shiny Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It shines with a dazzling light.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 80,
  },

  :HELIXFOSSIL => {
    :ID => 28,
    :name => "Helix Fossil",
    :desc => "A fossil of an ancient Pokémon that lived in the sea. It appears to be part of a seashell.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :DOMEFOSSIL => {
    :ID => 29,
    :name => "Dome Fossil",
    :desc => "A fossil of an ancient Pokémon that lived in the sea. It appears to be part of a shell.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :OLDAMBER => {
    :ID => 30,
    :name => "Old Amber",
    :desc => "A piece of amber that contains the genetic material of an ancient Pokémon. It is clear with a reddish tint.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :ROOTFOSSIL => {
    :ID => 31,
    :name => "Root Fossil",
    :desc => "A fossil of an ancient Pokémon that lived in the sea. It appears to be part of a plant root.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :CLAWFOSSIL => {
    :ID => 32,
    :name => "Claw Fossil",
    :desc => "A fossil of an ancient Pokémon that lived in the sea. It appears to be part of a claw.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :SKULLFOSSIL => {
    :ID => 33,
    :name => "Skull Fossil",
    :desc => "A fossil from a prehistoric Pokémon that lived on the land. It appears to be part of a head.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :ARMORFOSSIL => {
    :ID => 34,
    :name => "Armor Fossil",
    :desc => "A fossil from a prehistoric Pokémon that lived on the land. It appears to be part of a collar.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :COVERFOSSIL => {
    :ID => 35,
    :name => "Cover Fossil",
    :desc => "A fossil of an ancient Pokémon that lived in the sea in ancient times. It appears to be part of its back.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :PLUMEFOSSIL => {
    :ID => 36,
    :name => "Plume Fossil",
    :desc => "A fossil of an ancient Pokémon that flew in the sky in ancient times. It appears to be part of its wing.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :PRETTYWING => {
    :ID => 37,
    :name => "Pretty Feather",
    :desc => "Though this feather is beautiful, it's just a regular feather and has no effect on Pokémon.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 20,
    :justsell => true,
  },

  :TINYMUSHROOM => {
    :ID => 38,
    :name => "Tiny Mushroom",
    :desc => "A small and rare mushroom. It is sought after by collectors.",
    :price => 500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :BIGMUSHROOM => {
    :ID => 39,
    :name => "Big Mushroom",
    :desc => "A large and rare mushroom. It is sought after by collectors.",
    :price => 5000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :BALMMUSHROOM => {
    :ID => 40,
    :name => "Balm Mushroom",
    :desc => "A rare mushroom which gives off a nice fragrance. A maniac will buy it for a high price.",
    :price => 50000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :PEARL => {
    :ID => 41,
    :name => "Pearl",
    :desc => "A somewhat-small pearl that sparkles in a pretty silver color. It can be sold cheaply to shops.",
    :price => 1400,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :BIGPEARL => {
    :ID => 42,
    :name => "Big Pearl",
    :desc => "A quite-large pearl that sparkles in a pretty silver color. It can be sold at a high price to shops.",
    :price => 7500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :PEARLSTRING => {
    :ID => 43,
    :name => "Pearl String",
    :desc => "Very large pearls that sparkle in a pretty silver color. A maniac will buy them for a high price.",
    :price => 50000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :STARDUST => {
    :ID => 44,
    :name => "Stardust",
    :unit => "bag of Stardust",
    :desc => "Lovely, red-colored sand with a loose, silky feel. It can be sold at a high price to shops.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :STARPIECE => {
    :ID => 45,
    :name => "Star Piece",
    :desc => "A shard of a pretty gem that sparkles in a red color. It can be sold at a high price to shops.",
    :price => 9800,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :COMETSHARD => {
    :ID => 46,
    :name => "Comet Shard",
    :desc => "A shard which fell to the ground when a comet approached. A maniac will buy it for a high price.",
    :price => 120000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :NUGGET => {
    :ID => 47,
    :name => "Nugget",
    :desc => "A nugget of pure gold that gives off a lustrous gleam. It can be sold at a high price to shops.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :BIGNUGGET => {
    :ID => 48,
    :name => "Big Nugget",
    :desc => "A big nugget of pure gold that gives off a lustrous gleam. A maniac will buy it for a high price.",
    :price => 60000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 130,
    :justsell => true,
  },

  :HEARTSCALE => {
    :ID => 49,
    :name => "Heart Scale",
    :desc => "A pretty, heart-shaped scale that is extremely rare. It glows faintly in the colors of the rainbow.",
    :price => 100,
    :overworld => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :RAREBONE => {
    :ID => 51,
    :name => "Rare Bone",
    :desc => "A bone that is extremely valuable for Pokémon archaeology. It can be sold for a high price to shops.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :justsell => true,
  },

  :RELICCOPPER => {
    :ID => 52,
    :name => "Relic Copper",
    :desc => "A copper coin used in a civilization about 3,000 years ago. A maniac will buy it for a high price.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :RELICSILVER => {
    :ID => 53,
    :name => "Relic Silver",
    :desc => "A silver coin used in a civilization about 3,000 years ago. A maniac will buy it for a high price.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :RELICGOLD => {
    :ID => 54,
    :name => "Relic Gold",
    :desc => "A gold coin used in a civilization about 3,000 years ago. A maniac will buy it for a high price.",
    :price => 20000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :RELICVASE => {
    :ID => 55,
    :name => "Relic Vase",
    :desc => "A vase made in a civilization about 3,000 years ago. A maniac will buy it for a high price.",
    :price => 100000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :RELICBAND => {
    :ID => 56,
    :name => "Relic Band",
    :desc => "A bracelet made in a civilization about 3,000 years ago. A maniac will buy it for a high price.",
    :price => 200000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :RELICSTATUE => {
    :ID => 57,
    :name => "Relic Statue",
    :desc => "A stone figure made in a civilization about 3,000 years ago. A maniac will buy it for a high price.",
    :price => 400000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :RELICCROWN => {
    :ID => 58,
    :name => "Relic Crown",
    :desc => "A crown made in a civilization about 3,000 years ago. A maniac will buy it for a high price.",
    :price => 600000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :GROWTHMULCH => {
    :ID => 59,
    :name => "Growth Mulch",
    :unit => "bag of Growth Mulch",
    :desc => "A fertilizer to be spread on soft soil in regions where Berries are grown. A maniac will buy it for a high price.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :sidequest => true,
  },

  :DAMPMULCH => {
    :ID => 60,
    :name => "Damp Mulch",
    :unit => "bag of Damp Mulch",
    :desc => "A fertilizer to be spread on soft soil in regions where Berries are grown. A maniac will buy it for a high price.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :sidequest => true,
  },

  :STABLEMULCH => {
    :ID => 61,
    :name => "Stable Mulch",
    :unit => "bag of Stable Mulch",
    :desc => "A fertilizer to be spread on soft soil in regions where Berries are grown. A maniac will buy it for a high price.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :sidequest => true,
  },

  :GOOEYMULCH => {
    :ID => 62,
    :name => "Gooey Mulch",
    :unit => "bag of Gooey Mulch",
    :desc => "A fertilizer to be spread on soft soil in regions where Berries are grown. A maniac will buy it for a high price.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :sidequest => true,
  },

  :SHOALSALT => {
    :ID => 63,
    :name => "Shoal Salt",
    :unit => "pile of Shoal Salt",
    :desc => "Pure salt that can be discovered deep inside the Shoal Cave. A maniac will buy it for a high price.",
    :price => 20,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :SHOALSHELL => {
    :ID => 64,
    :name => "Shoal Shell",
    :desc => "A pretty seashell that can be found deep inside the Shoal Cave. A maniac will buy it for a high price.",
    :price => 20,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :ODDKEYSTONE => {
    :ID => 65,
    :name => "Odd Keystone",
    :desc => "A vital item that is needed to keep a stone tower from collapsing. Voices can be heard from it occasionally.",
    :price => 2100,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
    :sidequest => true,
  },

  :AIRBALLOON => {
    :ID => 66,
    :name => "Air Balloon",
    :desc => "When held by a Pokémon, the Pokémon will float into the air. When the holder is attacked, this item will burst.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 10,
  },

  :BRIGHTPOWDER => {
    :ID => 67,
    :name => "Bright Powder",
    :unit => "bag of Bright Powder",
    :desc => "An item to be held by a Pokémon. It casts a tricky glare that lowers the opponent's accuracy.",
    :price => 10,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :EVIOLITE => {
    :ID => 68,
    :name => "Eviolite",
    :desc => "A mysterious evolutionary lump. When held, it raises the Defense and Sp. Def of a Pokémon that can still evolve.",
    :price => 12500,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 40,
  },

  :FLOATSTONE => {
    :ID => 69,
    :name => "Float Stone",
    :desc => "A very light stone. It reduces the weight of a Pokémon when held.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :DESTINYKNOT => {
    :ID => 70,
    :name => "Destiny Knot",
    :desc => "A long, thin, bright-red string to be held by a Pokémon. If the holder becomes infatuated, the foe does too.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 10,
  },

  :ROCKYHELMET => {
    :ID => 71,
    :name => "Rocky Helmet",
    :desc => "If the holder of this item takes damage, the attacker will also be damaged upon contact.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 60,
  },

  :EJECTBUTTON => {
    :ID => 72,
    :name => "Eject Button",
    :desc => "If the holder is hit by an attack, it will switch with another Pokémon in your party.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :REDCARD => {
    :ID => 73,
    :name => "Red Card",
    :desc => "A card with a mysterious power. When the holder is struck by a foe, the attacker is removed from battle.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 10,
  },

  :SHEDSHELL => {
    :ID => 74,
    :name => "Shed Shell",
    :desc => "A tough, discarded carapace to be held by a Pokémon. It enables the holder to switch with a waiting Pokémon in battle.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :SMOKEBALL => {
    :ID => 75,
    :name => "Smoke Ball",
    :desc => "An item to be held by a Pokémon. It enables the holder to flee from any wild Pokémon without fail.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 30,
  },

  :LUCKYEGG => {
    :ID => 76,
    :name => "Lucky Egg",
    :desc => "An item to be held by a Pokémon. It is an egg filled with happiness that earns extra Exp. Points in battle.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 30,
  },

  :EXPSHARE => {
    :ID => 77,
    :name => "Exp. Share",
    :desc => "An item to be held by a Pokémon. The holder gets a share of a battle's Exp. Points without battling.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 30,
  },

  :AMULETCOIN => {
    :ID => 78,
    :name => "Amulet Coin",
    :desc => "An item to be held by a Pokémon. It doubles a battle's prize money if the holding Pokémon joins in.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 30,
  },

  :SOOTHEBELL => {
    :ID => 79,
    :name => "Soothe Bell",
    :desc => "An item to be held by a Pokémon. It is a bell with a comforting chime that calms the holder and makes it friendly.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 10,
  },

  :CLEANSETAG => {
    :ID => 80,
    :name => "Cleanse Tag",
    :desc => "An item to be held by a Pokémon. It helps keep wild Pokémon away if the holder is the first one in the party.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :CHOICEBAND => {
    :ID => 81,
    :name => "Choice Band",
    :desc => "An item to be held by a Pokémon. This headband ups Attack, but allows the use of only one of its moves.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :CHOICESPECS => {
    :ID => 82,
    :name => "Choice Specs",
    :unit => "pair of Choice Specs",
    :desc => "An item to be held by a Pokémon. These distinctive glasses boost Sp. Atk, but allow the use of only one of its moves.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :CHOICESCARF => {
    :ID => 83,
    :name => "Choice Scarf",
    :plural => "Choice Scarves",
    :desc => "An item to be held by a Pokémon. This scarf boosts Speed, but allows the use of only one of its moves.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :HEATROCK => {
    :ID => 84,
    :name => "Heat Rock",
    :desc => "A Pokémon held item that extends the duration of the move Sunny Day used by the holder.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 60,
  },

  :DAMPROCK => {
    :ID => 85,
    :name => "Damp Rock",
    :desc => "A Pokémon held item that extends the duration of the move Rain Dance used by the holder.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 60,
  },

  :SMOOTHROCK => {
    :ID => 86,
    :name => "Smooth Rock",
    :desc => "A Pokémon held item that extends the duration of the move Sandstorm used by the holder.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :ICYROCK => {
    :ID => 87,
    :name => "Icy Rock",
    :desc => "A Pokémon held item that extends the duration of the move Hail used by the holder.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 40,
  },

  :LIGHTCLAY => {
    :ID => 88,
    :name => "Light Clay",
    :unit => "lump of Light Clay",
    :desc => "A Pokémon held item that extends the duration of barrier moves like Light Screen and Reflect used by the holder.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :GRIPCLAW => {
    :ID => 89,
    :name => "Grip Claw",
    :desc => "A Pokémon held item that extends the duration of multiturn attacks like Bind and Wrap.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 90,
  },

  :BINDINGBAND => {
    :ID => 90,
    :name => "Binding Band",
    :desc => "A band that increases the power of binding moves when held.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :BIGROOT => {
    :ID => 91,
    :name => "Big Root",
    :desc => "A Pokémon held item that boosts the power of HP-stealing moves to let the holder recover more HP.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :BLACKSLUDGE => {
    :ID => 92,
    :name => "Black Sludge",
    :unit => "blob of Black Sludge",
    :desc => "A held item that gradually restores the HP of Poison-type Pokémon. It inflicts damage on all other types.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :LEFTOVERS => {
    :ID => 93,
    :name => "Leftovers",
    :unit => "serving of Leftovers",
    :desc => "An item to be held by a Pokémon. The holder's HP is gradually restored during battle.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :SHELLBELL => {
    :ID => 94,
    :name => "Shell Bell",
    :desc => "An item to be held by a Pokémon. The holder's HP is restored a little every time it inflicts damage.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :MENTALHERB => {
    :ID => 95,
    :name => "Mental Herb",
    :desc => "An item to be held by a Pokémon. It snaps the holder out of infatuation. It can be used only once.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 10,
  },

  :WHITEHERB => {
    :ID => 96,
    :name => "White Herb",
    :desc => "An item to be held by a Pokémon. It restores any lowered stat in battle. It can be used only once.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 10,
  },

  :POWERHERB => {
    :ID => 97,
    :name => "Power Herb",
    :desc => "A single-use item to be held by a Pokémon. It allows the immediate use of a move that charges on the first turn.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 10,
  },

  :ABSORBBULB => {
    :ID => 98,
    :name => "Absorb Bulb",
    :desc => "A consumable bulb. If the holder is hit by a Water-type move, its Sp. Atk will rise.",
    :price => 750,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :CELLBATTERY => {
    :ID => 99,
    :name => "Cell Battery",
    :desc => "A consumable battery. If the holder is hit by an Electric-type move, its Attack will rise.",
    :price => 750,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :LIFEORB => {
    :ID => 100,
    :name => "Life Orb",
    :desc => "An item to be held by a Pokémon. It boosts the power of moves, but at the cost of some HP on each hit.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :EXPERTBELT => {
    :ID => 101,
    :name => "Expert Belt",
    :desc => "An item to be held by a Pokémon. It is a well-worn belt that slightly boosts the power of supereffective moves.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :METRONOME => {
    :ID => 102,
    :name => "Metronome",
    :desc => "A Pokémon held item that boosts a move used consecutively. Its effect is reset if another move is used.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :MUSCLEBAND => {
    :ID => 103,
    :name => "Muscle Band",
    :desc => "An item to be held by a Pokémon. Boosts the power of physical moves by 10%.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :WISEGLASSES => {
    :ID => 104,
    :name => "Wise Glasses",
    :unit => "pair of Wise Glasses",
    :desc => "An item to be held by a Pokémon. Boosts the power of special moves by 10%.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :RAZORCLAW => {
    :ID => 105,
    :name => "Razor Claw",
  	:desc => "A sharply hooked claw that boosts the power of slicing moves by 20% when held.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
  },

  :SCOPELENS => {
    :ID => 106,
    :name => "Scope Lens",
    :plural => "Scope Lenses",
    :desc => "An item to be held by a Pokémon. It is a lens that boosts the holder's critical-hit ratio.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :WIDELENS => {
    :ID => 107,
    :name => "Wide Lens",
    :plural => "Wide Lenses",
    :desc => "An item to be held by a Pokémon. It is a magnifying lens that slightly boosts the accuracy of moves.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :ZOOMLENS => {
    :ID => 108,
    :name => "Zoom Lens",
    :plural => "Zoom Lenses",
    :desc => "An item to be held by a Pokémon. If the holder moves after its target, its accuracy will be boosted.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :KINGSROCK => {
    :ID => 109,
    :name => "King's Rock",
  	:desc => "An imposing, jagged stone. The holder deals 6% more damage for each fainted party member.",
    :price => 100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :RAZORFANG => {
    :ID => 110,
    :name => "Razor Fang",
  	:desc => "A sharp fang that increases the power of biting moves by 20% when held.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :LAGGINGTAIL => {
    :ID => 111,
    :name => "Lagging Tail",
    :desc => "An item to be held by a Pokémon. It is tremendously heavy and makes the holder move slower than usual.",
    :price => 500,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :QUICKCLAW => {
    :ID => 112,
    :name => "Quick Claw",
  	:desc => "A sharp and curved claw that boosts the power of raised-priority moves by 20% when held.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 80,
  },

  :FOCUSBAND => {
    :ID => 113,
    :name => "Focus Band",
  	:desc => "A tight band that improves focus. Holder takes 10% less damage if the move wouldn't KO them or trigger Sturdy.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :FOCUSSASH => {
    :ID => 114,
    :name => "Focus Sash",
    :plural => "Focus Sashes",
    :desc => "An item to be held by a Pokémon. If it has full HP, the holder will endure one potential KO attack, leaving 1 HP.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :consumehold => true,
    :flingdamage => 10,
  },

  :FLAMEORB => {
    :ID => 115,
    :name => "Flame Orb",
    :desc => "An item to be held by a Pokémon. It is a bizarre orb that inflicts a burn on the holder in battle.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :TOXICORB => {
    :ID => 116,
    :name => "Toxic Orb",
    :desc => "An item to be held by a Pokémon. It is a bizarre orb that badly poisons the holder in battle.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :STICKYBARB => {
    :ID => 117,
    :name => "Sticky Barb",
    :desc => "A held item that damages the holder on every turn. It may latch on to foes and allies that touch the holder.",
    :price => 500,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 80,
  },

  :IRONBALL => {
    :ID => 118,
    :name => "Iron Ball",
    :desc => "A Pokémon held item that cuts Speed. It makes Flying-type and levitating holders susceptible to Ground moves.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 130,
  },

  :RINGTARGET => {
    :ID => 119,
    :name => "Ring Target",
    :desc => "Moves that would otherwise have no effect will land on the Pokémon that holds it.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 10,
  },

  :MACHOBRACE => {
    :ID => 120,
    :name => "Macho Brace",
  	:desc => "An item to be used on a Pokémon that allows modification of its stats.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
  },

  :POWERWEIGHT => {
    :ID => 121,
    :name => "Power Weight",
    :desc => "A Pokémon held item that promotes HP gain on leveling, but reduces the Speed stat.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 70,
  },

  :POWERBRACER => {
    :ID => 122,
    :name => "Power Bracer",
    :desc => "A Pokémon held item that promotes Attack gain on leveling, but reduces the Speed stat.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 70,
  },

  :POWERBELT => {
    :ID => 123,
    :name => "Power Belt",
    :desc => "A Pokémon held item that promotes Defense gain on leveling, but reduces the Speed stat.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 70,
  },

  :POWERLENS => {
    :ID => 124,
    :name => "Power Lens",
    :plural => "Power Lenses",
    :desc => "A Pokémon held item that promotes Sp. Atk gain on leveling, but reduces the Speed stat.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 70,
  },

  :POWERBAND => {
    :ID => 125,
    :name => "Power Band",
    :desc => "A Pokémon held item that promotes Sp. Def gain on leveling, but reduces the Speed stat.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 70,
  },

  :POWERANKLET => {
    :ID => 126,
    :name => "Power Anklet",
    :desc => "A Pokémon held item that promotes Speed gain on leveling, but reduces the Speed stat.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 70,
  },

  :LAXINCENSE => {
    :ID => 127,
    :name => "Lax Incense",
    :unit => "jar of Lax Incense",
    :desc => "An item to be held by a Pokémon. The tricky aroma of this incense may make attacks miss the holder.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :flingdamage => 10,
  },

  :FULLINCENSE => {
    :ID => 128,
    :name => "Full Incense",
    :unit => "jar of Full Incense",
    :desc => "An item to be held by a Pokémon. It is an exotic-smelling incense that makes the holder bloated and slow moving.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :flingdamage => 10,
  },

  :LUCKINCENSE => {
    :ID => 129,
    :name => "Luck Incense",
    :unit => "jar of Luck Incense",
    :desc => "An item to be held by a Pokémon. It doubles a battle's prize money if the holding Pokémon joins in.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :flingdamage => 10,
  },

  :PUREINCENSE => {
    :ID => 130,
    :name => "Pure Incense",
    :unit => "jar of Pure Incense",
    :desc => "An item to be held by a Pokémon. It helps keep wild Pokémon away if the holder is the first one in the party.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :flingdamage => 10,
  },

  :SEAINCENSE => {
    :ID => 131,
    :name => "Sea Incense",
    :unit => "jar of Sea Incense",
    :desc => "An item to be held by a Pokémon. It is incense with a curious aroma that boosts the power of Water-type moves.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :typeboost => :WATER,
    :flingdamage => 10,
  },

  :WAVEINCENSE => {
    :ID => 132,
    :name => "Wave Incense",
    :unit => "jar of Wave Incense",
    :desc => "An item to be held by a Pokémon. It is incense with a curious aroma that boosts the power of Water-type moves.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :typeboost => :WATER,
    :flingdamage => 10,
  },

  :ROSEINCENSE => {
    :ID => 133,
    :name => "Rose Incense",
    :unit => "jar of Rose Incense",
    :desc => "An item to be held by a Pokémon. It is an exotic-smelling incense that boosts the power of Grass-type moves.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :typeboost => :GRASS,
    :flingdamage => 10,
  },

  :ODDINCENSE => {
    :ID => 134,
    :name => "Odd Incense",
    :unit => "jar of Odd Incense",
    :desc => "An item to be held by a Pokémon. It is an exotic-smelling incense that boosts the power of Psychic-type moves.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :typeboost => :PSYCHIC,
    :flingdamage => 10,
  },

  :ROCKINCENSE => {
    :ID => 135,
    :name => "Rock Incense",
    :unit => "jar of Rock Incense",
    :desc => "An item to be held by a Pokémon. It is an exotic-smelling incense that boosts the power of Rock-type moves.",
    :price => 9600,
    :noUseInBattle => true,
    :noUse => true,
    :incense => true,
    :typeboost => :ROCK,
    :flingdamage => 10,
  },

  :CHARCOAL => {
    :ID => 136,
    :name => "Charcoal",
    :unit => "piece of Charcoal",
    :desc => "An item to be held by a Pokémon. Boosts the power of Fire-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FIRE,
    :flingdamage => 30,
  },

  :MYSTICWATER => {
    :ID => 137,
    :name => "Mystic Water",
    :desc => "An item to be held by a Pokémon. Boosts the power of Water-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :WATER,
    :flingdamage => 30,
  },

  :MAGNET => {
    :ID => 138,
    :name => "Magnet",
    :desc => "An item to be held by a Pokémon. Boosts the power of Electric-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ELECTRIC,
    :flingdamage => 30,
  },

  :MIRACLESEED => {
    :ID => 139,
    :name => "Miracle Seed",
    :desc => "An item to be held by a Pokémon. Boosts the power of Grass-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GRASS,
    :flingdamage => 30,
  },

  :NEVERMELTICE => {
    :ID => 140,
    :name => "Never-Melt Ice",
    :unit => "piece of Never-Melt Ice",
    :desc => "An item to be held by a Pokémon. Boosts the power of Ice-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ICE,
    :flingdamage => 30,
  },

  :BLACKBELT => {
    :ID => 141,
    :name => "Black Belt",
    :desc => "An item to be held by a Pokémon. Boosts the power of Fighting-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FIGHTING,
    :flingdamage => 30,
  },

  :POISONBARB => {
    :ID => 142,
    :name => "Poison Barb",
    :desc => "An item to be held by a Pokémon. Boosts the power of Poison-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :POISON,
    :flingdamage => 70,
  },

  :SOFTSAND => {
    :ID => 143,
    :name => "Soft Sand",
    :desc => "An item to be held by a Pokémon. Boosts the power of Ground-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GROUND,
    :flingdamage => 10,
  },

  :SHARPBEAK => {
    :ID => 144,
    :name => "Sharp Beak",
    :desc => "An item to be held by a Pokémon. Boosts the power of Flying-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FLYING,
    :flingdamage => 50,
  },

  :TWISTEDSPOON => {
    :ID => 145,
    :name => "Twisted Spoon",
    :desc => "An item to be held by a Pokémon. Boosts the power of Psychic-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :PSYCHIC,
    :flingdamage => 30,
  },

  :SILVERPOWDER => {
    :ID => 146,
    :name => "Silver Powder",
    :desc => "An item to be held by a Pokémon. Boosts the power of Bug-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :BUG,
    :flingdamage => 10,
  },

  :HARDSTONE => {
    :ID => 147,
    :name => "Hard Stone",
    :desc => "An item to be held by a Pokémon. Boosts the power of Rock-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ROCK,
    :flingdamage => 100,
  },

  :SPELLTAG => {
    :ID => 148,
    :name => "Spell Tag",
    :desc => "An item to be held by a Pokémon. Boosts the power of Ghost-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GHOST,
    :flingdamage => 30,
  },

  :DRAGONFANG => {
    :ID => 149,
    :name => "Dragon Fang",
    :desc => "An item to be held by a Pokémon. Boosts the power of Dragon-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :DRAGON,
    :flingdamage => 70,
  },

  :BLACKGLASSES => {
    :ID => 150,
    :name => "Black Glasses",
    :desc => "An item to be held by a Pokémon. Boosts the power of Dark-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :DARK,
    :flingdamage => 30,
  },

  :METALCOAT => {
    :ID => 151,
    :name => "Metal Coat",
    :desc => "An item to be held by a Pokémon. Boosts the power of Steel-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :STEEL,
    :flingdamage => 30,
  },

  :SILKSCARF => {
    :ID => 152,
    :name => "Silk Scarf",
    :desc => "An item to be held by a Pokémon. Boosts the power of Normal-type moves by 20%.",
    :price => 800,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :NORMAL,
    :flingdamage => 10,
  },

  :FLAMEPLATE => {
    :ID => 153,
    :name => "Flame Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Fire-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FIRE,
    :plate => true,
    :flingdamage => 90,
  },

  :SPLASHPLATE => {
    :ID => 154,
    :name => "Splash Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Water-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :WATER,
    :plate => true,
    :flingdamage => 90,
  },

  :ZAPPLATE => {
    :ID => 155,
    :name => "Zap Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Electric-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ELECTRIC,
    :plate => true,
    :flingdamage => 90,
  },

  :MEADOWPLATE => {
    :ID => 156,
    :name => "Meadow Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Grass-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GRASS,
    :plate => true,
    :flingdamage => 90,
  },

  :ICICLEPLATE => {
    :ID => 157,
    :name => "Icicle Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Ice-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ICE,
    :plate => true,
    :flingdamage => 90,
  },

  :FISTPLATE => {
    :ID => 158,
    :name => "Fist Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Fighting-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FIGHTING,
    :plate => true,
    :flingdamage => 90,
  },

  :TOXICPLATE => {
    :ID => 159,
    :name => "Toxic Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Poison-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :POISON,
    :plate => true,
    :flingdamage => 90,
  },

  :EARTHPLATE => {
    :ID => 160,
    :name => "Earth Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Ground-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GROUND,
    :plate => true,
    :flingdamage => 90,
  },

  :SKYPLATE => {
    :ID => 161,
    :name => "Sky Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Flying-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FLYING,
    :plate => true,
    :flingdamage => 90,
  },

  :MINDPLATE => {
    :ID => 162,
    :name => "Mind Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Psychic-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :PSYCHIC,
    :plate => true,
    :flingdamage => 90,
  },

  :INSECTPLATE => {
    :ID => 163,
    :name => "Insect Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Bug-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :BUG,
    :plate => true,
    :flingdamage => 90,
  },

  :STONEPLATE => {
    :ID => 164,
    :name => "Stone Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Rock-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ROCK,
    :plate => true,
    :flingdamage => 90,
  },

  :SPOOKYPLATE => {
    :ID => 165,
    :name => "Spooky Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Ghost-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GHOST,
    :plate => true,
    :flingdamage => 90,
  },

  :DRACOPLATE => {
    :ID => 166,
    :name => "Draco Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Dragon-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :DRAGON,
    :plate => true,
    :flingdamage => 90,
  },

  :DREADPLATE => {
    :ID => 167,
    :name => "Dread Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Dark-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :DARK,
    :plate => true,
    :flingdamage => 90,
  },

  :IRONPLATE => {
    :ID => 168,
    :name => "Iron Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Steel-type moves.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :STEEL,
    :plate => true,
    :flingdamage => 90,
  },

  :FIREGEM => {
    :ID => 169,
    :name => "Fire Gem",
    :desc => "A gem with an essence of fire. When held, it strengthens the power of a Fire-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FIRE,
    :gem => true,
  },

  :WATERGEM => {
    :ID => 170,
    :name => "Water Gem",
    :desc => "A gem with an essence of water. When held, it strengthens the power of a Water-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :WATER,
    :gem => true,
  },

  :ELECTRICGEM => {
    :ID => 171,
    :name => "Electric Gem",
    :desc => "A gem with an essence of electricity. When held, it strengthens the power of an Electric-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ELECTRIC,
    :gem => true,
  },

  :GRASSGEM => {
    :ID => 172,
    :name => "Grass Gem",
    :desc => "A gem with an essence of nature. When held, it strengthens the power of a Grass-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GRASS,
    :gem => true,
  },

  :ICEGEM => {
    :ID => 173,
    :name => "Ice Gem",
    :desc => "A gem with an essence of ice. When held, it strengthens the power of an Ice-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ICE,
    :gem => true,
  },

  :FIGHTINGGEM => {
    :ID => 174,
    :name => "Fighting Gem",
    :desc => "A gem with an essence of combat. When held, it strengthens the power of a Fighting-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FIGHTING,
    :gem => true,
  },

  :POISONGEM => {
    :ID => 175,
    :name => "Poison Gem",
    :desc => "A gem with an essence of poison. When held, it strengthens the power of a Poison-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :POISON,
    :gem => true,
  },

  :GROUNDGEM => {
    :ID => 176,
    :name => "Ground Gem",
    :desc => "A gem with an essence of land. When held, it strengthens the power of a Ground-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GROUND,
    :gem => true,
  },

  :FLYINGGEM => {
    :ID => 177,
    :name => "Flying Gem",
    :desc => "A gem with an essence of air. When held, it strengthens the power of a Flying-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FLYING,
    :gem => true,
  },

  :PSYCHICGEM => {
    :ID => 178,
    :name => "Psychic Gem",
    :desc => "A gem with an essence of the mind. When held, it strengthens the power of a Psychic-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :PSYCHIC,
    :gem => true,
  },

  :BUGGEM => {
    :ID => 179,
    :name => "Bug Gem",
    :desc => "A gem with an insect-like essence. When held, it strengthens the power of a Bug-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :BUG,
    :gem => true,
  },

  :ROCKGEM => {
    :ID => 180,
    :name => "Rock Gem",
    :desc => "A gem with an essence of rock. When held, it strengthens the power of a Rock-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :ROCK,
    :gem => true,
  },

  :GHOSTGEM => {
    :ID => 181,
    :name => "Ghost Gem",
    :desc => "A gem with a spectral essence. When held, it strengthens the power of a Ghost-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :GHOST,
    :gem => true,
  },

  :DRAGONGEM => {
    :ID => 182,
    :name => "Dragon Gem",
    :desc => "A gem with a draconic essence. When held, it strengthens the power of a Dragon-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :DRAGON,
    :gem => true,
  },

  :DARKGEM => {
    :ID => 183,
    :name => "Dark Gem",
    :desc => "A gem with an essence of darkness. When held, it strengthens the power of a Dark-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :DARK,
    :gem => true,
  },

  :STEELGEM => {
    :ID => 184,
    :name => "Steel Gem",
    :desc => "A gem with an essence of steel. When held, it strengthens the power of a Steel-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :STEEL,
    :gem => true,
  },

  :NORMALGEM => {
    :ID => 185,
    :name => "Normal Gem",
    :desc => "A gem with an ordinary essence. When held, it strengthens the power of a Normal-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :NORMAL,
    :gem => true,
  },

  :LIGHTBALL => {
    :ID => 186,
    :name => "Light Ball",
    :desc => "An item to be held by Pikachu. It is a puzzling orb that raises the Attack and Sp. Atk stat.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :pokehold => true,
  },

  :LUCKYPUNCH => {
    :ID => 187,
    :name => "Lucky Punch",
    :plural => "Lucky Punches",
    :desc => "An item to be held by Chansey. It is a pair of gloves that boosts Chansey's critical-hit ratio.",
    :price => 10,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 40,
    :pokehold => true,
  },

  :METALPOWDER => {
    :ID => 188,
    :name => "Metal Powder",
    :unit => "bag of Metal Powder",
    :desc => "An item to be held by Ditto. Extremely fine yet hard, this odd powder boosts the Defense stat.",
    :price => 10,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :pokehold => true,
  },

  :QUICKPOWDER => {
    :ID => 189,
    :name => "Quick Powder",
    :unit => "bag of Quick Powder",
    :desc => "An item to be held by Ditto. Extremely fine yet hard, this odd powder boosts the Speed stat.",
    :price => 10,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :pokehold => true,
  },

  :THICKCLUB => {
    :ID => 190,
    :name => "Thick Club",
    :desc => "An item to be held by Cubone or Marowak. It is a hard bone of some sort that boosts the Attack stat.",
    :price => 500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 90,
    :pokehold => true,
  },

  :STICK => {
    :ID => 191,
    :name => "Leek",
    :desc => "An item to be held by Farfetch'd or Sirfetch'd. This long and stiff stalk of leek boosts its critical-hit ratio.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 60,
    :pokehold => true,
  },

  :SOULDEW => {
    :ID => 192,
    :name => "Soul Dew",
    :desc => "A wondrous orb to be held by Latios or Latias. It boosts the power of their Psychic- and Dragon-type moves.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :legendhold => true,
  },

  :DEEPSEATOOTH => {
    :ID => 193,
    :name => "Deep Sea Tooth",
    :plural => "Deep Sea Teeth",
    :desc => "An item to be held by Clamperl. A fang that gleams a sharp silver, it raises the Sp. Atk stat.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 90,
  },

  :DEEPSEASCALE => {
    :ID => 194,
    :name => "Deep Sea Scale",
    :desc => "An item to be held by Clamperl. A scale that shines a faint pink, it raises the Sp. Def stat.",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :ADAMANTORB => {
    :ID => 195,
    :name => "Adamant Orb",
    :desc => "A brightly gleaming orb to be held by Dialga. It boosts the power of Dragon- and Steel-type moves.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 60,
    :legendhold => true,
  },

  :LUSTROUSORB => {
    :ID => 196,
    :name => "Lustrous Orb",
    :desc => "A beautifully glowing orb to be held by Palkia. It boosts the power of Dragon- and Water-type moves.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 60,
    :legendhold => true,
  },

  :GRISEOUSORB => {
    :ID => 197,
    :name => "Griseous Orb",
    :desc => "A glowing orb to be held by Giratina. It boosts the power of Dragon- and Ghost-type moves.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 60,
    :legendhold => true,
  },

  :DOUSEDRIVE => {
    :ID => 198,
    :name => "Douse Drive",
    :desc => "A cassette to be held by Genesect. It changes Techno Blast to a Water-type move.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 70,
    :legendhold => true,
  },

  :SHOCKDRIVE => {
    :ID => 199,
    :name => "Shock Drive",
    :desc => "A cassette to be held by Genesect. It changes Techno Blast to an Electric-type move.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 70,
    :legendhold => true,
  },

  :BURNDRIVE => {
    :ID => 200,
    :name => "Burn Drive",
    :desc => "A cassette to be held by Genesect. It changes Techno Blast to a Fire-type move.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 70,
    :legendhold => true,
  },

  :CHILLDRIVE => {
    :ID => 201,
    :name => "Chill Drive",
    :desc => "A cassette to be held by Genesect. It changes Techno Blast to an Ice-type move.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 70,
    :legendhold => true,
  },

  :EVERSTONE => {
    :ID => 202,
    :name => "Everstone",
    :desc => "An item to be held by a Pokémon. The Pokémon holding this peculiar stone is prevented from evolving.",
    :price => 200,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :DRAGONSCALE => {
    :ID => 203,
    :name => "Dragon Scale",
    :desc => "A thick and tough scale. Dragon-type Pokémon may be holding this item when caught.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :UPGRADE => {
    :ID => 204,
    :name => "Up-Grade",
    :desc => "A transparent device filled with all sorts of data. It was produced by Silph Co.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :DUBIOUSDISC => {
    :ID => 205,
    :name => "Dubious Disc",
    :desc => "A transparent device overflowing with dubious data.  Its producer is unknown.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 50,
  },

  :PROTECTOR => {
    :ID => 206,
    :name => "Protector",
    :desc => "A protective item of some sort. It is extremely stiff and heavy. It is loved by a certain Pokémon.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
  },

  :ELECTIRIZER => {
    :ID => 207,
    :name => "Electirizer",
    :desc => "A box packed with a tremendous amount of electric energy. It is loved by a certain Pokémon.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
  },

  :MAGMARIZER => {
    :ID => 208,
    :name => "Magmarizer",
    :desc => "A box packed with a tremendous amount of magma energy. It is loved by a certain Pokémon.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
  },

  :REAPERCLOTH => {
    :ID => 209,
    :name => "Reaper Cloth",
    :unit => "scrap of Reaper Cloth",
    :desc => "A cloth imbued with horrifyingly strong spiritual energy. It is loved by a certain Pokémon.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
  },

  :PRISMSCALE => {
    :ID => 210,
    :name => "Prism Scale",
    :desc => "A mysterious scale that evolves certain Pokémon. It shines in rainbow colors.",
    :price => 500,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :OVALSTONE => {
    :ID => 211,
    :name => "Oval Stone",
    :desc => "A peculiar stone that makes certain species of Pokémon evolve. It is shaped like an egg.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
  },

  :REDSCARF => {
    :ID => 212,
    :name => "Old Scarf",
    :plural => "Old Scarves",
    :desc => "An old scarf. It looks like it's been here for ages.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :justsell => true,
    :sidequest => true,
  },

  :BLUESCARF => {
    :ID => 213,
    :name => "Blue Scarf",
    :plural => "Blue Scarves",
    :desc => "An item to be held by a Pokémon. It boosts the Beauty aspect of the holder in a Contest.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :justsell => true,
  },

  :PINKSCARF => {
    :ID => 214,
    :name => "Pink Scarf",
    :plural => "Pink Scarves",
    :desc => "An item to be held by a Pokémon. It boosts the Cute aspect of the holder in a Contest.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :justsell => true,
  },

  :GREENSCARF => {
    :ID => 215,
    :name => "Green Scarf",
    :plural => "Green Scarves",
    :desc => "An item to be held by a Pokémon. It boosts the Smart aspect of the holder in a Contest.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :justsell => true,
  },

  :YELLOWSCARF => {
    :ID => 216,
    :name => "Yellow Scarf",
    :plural => "Yellow Scarves",
    :desc => "An item to be held by a Pokémon. It boosts the Tough aspect of the holder in a Contest.",
    :price => 100,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :justsell => true,
  },

  :POTION => {
    :ID => 217,
    :name => "Potion",
    :desc => "A spray-type medicine for wounds. It restores the HP of one Pokémon by just 20 points.",
    :price => 300,
    :medicine => {
      :hp => 20,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :SUPERPOTION => {
    :ID => 218,
    :name => "Super Potion",
    :desc => "A spray-type medicine for wounds. It restores the HP of one Pokémon by 60 points.",
    :price => 700,
    :medicine => {
      :hp => 60,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :HYPERPOTION => {
    :ID => 219,
    :name => "Hyper Potion",
    :desc => "A spray-type medicine for wounds. It restores the HP of one Pokémon by 120 points.",
    :price => 1200,
    :medicine => {
      :hp => 120,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :MAXPOTION => {
    :ID => 220,
    :name => "Max Potion",
    :desc => "A spray-type medicine for wounds. It completely restores the HP of a single Pokémon.",
    :price => 2500,
    :medicine => {
      :hp => 1.0,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :FULLRESTORE => {
    :ID => 221,
    :name => "Full Restore",
    :desc => "A medicine that fully restores the HP and heals any status problems of a single Pokémon.",
    :price => 3000,
    :medicine => {
      :hp => 1.0,
      :status => :FULLHEAL,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :SACREDASH => {
    :ID => 222,
    :name => "Sacred Ash",
    :unit => "bag of Sacred Ash",
    :desc => "It revives all fainted Pokémon. In doing so, it also fully restores their HP.",
    :price => 200,
    :medicine => {
      :revive => 1.0,
    },
    :noUseInBattle => true,
    :flingdamage => 30,
    :revival => true,
  },

  :AWAKENING => {
    :ID => 223,
    :name => "Awakening",
    :desc => "A spray-type medicine. It awakens a Pokémon from the clutches of sleep.",
    :price => 250,
    :medicine => {
      :status => :SLEEP,
    },
    :flingdamage => 30,
    :status => true,
  },

  :ANTIDOTE => {
    :ID => 224,
    :name => "Antidote",
    :desc => "A spray-type medicine. It lifts the effect of poison from one Pokémon.",
    :price => 100,
    :medicine => {
      :status => :POISON,
    },
    :flingdamage => 30,
    :status => true,
  },

  :BURNHEAL => {
    :ID => 225,
    :name => "Burn Heal",
    :desc => "A spray-type medicine. It heals a single Pokémon that is suffering from a burn.",
    :price => 250,
    :medicine => {
      :status => :BURN,
    },
    :flingdamage => 30,
    :status => true,
  },

  :PARLYZHEAL => {
    :ID => 226,
    :name => "Paralyze Heal",
    :desc => "A spray-type medicine. It eliminates paralysis from a single Pokémon.",
    :price => 200,
    :medicine => {
      :status => :PARALYSIS,
    },
    :flingdamage => 30,
    :status => true,
  },

  :ICEHEAL => {
    :ID => 227,
    :name => "Ice Heal",
    :desc => "A spray-type medicine. It defrosts a Pokémon that has been frozen solid.",
    :price => 250,
    :medicine => {
      :status => :FROZEN,
    },
    :flingdamage => 30,
    :status => true,
  },

  :FULLHEAL => {
    :ID => 228,
    :name => "Full Heal",
    :desc => "A spray-type medicine. It heals all the status problems of a single Pokémon.",
    :price => 600,
    :medicine => {
      :status => :FULLHEAL,
    },
    :flingdamage => 30,
    :status => true,
  },

  :LAVACOOKIE => {
    :ID => 229,
    :name => "Lava Cookie",
    :desc => "Lavaridge Town's local specialty. It heals all the status problems of one Pokémon.",
    :price => 200,
    :medicine => {
      :status => :FULLHEAL,
    },
    :flingdamage => 30,
    :status => true,
  },

  :OLDGATEAU => {
    :ID => 230,
    :name => "Old Gateau",
    :plural => "Old Gateaux",
    :desc => "Old Chateau's hidden specialty. It heals all the status problems of a single Pokémon.",
    :price => 200,
    :medicine => {
      :status => :FULLHEAL,
    },
    :flingdamage => 30,
    :status => true,
  },

  :CASTELIACONE => {
    :ID => 231,
    :name => "Casteliacone",
    :desc => "Castelia City's specialty, soft-serve ice cream. It heals all the status problems of a single Pokémon.",
    :price => 100,
    :medicine => {
      :status => :FULLHEAL,
    },
    :flingdamage => 30,
    :status => true,
  },

  :REVIVE => {
    :ID => 232,
    :name => "Revive",
    :desc => "A medicine that revives a fainted Pokémon. It restores half the Pokémon's maximum HP.",
    :price => 8500,
    :medicine => {
      :revive => 0.5,
    },
    :flingdamage => 30,
    :revival => true,
  },

  :MAXREVIVE => {
    :ID => 233,
    :name => "Max Revive",
    :desc => "A medicine that revives a fainted Pokémon. It fully restores the Pokémon's HP.",
    :price => 4000,
    :medicine => {
      :revive => 1.0,
    },
    :flingdamage => 30,
    :revival => true,
  },

  :BERRYJUICE => {
    :ID => 234,
    :name => "Berry Juice",
    :desc => "A 100% pure juice made of Berries. It restores the HP of one Pokémon by just 20 points.",
    :price => 300,
    :medicine => {
      :hp => 20,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :RAGECANDYBAR => {
    :ID => 235,
    :name => "Rage Candy Bar",
    :desc => "Mahogany Town's famous candy. It can be used once to heal all the status conditions of a Pokémon.",
    :price => 400,
    :medicine => {
      :status => :FULLHEAL,
    },
    :flingdamage => 30,
    :status => true,
  },

  :SWEETHEART => {
    :ID => 236,
    :name => "Sweet Heart",
    :desc => "Very sweet chocolate. It restores the HP of one Pokémon by only 20 points.",
    :price => 100,
    :medicine => {
      :hp => 20,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :FRESHWATER => {
    :ID => 237,
    :name => "Fresh Water",
    :unit => "bottle of Fresh Water",
    :desc => "Water with a high mineral content. It restores the HP of one Pokémon by 30 points.",
    :price => 200,
    :medicine => {
      :hp => 30,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :SODAPOP => {
    :ID => 238,
    :name => "Soda Pop",
    :unit => "bottle of Soda Pop",
    :desc => "A fizzy soda drink. It restores the HP of one Pokémon by 50 points.",
    :price => 300,
    :medicine => {
      :hp => 50,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :LEMONADE => {
    :ID => 239,
    :name => "Lemonade",
    :unit => "can of Lemonade",
    :desc => "A very sweet drink. It restores the HP of one Pokémon by 70 points.",
    :price => 350,
    :medicine => {
      :hp => 70,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :MOOMOOMILK => {
    :ID => 240,
    :name => "Moomoo Milk",
    :unit => "bottle of Moomoo Milk",
    :desc => "Milk with a very high nutrition content. It restores the HP of one Pokémon by 100 points.",
    :price => 1500,
    :medicine => {
      :hp => 100,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :ENERGYPOWDER => {
    :ID => 241,
    :name => "Energy Powder",
    :unit => "dose of Energy Powder",
    :desc => "A very bitter medicine powder. It restores the HP of one Pokémon by 60 points.",
    :price => 500,
    :medicine => {
      :hp => 60,
      :happiness => :Powder,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :ENERGYROOT => {
    :ID => 242,
    :name => "Energy Root",
    :desc => "A very bitter root. It restores the HP of one Pokémon by 120 points.",
    :price => 800,
    :medicine => {
      :hp => 120,
      :happiness => :EnergyRoot,
    },
    :flingdamage => 30,
    :healing => true,
  },

  :HEALPOWDER => {
    :ID => 243,
    :name => "Heal Powder",
    :unit => "dose of Heal Powder",
    :desc => "A very bitter medicine powder. It heals all the status problems of a single Pokémon.",
    :price => 450,
    :medicine => {
      :status => :FULLHEAL,
      :happiness => :Powder,
    },
    :flingdamage => 30,
    :status => true,
  },

  :REVIVALHERB => {
    :ID => 244,
    :name => "Revival Herb",
    :desc => "A very bitter medicinal herb. It revives a fainted Pokémon, fully restoring its HP.",
    :price => 2800,
    :medicine => {
      :revive => 1.0,
      :happiness => :RevivalHerb,
    },
    :flingdamage => 30,
    :revival => true,
  },

  :ETHER => {
    :ID => 245,
    :name => "Ether",
    :desc => "It restores the PP of a Pokémon's selected move by a maximum of 10 points.",
    :price => 1200,
    :medicine => {},
    :flingdamage => 30,
    :pprestore => true,
  },

  :MAXETHER => {
    :ID => 246,
    :name => "Max Ether",
    :desc => "It fully restores the PP of a single selected move that has been learned by the target Pokémon.",
    :price => 2000,
    :medicine => {},
    :flingdamage => 30,
    :pprestore => true,
  },

  :ELIXIR => {
    :ID => 247,
    :name => "Elixir",
    :desc => "It restores the PP of all the moves learned by the targeted Pokémon by 10 points each.",
    :price => 3000,
    :medicine => {},
    :flingdamage => 30,
    :pprestore => true,
  },

  :MAXELIXIR => {
    :ID => 248,
    :name => "Max Elixir",
    :desc => "It fully restores the PP of all the moves learned by the targeted Pokémon.",
    :price => 4500,
    :medicine => {},
    :flingdamage => 30,
    :pprestore => true,
  },

  :PPUP => {
    :ID => 249,
    :name => "PP Up",
    :unit => "bottle of PP Up",
    :desc => "It slightly raises the maximum PP of a selected move that has been learned by the target Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :PPMAX => {
    :ID => 250,
    :name => "PP Max",
    :unit => "bottle of PP Max",
    :desc => "It maximally raises the top PP of a selected move that has been learned by the target Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :HPUP => {
    :ID => 251,
    :name => "HP Up",
    :unit => "bottle of HP Up",
    :desc => "A nutritious drink for Pokémon. It raises the base HP of a single Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :PROTEIN => {
    :ID => 252,
    :name => "Protein",
    :unit => "bottle of Protein",
    :desc => "A nutritious drink for Pokémon. It raises the base Attack stat of a single Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :IRON => {
    :ID => 253,
    :name => "Iron",
    :unit => "bottle of Iron",
    :desc => "A nutritious drink for Pokémon. It raises the base Defense stat of a single Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :CALCIUM => {
    :ID => 254,
    :name => "Calcium",
    :unit => "bottle of Calcium",
    :desc => "A nutritious drink for Pokémon. It raises the base Sp. Atk (Special Attack) stat of a single Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :ZINC => {
    :ID => 255,
    :name => "Zinc",
    :unit => "bottle of Zinc",
    :desc => "A nutritious drink for Pokémon. It raises the base Sp. Def (Special Defense) stat of a single Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :CARBOS => {
    :ID => 256,
    :name => "Carbos",
    :unit => "bottle of Carbos",
    :desc => "A nutritious drink for Pokémon. It raises the base Speed stat of a single Pokémon.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :HEALTHWING => {
    :ID => 257,
    :name => "Health Feather",
    :desc => "An item for use on a Pokémon. It slightly increases the base HP of a single Pokémon.",
    :price => 3000,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 20,
    :evup => true,
  },

  :MUSCLEWING => {
    :ID => 258,
    :name => "Muscle Feather",
    :desc => "An item for use on a Pokémon. It slightly increases the base Attack stat of a single Pokémon.",
    :price => 3000,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 20,
    :evup => true,
  },

  :RESISTWING => {
    :ID => 259,
    :name => "Resist Feather",
    :desc => "An item for use on a Pokémon. It slightly increases the base Defense stat of a single Pokémon.",
    :price => 3000,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 20,
    :evup => true,
  },

  :GENIUSWING => {
    :ID => 260,
    :name => "Genius Feather",
    :desc => "An item for use on a Pokémon. It slightly increases the base Sp. Atk stat of a single Pokémon.",
    :price => 3000,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 20,
    :evup => true,
  },

  :CLEVERWING => {
    :ID => 261,
    :name => "Clever Feather",
    :desc => "An item for use on a Pokémon. It slightly increases the base Sp. Def stat of a single Pokémon.",
    :price => 3000,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 20,
    :evup => true,
  },

  :SWIFTWING => {
    :ID => 262,
    :name => "Swift Feather",
    :desc => "An item for use on a Pokémon. It slightly increases the base Speed stat of a single Pokémon.",
    :price => 3000,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 20,
    :evup => true,
  },

  :RARECANDY => {
    :ID => 263,
    :name => "Rare Candy",
    :desc => "A candy that is packed with energy. It raises the level of a single Pokémon by one.",
    :price => 0,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :levelup => true,
  },

  :MASTERBALL => {
    :ID => 264,
    :name => "Master Ball",
    :desc => "The best Ball with the ultimate level of performance. It will catch any wild Pokémon without fail.",
    :price => 0,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :ULTRABALL => {
    :ID => 265,
    :name => "Ultra Ball",
    :desc => "An ultra-performance Ball that provides a higher Pokémon catch rate than a Great Ball.",
    :price => 1200,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :GREATBALL => {
    :ID => 266,
    :name => "Great Ball",
    :desc => "A good, high-performance Ball that provides a higher Pokémon catch rate than a standard Poké Ball.",
    :price => 600,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :POKEBALL => {
    :ID => 267,
    :name => "Poké Ball",
    :desc => "A device for catching wild Pokémon. It is thrown like a ball at the target. It is designed as a capsule system.",
    :price => 200,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :SAFARIBALL => {
    :ID => 268,
    :name => "Safari Ball",
    :desc => "A special Poké Ball that is used only in the Great Marsh. It is decorated in a camouflage pattern.",
    :price => 0,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :SPORTBALL => {
    :ID => 269,
    :name => "Sport Ball",
    :desc => "A special Poké Ball for the Bug-Catching Contest.",
    :price => 0,
    :ball => true,
    :noUse => true,
  },

  :NETBALL => {
    :ID => 270,
    :name => "Net Ball",
    :desc => "A somewhat different Poké Ball that works especially well on Water- and Bug-type Pokémon.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :DIVEBALL => {
    :ID => 271,
    :name => "Dive Ball",
    :desc => "A somewhat different Poké Ball that works especially well on Pokémon that live underwater.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :NESTBALL => {
    :ID => 272,
    :name => "Nest Ball",
    :desc => "A somewhat different Poké Ball that works especially well on weaker Pokémon in the wild.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :REPEATBALL => {
    :ID => 273,
    :name => "Repeat Ball",
    :desc => "A somewhat different Poké Ball that works especially well on Pokémon species that were previously caught.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :TIMERBALL => {
    :ID => 274,
    :name => "Timer Ball",
    :desc => "A somewhat different Ball that becomes progressively better the more turns there are in a battle.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :LUXURYBALL => {
    :ID => 275,
    :name => "Luxury Ball",
    :desc => "A comfortable Poké Ball that makes a caught wild Pokémon quickly grow friendly.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :PREMIERBALL => {
    :ID => 276,
    :name => "Premier Ball",
    :desc => "A somewhat rare Poké Ball that has been specially made to commemorate an event of some sort.",
    :price => 200,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :DUSKBALL => {
    :ID => 277,
    :name => "Dusk Ball",
    :desc => "A somewhat different Poké Ball that makes it easier to catch wild Pokémon at night or in dark places like caves.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :HEALBALL => {
    :ID => 278,
    :name => "Heal Ball",
    :desc => "A remedial Poké Ball that restores the caught Pokémon's HP and eliminates any status problem.",
    :price => 300,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :QUICKBALL => {
    :ID => 279,
    :name => "Quick Ball",
    :desc => "A somewhat different Poké Ball that provides a better catch rate if it is used at the start of a wild encounter.",
    :price => 1000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :CHERISHBALL => {
    :ID => 280,
    :name => "Cherish Ball",
    :desc => "A quite rare Poké Ball that has been specially crafted to commemorate an occasion of some sort.",
    :price => 200,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :FASTBALL => {
    :ID => 281,
    :name => "Fast Ball",
    :desc => "A Poké Ball that makes it easier to catch Pokémon which are quick to run away.",
    :price => 300,
    :ball => true,
    :noUse => true,
  },

  :LEVELBALL => {
    :ID => 282,
    :name => "Level Ball",
    :desc => "A Poké Ball for catching Pokémon that are a lower level than your own.",
    :price => 300,
    :ball => true,
    :noUse => true,
  },

  :LUREBALL => {
    :ID => 283,
    :name => "Lure Ball",
    :desc => "A Poké Ball for catching Pokémon hooked by a Rod when fishing.",
    :price => 300,
    :ball => true,
    :noUse => true,
  },

  :HEAVYBALL => {
    :ID => 284,
    :name => "Heavy Ball",
    :desc => "A Poké Ball for catching very heavy Pokémon.",
    :price => 300,
    :ball => true,
    :noUse => true,
  },

  :LOVEBALL => {
    :ID => 285,
    :name => "Love Ball",
    :desc => "A Poké Ball for catching Pokémon that are the opposite gender of your Pokémon.",
    :price => 300,
    :ball => true,
    :noUse => true,
  },

  :FRIENDBALL => {
    :ID => 286,
    :name => "Friend Ball",
    :desc => "A Poké Ball that makes caught Pokémon more friendly.",
    :price => 300,
    :ball => true,
    :noUse => true,
  },

  :MOONBALL => {
    :ID => 287,
    :name => "Moon Ball",
    :desc => "A Poké Ball for catching Pokémon that evolve using the Moon Stone.",
    :price => 300,
    :ball => true,
    :noUse => true,
  },

  :TM01 => {
    :ID => 288,
    :name => "TM01",
    :price => 500,
    :tm => :CUT,
    :noUseInBattle => true,
  },

  :TM02 => {
    :ID => 289,
    :name => "TM02",
    :price => 1000,
    :tm => :COVET,
    :noUseInBattle => true,
  },

  :TM03 => {
    :ID => 290,
    :name => "TM03",
    :price => 300,
    :tm => :BIND,
    :noUseInBattle => true,
  },

  :TM04 => {
    :ID => 291,
    :name => "TM04",
    :price => 2000,
    :tm => :ROCKSMASH,
    :noUseInBattle => true,
  },

  :TM05 => {
    :ID => 292,
    :name => "TM05",
    :price => 4000,
    :tm => :ROCKTOMB,
    :noUseInBattle => true,
  },

  :TM06 => {
    :ID => 293,
    :name => "TM06",
    :price => 4000,
    :tm => :BULLDOZE,
    :noUseInBattle => true,
  },

  :TM07 => {
    :ID => 294,
    :name => "TM07",
    :price => 3000,
    :tm => :POISONSWEEP,
    :noUseInBattle => true,
  },

  :TM08 => {
    :ID => 295,
    :name => "TM08",
    :price => 1500,
    :tm => :AERIALACE,
    :noUseInBattle => true,
  },

  :TM09 => {
    :ID => 296,
    :name => "TM09",
    :price => 1500,
    :tm => :SHOCKWAVE,
    :noUseInBattle => true,
  },

  :TM10 => {
    :ID => 297,
    :name => "TM10",
    :price => 1500,
    :tm => :WATERPULSE,
    :noUseInBattle => true,
  },

  :TM11 => {
    :ID => 298,
    :name => "TM11",
    :price => 1500,
    :tm => :INCINERATE,
    :noUseInBattle => true,
  },

  :TM12 => {
    :ID => 299,
    :name => "TM12",
    :price => 2000,
    :tm => :THUNDERFANG,
    :noUseInBattle => true,
  },

  :TM13 => {
    :ID => 300,
    :name => "TM13",
    :price => 2000,
    :tm => :FIREFANG,
    :noUseInBattle => true,
  },

  :TM14 => {
    :ID => 301,
    :name => "TM14",
    :price => 2000,
    :tm => :ICEFANG,
    :noUseInBattle => true,
  },

  :TM15 => {
    :ID => 302,
    :name => "TM15",
    :price => 5000,
    :tm => :HELPINGHAND,
    :noUseInBattle => true,
  },

  :TM16 => {
    :ID => 303,
    :name => "TM16",
    :price => 5000,
    :tm => :NATUREPOWER,
    :noUseInBattle => true,
  },

  :TM17 => {
    :ID => 304,
    :name => "TM17",
    :price => 20000,
    :tm => :PROTECT,
    :noUseInBattle => true,
  },

  :TM18 => {
    :ID => 305,
    :name => "TM18",
    :price => 20000,
    :tm => :RAINDANCE,
    :noUseInBattle => true,
  },

  :TM19 => {
    :ID => 306,
    :name => "TM19",
    :price => 30000,
    :tm => :SECRETPOWER,
    :noUseInBattle => true,
  },

  :TM20 => {
    :ID => 307,
    :name => "TM20",
    :price => 20000,
    :tm => :SAFEGUARD,
    :noUseInBattle => true,
  },

  :TM21 => {
    :ID => 308,
    :name => "TM21",
    :price => 10000,
    :tm => :FRUSTRATION,
    :noUseInBattle => true,
  },

  :TM22 => {
    :ID => 309,
    :name => "TM22",
    :price => 30000,
    :tm => :SOLARBEAM,
    :noUseInBattle => true,
  },

  :TM23 => {
    :ID => 310,
    :name => "TM23",
    :price => 30000,
    :tm => :SMACKDOWN,
    :noUseInBattle => true,
  },

  :TM24 => {
    :ID => 311,
    :name => "TM24",
    :price => 30000,
    :tm => :THUNDERBOLT,
    :noUseInBattle => true,
  },

  :TM25 => {
    :ID => 312,
    :name => "TM25",
    :price => 100000,
    :tm => :THUNDER,
    :noUseInBattle => true,
  },

  :TM26 => {
    :ID => 313,
    :name => "TM26",
    :price => 130000,
    :tm => :EARTHQUAKE,
    :noUseInBattle => true,
  },

  :TM27 => {
    :ID => 314,
    :name => "TM27",
    :price => 10000,
    :tm => :RETURN,
    :noUseInBattle => true,
  },

  :TM28 => {
    :ID => 315,
    :name => "TM28",
    :price => 20000,
    :tm => :DIG,
    :noUseInBattle => true,
  },

  :TM29 => {
    :ID => 316,
    :name => "TM29",
    :price => 30000,
    :tm => :PSYCHIC,
    :noUseInBattle => true,
  },

  :TM30 => {
    :ID => 317,
    :name => "TM30",
    :price => 30000,
    :tm => :SHADOWBALL,
    :noUseInBattle => true,
  },

  :TM31 => {
    :ID => 318,
    :name => "TM31",
    :price => 30000,
    :tm => :BRICKBREAK,
    :noUseInBattle => true,
  },

  :TM32 => {
    :ID => 319,
    :name => "TM32",
    :price => 10000,
    :tm => :DOUBLETEAM,
    :noUseInBattle => true,
  },

  :TM33 => {
    :ID => 320,
    :name => "TM33",
    :price => 20000,
    :tm => :REFLECT,
    :noUseInBattle => true,
  },

  :TM34 => {
    :ID => 321,
    :name => "TM34",
    :price => 30000,
    :tm => :SLUDGEWAVE,
    :noUseInBattle => true,
  },

  :TM35 => {
    :ID => 322,
    :name => "TM35",
    :price => 30000,
    :tm => :FLAMETHROWER,
    :noUseInBattle => true,
  },

  :TM36 => {
    :ID => 323,
    :name => "TM36",
    :price => 30000,
    :tm => :SLUDGEBOMB,
    :noUseInBattle => true,
  },

  :TM37 => {
    :ID => 324,
    :name => "TM37",
    :price => 20000,
    :tm => :SANDSTORM,
    :noUseInBattle => true,
  },

  :TM38 => {
    :ID => 325,
    :name => "TM38",
    :price => 100000,
    :tm => :FIREBLAST,
    :noUseInBattle => true,
  },

  :TM39 => {
    :ID => 326,
    :name => "TM39",
    :price => 20000,
    :tm => :ROCKTOMB,
    :noUseInBattle => true,
  },

  :TM40 => {
    :ID => 327,
    :name => "TM40",
    :price => 30000,
    :tm => :AERIALACE,
    :noUseInBattle => true,
  },

  :TM41 => {
    :ID => 328,
    :name => "TM41",
    :price => 15000,
    :tm => :TORMENT,
    :noUseInBattle => true,
  },

  :TM42 => {
    :ID => 329,
    :name => "TM42",
    :price => 30000,
    :tm => :FACADE,
    :noUseInBattle => true,
  },

  :TM43 => {
    :ID => 330,
    :name => "TM43",
    :price => 20000,
    :tm => :FLAMECHARGE,
    :noUseInBattle => true,
  },

  :TM44 => {
    :ID => 331,
    :name => "TM44",
    :price => 30000,
    :tm => :REST,
    :noUseInBattle => true,
  },

  :TM45 => {
    :ID => 332,
    :name => "TM45",
    :price => 30000,
    :tm => :ATTRACT,
    :noUseInBattle => true,
  },

  :TM46 => {
    :ID => 333,
    :name => "TM46",
    :price => 20000,
    :tm => :THIEF,
    :noUseInBattle => true,
  },

  :TM47 => {
    :ID => 334,
    :name => "TM47",
    :price => 30000,
    :tm => :LOWSWEEP,
    :noUseInBattle => true,
  },

  :TM48 => {
    :ID => 335,
    :name => "TM48",
    :price => 30000,
    :tm => :ROUND,
    :noUseInBattle => true,
  },

  :TM49 => {
    :ID => 336,
    :name => "TM49",
    :price => 15000,
    :tm => :ECHOEDVOICE,
    :noUseInBattle => true,
  },

  :TM50 => {
    :ID => 337,
    :name => "TM50",
    :price => 55000,
    :tm => :OVERHEAT,
    :noUseInBattle => true,
  },

  :TM51 => {
    :ID => 338,
    :name => "TM51",
    :price => 10000,
    :tm => :STEELWING,
    :noUseInBattle => true,
  },

  :TM52 => {
    :ID => 339,
    :name => "TM52",
    :price => 55000,
    :tm => :FOCUSBLAST,
    :noUseInBattle => true,
  },

  :TM53 => {
    :ID => 340,
    :name => "TM53",
    :price => 30000,
    :tm => :ENERGYBALL,
    :noUseInBattle => true,
  },

  :TM54 => {
    :ID => 341,
    :name => "TM54",
    :price => 20000,
    :tm => :FALSESWIPE,
    :noUseInBattle => true,
  },

  :TM55 => {
    :ID => 342,
    :name => "TM55",
    :price => 13000,
    :tm => :SCALD,
    :noUseInBattle => true,
  },

  :TM56 => {
    :ID => 343,
    :name => "TM56",
    :price => 20000,
    :tm => :FLING,
    :noUseInBattle => true,
  },

  :TM57 => {
    :ID => 344,
    :name => "TM57",
    :price => 30000,
    :tm => :CHARGEBEAM,
    :noUseInBattle => true,
  },

  :TM58 => {
    :ID => 345,
    :name => "TM58",
    :price => 20000,
    :tm => :SKYDROP,
    :noUseInBattle => true,
  },

  :TM59 => {
    :ID => 346,
    :name => "TM59",
    :price => 15000,
    :tm => :INCINERATE,
    :noUseInBattle => true,
  },

  :TM60 => {
    :ID => 347,
    :name => "TM60",
    :price => 30000,
    :tm => :QUASH,
    :noUseInBattle => true,
  },

  :TM61 => {
    :ID => 348,
    :name => "TM61",
    :price => 20000,
    :tm => :WILLOWISP,
    :noUseInBattle => true,
  },

  :TM62 => {
    :ID => 349,
    :name => "TM62",
    :price => 30000,
    :tm => :ACROBATICS,
    :noUseInBattle => true,
  },

  :TM63 => {
    :ID => 350,
    :name => "TM63",
    :price => 20000,
    :tm => :EMBARGO,
    :noUseInBattle => true,
  },

  :TM64 => {
    :ID => 351,
    :name => "TM64",
    :price => 75000,
    :tm => :EXPLOSION,
    :noUseInBattle => true,
  },

  :TM65 => {
    :ID => 352,
    :name => "TM65",
    :price => 30000,
    :tm => :SHADOWCLAW,
    :noUseInBattle => true,
  },

  :TM66 => {
    :ID => 353,
    :name => "TM66",
    :price => 30000,
    :tm => :PAYBACK,
    :noUseInBattle => true,
  },

  :TM67 => {
    :ID => 354,
    :name => "TM67",
    :price => 30000,
    :tm => :ROOST,
    :noUseInBattle => true,
  },

  :TM68 => {
    :ID => 355,
    :name => "TM68",
    :price => 75000,
    :tm => :GIGAIMPACT,
    :noUseInBattle => true,
  },

  :TM69 => {
    :ID => 356,
    :name => "TM69",
    :price => 15000,
    :tm => :ROCKPOLISH,
    :noUseInBattle => true,
  },

  :TM70 => {
    :ID => 357,
    :name => "TM70",
    :price => 10000,
    :tm => :FLASH,
    :noUseInBattle => true,
  },

  :TM71 => {
    :ID => 358,
    :name => "TM71",
    :price => 30000,
    :tm => :STONEEDGE,
    :noUseInBattle => true,
  },

  :TM72 => {
    :ID => 359,
    :name => "TM72",
    :price => 30000,
    :tm => :VOLTSWITCH,
    :noUseInBattle => true,
  },

  :TM73 => {
    :ID => 360,
    :name => "TM73",
    :price => 20000,
    :tm => :THUNDERWAVE,
    :noUseInBattle => true,
  },

  :TM74 => {
    :ID => 361,
    :name => "TM74",
    :price => 30000,
    :tm => :GYROBALL,
    :noUseInBattle => true,
  },

  :TM75 => {
    :ID => 362,
    :name => "TM75",
    :price => 55000,
    :tm => :SWORDSDANCE,
    :noUseInBattle => true,
  },

  :TM76 => {
    :ID => 363,
    :name => "TM76",
    :price => 20000,
    :tm => :STRUGGLEBUG,
    :noUseInBattle => true,
  },

  :TM77 => {
    :ID => 364,
    :name => "TM77",
    :price => 15000,
    :tm => :PSYCHUP,
    :noUseInBattle => true,
  },

  :TM78 => {
    :ID => 365,
    :name => "TM78",
    :price => 15000,
    :tm => :BULLDOZE,
    :noUseInBattle => true,
  },

  :TM79 => {
    :ID => 366,
    :name => "TM79",
    :price => 30000,
    :tm => :FROSTBREATH,
    :noUseInBattle => true,
  },

  :TM80 => {
    :ID => 367,
    :name => "TM80",
    :price => 30000,
    :tm => :ROCKSLIDE,
    :noUseInBattle => true,
  },

  :TM81 => {
    :ID => 368,
    :name => "TM81",
    :price => 30000,
    :tm => :XSCISSOR,
    :noUseInBattle => true,
  },

  :TM82 => {
    :ID => 369,
    :name => "TM82",
    :price => 10000,
    :tm => :DRAGONTAIL,
    :noUseInBattle => true,
  },

  :TM83 => {
    :ID => 370,
    :name => "TM83",
    :price => 20000,
    :tm => :INFESTATION,
    :noUseInBattle => true,
  },

  :TM84 => {
    :ID => 371,
    :name => "TM84",
    :price => 30000,
    :tm => :POISONJAB,
    :noUseInBattle => true,
  },

  :TM85 => {
    :ID => 372,
    :name => "TM85",
    :price => 30000,
    :tm => :DREAMEATER,
    :noUseInBattle => true,
  },

  :TM86 => {
    :ID => 373,
    :name => "TM86",
    :price => 30000,
    :tm => :GRASSKNOT,
    :noUseInBattle => true,
  },

  :TM87 => {
    :ID => 374,
    :name => "TM87",
    :price => 15000,
    :tm => :SWAGGER,
    :noUseInBattle => true,
  },

  :TM88 => {
    :ID => 375,
    :name => "TM88",
    :price => 30000,
    :tm => :SLEEPTALK,
    :noUseInBattle => true,
  },

  :TM89 => {
    :ID => 376,
    :name => "TM89",
    :price => 30000,
    :tm => :UTURN,
    :noUseInBattle => true,
  },

  :TM90 => {
    :ID => 377,
    :name => "TM90",
    :price => 10000,
    :tm => :SUBSTITUTE,
    :noUseInBattle => true,
  },

  :TM91 => {
    :ID => 378,
    :name => "TM91",
    :price => 30000,
    :tm => :FLASHCANNON,
    :noUseInBattle => true,
  },

  :TM92 => {
    :ID => 379,
    :name => "TM92",
    :price => 55000,
    :tm => :TRICKROOM,
    :noUseInBattle => true,
  },

  :TM93 => {
    :ID => 380,
    :name => "TM93",
    :price => 30000,
    :tm => :WILDCHARGE,
    :noUseInBattle => true,
  },

  :TM94 => {
    :ID => 381,
    :name => "TM94",
    :price => 10000,
    :tm => :ROCKSMASH,
    :noUseInBattle => true,
  },

  :TM95 => {
    :ID => 382,
    :name => "TM95",
    :price => 30000,
    :tm => :SNARL,
    :noUseInBattle => true,
  },

  :HM01 => {
    :ID => 383,
    :name => "HM01",
    :price => 0,
    :tm => :CUT,
    :noUseInBattle => true,
  },

  :HM02 => {
    :ID => 384,
    :name => "HM02",
    :price => 0,
    :tm => :FLY,
    :noUseInBattle => true,
  },

  :HM03 => {
    :ID => 385,
    :name => "HM03",
    :price => 0,
    :tm => :SURF,
    :noUseInBattle => true,
  },

  :HM04 => {
    :ID => 386,
    :name => "HM04",
    :price => 0,
    :tm => :STRENGTH,
    :noUseInBattle => true,
  },

  :HM05 => {
    :ID => 387,
    :name => "HM05",
    :price => 0,
    :tm => :WATERFALL,
    :noUseInBattle => true,
  },

  :HM06 => {
    :ID => 388,
    :name => "HM06",
    :price => 0,
    :tm => :DIVE,
    :noUseInBattle => true,
  },

  :CHERIBERRY => {
    :ID => 389,
    :name => "Cheri Berry",
    :desc => "It may be used or held by a Pokémon to recover from paralysis.",
    :price => 200,
    :medicine => {
      :status => :PARALYSIS,
    },
    :berry => {
      :naturaltype => :FIRE,
      :naturalpower => 80,
      :flavors => [:spicy],
      :time => 12,
      :yield => 2..5,
    },
  },

  :CHESTOBERRY => {
    :ID => 390,
    :name => "Chesto Berry",
    :desc => "It may be used or held by a Pokémon to recover from sleep.",
    :price => 200,
    :medicine => {
      :status => :SLEEP,
    },
    :berry => {
      :naturaltype => :WATER,
      :naturalpower => 80,
      :flavors => [:dry],
      :time => 12,
      :yield => 2..5,
    },
  },

  :PECHABERRY => {
    :ID => 391,
    :name => "Pecha Berry",
    :desc => "It may be used or held by a Pokémon to recover from poison.",
    :price => 200,
    :medicine => {
      :status => :POISON,
    },
    :berry => {
      :naturaltype => :ELECTRIC,
      :naturalpower => 80,
      :flavors => [:sweet],
      :time => 12,
      :yield => 2..5,
    },
  },

  :RAWSTBERRY => {
    :ID => 392,
    :name => "Rawst Berry",
    :desc => "It may be used or held by a Pokémon to recover from a burn.",
    :price => 200,
    :medicine => {
      :status => :BURN,
    },
    :berry => {
      :naturaltype => :GRASS,
      :naturalpower => 80,
      :flavors => [:bitter],
      :time => 12,
      :yield => 2..5,
    },
  },

  :ASPEARBERRY => {
    :ID => 393,
    :name => "Aspear Berry",
    :desc => "It may be used or held by a Pokémon to defrost it.",
    :price => 200,
    :medicine => {
      :status => :FROZEN,
    },
    :berry => {
      :naturaltype => :ICE,
      :naturalpower => 80,
      :flavors => [:sour],
      :time => 12,
      :yield => 2..5,
    },
  },

  :LEPPABERRY => {
    :ID => 394,
    :name => "Leppa Berry",
    :desc => "It may be used or held by a Pokémon to restore a move's PP by 10.",
    :price => 300,
    :berry => {
      :naturaltype => :FIGHTING,
      :naturalpower => 80,
      :flavors => [:spicy, :sweet, :bitter, :sour],
      :time => 16,
      :yield => 2..5,
    },
  },

  :ORANBERRY => {
    :ID => 395,
    :name => "Oran Berry",
    :desc => "It may be used or held by a Pokémon to heal the user by just 10 HP.",
    :price => 100,
    :medicine => {
      :hp => 10,
    },
    :berry => {
      :naturaltype => :POISON,
      :naturalpower => 80,
      :flavors => [:spicy, :dry, :bitter, :sour],
      :time => 16,
      :yield => 2..5,
    },
  },

  :PERSIMBERRY => {
    :ID => 396,
    :name => "Persim Berry",
    :desc => "It may be used or held by a Pokémon to recover from confusion.",
    :price => 300,
    :berry => {
      :naturaltype => :GROUND,
      :naturalpower => 80,
      :flavors => [:spicy, :dry, :sweet, :sour],
      :time => 16,
      :yield => 2..5,
    },
    :noUse => true,
  },

  :LUMBERRY => {
    :ID => 397,
    :name => "Lum Berry",
    :desc => "It may be used or held by a Pokémon to recover from any status problem.",
    :price => 1000,
    :medicine => {
      :status => :FULLHEAL,
    },
    :berry => {
      :naturaltype => :FLYING,
      :naturalpower => 80,
      :flavors => [:spicy, :dry, :sweet, :bitter],
      :time => 48,
      :yield => 2..5,
    },
  },

  :SITRUSBERRY => {
    :ID => 398,
    :name => "Sitrus Berry",
    :desc => "It may be used or held by a Pokémon to heal the user's HP a little.",
    :price => 750,
    :medicine => {
      :hp => 0.25,
    },
    :berry => {
      :naturaltype => :PSYCHIC,
      :naturalpower => 80,
      :flavors => [:dry, :sweet, :bitter, :sour],
      :time => 32,
      :yield => 2..5,
    },
  },

  :FIGYBERRY => {
    :ID => 399,
    :name => "Figy Berry",
    :desc => "If held by a Pokémon, it restores the user's HP in a pinch, but will cause confusion if it hates the taste.",
    :price => 750,
    :medicine => {
      :hp => 1/3r,
    },
    :berry => {
      :naturaltype => :BUG,
      :naturalpower => 80,
      :flavors => [:spicy],
      :pinch => true,
      :time => 20,
      :yield => 1..5,
    },
  },

  :WIKIBERRY => {
    :ID => 400,
    :name => "Wiki Berry",
    :desc => "If held by a Pokémon, it restores the user's HP in a pinch, but will cause confusion if it hates the taste.",
    :price => 750,
    :medicine => {
      :hp => 1/3r,
    },
    :berry => {
      :naturaltype => :ROCK,
      :naturalpower => 80,
      :flavors => [:dry],
      :pinch => true,
      :time => 20,
      :yield => 1..5,
    },
  },

  :MAGOBERRY => {
    :ID => 401,
    :name => "Mago Berry",
    :desc => "If held by a Pokémon, it restores the user's HP in a pinch, but will cause confusion if it hates the taste.",
    :price => 750,
    :medicine => {
      :hp => 1/3r,
    },
    :berry => {
      :naturaltype => :GHOST,
      :naturalpower => 80,
      :flavors => [:sweet],
      :pinch => true,
      :time => 20,
      :yield => 1..5,
    },
  },

  :AGUAVBERRY => {
    :ID => 402,
    :name => "Aguav Berry",
    :desc => "If held by a Pokémon, it restores the user's HP in a pinch, but will cause confusion if it hates the taste.",
    :price => 750,
    :medicine => {
      :hp => 1/3r,
    },
    :berry => {
      :naturaltype => :DRAGON,
      :naturalpower => 80,
      :flavors => [:bitter],
      :pinch => true,
      :time => 20,
      :yield => 1..5,
    },
  },

  :IAPAPABERRY => {
    :ID => 403,
    :name => "Iapapa Berry",
    :desc => "If held by a Pokémon, it restores the user's HP in a pinch, but will cause confusion if it hates the taste.",
    :price => 750,
    :medicine => {
      :hp => 1/3r,
    },
    :berry => {
      :naturaltype => :DARK,
      :naturalpower => 80,
      :flavors => [:sour],
      :pinch => true,
      :time => 20,
      :yield => 1..5,
    },
  },

  :RAZZBERRY => {
    :ID => 404,
    :name => "Razz Berry",
    :desc => "Makes Natural Gift a 90BP Fairy move.",
    :price => 200,
    :berry => {
      :naturaltype => :FAIRY,
      :naturalpower => 90,
      :flavors => [:spicy, :dry],
      :time => 8,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :BLUKBERRY => {
    :ID => 405,
    :name => "Bluk Berry",
    :desc => "Makes Natural Gift a 90BP Fire  move.",
    :price => 200,
    :berry => {
      :naturaltype => :FIRE,
      :naturalpower => 90,
      :flavors => [:dry, :sweet],
      :time => 8,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :NANABBERRY => {
    :ID => 406,
    :name => "Nanab Berry",
    :desc => "Makes Natural Gift a 90BP Water move.",
    :price => 200,
    :berry => {
      :naturaltype => :WATER,
      :naturalpower => 90,
      :flavors => [:sweet, :bitter],
      :time => 8,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :WEPEARBERRY => {
    :ID => 407,
    :name => "Wepear Berry",
    :desc => "Makes Natural Gift a 90BP Electric move.",
    :price => 200,
    :berry => {
      :naturaltype => :ELECTRIC,
      :naturalpower => 90,
      :flavors => [:bitter, :sour],
      :time => 8,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :PINAPBERRY => {
    :ID => 408,
    :name => "Pinap Berry",
    :desc => "Makes Natural Gift a 90BP Grass move.",
    :price => 200,
    :berry => {
      :naturaltype => :GRASS,
      :naturalpower => 90,
      :flavors => [:spicy, :sour],
      :time => 8,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :POMEGBERRY => {
    :ID => 409,
    :name => "Pomeg Berry",
    :desc => "Makes Natural Gift a 90BP Icemove.",
    :price => 200,
    :berry => {
      :naturaltype => :ICE,
      :naturalpower => 90,
      :flavors => [:spicy, :sweet, :bitter],
      :time => 32,
      :yield => 1..5,
    },
    :noUseInBattle => true,
  },

  :KELPSYBERRY => {
    :ID => 410,
    :name => "Kelpsy Berry",
    :desc => "Makes Natural Gift a 90BP Fighting move.",
    :price => 200,
    :berry => {
      :naturaltype => :FIGHTING,
      :naturalpower => 90,
      :flavors => [:dry, :bitter, :sour],
      :time => 32,
      :yield => 1..5,
    },
    :noUseInBattle => true,
  },

  :QUALOTBERRY => {
    :ID => 411,
    :name => "Qualot Berry",
    :desc => "Makes Natural Gift a 90BP Poison move.",
    :price => 200,
    :berry => {
      :naturaltype => :POISON,
      :naturalpower => 90,
      :flavors => [:spicy, :sweet, :sour],
      :time => 32,
      :yield => 1..5,
    },
    :noUseInBattle => true,
  },

  :HONDEWBERRY => {
    :ID => 412,
    :name => "Hondew Berry",
    :desc => "Makes Natural Gift a 90BP Ground move.",
    :price => 200,
    :berry => {
      :naturaltype => :GROUND,
      :naturalpower => 90,
      :flavors => [:spicy, :dry, :bitter],
      :time => 32,
      :yield => 1..5,
    },
    :noUseInBattle => true,
  },

  :GREPABERRY => {
    :ID => 413,
    :name => "Grepa Berry",
    :desc => "Makes Natural Gift a 90BP Flying move.",
    :price => 200,
    :berry => {
      :naturaltype => :FLYING,
      :naturalpower => 90,
      :flavors => [:dry, :sweet, :sour],
      :time => 32,
      :yield => 1..5,
    },
    :noUseInBattle => true,
  },

  :TAMATOBERRY => {
    :ID => 414,
    :name => "Tamato Berry",
    :desc => "Makes Natural Gift a 90BP Psychic move.",
    :price => 200,
    :berry => {
      :naturaltype => :PSYCHIC,
      :naturalpower => 90,
      :flavors => [:spicy, :dry],
      :time => 32,
      :yield => 1..5,
    },
    :noUseInBattle => true,
  },

  :CORNNBERRY => {
    :ID => 415,
    :name => "Cornn Berry",
    :desc => "Makes Natural Gift a 90BP Bug move.",
    :price => 200,
    :berry => {
      :naturaltype => :BUG,
      :naturalpower => 90,
      :flavors => [:dry, :sweet],
      :time => 24,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :MAGOSTBERRY => {
    :ID => 416,
    :name => "Magost Berry",
    :desc => "Makes Natural Gift a 90BP Rock move.",
    :price => 200,
    :berry => {
      :naturaltype => :ROCK,
      :naturalpower => 90,
      :flavors => [:sweet, :bitter],
      :time => 24,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :RABUTABERRY => {
    :ID => 417,
    :name => "Rabuta Berry",
    :desc => "Makes Natural Gift a 90BP Ghost move.",
    :price => 200,
    :berry => {
      :naturaltype => :GHOST,
      :naturalpower => 90,
      :flavors => [:bitter, :sour],
      :time => 24,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :NOMELBERRY => {
    :ID => 418,
    :name => "Nomel Berry",
    :desc => "Makes Natural Gift a 90BP Dragon move.",
    :price => 200,
    :berry => {
      :naturaltype => :DRAGON,
      :naturalpower => 90,
      :flavors => [:spicy, :sour],
      :time => 24,
      :yield => 2..10,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :SPELONBERRY => {
    :ID => 419,
    :name => "Spelon Berry",
    :desc => "Makes Natural Gift a 90BP Dark move.",
    :price => 200,
    :berry => {
      :naturaltype => :DARK,
      :naturalpower => 90,
      :flavors => [:spicy, :dry],
      :time => 60,
      :yield => 2..15,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :PAMTREBERRY => {
    :ID => 420,
    :name => "Pamtre Berry",
    :desc => "Makes Natural Gift a 90BP Steel move.",
    :price => 200,
    :berry => {
      :naturaltype => :STEEL,
      :naturalpower => 90,
      :flavors => [:dry, :sweet],
      :time => 60,
      :yield => 3..15,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :WATMELBERRY => {
    :ID => 421,
    :name => "Watmel Berry",
    :desc => "In the Sinnoh region, they like to make sweets known as Poffins with this Berry and feed them to their Pokémon.",
    :price => 20,
    :berry => {
      :naturaltype => :FIRE,
      :naturalpower => 100,
      :flavors => [:sweet, :bitter],
      :time => 60,
      :yield => 2..15,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :DURINBERRY => {
    :ID => 422,
    :name => "Durin Berry",
    :desc => "In the Sinnoh region, they like to make sweets known as Poffins with this Berry and feed them to their Pokémon.",
    :price => 20,
    :berry => {
      :naturaltype => :WATER,
      :naturalpower => 100,
      :flavors => [:bitter, :sour],
      :time => 60,
      :yield => 3..15,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :BELUEBERRY => {
    :ID => 423,
    :name => "Belue Berry",
    :desc => "In the Sinnoh region, they like to make sweets known as Poffins with this Berry and feed them to their Pokémon.",
    :price => 20,
    :berry => {
      :naturaltype => :ELECTRIC,
      :naturalpower => 100,
      :flavors => [:spicy, :sour],
      :time => 60,
      :yield => 2..15,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :OCCABERRY => {
    :ID => 424,
    :name => "Occa Berry",
    :desc => "Weakens a supereffective Fire-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :FIRE,
      :naturalpower => 80,
      :flavors => [:spicy, :sweet],
      :resist => :FIRE,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :PASSHOBERRY => {
    :ID => 425,
    :name => "Passho Berry",
    :desc => "Weakens a supereffective Water-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :WATER,
      :naturalpower => 80,
      :flavors => [:dry, :bitter],
      :resist => :WATER,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :WACANBERRY => {
    :ID => 426,
    :name => "Wacan Berry",
    :desc => "Weakens a supereffective Electric-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :ELECTRIC,
      :naturalpower => 80,
      :flavors => [:sweet, :sour],
      :resist => :ELECTRIC,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :RINDOBERRY => {
    :ID => 427,
    :name => "Rindo Berry",
    :desc => "Weakens a supereffective Grass-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :GRASS,
      :naturalpower => 80,
      :flavors => [:spicy, :bitter],
      :resist => :GRASS,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :YACHEBERRY => {
    :ID => 428,
    :name => "Yache Berry",
    :desc => "Weakens a supereffective Ice-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :ICE,
      :naturalpower => 80,
      :flavors => [:dry, :sour],
      :resist => :ICE,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHOPLEBERRY => {
    :ID => 429,
    :name => "Chople Berry",
    :desc => "Weakens a supereffective Fighting-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :FIGHTING,
      :naturalpower => 80,
      :flavors => [:spicy, :bitter],
      :resist => :FIGHTING,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :KEBIABERRY => {
    :ID => 430,
    :name => "Kebia Berry",
    :desc => "Weakens a supereffective Poison-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :POISON,
      :naturalpower => 80,
      :flavors => [:dry, :sour],
      :resist => :POISON,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :SHUCABERRY => {
    :ID => 431,
    :name => "Shuca Berry",
    :desc => "Weakens a supereffective Ground-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :GROUND,
      :naturalpower => 80,
      :flavors => [:spicy, :sweet],
      :resist => :GROUND,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :COBABERRY => {
    :ID => 432,
    :name => "Coba Berry",
    :desc => "Weakens a supereffective Flying-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :FLYING,
      :naturalpower => 80,
      :flavors => [:dry, :bitter],
      :resist => :FLYING,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :PAYAPABERRY => {
    :ID => 433,
    :name => "Payapa Berry",
    :desc => "Weakens a supereffective Psychic-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :PSYCHIC,
      :naturalpower => 80,
      :flavors => [:sweet, :sour],
      :resist => :PSYCHIC,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :TANGABERRY => {
    :ID => 434,
    :name => "Tanga Berry",
    :desc => "Weakens a supereffective Bug-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :BUG,
      :naturalpower => 80,
      :flavors => [:spicy, :sour],
      :resist => :BUG,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHARTIBERRY => {
    :ID => 435,
    :name => "Charti Berry",
    :desc => "Weakens a supereffective Rock-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :ROCK,
      :naturalpower => 80,
      :flavors => [:spicy, :dry],
      :resist => :ROCK,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :KASIBBERRY => {
    :ID => 436,
    :name => "Kasib Berry",
    :desc => "Weakens a supereffective Ghost-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :GHOST,
      :naturalpower => 80,
      :flavors => [:dry, :sweet],
      :resist => :GHOST,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :HABANBERRY => {
    :ID => 437,
    :name => "Haban Berry",
    :desc => "Weakens a supereffective Dragon-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :DRAGON,
      :naturalpower => 80,
      :flavors => [:sweet, :bitter],
      :resist => :DRAGON,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :COLBURBERRY => {
    :ID => 438,
    :name => "Colbur Berry",
    :desc => "Weakens a supereffective Dark-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :DARK,
      :naturalpower => 80,
      :flavors => [:bitter, :sour],
      :resist => :DARK,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :BABIRIBERRY => {
    :ID => 439,
    :name => "Babiri Berry",
    :desc => "Weakens a supereffective Steel-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :STEEL,
      :naturalpower => 80,
      :flavors => [:spicy, :dry],
      :resist => :STEEL,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHILANBERRY => {
    :ID => 440,
    :name => "Chilan Berry",
    :desc => "Weakens a Normal-type attack against the Pokémon holding this berry.",
    :price => 750,
    :berry => {
      :naturaltype => :NORMAL,
      :naturalpower => 80,
      :flavors => [:dry, :sweet],
      :resist => :NORMAL,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :LIECHIBERRY => {
    :ID => 441,
    :name => "Liechi Berry",
    :desc => "If held by a Pokémon, it raises its Attack stat in a pinch.",
    :price => 1250,
    :berry => {
      :naturaltype => :GRASS,
      :naturalpower => 100,
      :flavors => [:spicy, :dry, :sweet],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :GANLONBERRY => {
    :ID => 442,
    :name => "Ganlon Berry",
    :desc => "If held by a Pokémon, it raises its Defense stat in a pinch.",
    :price => 1250,
    :berry => {
      :naturaltype => :ICE,
      :naturalpower => 100,
      :flavors => [:dry, :sweet, :bitter],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :SALACBERRY => {
    :ID => 443,
    :name => "Salac Berry",
    :desc => "If held by a Pokémon, it raises its Speed stat in a pinch.",
    :price => 1250,
    :berry => {
      :naturaltype => :FIGHTING,
      :naturalpower => 100,
      :flavors => [:sweet, :bitter, :sour],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :PETAYABERRY => {
    :ID => 444,
    :name => "Petaya Berry",
    :desc => "If held by a Pokémon, it raises its Sp. Atk stat in a pinch.",
    :price => 1250,
    :berry => {
      :naturaltype => :POISON,
      :naturalpower => 100,
      :flavors => [:spicy, :bitter, :sour],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :APICOTBERRY => {
    :ID => 445,
    :name => "Apicot Berry",
    :desc => "If held by a Pokémon, it raises its Sp. Def stat in a pinch.",
    :price => 1250,
    :berry => {
      :naturaltype => :GROUND,
      :naturalpower => 100,
      :flavors => [:spicy, :dry, :sour],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :LANSATBERRY => {
    :ID => 446,
    :name => "Lansat Berry",
    :desc => "If held by a Pokémon, it raises its critical-hit ratio in a pinch.",
    :price => 1000,
    :berry => {
      :naturaltype => :FLYING,
      :naturalpower => 100,
      :flavors => [:spicy, :dry, :sweet, :bitter, :sour],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :STARFBERRY => {
    :ID => 447,
    :name => "Starf Berry",
    :desc => "If held by a Pokémon, it sharply raises one of its stats in a pinch.",
    :price => 1000,
    :berry => {
      :naturaltype => :PSYCHIC,
      :naturalpower => 100,
      :flavors => [:spicy, :dry, :sweet, :bitter, :sour],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :ENIGMABERRY => {
    :ID => 448,
    :name => "Enigma Berry",
    :desc => "If held by a Pokémon, it restores its HP if it is hit by any supereffective attack.",
    :price => 500,
    :berry => {
      :naturaltype => :BUG,
      :naturalpower => 100,
      :flavors => [:spicy, :dry],
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :MICLEBERRY => {
    :ID => 449,
    :name => "Micle Berry",
    :desc => "If held by a Pokémon, it raises the accuracy of a move just once in a pinch.",
    :price => 500,
    :berry => {
      :naturaltype => :ROCK,
      :naturalpower => 100,
      :flavors => [:dry, :sweet],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :CUSTAPBERRY => {
    :ID => 450,
    :name => "Custap Berry",
    :desc => "If held by a Pokémon, it gets to move first just once in a pinch.",
    :price => 1500,
    :berry => {
      :naturaltype => :GHOST,
      :naturalpower => 100,
      :flavors => [:sweet, :bitter],
      :pinch => true,
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :JABOCABERRY => {
    :ID => 451,
    :name => "Jaboca Berry",
    :desc => "If held by a Pokémon and a physical attack lands, the attacker also takes damage.",
    :price => 900,
    :berry => {
      :naturaltype => :DRAGON,
      :naturalpower => 100,
      :flavors => [:bitter, :sour],
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :ROWAPBERRY => {
    :ID => 452,
    :name => "Rowap Berry",
    :desc => "If held by a Pokémon and a special attack lands, the attacker also takes damage.",
    :price => 900,
    :berry => {
      :naturaltype => :DARK,
      :naturalpower => 100,
      :flavors => [:spicy, :sour],
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :GRASSMAIL => {
    :ID => 453,
    :name => "Grass Mail",
    :unit => "piece of Grass Mail",
    :desc => "Stationery featuring a print of a refreshingly green field. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FLAMEMAIL => {
    :ID => 454,
    :name => "Flame Mail",
    :unit => "piece of Flame Mail",
    :desc => "Stationery featuring a print of flames in blazing red. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BUBBLEMAIL => {
    :ID => 455,
    :name => "Bubble Mail",
    :unit => "piece of Bubble Mail",
    :desc => "Stationery featuring a print of a blue world underwater. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BLOOMMAIL => {
    :ID => 456,
    :name => "Bloom Mail",
    :unit => "piece of Bloom Mail",
    :desc => "Stationery featuring a print of pretty floral patterns. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TUNNELMAIL => {
    :ID => 457,
    :name => "Tunnel Mail",
    :unit => "piece of Tunnel Mail",
    :desc => "Stationery featuring a print of a dimly lit coal mine. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :STEELMAIL => {
    :ID => 458,
    :name => "Steel Mail",
    :unit => "piece of Steel Mail",
    :desc => "Stationery featuring a print of cool mechanical designs. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HEARTMAIL => {
    :ID => 459,
    :name => "Heart Mail",
    :unit => "piece of Heart Mail",
    :desc => "Stationery featuring a print of giant heart patterns. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SNOWMAIL => {
    :ID => 460,
    :name => "Snow Mail",
    :unit => "piece of Snow Mail",
    :desc => "Stationery featuring a print of a chilly, snow-covered world. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SPACEMAIL => {
    :ID => 461,
    :name => "Space Mail",
    :unit => "piece of Space Mail",
    :desc => "Stationery featuring a print depicting the huge expanse of space. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :AIRMAIL => {
    :ID => 462,
    :name => "Air Mail",
    :unit => "piece of Air Mail",
    :desc => "Stationery featuring a print of colorful letter sets. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MOSAICMAIL => {
    :ID => 463,
    :name => "Mosaic Mail",
    :unit => "piece of Mosaic Mail",
    :desc => "Stationery featuring a print of a vivid rainbow pattern. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BRICKMAIL => {
    :ID => 464,
    :name => "Brick Mail",
    :unit => "piece of Brick Mail",
    :desc => "Stationery featuring a print of a tough-looking brick pattern. Let a Pokémon hold it for delivery.",
    :price => 50,
    :mail => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :XATTACK => {
    :ID => 465,
    :name => "X Attack",
    :desc => "An item that raises the Attack stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 500,
    :medicine => {
      :xitem => { stat: PBStats::ATTACK, amount: 2 },
    },
    :noUse => true,
    :flingdamage => 30,
  },

  :XATTACK2 => {
    :ID => 466,
    :name => "X Attack 2",
    :desc => "It sharply raises the Attack stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::ATTACK, amount: 2 },
    },
    :noUse => true,
  },

  :XATTACK3 => {
    :ID => 467,
    :name => "X Attack 3",
    :desc => "It drastically raises the Attack stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::ATTACK, amount: 3 },
    },
    :noUse => true,
  },

  :XATTACK6 => {
    :ID => 468,
    :name => "X Attack 6",
    :desc => "It raises the Attack stat of a Pokémon in battle immensely. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::ATTACK, amount: 6 },
    },
    :noUse => true,
  },

  :XDEFEND => {
    :ID => 469,
    :name => "X Defense",
    :desc => "An item that raises the Defense of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 550,
    :medicine => {
      :xitem => { stat: PBStats::DEFENSE, amount: 2 },
    },
    :noUse => true,
    :flingdamage => 30,
  },

  :XDEFEND2 => {
    :ID => 470,
    :name => "X Defense 2",
    :desc => "It sharply raises the Defense stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::DEFENSE, amount: 2 },
    },
    :noUse => true,
  },

  :XDEFEND3 => {
    :ID => 471,
    :name => "X Defense 3",
    :desc => "It drastically raises the Defense stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::DEFENSE, amount: 3 },
    },
    :noUse => true,
  },

  :XDEFEND6 => {
    :ID => 472,
    :name => "X Defense 6",
    :desc => "It raises the Defense stat of a Pokémon in battle immensely. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::DEFENSE, amount: 6 },
    },
    :noUse => true,
  },

  :XSPECIAL => {
    :ID => 473,
    :name => "X Sp. Atk",
    :desc => "An item that raises the Sp. Atk stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 350,
    :medicine => {
      :xitem => { stat: PBStats::SPATK, amount: 2 },
    },
    :noUse => true,
    :flingdamage => 30,
  },

  :XSPECIAL2 => {
    :ID => 474,
    :name => "X Sp. Atk 2",
    :desc => "It sharply raises the Sp. Atk stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPATK, amount: 2 },
    },
    :noUse => true,
  },

  :XSPECIAL3 => {
    :ID => 475,
    :name => "X Sp. Atk 3",
    :desc => "It drastically raises the Sp. Atk stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPATK, amount: 3 },
    },
    :noUse => true,
  },

  :XSPECIAL6 => {
    :ID => 476,
    :name => "X Sp. Atk 6",
    :desc => "It raises the Sp. Atk stat of a Pokémon in battle immensely. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPATK, amount: 6 },
    },
    :noUse => true,
  },

  :XSPDEF => {
    :ID => 477,
    :name => "X Sp. Def",
    :desc => "An item that raises the Sp. Def stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 350,
    :medicine => {
      :xitem => { stat: PBStats::SPDEF, amount: 2 },
    },
    :noUse => true,
    :flingdamage => 30,
  },

  :XSPDEF2 => {
    :ID => 478,
    :name => "X Sp. Def 2",
    :desc => "It sharply raises the Sp. Def stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPDEF, amount: 2 },
    },
    :noUse => true,
  },

  :XSPDEF3 => {
    :ID => 479,
    :name => "X Sp. Def 3",
    :desc => "It drastically raises the Sp. Def stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPDEF, amount: 3 },
    },
    :noUse => true,
  },

  :XSPDEF6 => {
    :ID => 480,
    :name => "X Sp. Def 6",
    :desc => "It raises the Sp. Def stat of a Pokémon in battle immensely. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPDEF, amount: 6 },
    },
    :noUse => true,
  },

  :XSPEED => {
    :ID => 481,
    :name => "X Speed",
    :desc => "An item that raises the Speed stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 350,
    :medicine => {
      :xitem => { stat: PBStats::SPEED, amount: 2 },
    },
    :noUse => true,
    :flingdamage => 30,
  },

  :XSPEED2 => {
    :ID => 482,
    :name => "X Speed 2",
    :desc => "It sharply raises the Speed stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPEED, amount: 2 },
    },
    :noUse => true,
  },

  :XSPEED3 => {
    :ID => 483,
    :name => "X Speed 3",
    :desc => "It drastically raises the Speed stat of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPEED, amount: 3 },
    },
    :noUse => true,
  },

  :XSPEED6 => {
    :ID => 484,
    :name => "X Speed 6",
    :desc => "It raises the Speed stat of a Pokémon in battle immensely. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::SPEED, amount: 6 },
    },
    :noUse => true,
  },

  :XACCURACY => {
    :ID => 485,
    :name => "X Accuracy",
    :desc => "An item that raises the accuracy of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 950,
    :medicine => {
      :xitem => { stat: PBStats::ACCURACY, amount: 2 },
    },
    :noUse => true,
    :flingdamage => 30,
  },

  :XACCURACY2 => {
    :ID => 486,
    :name => "X Accuracy 2",
    :desc => "It sharply raises the accuracy of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::ACCURACY, amount: 2 },
    },
    :noUse => true,
  },

  :XACCURACY3 => {
    :ID => 487,
    :name => "X Accuracy 3",
    :desc => "It drastically raises the accuracy of a Pokémon in battle. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::ACCURACY, amount: 3 },
    },
    :noUse => true,
  },

  :XACCURACY6 => {
    :ID => 488,
    :name => "X Accuracy 6",
    :desc => "It raises the accuracy of a Pokémon in battle immensely. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :medicine => {
      :xitem => { stat: PBStats::ACCURACY, amount: 6 },
    },
    :noUse => true,
  },

  :DIREHIT => {
    :ID => 489,
    :name => "Dire Hit",
    :desc => "It raises the critical-hit ratio greatly. It can be used only once and wears off if the Pokémon is withdrawn.",
    :price => 650,
    :battleitem => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :DIREHIT2 => {
    :ID => 490,
    :name => "Dire Hit 2",
    :desc => "It can be used many times to raise the critical-hit ratio of one Pokémon. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :battleitem => true,
    :noUse => true,
  },

  :DIREHIT3 => {
    :ID => 491,
    :name => "Dire Hit 3",
    :desc => "It can be used many times to greatly raise a Pokémon's critical-hit ratio. It wears off if the Pokémon is withdrawn.",
    :price => 0,
    :battleitem => true,
    :noUse => true,
  },

  :GUARDSPEC => {
    :ID => 492,
    :name => "Guard Spec.",
    :plural => "Guard Specs.",
    :desc => "An item that prevents stat reduction among the Trainer's party Pokémon for five turns after use.",
    :price => 700,
    :battleitem => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :BLUEFLUTE => {
    :ID => 497,
    :name => "Blue Flute",
    :desc => "A blue flute made from blown glass. Its melody awakens a single Pokémon from sleep.",
    :price => 100,
    :battleitem => true,
    :flingdamage => 30,
  },

  :YELLOWFLUTE => {
    :ID => 498,
    :name => "Yellow Flute",
    :desc => "A yellow flute made from blown glass. Its melody snaps a single Pokémon out of confusion.",
    :price => 200,
    :battleitem => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :REDFLUTE => {
    :ID => 499,
    :name => "Red Flute",
    :desc => "A red flute made from blown glass. Its melody snaps a single Pokémon out of infatuation.",
    :price => 300,
    :battleitem => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :POKEDOLL => {
    :ID => 500,
    :name => "Poké Doll",
    :desc => "A doll that attracts Pokémon. Use it to flee from any battle with a wild Pokémon.",
    :price => 1000,
    :battleitem => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :FLUFFYTAIL => {
    :ID => 501,
    :name => "Fluffy Tail",
    :desc => "An item that attracts Pokémon. Use it to flee from any battle with a wild Pokémon.",
    :price => 1000,
    :battleitem => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :POKETOY => {
    :ID => 502,
    :name => "Poké Toy",
    :desc => "An item that attracts Pokémon. Use it to flee from any battle with a wild Pokémon.",
    :price => 500,
    :battleitem => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :BICYCLE => {
    :ID => 503,
    :name => "Bicycle",
    :desc => "A folding Bicycle that enables much faster movement than the Running Shoes.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :general => true,
  },

  :OLDROD => {
    :ID => 504,
    :name => "Old Rod",
    :desc => "An old and beat-up fishing rod. Use it by any body of water to fish for wild aquatic Pokémon.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :general => true,
  },

  :GOODROD => {
    :ID => 505,
    :name => "Good Rod",
    :desc => "A new, good-quality fishing rod. Use it by any body of water to fish for wild aquatic Pokémon.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :general => true,
  },

  :SUPERROD => {
    :ID => 506,
    :name => "Super Rod",
    :desc => "An awesome, high-tech fishing rod. Use it by any body of water to fish for wild aquatic Pokémon.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :general => true,
  },

  :ITEMFINDER => {
    :ID => 507,
    :name => "Itemfinder",
    :desc => "A device used for finding items. If there is a hidden item nearby when it is used, it emits a signal.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :general => true,
  },

  :DOWSINGMCHN => {
    :ID => 508,
    :name => "Dowsing Machine",
    :desc => "It checks for unseen items in the area and makes noise and lights when it finds something.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :general => true,
  },

  :POKERADAR => {
    :ID => 509,
    :name => "Poké Radar",
    :desc => "A tool that can search out Pokémon that are hiding in grass. Its battery is recharged as you walk.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :TOWNMAP => {
    :ID => 510,
    :name => "Town Map",
    :desc => "A very convenient map that can be viewed anytime. It even shows your present location.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :general => true,
  },

  :POKEFLUTE => {
    :ID => 511,
    :name => "Poké Flute",
    :desc => "A flute that is said to instantly awaken any Pokémon. It has a lovely tone.",
    :price => 7000,
    :keyitem => true,
    :niche => true,
  },

  :COINCASE => {
    :ID => 512,
    :name => "Coin Case",
    :desc => "A case for holding coins obtained at the Game Corner. It holds up to 50,000 coins.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :important => true,
  },

  :SILPHSCOPE => {
    :ID => 514,
    :name => "Silph Scope",
    :desc => "A scope that makes unseeable Pokémon visible. It is made by Silph Co.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :niche => true,
  },

  :SQUIRTBOTTLE => {
    :ID => 516,
    :name => "Squirtbottle",
    :desc => "A bottle used for watering plants.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :SPRAYDUCK => {
    :ID => 517,
    :name => "Sprayduck",
    :desc => "A watering can shaped like a Psyduck. It helps promote healthy growth of Berries planted in soft soil.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :WAILMERPAIL => {
    :ID => 518,
    :name => "Wailmer Pail",
    :desc => "A tool used for watering Berries and plants.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :GRACIDEA => {
    :ID => 519,
    :name => "Gracidea",
    :desc => "A flower sometimes bundled in bouquets to convey gratitude on special occasions like birthdays.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :AURORATICKET => {
    :ID => 520,
    :name => "Aurora Ticket",
    :desc => "A ticket required to board the ship to Doxy Island. It glows beautifully.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :OLDSEAMAP => {
    :ID => 521,
    :name => "Old Sea Map",
    :desc => "A faded sea chart that shows the way to a certain island.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DNASPLICERS => {
    :ID => 522,
    :name => "DNA Splicers",
    :unit => "set of DNA Splicers",
    :desc => "A splicer that fuses Kyurem and a certain Pokémon. They are said to have been one in the beginning.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :REVEALGLASS => {
    :ID => 523,
    :name => "Reveal Glass",
    :plural => "Reveal Glasses",
    :desc => "A glass that reveals the truth. It is a mysterious glass that returns a Pokémon back to its original shape.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :OVALCHARM => {
    :ID => 524,
    :name => "Oval Charm",
    :desc => "An oval charm said to increase the chance of Eggs being found at the Day Care.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :important => true,
  },

  :SHINYCHARM => {
    :ID => 525,
    :name => "Shiny Charm",
    :desc => "A shiny charm said to increase the chance of finding a Shiny Pokémon.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :important => true,
  },

  :REVERSECANDY => {
    :ID => 526,
    :name => "Reverse Candy",
    :desc => "A candy that reduces a Pokémon's level by 1.",
    :price => 50,
    :medicine => {},
    :noUseInBattle => true,
    :levelup => true,
  },

  :MYSTERYGOOD => {
    :ID => 527,
    :name => "Mystery Good",
    :desc => "An item that you can't quite make out. What is it?",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :TM108 => {
    :ID => 528,
    :name => "TM108",
    :price => 30000,
    :tm => :MUDBARRAGE,
    :noUseInBattle => true,
  },

  :GOTHCREST => {
    :ID => 529,
    :name => "Gothitelle Crest",
    :desc => "Using Dark- and Psychic-type moves swaps between respective types. Recovers HP. SpATK buffed by 1.25x.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LOVELETTE => {
    :ID => 530,
    :name => "Roman's Letter",
    :desc => "A letter written by Roman for Louis. It's written from the heart.",
    :noArticle => true,
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :DEMONSTONE => {
    :ID => 531,
    :name => "Rift Matter",
    :plural => "Rift Matter",
    :desc => "A mysterious stone",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :CHINESEFOOD => {
    :ID => 532,
    :name => "Mystery Bowl",
    :desc => "Weird concoction of ingredients. It smells good-ish?",
    :price => 100,
    :medicine => {
      :hp => 300,
    },
    :sidequest => true,
  },

  :SOULSTONE => {
    :ID => 533,
    :name => "Soul Stone",
    :desc => "A mysterious stone with a mystical presence inside.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :WEIRDLETTER => {
    :ID => 534,
    :name => "Weird Letter",
    :desc => "A suspicious letter given to you by a scientist.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :LINKHEART => {
    :ID => 535,
    :name => "Link Heart",
    :desc => "A stone that fills the Pokémon's heart with a feeling similar to that of being traded.",
    :price => 10000,
    :evoitem => true,
    :noUseInBattle => true,
  },

  :GOURMETTREAT => {
    :ID => 536,
    :name => "Gourmet Treat",
    :desc => "A treat that attracts rogue wild Pokémon.",
    :price => 1500,
    :medicine => {},
    :healing => true,
  },

  :ABOMASITE => {
    :ID => 537,
    :name => "Abomasite",
    :desc => "One variety of Mega Stone. Have Abomasnow hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ABSOLITE => {
    :ID => 538,
    :name => "Absolite",
    :desc => "One variety of Mega Stone. Have Absol hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :AERODACTYLITE => {
    :ID => 539,
    :name => "Aerodactylite",
    :desc => "One variety of Mega Stone. Have Aerodactyl hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :AGGRONITE => {
    :ID => 540,
    :name => "Aggronite",
    :desc => "One variety of Mega Stone. Have Aggron hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ALAKAZITE => {
    :ID => 541,
    :name => "Alakazite",
    :desc => "One variety of Mega Stone. Have Alakazam hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :AMPHAROSITE => {
    :ID => 542,
    :name => "Ampharosite",
    :desc => "One variety of Mega Stone. Have Ampharos hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ASSAULTVEST => {
    :ID => 543,
    :name => "Assault Vest",
    :desc => "An item to be held by a Pokémon. This offensive vest raises Sp. Def but prevents the use of status moves.",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 80,
  },

  :BANETTITE => {
    :ID => 544,
    :name => "Banettite",
    :desc => "One variety of Mega Stone. Have Banette hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BLASTOISINITE => {
    :ID => 545,
    :name => "Blastoisinite",
    :desc => "One variety of Mega Stone. Have Blastoise hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BLAZIKENITE => {
    :ID => 546,
    :name => "Blazikenite",
    :desc => "One variety of Mega Stone. Have Blaziken hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHARIZARDITEX => {
    :ID => 547,
    :name => "Charizardite X",
    :desc => "One variety of Mega Stone. Have Charizard hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHARIZARDITEY => {
    :ID => 548,
    :name => "Charizardite Y",
    :desc => "One variety of Mega Stone. Have Charizard hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GARCHOMPITE => {
    :ID => 549,
    :name => "Garchompite",
    :desc => "One variety of Mega Stone. Have Garchomp hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GARDEVOIRITE => {
    :ID => 550,
    :name => "Gardevoirite",
    :desc => "One variety of Mega Stone. Have Gardevoir hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GENGARITE => {
    :ID => 551,
    :name => "Gengarite",
    :desc => "One variety of Mega Stone. Have Gengar hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GYARADOSITE => {
    :ID => 552,
    :name => "Gyaradosite",
    :desc => "One variety of Mega Stone. Have Gyarados hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HERACRONITE => {
    :ID => 553,
    :name => "Heracronite",
    :desc => "A stone that enables Heracross to Mega Evolve in Battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HOUNDOOMINITE => {
    :ID => 554,
    :name => "Houndoominite",
    :desc => "One variety of Mega Stone. Have Houndoom hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :INTRIGUINGSTONE => {
    :ID => 555,
    :name => "Intriguing Stone",
    :desc => "A rather curious stone that might appear to be valuable to some. It's all in the eye of the beholder.",
    :price => 999,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :JAWFOSSIL => {
    :ID => 556,
    :name => "Jaw Fossil",
    :desc => "A fossil of an ancient Pokémon that lived in the sea in ancient times. It appears to be part of its jaw.",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :KANGASKHANITE => {
    :ID => 557,
    :name => "Kangaskhanite",
    :desc => "One variety of Mega Stone. Have Kangaskhan hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :KEEBERRY => {
    :ID => 558,
    :name => "Kee Berry",
    :desc => "If held by a Pokémon, this Berry will increase the Pokémon's Defense stat when hit by a physical attack.",
    :price => 1000,
    :berry => {
      :naturaltype => :FAIRY,
      :naturalpower => 100,
      :flavors => [:spicy, :dry, :sweet, :bitter, :sour],
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :LUCARIONITE => {
    :ID => 559,
    :name => "Lucarionite",
    :desc => "One variety of Mega Stone. Have Lucario hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LUMIOSEGALETTE => {
    :ID => 561,
    :name => "Lumiose Galette",
    :desc => "It can be used once to heal all the status conditions of a Pokémon.",
    :price => 999,
    :medicine => {
      :status => :FULLHEAL,
    },
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :status => true,
  },

  :MANECTITE => {
    :ID => 562,
    :name => "Manectite",
    :desc => "One variety of Mega Stone. Have Manectric hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MARANGABERRY => {
    :ID => 563,
    :name => "Maranga Berry",
    :desc => "If held by a Pokémon, this Berry will increase the Pokémon's Sp. Defense stat when hit by a special attack.",
    :price => 1000,
    :berry => {
      :naturaltype => :DARK,
      :naturalpower => 100,
      :flavors => [:spicy, :dry, :sweet, :bitter, :sour],
      :time => 96,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :MAWILITE => {
    :ID => 564,
    :name => "Mawilite",
    :desc => "One variety of Mega Stone. Have Mawile hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEDICHAMITE => {
    :ID => 565,
    :name => "Medichamite",
    :desc => "One variety of Mega Stone. Have Medicham hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEGARING => {
    :ID => 566,
    :name => "Omni Ring",
    :desc => "This ring contains untold power that unleashes the hidden potential of certain Pokémon!",
    :price => 999,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :MEWTWONITEX => {
    :ID => 567,
    :name => "Mewtwonite X",
    :desc => "One of Mega Stones. Have Mewtwo hold it, and this stone will enable it to Mega Evolve in battle",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEWTWONITEY => {
    :ID => 568,
    :name => "Mewtwonite Y",
    :desc => "One of Mega Stones. Have Mewtwo hold it, and this stone will enable it to Mega Evolve in battle",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PINSIRITE => {
    :ID => 569,
    :name => "Pinsirite",
    :desc => "One variety of Mega Stone. Have Pinsir hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PIXIEPLATE => {
    :ID => 570,
    :name => "Pixie Plate",
    :desc => "An item to be held by a Pokémon. It is a stone tablet that boosts the power of Fairy-type moves.",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FAIRY,
    :plate => true,
    :flingdamage => 90,
  },

  :ROSELIBERRY => {
    :ID => 571,
    :name => "Roseli Berry",
    :desc => "Weakens a supereffective Fairy-type attack against the holding Pokémon.",
    :price => 750,
    :berry => {
      :naturaltype => :FAIRY,
      :naturalpower => 80,
      :flavors => [:sweet, :bitter],
      :resist => :FAIRY,
      :time => 72,
      :yield => 1..5,
    },
    :noUseInBattle => true,
    :noUse => true,
  },

  :SACHET => {
    :ID => 572,
    :name => "Sachet",
    :desc => "A sachet filled with fragrant perfumes that are too overwhelming. Yet it's loved by a certain Pokémon.",
    :price => 1000,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
  },

  :SAFETYGOGGLES => {
    :ID => 573,
    :name => "Safety Goggles",
    :unit => "pair of Safety Goggles",
    :desc => "An item to be held by a Pokémon. These goggles protect the holder from both weather-related damage and powder.",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 80,
  },

  :SAILFOSSIL => {
    :ID => 574,
    :name => "Sail Fossil",
    :desc => "A fossil of an ancient Pokémon that lived in the sea in ancient times. It appears to be part of its sail",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :SCIZORITE => {
    :ID => 575,
    :name => "Scizorite",
    :desc => "One variety of Mega Stone. Have Scizor hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SNOWBALL => {
    :ID => 576,
    :name => "Snowball",
    :desc => "An item to be held by a Pokémon. It boosts Attack if hit with an Ice-type attack. It can only be used once.",
    :price => 750,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :TYRANITARITE => {
    :ID => 577,
    :name => "Tyranitarite",
    :desc => "One variety of Mega Stone. Have Tyranitar hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :VENUSAURITE => {
    :ID => 578,
    :name => "Venusaurite",
    :desc => "One variety of Mega Stone. Have Venusaur hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :WEAKNESSPOLICY => {
    :ID => 579,
    :name => "Weakness Policy",
    :desc => "An item to be held by a Pokémon. Attack and Sp. Atk sharply increase if the holder is hit with a move it's weak to.",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 80,
  },

  :WHIPPEDDREAM => {
    :ID => 580,
    :name => "Whipped Dream",
    :unit => "dollop of Whipped Dream",
    :desc => "A soft and sweet treat made of fluffy, puffy, whipped and whirled cream. It's loved by a certain Pokémon.",
    :price => 1000,
    :evoitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 80,
  },

  :ABILITYCAPSULE => {
    :ID => 581,
    :name => "Ability Capsule",
    :desc => "A capsule that allows a Pokémon to switch abilities when it is used.",
    :price => 999,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 0,
    :levelup => true,
  },

  :TM96 => {
    :ID => 582,
    :name => "TM96",
    :price => 30000,
    :tm => :NATUREPOWER,
    :noUseInBattle => true,
  },

  :TM97 => {
    :ID => 583,
    :name => "TM97",
    :price => 55000,
    :tm => :DARKPULSE,
    :noUseInBattle => true,
  },

  :TM98 => {
    :ID => 584,
    :name => "TM98",
    :price => 30000,
    :tm => :POWERUPPUNCH,
    :noUseInBattle => true,
  },

  :TM99 => {
    :ID => 585,
    :name => "TM99",
    :price => 40000,
    :tm => :DAZZLINGGLEAM,
    :noUseInBattle => true,
  },

  :TM100 => {
    :ID => 586,
    :name => "TM100",
    :price => 10000,
    :tm => :CONFIDE,
    :noUseInBattle => true,
  },

  :SPICEPOWDER => {
    :ID => 587,
    :name => "Spice Powder",
    :desc => "Tropical spices grounded up into one. Great for getting pesky Pokémon to move from their location.",
    :price => 850,
    :overworld => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ANCIENTWING => {
    :ID => 588,
    :name => "Ancient Wing",
    :desc => "A mysterious stone wing. It looks like it was attatched to something.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :ROOMIDCARD => {
    :ID => 589,
    :name => "Room ID Card",
    :desc => "A card key that was found in Melia's bag. It seems a little damaged...",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :EMOTIONPOWDER => {
    :ID => 590,
    :name => "Emotion Powder",
    :desc => "A mysterious substance that is used to travel in Valor Mountain.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :DULLKEY => {
    :ID => 591,
    :name => "Dull Key",
    :desc => "A peculiar key to some door in Aevium.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :SECRETPOTION => {
    :ID => 592,
    :name => "Secret Potion",
    :desc => "An extremely powerful medicine that originated from Olivine City in the Johto region.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :EXCLUSIVEPASS => {
    :ID => 593,
    :name => "Exclusive Pass",
    :plural => "Exclusive Passes",
    :desc => "A pass that allows the lucky wielder to enter Grand Dream City during their celebrity event.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :JOYSCENT => {
    :ID => 601,
    :name => "Joy Scent",
    :desc => "This scent massage opens the hearts of Pokémon a little.",
    :price => 300,
    :medicine => {},
    :noUseInBattle => true,
  },

  :EXCITESCENT => {
    :ID => 602,
    :name => "Excite Scent",
    :desc => "This scent massage opens the hearts of Pokémon.",
    :price => 500,
    :medicine => {},
    :noUseInBattle => true,
  },

  :VIVIDSCENT => {
    :ID => 603,
    :name => "Vivid Scent",
    :desc => "This scent massage opens the hearts of Pokémon a lot.",
    :price => 800,
    :medicine => {},
    :noUseInBattle => true,
  },

  :TIMEFLUTE => {
    :ID => 604,
    :name => "Time Flute",
    :desc => "This item fully opens the heart of a Shadow Pokémon.",
    :price => 3000,
    :medicine => {},
    :noUseInBattle => true,
  },

  :WHITEKEY => {
    :ID => 605,
    :name => "White Key",
    :desc => "A mysterious key that opens a door somewhere nearby.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :MININGKIT => {
    :ID => 607,
    :name => "Mining Kit",
    :desc => "A kit that contains tools for mining.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
    :important => true,
  },

  :LADDER => {
    :ID => 608,
    :name => "Ladder",
    :desc => "A sturdy ladder",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :ODDKEY => {
    :ID => 609,
    :name => "Odd Key",
    :desc => "A key to some house in Goldenleaf.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :BRASSKEY => {
    :ID => 610,
    :name => "Brass Key",
    :desc => "A key that can be used to open up the way to the Lost Camp.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :BLACKSHARD => {
    :ID => 611,
    :name => "Black Shard",
    :desc => "An extremely rare shard that can only be found in certain places.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :TM101 => {
    :ID => 612,
    :name => "TM101",
    :price => 20000,
    :tm => :ROCKCLIMB,
    :noUseInBattle => true,
  },

  :CHESTNUT => {
    :ID => 613,
    :name => "Chestnut",
    :desc => "A spiny delicacy. It restores 20 HP.",
    :price => 300,
    :medicine => {
      :hp => 20,
    },
    :noUseInBattle => true,
    :noUse => true,
    :healing => true,
  },

  :CRYSTALSHARD => {
    :ID => 614,
    :name => "Crystal Shard",
    :desc => "A translucent shard that is completely devoid of energy. It nearly looks like glass!",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :VISITORSPASS => {
    :ID => 615,
    :name => "Visitor's Pass",
    :plural => "Visitor's Passes",
    :desc => "A pass that allows visitors to access Axis University.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :METAGROSSITE => {
    :ID => 616,
    :name => "Metagrossite",
    :desc => "One variety of Mega Stone. Have Metagross hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DEFIBRILLATOR => {
    :ID => 617,
    :name => "Defibrillator",
    :desc => "A machine that can conduct electricity into a person.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :YACHTKEYS => {
    :ID => 618,
    :name => "Yacht Keys",
    :desc => "Keys to Tesla's Yacht on Teila Resort's shore.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :MOONDIAL => {
    :ID => 619,
    :name => "Moon Dial",
    :desc => "A pendant that's oddly shaped like a Pokémon...",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :PHASEDIAL => {
    :ID => 620,
    :name => "Phase Dial",
    :desc => "A pendant that's simultaneously shaped like the sun and the moon.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :sidequest => true,
  },

  :CENTERKEYS => {
    :ID => 621,
    :name => "Center Keys",
    :desc => "Keys to another Help Center somewhere on Terajuma Island.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :FUNNELCAKE => {
    :ID => 622,
    :name => "Funnel Cake",
    :desc => "A delicious pastry that has the ability to revive fainted Pokémon.",
    :price => 7000,
    :medicine => {
      :revive => 0.5,
    },
    :revival => true,
  },

  :TM102 => {
    :ID => 623,
    :name => "TM102",
    :price => 10000,
    :tm => :POISONSWEEP,
    :noUseInBattle => true,
  },

  :TM103 => {
    :ID => 624,
    :name => "TM103",
    :price => 20000,
    :tm => :STACKINGSHOT,
    :noUseInBattle => true,
  },

  :GREENKEY => {
    :ID => 625,
    :name => "Green Key",
    :desc => "A key to Madelis' throne room.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :YELLOWKEY => {
    :ID => 626,
    :name => "Yellow Key",
    :desc => "A key to Madelis' throne room.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :BLUEKEY => {
    :ID => 627,
    :name => "Blue Key",
    :desc => "A key to Madelis' throne room.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :REDKEY => {
    :ID => 628,
    :name => "Red Key",
    :desc => "A key to Madelis' throne room.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :BLUEMIC => {
    :ID => 629,
    :name => "Blue Moon Ice Cream",
    :shortname => "B. M. Ice Cream",
    :unit => "cone of Blue Moon Ice Cream",
    :desc => "An extremely rare ice cream! Eat it before it melts to restore 200 HP!",
    :price => 20000,
    :medicine => {
      :hp => 200,
      :happiness => :BlueCandy,
    },
    :flingdamage => 10,
    :healing => true,
  },

  :ANCIENTBOOK => {
    :ID => 630,
    :name => "Ancient Book",
    :desc => "A book that is said to have the power to translate ancient Garufa text.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :MYSTERYITEM => {
    :ID => 631,
    :name => "Mystery Item",
    :desc => "An object that is an item-- but also a mystery.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :VANILLAIC => {
    :ID => 632,
    :name => "Vanilla Ice Cream",
    :unit => "cone of Vanilla Ice Cream",
    :desc => "A vanilla flavored treat! Eat it before it melts!",
    :price => 400,
    :medicine => {
      :hp => 30,
      :happiness => :Candy,
    },
    :flingdamage => 10,
    :healing => true,
  },

  :CHOCOLATEIC => {
    :ID => 633,
    :name => "Choc Ice Cream",
    :unit => "cone of Choc Ice Cream",
    :desc => "A chocolate flavored treat! Eat it before it melts!",
    :price => 600,
    :medicine => {
      :hp => 70,
      :happiness => :Candy,
    },
    :flingdamage => 10,
    :healing => true,
  },

  :STRAWBIC => {
    :ID => 634,
    :name => "Berry Ice Cream",
    :unit => "cone of Berry Ice Cream",
    :desc => "A strawberry flavored treat! Eat it before it melts!",
    :price => 800,
    :medicine => {
      :hp => 90,
      :happiness => :Candy,
    },
    :flingdamage => 10,
    :healing => true,
  },

  :BIKEV => {
    :ID => 635,
    :name => "Bike Voucher",
    :desc => "Redeem this at the Jynnobi Pass bike shop for a free bike!",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :BRKA => {
    :ID => 636,
    :name => "Broken Antenna",
    :desc => "A broken interfering signal antenna. The guard named it Philip. RIP Guard.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :BRKAR => {
    :ID => 637,
    :name => "Refurbished Laser",
    :desc => "A broken antenna that was turned into a small laser.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :MAGSTONE => {
    :ID => 638,
    :name => "Earth Heart",
    :desc => "A special scale that has the power to break auras.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :TM110 => {
    :ID => 639,
    :name => "TM110",
    :price => 30000,
    :tm => :MAGMADRIFT,
    :noUseInBattle => true,
  },

  :TM104 => {
    :ID => 640,
    :name => "TM104",
    :price => 30000,
    :tm => :DELUGE,
    :noUseInBattle => true,
  },

  :STOREKEY1 => {
    :ID => 641,
    :name => "Storage Key-1",
    :plural => "Storage Keys-1",
    :desc => "A key that can be used to open up Storage Unit #1 in Akuwa Town.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :POLIFLUTE => {
    :ID => 642,
    :name => "Troupe Flute",
    :desc => "A flute that can be used to gather the Poliwag Troupe.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :XENKEY => {
    :ID => 643,
    :name => "V.G.C.R. Key",
    :desc => "A key that can unlock a door at the V.G.C.R. underneath Carotos Mountain.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :CARDKEYS => {
    :ID => 644,
    :name => "Card Key Shard",
    :desc => "A piece of a broken card key.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :CARDKEYS2 => {
    :ID => 645,
    :name => "Card Key Shard",
    :desc => "A piece of a broken card key.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :CARDKEYS3 => {
    :ID => 646,
    :name => "Card Key Shard",
    :desc => "A piece of a broken card key.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :TM105 => {
    :ID => 647,
    :name => "TM105",
    :price => 30000,
    :tm => :ARENITEWALL,
    :noUseInBattle => true,
  },

  :TM106 => {
    :ID => 648,
    :name => "TM106",
    :price => 30000,
    :tm => :IRRITATION,
    :noUseInBattle => true,
  },

  :KKEY => {
    :ID => 649,
    :name => "Apartment Key",
    :desc => "A key to some apartment in Kugearen City.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :TP => {
    :ID => 650,
    :name => "Toilet Paper",
    :unit => "roll of Toilet Paper",
    :desc => "Toilet Paper... okay?",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :WEIRDDIARY => {
    :ID => 651,
    :name => "Weird Diary",
    :desc => "A weird diary that claims to have the answer to Dimensional Rift purification.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :ATKCARD => {
    :ID => 652,
    :name => "Attack Card",
    :desc => "A card that allows the owner to participate in the Attack EV center service.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SPATKCARD => {
    :ID => 653,
    :name => "SPAttack Card",
    :desc => "A card that allows the owner to participate in the Special Attack EV center service.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DEFCARD => {
    :ID => 654,
    :name => "Defense Card",
    :desc => "A card that allows the owner to participate in the Defense EV center service.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DATACHIP => {
    :ID => 655,
    :name => "Data Drive",
    :desc => "A mysterious USB filled with data that is equally as mysterious. Somehow your hand shakes nervously while you hold it.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :TM107 => {
    :ID => 656,
    :name => "TM107",
    :price => 40000,
    :tm => :SLASHANDBURN,
    :noUseInBattle => true,
  },

  :STRAWCAKE => {
    :ID => 657,
    :name => "Strawberry Cake",
    :desc => "A delicious cake made from strawberries! Restores 150 HP.",
    :price => 3700,
    :medicine => {
      :hp => 150,
    },
    :healing => true,
  },

  :ROSETEA => {
    :ID => 658,
    :name => "Rose Tea",
    :unit => "cup of Rose Tea",
    :desc => "Delicious tea made from dried rose petals. Restores PP on all moves.",
    :price => 4700,
    :medicine => {},
    :noUseInBattle => true,
    :pprestore => true,
  },

  :HERBALTEA => {
    :ID => 659,
    :name => "Herbal Tea",
    :unit => "cup of Herbal Tea",
    :desc => "Tea made from fresh herbs. Fully revives a single Pokémon and increases happiness.",
    :price => 4700,
    :medicine => {
      :revive => 1.0,
      :happiness => :EVBerry,
    },
    :revival => true,
  },

  :RAZZTART => {
    :ID => 660,
    :name => "Razz Berry Tart",
    :desc => "A sour pastry made from fresh Razz Berries. Cures status ailments.",
    :price => 1700,
    :medicine => {
      :status => :FULLHEAL,
    },
    :noUse => true,
    :gem => true,
    :status => true,
  },

  :SCEPTILITE => {
    :ID => 661,
    :name => "Sceptilite",
    :desc => "One variety of Mega Stone. Have Sceptile hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LIGHTKEY => {
    :ID => 662,
    :name => "Lighthouse Key",
    :desc => "A key to the help center in Kristiline Town.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :SPDEFCARD => {
    :ID => 663,
    :name => "SPDefense Card",
    :desc => "A card that allows the owner to participate in the Special Defense EV center service.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GATEKEY => {
    :ID => 664,
    :name => "Gate Key",
    :desc => "A key that opens a door somewhere in the Darchlight Manor.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :STEAMBALL => {
    :ID => 665,
    :name => "Steam Ball",
    :desc => "A somewhat different Poké Ball that works especially well on Water- and Fire-type Pokémon.",
    :price => 1200,
    :ball => true,
    :noUse => true,
  },

  :MINERALBALL => {
    :ID => 666,
    :name => "Mineral Ball",
    :desc => "A somewhat different Poké Ball that works especially well on Rock- Ground- and Steel-type Pokémon.",
    :price => 1200,
    :ball => true,
    :noUse => true,
  },

  :GATHERCUBE => {
    :ID => 667,
    :name => "Gather Cube",
    :desc => "A Mysterious Cube that has the power to gather various types of cells.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :important => true,
  },

  :ANJUPENDANT => {
    :ID => 668,
    :name => "Anju's Pendant",
    :desc => "A pendant that belongs to a mysterious woman named Anju. It apparently means a lot to her.",
    :noArticle => true,
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :SNAGMACHINE => {
    :ID => 669,
    :name => "Snag Machine",
    :desc => "A machine that allows the user to snag Shadow Pokémon.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :SNAGMACHINE1 => {
    :ID => 670,
    :name => "Snag Machine",
    :desc => "Once a machine capable of capturing Shadow Pokémon. Madelis interfered with the device and destroyed it.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :APOPHYLLPAN => {
    :ID => 671,
    :name => "Apophyll Pancakes",
    :desc => "Delicious pancakes imported from Apophyll Academy. They're magically delicious!",
    :price => 3000,
    :evoitem => true,
    :noUseInBattle => true,
  },

  :NIGHTMED => {
    :ID => 672,
    :name => "Nightmare Medallion",
    :desc => "A cursed medal that will guarantee the user to experience nightmares while they sleep. ",
    :price => 4800,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :LABKEY => {
    :ID => 673,
    :name => "Lab Key",
    :desc => "A key that Professor Matthew found in the Forsaken Laboratory.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :STARSHARD1 => {
    :ID => 674,
    :name => "Star Shard",
    :desc => "A star piece that seems to be part of something bigger.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :STARSHARD2 => {
    :ID => 675,
    :name => "Star Shard",
    :desc => "A star piece that seems to be part of something bigger. There are two shards here.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :STARSHARD3 => {
    :ID => 676,
    :name => "Star Shard",
    :desc => "A star piece that seems to be part of something bigger. There are three shards here.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :STARSHARD4 => {
    :ID => 677,
    :name => "Star Shard",
    :desc => "A star piece that seems to be part of something bigger. There are four shards here.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :INVITATION => {
    :ID => 678,
    :name => "Secret Invitation",
    :desc => "An invitation to a secret event! Take it to the Gearen Laboratory!",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :FAMILYPORTRAIT => {
    :ID => 679,
    :name => "Family Portrait",
    :desc => "A portait of a family that once lived in Aevium. Their history is unknown.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :ULTRAPOTION => {
    :ID => 680,
    :name => "Ultra Potion",
    :desc => "A spray-type medicine for wounds. It restores the HP of one Pokémon by 200 points.",
    :price => 2200,
    :medicine => {
      :hp => 200,
    },
    :healing => true,
  },

  :ADRENALINEORB => {
    :ID => 690,
    :name => "Adrenaline Orb",
    :desc => "If held by a Pokémon, it boosts Speed when intimidated. It can be used only once.",
    :price => 300,
    :overworld => true,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :BIGMALASADA => {
    :ID => 691,
    :name => "Big Malasada",
    :desc => "The Alola region's local specialty—fried bread. It can be used once to heal all the status conditions of a Pokémon.",
    :price => 200,
    :medicine => {
      :status => :FULLHEAL,
    },
    :flingdamage => 30,
    :status => true,
  },

  :ICESTONE => {
    :ID => 692,
    :name => "Ice Stone",
    :desc => "A peculiar stone that can make certain species of Pokémon evolve. It has an unmistakable snowflake pattern. ",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :PROTECTIVEPADS => {
    :ID => 693,
    :name => "Protective Pads",
    :unit => "set of Protective Pads",
    :desc => "An item to be held by a Pokémon. These pads protect the holder from effects caused by making direct contact. ",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :FIREMEMORY => {
    :ID => 694,
    :name => "Fire Memory",
    :desc => "A memory disc that contains Fire-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :FIRE,
    :flingdamage => 50,
  },

  :WATERMEMORY => {
    :ID => 695,
    :name => "Water Memory",
    :desc => "A memory disc that contains Water-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :WATER,
    :flingdamage => 50,
  },

  :ELECTRICMEMORY => {
    :ID => 696,
    :name => "Electric Memory",
    :desc => "A memory disc that contains Electric-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :ELECTRIC,
    :flingdamage => 50,
  },

  :GRASSMEMORY => {
    :ID => 697,
    :name => "Grass Memory",
    :desc => "A memory disc that contains Grass-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :GRASS,
    :flingdamage => 50,
  },

  :ICEMEMORY => {
    :ID => 698,
    :name => "Ice Memory",
    :desc => "A memory disc that contains Ice-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :ICE,
    :flingdamage => 50,
  },

  :FIGHTINGMEMORY => {
    :ID => 699,
    :name => "Fighting Memory",
    :desc => "A memory disc that contains Fighting-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :FIGHTING,
    :flingdamage => 50,
  },

  :POISONMEMORY => {
    :ID => 700,
    :name => "Poison Memory",
    :desc => "A memory disc that contains Poison-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :POISON,
    :flingdamage => 50,
  },

  :GROUNDMEMORY => {
    :ID => 701,
    :name => "Ground Memory",
    :desc => "A memory disc that contains Ground-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :GROUND,
    :flingdamage => 50,
  },

  :FLYINGMEMORY => {
    :ID => 702,
    :name => "Flying Memory",
    :desc => "A memory disc that contains Flying-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :FLYING,
    :flingdamage => 50,
  },

  :PSYCHICMEMORY => {
    :ID => 703,
    :name => "Psychic Memory",
    :desc => "A memory disc that contains Psychic-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :PSYCHIC,
    :flingdamage => 50,
  },

  :BUGMEMORY => {
    :ID => 704,
    :name => "Bug Memory",
    :desc => "A memory disc that contains Bug-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :BUG,
    :flingdamage => 50,
  },

  :ROCKMEMORY => {
    :ID => 705,
    :name => "Rock Memory",
    :desc => "A memory disc that contains Rock-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :ROCK,
    :flingdamage => 50,
  },

  :GHOSTMEMORY => {
    :ID => 706,
    :name => "Ghost Memory",
    :desc => "A memory disc that contains Ghost-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :GHOST,
    :flingdamage => 50,
  },

  :DRAGONMEMORY => {
    :ID => 707,
    :name => "Dragon Memory",
    :desc => "A memory disc that contains Dragon-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :DRAGON,
    :flingdamage => 50,
  },

  :DARKMEMORY => {
    :ID => 708,
    :name => "Dark Memory",
    :desc => "A memory disc that contains Dark-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :DARK,
    :flingdamage => 50,
  },

  :STEELMEMORY => {
    :ID => 709,
    :name => "Steel Memory",
    :desc => "A memory disc that contains Steel-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :STEEL,
    :flingdamage => 50,
  },

  :FAIRYMEMORY => {
    :ID => 710,
    :name => "Fairy Memory",
    :desc => "A memory disc that contains Fairy-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :FAIRY,
    :flingdamage => 50,
  },

  :BEASTBALL => {
    :ID => 712,
    :name => "Beast Ball",
    :desc => "A special Poké Ball designed to catch Ultra Beasts. It has a low success rate for catching others.",
    :price => 5000,
    :ball => true,
    :noUse => true,
  },

  :REDNECTAR => {
    :ID => 713,
    :name => "Red Nectar",
    :unit => "jar of Red Nectar",
    :desc => "A flower nectar imported from Ula'ula Meadow. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :YELLOWNECTAR => {
    :ID => 714,
    :name => "Yellow Nectar",
    :unit => "jar of Yellow Nectar",
    :desc => "A flower nectar imported from Melemele Meadow. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :PINKNECTAR => {
    :ID => 715,
    :name => "Pink Nectar",
    :unit => "jar of Pink Nectar",
    :desc => "A flower nectar imported from the Royal Avenue. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :PURPLENECTAR => {
    :ID => 716,
    :name => "Purple Nectar",
    :unit => "jar of Purple Nectar",
    :desc => "A flower nectar imported from Poni Meadow. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :TM111 => {
    :ID => 717,
    :name => "TM111",
    :price => 100000,
    :tm => :AURORAVEIL,
    :noUseInBattle => true,
  },

  :BUGINIUMZ => {
    :ID => 718,
    :name => "Buginium Z",
    :unit => "piece of Buginium Z",
    :desc => "It converts Z-Power into crystals that upgrade Bug-type moves to Bug-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SAVAGESPINOUT,
    :noUseInBattle => true,
  },

  :DARKINIUMZ => {
    :ID => 720,
    :name => "Darkinium Z",
    :unit => "piece of Darkinium Z",
    :desc => "It converts Z-Power into crystals that upgrade Dark-type moves to Dark-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :BLACKHOLEECLIPSE,
    :noUseInBattle => true,
  },

  :DRAGONIUMZ => {
    :ID => 722,
    :name => "Dragonium Z",
    :unit => "piece of Dragonium Z",
    :desc => "It converts Z-Power into crystals that upgrade Dragon-type moves to Dragon-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :DEVASTATINGDRAKE,
    :noUseInBattle => true,
  },

  :ELECTRIUMZ => {
    :ID => 724,
    :name => "Electrium Z",
    :unit => "piece of Electrium Z",
    :desc => "It converts Z-Power into crystals that upgrade Electric-type moves to Electric-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :GIGAVOLTHAVOC,
    :noUseInBattle => true,
  },

  :FAIRIUMZ => {
    :ID => 726,
    :name => "Fairium Z",
    :unit => "piece of Fairium Z",
    :desc => "It converts Z-Power into crystals that upgrade Fairy-type moves to Fairy-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :TWINKLETACKLE,
    :noUseInBattle => true,
  },

  :FIGHTINIUMZ => {
    :ID => 728,
    :name => "Fightinium Z",
    :unit => "piece of Fightinium Z",
    :desc => "It converts Z-Power into crystals that upgrade Fighting-type moves to Fighting-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :ALLOUTPUMMELING,
    :noUseInBattle => true,
  },

  :FIRIUMZ => {
    :ID => 730,
    :name => "Firium Z",
    :unit => "piece of Firium Z",
    :desc => "It converts Z-Power into crystals that upgrade Fire-type moves to Fire-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :INFERNOOVERDRIVE,
    :noUseInBattle => true,
  },

  :FLYINIUMZ => {
    :ID => 732,
    :name => "Flyinium Z",
    :unit => "piece of Flyinium Z",
    :desc => "It converts Z-Power into crystals that upgrade Flying-type moves to Flying-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SUPERSONICSKYSTRIKE,
    :noUseInBattle => true,
  },

  :GHOSTIUMZ => {
    :ID => 734,
    :name => "Ghostium Z",
    :unit => "piece of Ghostium Z",
    :desc => "It converts Z-Power into crystals that upgrade Ghost-type moves to Ghost-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :NEVERENDINGNIGHTMARE,
    :noUseInBattle => true,
  },

  :GRASSIUMZ => {
    :ID => 736,
    :name => "Grassium Z",
    :unit => "piece of Grassium Z",
    :desc => "It converts Z-Power into crystals that upgrade Grass-type moves to Grass-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :BLOOMDOOM,
    :noUseInBattle => true,
  },

  :GROUNDIUMZ => {
    :ID => 738,
    :name => "Groundium Z",
    :unit => "piece of Groundium Z",
    :desc => "It converts Z-Power into crystals that upgrade Ground-type moves to Ground-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :TECTONICRAGE,
    :noUseInBattle => true,
  },

  :ICIUMZ => {
    :ID => 740,
    :name => "Icium Z",
    :unit => "piece of Icium Z",
    :desc => "It converts Z-Power into crystals that upgrade Ice-type moves to Ice-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SUBZEROSLAMMER,
    :noUseInBattle => true,
  },

  :NORMALIUMZ => {
    :ID => 742,
    :name => "Normalium Z",
    :unit => "piece of Normalium Z",
    :desc => "It converts Z-Power into crystals that upgrade Normal-type moves to Normal-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :BREAKNECKBLITZ,
    :noUseInBattle => true,
  },

  :POISONIUMZ => {
    :ID => 744,
    :name => "Poisonium Z",
    :unit => "piece of Poisonium Z",
    :desc => "It converts Z-Power into crystals that upgrade Poison-type moves to Poison-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :ACIDDOWNPOUR,
    :noUseInBattle => true,
  },

  :PSYCHIUMZ => {
    :ID => 746,
    :name => "Psychium Z",
    :unit => "piece of Psychium Z",
    :desc => "It converts Z-Power into crystals that upgrade Psychic-type moves to Psychic-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SHATTEREDPSYCHE,
    :noUseInBattle => true,
  },

  :ROCKIUMZ => {
    :ID => 748,
    :name => "Rockium Z",
    :unit => "piece of Rockium Z",
    :desc => "It converts Z-Power into crystals that upgrade Rock-type moves to Rock-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :CONTINENTALCRUSH,
    :noUseInBattle => true,
  },

  :STEELIUMZ => {
    :ID => 750,
    :name => "Steelium Z",
    :unit => "piece of Steelium Z",
    :desc => "It converts Z-Power into crystals that upgrade Steel-type moves to Steel-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :CORKSCREWCRASH,
    :noUseInBattle => true,
  },

  :WATERIUMZ => {
    :ID => 752,
    :name => "Waterium Z",
    :unit => "piece of Waterium Z",
    :desc => "It converts Z-Power into crystals that upgrade Water-type moves to Water-type Z-Moves.",
    :price => 0,
    :crystal => true,
    :zcrystal => :HYDROVORTEX,
    :noUseInBattle => true,
  },

  :ALORAICHIUMZ => {
    :ID => 754,
    :name => "Aloraichium Z",
    :unit => "piece of Aloraichium Z",
    :desc => "It converts Z-Power into crystals that upgrade Alolan Raichu's Thunderbolt to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :STOKEDSPARKSURFER,
    :noUseInBattle => true,
  },

  :DECIDIUMZ => {
    :ID => 756,
    :name => "Decidium Z",
    :unit => "piece of Decidium Z",
    :desc => "It converts Z-Power into crystals that upgrade Decidueye's Spirit Shackle to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SINISTERARROWRAID,
    :noUseInBattle => true,
  },

  :INCINIUMZ => {
    :ID => 758,
    :name => "Incinium Z",
    :unit => "piece of Incinium Z",
    :desc => "It converts Z-Power into crystals that upgrade Incineroar's Darkest Lariat to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :MALICIOUSMOONSAULT,
    :noUseInBattle => true,
  },

  :PRIMARIUMZ => {
    :ID => 760,
    :name => "Primarium Z",
    :unit => "piece of Primarium Z",
    :desc => "It converts Z-Power into crystals that upgrade Primarina's Sparkling Aria to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :OCEANICOPERETTA,
    :noUseInBattle => true,
  },

  :EEVIUMZ => {
    :ID => 762,
    :name => "Eevium Z",
    :unit => "piece of Eevium Z",
    :desc => "It converts Z-Power into crystals that upgrade Eevee's Last Resort to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :EXTREMEEVOBOOST,
    :noUseInBattle => true,
  },

  :PIKANIUMZ => {
    :ID => 764,
    :name => "Pikanium Z",
    :unit => "piece of Pikanium Z",
    :desc => "It converts Z-Power into crystals that upgrade Pikachu's Volt Tackle to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :CATASTROPIKA,
    :noUseInBattle => true,
  },

  :SNORLIUMZ => {
    :ID => 766,
    :name => "Snorlium Z",
    :unit => "piece of Snorlium Z",
    :desc => "It converts Z-Power into crystals that upgrade Snorlax's Giga Impact to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :PULVERIZINGPANCAKE,
    :noUseInBattle => true,
  },

  :MEWNIUMZ => {
    :ID => 768,
    :name => "Mewnium Z",
    :unit => "piece of Mewnium Z",
    :desc => "It converts Z-Power into crystals that upgrade Mew's Psychic to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :GENESISSUPERNOVA,
    :noUseInBattle => true,
  },

  :TAPUNIUMZ => {
    :ID => 770,
    :name => "Tapunium Z",
    :unit => "piece of Tapunium Z",
    :desc => "It converts Z-Power into crystals that upgrade the tapus' Nature's Madness to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :GUARDIANOFALOLA,
    :noUseInBattle => true,
  },

  :MARSHADIUMZ => {
    :ID => 772,
    :name => "Marshadium Z",
    :unit => "piece of Marshadium Z",
    :desc => "It converts Z-Power into crystals that upgrade Marshadow's Spectral Thief to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SOULSTEALING7STARSTRIKE,
    :noUseInBattle => true,
  },

  :ELEMENTALSEED => {
    :ID => 774,
    :name => "Elemental Seed",
    :desc => "A single-use seed that boosts its holder in Elemental Fields.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
  },

  :MAGICALSEED => {
    :ID => 775,
    :name => "Magical Seed",
    :desc => "A single-use seed that boosts its holder in Magical Fields.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
  },

  :TELLURICSEED => {
    :ID => 776,
    :name => "Telluric Seed",
    :desc => "A single-use seed that boosts its holder in Telluric Fields.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
  },

  :SYNTHETICSEED => {
    :ID => 777,
    :name => "Synthetic Seed",
    :desc => "A single-use seed that boosts its holder in Synthetic Fields.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
  },

  :GEARAMULET => {
    :ID => 778,
    :name => "Time Gear Amulet",
    :desc => "An amulet with a Time Gear on it. Its function is unknown.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :GARUFABOOK => {
    :ID => 779,
    :name => "Garufa Spellbook",
    :desc => "A book that contains a myriad of spells created by the Garufa.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :SCANE => {
    :ID => 780,
    :name => "Souta's Cane",
    :desc => "A mystical cane that Souta owned. It can extend and shorten itself at the base. ",
    :noArticle => true,
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :PIDGEOTITE => {
    :ID => 781,
    :name => "Pidgeotite",
    :desc => "One variety of Mega Stone. Have Pidgeot hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SLOWBRONITE => {
    :ID => 782,
    :name => "Slowbronite",
    :desc => "One variety of Mega Stone. Have Slowbro hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TM112 => {
    :ID => 783,
    :name => "TM112",
    :price => 20000,
    :tm => :SMARTSTRIKE,
    :noUseInBattle => true,
  },

  :TM113 => {
    :ID => 784,
    :name => "TM113",
    :price => 20000,
    :tm => :BRUTALSWING,
    :noUseInBattle => true,
  },

  :TM114 => {
    :ID => 785,
    :name => "TM114",
    :price => 35000,
    :tm => :LEECHLIFE,
    :noUseInBattle => true,
  },

  :MYSTEMBLEM => {
    :ID => 786,
    :name => "Mysterious Emblem",
    :desc => "A mysterious emblem that depicts an odd shape.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :RESEARCHNOTES => {
    :ID => 787,
    :name => "Research Notes",
    :desc => "A book filled with research notes about the Pokémon Flabébé.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :SPUPARCEL => {
    :ID => 788,
    :name => "SPU Parcel",
    :desc => "A parcel from the broken down SPU truck. Take this to its rightful owner!",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :DARCHMIRROR => {
    :ID => 789,
    :name => "Darchlight Mirror",
    :desc => "A mysterious mirror that's said to act as a bridge between dimensions.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :DARKMATTER => {
    :ID => 790,
    :name => "Dark Material",
    :unit => "piece of Dark Material",
    :desc => "A fragment of pitch-dark energy.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :justsell => true,
  },

  :CURSEDCANDLE => {
    :ID => 791,
    :name => "Cursed Candle",
    :desc => "A candle that has a dark curse placed upon it. It seems like it was crafted specifically to fit atop a grave.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :AUDITIONTAPE => {
    :ID => 792,
    :name => "Audition Tape",
    :desc => "A tape Melia made to audition for the Normal-Type Gym Leader position. It's apparently very embarrassing.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :ACHIEVEMENTCARD => {
    :ID => 793,
    :name => "Achievement Card",
    :desc => "A card that displays the amount of AP on hand.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :important => true,
  },

  :GOLDENGAUNTLET => {
    :ID => 794,
    :name => "Golden Gauntlet",
    :desc => "A golden item that allows for the use of Strength without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLDENAXE => {
    :ID => 795,
    :name => "Golden Axe",
    :desc => "A golden item that allows for the use of Cut without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLDENHAMMER => {
    :ID => 796,
    :name => "Golden Hammer",
    :desc => "A golden item that allows for the use of Rock Smash without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLDENSURFBOARD => {
    :ID => 797,
    :name => "Golden Surfboard",
    :desc => "A golden item that allows for the use of Surf without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLDENSCUBAGEAR => {
    :ID => 798,
    :name => "Golden Scuba Gear",
    :unit => "set of Golden Scuba Gear",
    :desc => "A golden item that allows for the use of Dive without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLDENWINGS => {
    :ID => 799,
    :name => "Golden Wings",
    :desc => "A golden item that allows for the use of Fly without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
  },

  :GOLDENJETPACK => {
    :ID => 800,
    :name => "Golden Jetpack",
    :desc => "A golden item that allows for the use of Waterfall without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLDENDRIFTBOARD => {
    :ID => 801,
    :name => "Golden Drift Board",
    :desc => "A golden item that allows for the use of Magma Drift without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLDENCLAWS => {
    :ID => 802,
    :name => "Golden Claws",
    :desc => "A golden item that allows for the use of Rock Climb without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :EXPALL => {
    :ID => 803,
    :name => "Exp. All",
    :desc => "Turning On this special device will allow all Pokémon on your team to receive Exp. Points from battles.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
    :important => true,
  },

  :BEEDRILLITE => {
    :ID => 805,
    :name => "Beedrillite",
    :desc => "One variety of Mega Stone. Have Beedrill hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :STEELIXITE => {
    :ID => 806,
    :name => "Steelixite",
    :desc => "One variety of Mega Stone. Have Steelix hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SWAMPERTITE => {
    :ID => 807,
    :name => "Swampertite",
    :desc => "One variety of Mega Stone. Have Swampert hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SABLENITE => {
    :ID => 808,
    :name => "Sablenite",
    :desc => "One variety of Mega Stone. Have Sableye hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SHARPEDONITE => {
    :ID => 809,
    :name => "Sharpedonite",
    :desc => "One variety of Mega Stone. Have Sharpedo hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CAMERUPTITE => {
    :ID => 810,
    :name => "Cameruptite",
    :desc => "One variety of Mega Stone. Have Camerupt hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ALTARIANITE => {
    :ID => 811,
    :name => "Altarianite",
    :desc => "One variety of Mega Stone. Have Altaria hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GLALITITE => {
    :ID => 812,
    :name => "Glalitite",
    :desc => "One variety of Mega Stone. Have Glalie hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SALAMENCITE => {
    :ID => 813,
    :name => "Salamencite",
    :desc => "One variety of Mega Stone. Have Salamence hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LATIASITE => {
    :ID => 814,
    :name => "Latiasite",
    :desc => "One variety of Mega Stone. Have Latias hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LATIOSITE => {
    :ID => 815,
    :name => "Latiosite",
    :desc => "One variety of Mega Stone. Have Latios hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LOPUNNITE => {
    :ID => 816,
    :name => "Lopunnite",
    :desc => "One variety of Mega Stone. Have Lopunny hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GALLADITE => {
    :ID => 817,
    :name => "Galladite",
    :desc => "One variety of Mega Stone. Have Gallade hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :AUDINITE => {
    :ID => 818,
    :name => "Audinite",
    :desc => "One variety of Mega Stone. Have Audino hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DIANCITE => {
    :ID => 819,
    :name => "Diancite",
    :desc => "One variety of Mega Stone. Have Diancie hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BLACKSHARD2 => {
    :ID => 820,
    :name => "Black Shard",
    :desc => "A mysterious shard that was created by smelting Black Ore.",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :SCENTEDLURE => {
    :ID => 821,
    :name => "Scented Lure",
    :desc => "A lure that brings Pokémon out at certain spots.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :justsell => true,
  },

  :MAGCREST => {
    :ID => 823,
    :name => "Magcargo Crest",
    :desc => "Magcargo's Defense and Speed are swapped, and Sp. Atk increases by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FEARCREST => {
    :ID => 825,
    :name => "Fearow Crest",
    :desc => "Increases the power of stabbing moves by 50%. Increase critical-hit ratio by 1.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :STANTCREST => {
    :ID => 826,
    :name => "Stantler Crest",
    :desc => "Increases Stantler's and Wyrdeer's Attack and Accuracy by 50%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HYPCREST => {
    :ID => 827,
    :name => "Hypno Crest",
    :desc => "Increases Hypno's Special Attack and Accuracy by 50%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GLACCREST => {
    :ID => 828,
    :name => "Glaceon Crest",
    :desc => "Glaceon takes resisted damage from Rock and Fighting attacks. Abilities apply regardless of the weather.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LEAFCREST => {
    :ID => 829,
    :name => "Leafeon Crest",
    :desc => "Leafeon takes resisted damage from Fire and Flying attacks. Abilities apply regardless of if their weather is active.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :RELICREST => {
    :ID => 830,
    :name => "Relicanth Crest",
    :desc => "Increases Relicanth's Attack by 25% and Sp. Def by 35%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ORICREST => {
    :ID => 831,
    :name => "Oricorio Crest",
    :desc => "Increases Oricorio's Speed and Sp. Atk stat by 25%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SILVCREST => {
    :ID => 832,
    :name => "Silvally Crest",
    :desc => "Has a special effect for each held Memory and boosts that type's attacks.",
    :price => 0,
    :keyitem => true,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SEVCREST => {
    :ID => 833,
    :name => "Seviper Crest",
    :desc => "Seviper deals more damage against healthier foes, up to 50%. Speed increased by 50%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :COFCREST => {
    :ID => 834,
    :name => "Cofagrigus Crest",
    :desc => "Increases Cofagrigus's Defense by 40% and Sp. Atk by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DUSKCREST => {
    :ID => 835,
    :name => "Dusknoir Crest",
    :desc => "Increases Dusknoir's Attack by 50% and boosts weaker moves.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BADGECARD => {
    :ID => 836,
    :name => "Badge Card",
    :desc => "A card that holds every virtual badge earned.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :important => true,
  },

  :PULSEPLUS => {
    :ID => 837,
    :name => "Pulse+",
    :plural => "Pulses+",
    :desc => "???.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :AQUAMARINEORE => {
    :ID => 838,
    :name => "Aquamarine Ore",
    :unit => "piece of Aquamarine Ore",
    :desc => "Rare ore found within Aquamarine Cave.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :TECANLITEKEY => {
    :ID => 839,
    :name => "Tecanlite Key",
    :desc => "A key to a room in the Tecanlite Factory.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :NSOLARIZER => {
    :ID => 840,
    :name => "N-Solarizer",
    :desc => "This item is used to fuse Necrozma and Solgaleo to create Dusk Mane Necrozma.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :NLUNARIZER => {
    :ID => 841,
    :name => "N-Lunarizer",
    :desc => "This item is used to fuse Necrozma and Lunala to create Dawn Wings Necrozma.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :KOMMONIUMZ => {
    :ID => 842,
    :name => "Kommonium Z",
    :unit => "piece of Kommonium Z",
    :desc => "It converts Z-Power into crystals that upgrade Kommo-o's Clanging Scales to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :CLANGOROUSSOULBLAZE,
    :noUseInBattle => true,
  },

  :LYCANIUMZ => {
    :ID => 844,
    :name => "Lycanium Z",
    :unit => "piece of Lycanium Z",
    :desc => "It converts Z-Power into crystals that upgrade Lycanroc's Stone Edge to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SPLINTEREDSTORMSHARDS,
    :noUseInBattle => true,
  },

  :MIMIKIUMZ => {
    :ID => 846,
    :name => "Mimikium Z",
    :unit => "piece of Mimikium Z",
    :desc => "It converts Z-Power into crystals that upgrade Mimikyu's Play Rough to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :LETSSNUGGLEFOREVER,
    :noUseInBattle => true,
  },

  :SOLGANIUMZ => {
    :ID => 848,
    :name => "Solganium Z",
    :unit => "piece of Solganium Z",
    :desc => "It converts Z-Power into crystals that upgrade Solgaleo's Sunsteel Strike to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :SEARINGSUNRAZESMASH,
    :noUseInBattle => true,
  },

  :LUNALIUMZ => {
    :ID => 850,
    :name => "Lunalium Z",
    :unit => "piece of Lunalium Z",
    :desc => "It converts Z-Power into crystals that upgrade Lunala's Moongeist Beam to an exclusive Z-Move.",
    :price => 0,
    :crystal => true,
    :zcrystal => :MENACINGMOONRAZEMAELSTROM,
    :noUseInBattle => true,
  },

  :ULTRANECROZIUMZ => {
    :ID => 852,
    :name => "Ultranecrozium Z",
    :unit => "piece of Ultranecrozium Z",
    :desc => "It's a crystal that allows Necrozma fused with another Pokémon to change forme.",
    :price => 0,
    :crystal => true,
    :zcrystal => :LIGHTTHATBURNSTHESKY,
    :noUseInBattle => true,
  },

  :BLASTPOWDER => {
    :ID => 854,
    :name => "Blast Powder",
    :unit => "pile of Blast Powder",
    :desc => "A powder made from Electrode. Explodes to break up certain rock formations.",
    :price => 2500,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :AMPLIFIELDROCK => {
    :ID => 855,
    :name => "Amplifield Rock",
    :desc => "A Pokémon held item that extends the duration of the area-altering moves used by the holder.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 60,
  },

  :RIFTSEED => {
    :ID => 856,
    :name => "Rift Seed",
    :desc => "A single-use seed that boosts its holder in Telluric Fields.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
  },

  :MYSTBLACKBOX => {
    :ID => 857,
    :name => "Mysterious Black Box",
    :plural => "Mysterious Black Boxes",
    :desc => "A mysterious black box that belonged to Nancy. It gives off a faint pink glow.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :HOUSEKEY => {
    :ID => 858,
    :name => "House Key",
    :desc => "A key to the strange house south of Sashila Village. It's really rusty.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :REFORGEDKEY => {
    :ID => 859,
    :name => "Reforged Key",
    :desc => "A key to the strange house south of Sashila Village. It's brand new!",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :GREGPOSTCARD => {
    :ID => 860,
    :name => "Lake Postcard",
    :desc => "A postcard with a lovely picture of Gregorian Lake on it.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :SKUNCREST => {
    :ID => 861,
    :name => "Skuntank Crest",
    :desc => "Nullifies damage and boosts Attack when hit by a Ground-type move. Increases Attack and Sp. Atk by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TRANSMITTER => {
    :ID => 862,
    :name => "Transmitter",
    :desc => "A transmitter given to you by Nastasia. It can be used to speak to Ren or Aelita.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :ZONEZEROKEY => {
    :ID => 863,
    :name => "Zone Zero Key",
    :desc => "A key to open the gate to Zone Zero from Alamissa Urben.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :DARMCREST => {
    :ID => 864,
    :name => "Darmanitan Crest",
    :desc => "Darmanitan is forced into Zen Mode while holding this crest.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHERCREST => {
    :ID => 865,
    :name => "Cherrim Crest",
    :desc => "Activates Flower Gift regardless of weather. Flower Gift additionally boosts Defense and SpAtk.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CLAYCREST => {
    :ID => 866,
    :name => "Claydol Crest",
    :desc => "Claydol's Special attacks use its Defense stat. The power of beam moves is increased by 50%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DEDECREST => {
    :ID => 867,
    :name => "Dedenne Crest",
    :desc => "Dedenne's attacks use its Speed stat rather than the respective offensive stat.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ZANGCREST => {
    :ID => 868,
    :name => "Zangoose Crest",
    :desc => "Zangoose becomes poisoned upon switching in, and restores HP while poisoned.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BASTCREST => {
    :ID => 869,
    :name => "Bastiodon Crest",
    :desc => "Attackers take 50% of the damage they deal as recoil, and the wearer is healed the same amount.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEGCREST => {
    :ID => 870,
    :name => "Meganium Crest",
    :desc => "Meganium and its allies take reduced damage and recover every turn.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TYPHCREST => {
    :ID => 871,
    :name => "Typhlosion Crest",
    :desc => "Typhlosion's Attack is equivalent with Sp. Atk, and contact moves do an additional hit of damage.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FERACREST => {
    :ID => 872,
    :name => "Feraligatr Crest",
    :desc => "First move has increased priority if it's damaging. Biting moves deal 50% more damage.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :RAMPCREST => {
    :ID => 873,
    :name => "Rampardos Crest",
    :desc => "Rampardos will hang on with 1HP regardless of HP once per battle and does not take recoil.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LEDICREST => {
    :ID => 874,
    :name => "Ledian Crest",
    :desc => "Ledian punches four times at once. Secondary effects only occur on the first two hits.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ARIACREST => {
    :ID => 875,
    :name => "Ariados Crest",
    :desc => "Ariados's speed is increased by 50% and cannot be lowered. Deals critical hits against slowed or poisoned targets.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SPIRITCREST => {
    :ID => 876,
    :name => "Spiritomb Crest",
    :desc => "Spiritomb becomes stronger for each defeated ally. Recovers health based on KO'd enemies.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :WHISCREST => {
    :ID => 877,
    :name => "Whiscash Crest",
    :desc => "Nullifies damage and boosts Attack when hit by a Grass-type move. Increase Atk and Sp. Atk by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ENIGMATICKEY => {
    :ID => 878,
    :name => "Enigmatic Key",
    :desc => "A key that was previously the Normality Badge. The Normality Badge's true form.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :BEHECREST => {
    :ID => 879,
    :name => "Beheeyem Crest",
    :desc => "Beheyeem disables an opponent's move when attacked. Faster opponents do reduced damage to Beheeyem.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TORCREST => {
    :ID => 880,
    :name => "Torterra Crest",
    :desc => "Torterra's resistances and weaknesses are swapped, retaining immunities. Attacks restore HP.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :INFCREST => {
    :ID => 881,
    :name => "Infernape Crest",
    :desc => "Infernape's Attacking and Defensive stats are equalized. 1/16th Max HP is restored every turn.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :EMPCREST => {
    :ID => 882,
    :name => "Empoleon Crest",
    :desc => "Empoleon's Ice-type moves are boosted by 50%, and Speed is doubled in Hail, Snow and on Ice Fields.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MAGWAND => {
    :ID => 883,
    :name => "Magic Wand",
    :desc => "A stick Braixen used to use for her attacks.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :DARKCORE => {
    :ID => 884,
    :name => "Dark Matter Core",
    :desc => "A core filled to the brim with Dark Matter.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :justsell => true,
  },

  :RM01 => {
    :ID => 885,
    :name => "RM01",
    :price => 75000,
    :tm => :HONECLAWS,
    :noUseInBattle => true,
  },

  :RM02 => {
    :ID => 886,
    :name => "RM02",
    :price => 20000,
    :tm => :AVALANCHE,
    :noUseInBattle => true,
  },

  :RM03 => {
    :ID => 887,
    :name => "RM03",
    :price => 30000,
    :tm => :ZAPCANNON,
    :noUseInBattle => true,
  },

  :RM04 => {
    :ID => 888,
    :name => "RM04",
    :price => 10000,
    :tm => :METRONOME,
    :noUseInBattle => true,
  },

  :RM05 => {
    :ID => 889,
    :name => "RM05",
    :price => 50000,
    :tm => :SUCKERPUNCH,
    :noUseInBattle => true,
  },

  :RM06 => {
    :ID => 890,
    :name => "RM06",
    :price => 15000,
    :tm => :RETALIATE,
    :noUseInBattle => true,
  },

  :RM07 => {
    :ID => 891,
    :name => "RM07",
    :price => 25000,
    :tm => :DYNAMICPUNCH,
    :noUseInBattle => true,
  },

  :RM08 => {
    :ID => 892,
    :name => "RM08",
    :price => 20000,
    :tm => :VACUUMWAVE,
    :noUseInBattle => true,
  },

  :CRYCREST => {
    :ID => 893,
    :name => "Cryogonal Crest",
    :desc => "Increases Cryogonal's Sp. Def by 20%, then increases its other stats by 10% of its Sp. Def.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CASTCREST => {
    :ID => 894,
    :name => "Castform Crest",
    :desc => "Castform uses the first weather move it knows. Its Forecast forms also become empowered.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :RM09 => {
    :ID => 895,
    :name => "RM09",
    :price => 20000,
    :tm => :TRIATTACK,
    :noUseInBattle => true,
  },

  :TARTAPPLE => {
    :ID => 896,
    :name => "Tart Apple",
    :desc => "A peculiar apple that can make a certain species of Pokémon evolve. It's exceptionally tart.",
    :price => 1100,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :SWEETAPPLE => {
    :ID => 897,
    :name => "Sweet Apple",
    :desc => "A peculiar apple that can make a certain species of Pokémon evolve. It's exceptionally sweet.",
    :price => 1100,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :CHIPPEDPOT => {
    :ID => 898,
    :name => "Chipped Pot",
    :desc => "A peculiar teapot that can make a certain Pokémon evolve. While it is chipped, tea poured from it is delicious.",
    :price => 800,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 80,
  },

  :CRACKEDPOT => {
    :ID => 899,
    :name => "Cracked Pot",
    :desc => "A peculiar teapot that can make a certain Pokémon evolve. While it is cracked, tea poured from it is delicious.",
    :price => 800,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 80,
  },

  :RUSTEDSWORD => {
    :ID => 900,
    :name => "Rusted Sword",
    :desc => "It is said that a hero used this sword to halt a terrible disaster in ancient times. It's grown rusty and worn.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 0,
    :legendhold => true,
  },

  :RUSTEDSHIELD => {
    :ID => 901,
    :name => "Rusted Shield",
    :desc => "It is said that a hero used this shield to halt a terrible disaster in ancient times. It's grown rusty and worn.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 0,
    :legendhold => true,
  },

  :FOSSILIZEDBIRD => {
    :ID => 902,
    :name => "Fossilized Bird",
    :desc => "The fossil of an ancient Pokémon that once soared through the sky. What it looked like is a mystery.",
    :price => 2500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :FOSSILIZEDDINO => {
    :ID => 903,
    :name => "Fossilized Dino",
    :desc => "The fossil of an ancient Pokémon that once lived in the sea. What it looked like is a mystery.",
    :price => 2500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :FOSSILIZEDDRAKE => {
    :ID => 904,
    :name => "Fossilized Drake",
    :desc => "The fossil of an ancient Pokémon that once roamed the land. What it looked like is a mystery.",
    :price => 2500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :FOSSILIZEDFISH => {
    :ID => 905,
    :name => "Fossilized Fish",
    :plural => "Fossilized Fish",
    :desc => "The fossil of an ancient Pokémon that once lived in the sea. What it looked like is a mystery.",
    :price => 2500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 100,
    :fossil => true,
  },

  :THROATSPRAY => {
    :ID => 906,
    :name => "Throat Spray",
    :unit => "bottle of Throat Spray",
    :desc => "This item, when held, causes a Pokémon's Special Attack stat to be raised by one stage when it uses a Sound based move",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :EJECTPACK => {
    :ID => 907,
    :name => "Eject Pack",
    :desc => "An item to be held by a Pokémon. When the holder's stats are lowered, it will be switched out of battle.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 50,
  },

  :HEAVYDUTYBOOTS => {
    :ID => 908,
    :name => "Heavy-Duty Boots",
    :unit => "pair of Heavy-Duty Boots",
    :desc => "These boots prevent the effects of traps set on the battlefield.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 80,
  },

  :BLUNDERPOLICY => {
    :ID => 909,
    :name => "Blunder Policy",
    :desc => "Raises Speed sharply when a Pokémon misses with a move because of accuracy.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 80,
  },

  :ROOMSERVICE => {
    :ID => 910,
    :name => "Room Service",
    :unit => "voucher for Room Service",
    :desc => "An item to be held by a Pokémon. Lowers Speed when Trick Room takes effect.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 100,
  },

  :UTILITYUMBRELLA => {
    :ID => 911,
    :name => "Utility Umbrella",
    :desc => "This sturdy umbrella protects the holder from the effects of rain and harsh sunlight.",
    :price => 2000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 60,
  },

  :EXPCANDYXS => {
    :ID => 912,
    :name => "Infinite Exp. Candy",
    :desc => "A candy that is packed with energy. Brings a pokemon to the level cap when used..",
    :price => 0,
    :medicine => {},
    :noUseInBattle => true,
    :levelup => true,
  },

  :EXPCANDYS => {
    :ID => 913,
    :name => "Exp. Candy S",
    :plural => "Exp. Candies S",
    :desc => "A candy that is packed with energy. When consumed, it will grant a Pokémon a small amount of Exp. Points.",
    :price => 100,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :levelup => true,
  },

  :EXPCANDYM => {
    :ID => 914,
    :name => "Exp. Candy M",
    :plural => "Exp. Candies M",
    :desc => "A candy that is packed with energy. When consumed, it will grant a Pokémon a moderate amount of Exp. Points.",
    :price => 100,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :levelup => true,
  },

  :EXPCANDYL => {
    :ID => 915,
    :name => "Exp. Candy L",
    :plural => "Exp. Candies L",
    :desc => "A candy that is packed with energy. When consumed, it will grant a Pokémon a large amount of Exp. Points.",
    :price => 100,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :levelup => true,
  },

  :EXPCANDYXL => {
    :ID => 916,
    :name => "Exp. Candy XL",
    :plural => "Exp. Candies XL",
    :desc => "A candy that is packed with energy. When consumed, it will grant a Pokémon a very large amount of Exp. Points.",
    :price => 100,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :levelup => true,
  },

  :ADAMANTMINT => {
    :ID => 917,
    :name => "Adamant Mint",
    :unit => "sprig of Adamant Mint",
    :desc => "When a Pokémon smells this mint, its Attack will grow more easily, but its Sp. Atk will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :ADAMANT,
  },

  :LONELYMINT => {
    :ID => 918,
    :name => "Lonely Mint",
    :unit => "sprig of Lonely Mint",
    :desc => "When a Pokémon smells this mint, its Attack will grow more easily, but its Defense will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :LONELY,
  },

  :NAUGHTYMINT => {
    :ID => 919,
    :name => "Naughty Mint",
    :unit => "sprig of Naughty Mint",
    :desc => "When a Pokémon smells this mint, its Attack will grow more easily, but its Sp. Def will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :NAUGHTY,
  },

  :BRAVEMINT => {
    :ID => 920,
    :name => "Brave Mint",
    :unit => "sprig of Brave Mint",
    :desc => "When a Pokémon smells this mint, its Attack will grow more easily, but its Speed will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :BRAVE,
  },

  :BOLDMINT => {
    :ID => 921,
    :name => "Bold Mint",
    :unit => "sprig of Bold Mint",
    :desc => "When a Pokémon smells this mint, its Defense will grow more easily, but its Attack will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :BOLD,
  },

  :IMPISHMINT => {
    :ID => 922,
    :name => "Impish Mint",
    :unit => "sprig of Impish Mint",
    :desc => "When a Pokémon smells this mint, its Defense will grow more easily, but its Sp. Att will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :IMPISH,
  },

  :LAXMINT => {
    :ID => 923,
    :name => "Lax Mint",
    :unit => "sprig of Lax Mint",
    :desc => "When a Pokémon smells this mint, its Defense will grow more easily, but its Sp. Def will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :LAX,
  },

  :RELAXEDMINT => {
    :ID => 924,
    :name => "Relaxed Mint",
    :unit => "sprig of Relaxed Mint",
    :desc => "When a Pokémon smells this mint, its Defense will grow more easily, but its Speed will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :RELAXED,
  },

  :MODESTMINT => {
    :ID => 925,
    :name => "Modest Mint",
    :unit => "sprig of Modest Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Attack will grow more easily, but its Attack will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :MODEST,
  },

  :MILDMINT => {
    :ID => 926,
    :name => "Mild Mint",
    :unit => "sprig of Mild Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Attack will grow more easily, but its Defense will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :MILD,
  },

  :RASHMINT => {
    :ID => 927,
    :name => "Rash Mint",
    :unit => "sprig of Rash Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Attack will grow more easily, but its Sp. Def will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :RASH,
  },

  :QUIETMINT => {
    :ID => 928,
    :name => "Quiet Mint",
    :unit => "sprig of Quiet Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Attack will grow more easily, but its Speed will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :QUIET,
  },

  :CALMMINT => {
    :ID => 929,
    :name => "Calm Mint",
    :unit => "sprig of Calm Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Def will grow more easily, but its Attack will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :CALM,
  },

  :GENTLEMINT => {
    :ID => 930,
    :name => "Gentle Mint",
    :unit => "sprig of Gentle Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Def will grow more easily, but its Defense will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :GENTLE,
  },

  :CAREFULMINT => {
    :ID => 931,
    :name => "Careful Mint",
    :unit => "sprig of Careful Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Def will grow more easily, but its Sp. Attack will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :CAREFUL,
  },

  :SASSYMINT => {
    :ID => 932,
    :name => "Sassy Mint",
    :unit => "sprig of Sassy Mint",
    :desc => "When a Pokémon smells this mint, its Sp. Def will grow more easily, but its Speed will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :SASSY,
  },

  :TIMIDMINT => {
    :ID => 933,
    :name => "Timid Mint",
    :unit => "sprig of Timid Mint",
    :desc => "When a Pokémon smells this mint, its Speed will grow more easily, but its Attack will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :TIMID,
  },

  :HASTYMINT => {
    :ID => 934,
    :name => "Hasty Mint",
    :unit => "sprig of Hasty Mint",
    :desc => "When a Pokémon smells this mint, its Speed will grow more easily, but its Defense will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :HASTY,
  },

  :JOLLYMINT => {
    :ID => 935,
    :name => "Jolly Mint",
    :unit => "sprig of Jolly Mint",
    :desc => "When a Pokémon smells this mint, its Speed will grow more easily, but its Sp. Att will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :JOLLY,
  },

  :NAIVEMINT => {
    :ID => 936,
    :name => "Naive Mint",
    :unit => "sprig of Naive Mint",
    :desc => "When a Pokémon smells this mint, its Speed will grow more easily, but its Sp. Def will grow more slowly.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :NAIVE,
  },

  :SERIOUSMINT => {
    :ID => 937,
    :name => "Serious Mint",
    :unit => "sprig of Serious Mint",
    :desc => "When a Pokémon smells this mint, all of its stats will grow at an equal rate.",
    :price => 10,
    :medicine => {},
    :noUseInBattle => true,
    :mint => :SERIOUS,
  },

  :RIFTFRAGMENT => {
    :ID => 938,
    :name => "Rift Fragment",
    :desc => "Throw one into a Pokémon Den to attract a wild Rift Pokémon.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :justsell => true,
  },

  :CATCHINGCHARM => {
    :ID => 939,
    :name => "Catching Charm",
    :desc => "Holding it is said to increase the chance of getting a critical capture. Curiously, the charm doesn't shake much.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :important => true,
  },

  :DUNGEONKEY => {
    :ID => 940,
    :name => "Dungeon Key",
    :desc => "A key to open doors in various dungeons",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :DREAMBALL => {
    :ID => 941,
    :name => "Dream Ball",
    :desc => "A somewhat different Poké Ball that works especially well on sleeping Pokémon.",
    :price => 200,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :PECHABERRY2 => {
    :ID => 942,
    :name => "Pecha Berry?",
    :plural => "Pecha Berries?",
    :desc => "A special 'Pecha Berry' given to you by the employee at The Berry Emporium.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :ROTOMPHONE => {
    :ID => 943,
    :name => "Rotom Phone",
    :desc => "A smartphone that was enhanced with a Rotom!",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :niche => true,
  },

  :CONCERTTCK => {
    :ID => 944,
    :name => "Concert Tickets",
    :desc => "Tickets to Amber's concert! These are VIP too!",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :AMBERSLET => {
    :ID => 945,
    :name => "Amber's Letter",
    :desc => "A handwritten letter by Amber. Only you can read this, but Amber doesn't want you to just yet.",
    :noArticle => true,
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :TM115 => {
    :ID => 946,
    :name => "TM115",
    :price => 35000,
    :tm => :MEGAPUNCH,
    :noUseInBattle => true,
  },

  :TM116 => {
    :ID => 947,
    :name => "TM116",
    :price => 75000,
    :tm => :MEGAKICK,
    :noUseInBattle => true,
  },

  :TM117 => {
    :ID => 948,
    :name => "TM117",
    :price => 30000,
    :tm => :PAYDAY,
    :noUseInBattle => true,
  },

  :TM118 => {
    :ID => 949,
    :name => "TM118",
    :price => 25000,
    :tm => :PINMISSILE,
    :noUseInBattle => true,
  },

  :TM119 => {
    :ID => 950,
    :name => "TM119",
    :price => 20000,
    :tm => :MAGICALLEAF,
    :noUseInBattle => true,
  },

  :TM120 => {
    :ID => 951,
    :name => "TM120",
    :price => 45000,
    :tm => :SOLARBLADE,
    :noUseInBattle => true,
  },

  :TM121 => {
    :ID => 952,
    :name => "TM121",
    :price => 20000,
    :tm => :FIRESPIN,
    :noUseInBattle => true,
  },

  :TM122 => {
    :ID => 953,
    :name => "TM122",
    :price => 15000,
    :tm => :SCREECH,
    :noUseInBattle => true,
  },

  :TM123 => {
    :ID => 954,
    :name => "TM123",
    :price => 50000,
    :tm => :SELFDESTRUCT,
    :noUseInBattle => true,
  },

  :TM124 => {
    :ID => 955,
    :name => "TM124",
    :price => 15000,
    :tm => :SCARYFACE,
    :noUseInBattle => true,
  },

  :TM125 => {
    :ID => 956,
    :name => "TM125",
    :price => 15000,
    :tm => :CHARM,
    :noUseInBattle => true,
  },

  :TM126 => {
    :ID => 957,
    :name => "TM126",
    :price => 20000,
    :tm => :WHIRLPOOL,
    :noUseInBattle => true,
  },

  :TM127 => {
    :ID => 958,
    :name => "TM127",
    :price => 15000,
    :tm => :BEATUP,
    :noUseInBattle => true,
  },

  :TM128 => {
    :ID => 959,
    :name => "TM128",
    :price => 20000,
    :tm => :WEATHERBALL,
    :noUseInBattle => true,
  },

  :TM129 => {
    :ID => 960,
    :name => "TM129",
    :price => 15000,
    :tm => :FAKETEARS,
    :noUseInBattle => true,
  },

  :TM130 => {
    :ID => 961,
    :name => "TM130",
    :price => 20000,
    :tm => :SANDTOMB,
    :noUseInBattle => true,
  },

  :TM131 => {
    :ID => 962,
    :name => "TM131",
    :price => 30000,
    :tm => :BULLETSEED,
    :noUseInBattle => true,
  },

  :TM132 => {
    :ID => 963,
    :name => "TM132",
    :price => 30000,
    :tm => :ICICLESPEAR,
    :noUseInBattle => true,
  },

  :TM133 => {
    :ID => 964,
    :name => "TM133",
    :price => 20000,
    :tm => :MUDSHOT,
    :noUseInBattle => true,
  },

  :TM134 => {
    :ID => 965,
    :name => "TM134",
    :price => 30000,
    :tm => :ROCKBLAST,
    :noUseInBattle => true,
  },

  :TM135 => {
    :ID => 966,
    :name => "TM135",
    :price => 25000,
    :tm => :BRINE,
    :noUseInBattle => true,
  },

  :TM136 => {
    :ID => 967,
    :name => "TM136",
    :price => 20000,
    :tm => :ASSURANCE,
    :noUseInBattle => true,
  },

  :TM137 => {
    :ID => 968,
    :name => "TM137",
    :price => 10000,
    :tm => :POWERSWAP,
    :noUseInBattle => true,
  },

  :TM138 => {
    :ID => 969,
    :name => "TM138",
    :price => 10000,
    :tm => :GUARDSWAP,
    :noUseInBattle => true,
  },

  :TM139 => {
    :ID => 970,
    :name => "TM139",
    :price => 10000,
    :tm => :SPEEDSWAP,
    :noUseInBattle => true,
  },

  :TM140 => {
    :ID => 971,
    :name => "TM140",
    :price => 10000,
    :tm => :ICEFANG,
    :noUseInBattle => true,
  },

  :TM141 => {
    :ID => 972,
    :name => "TM141",
    :price => 10000,
    :tm => :FIREFANG,
    :noUseInBattle => true,
  },

  :TM142 => {
    :ID => 973,
    :name => "TM142",
    :price => 10000,
    :tm => :THUNDERFANG,
    :noUseInBattle => true,
  },

  :TM143 => {
    :ID => 974,
    :name => "TM143",
    :price => 25000,
    :tm => :PSYCHOCUT,
    :noUseInBattle => true,
  },

  :TM144 => {
    :ID => 975,
    :name => "TM144",
    :price => 25000,
    :tm => :CROSSPOISON,
    :noUseInBattle => true,
  },

  :TM145 => {
    :ID => 976,
    :name => "TM145",
    :price => 25000,
    :tm => :HEX,
    :noUseInBattle => true,
  },

  :TM146 => {
    :ID => 977,
    :name => "TM146",
    :price => 25000,
    :tm => :RAZORSHELL,
    :noUseInBattle => true,
  },

  :TM147 => {
    :ID => 978,
    :name => "TM147",
    :price => 30000,
    :tm => :TAILSLAP,
    :noUseInBattle => true,
  },

  :TM148 => {
    :ID => 979,
    :name => "TM148",
    :price => 35000,
    :tm => :PHANTOMFORCE,
    :noUseInBattle => true,
  },

  :TM149 => {
    :ID => 980,
    :name => "TM149",
    :price => 30000,
    :tm => :DRAININGKISS,
    :noUseInBattle => true,
  },

  :TM150 => {
    :ID => 981,
    :name => "TM150",
    :price => 10000,
    :tm => :GRASSYTERRAIN,
    :noUseInBattle => true,
  },

  :TM151 => {
    :ID => 982,
    :name => "TM151",
    :price => 10000,
    :tm => :ELECTRICTERRAIN,
    :noUseInBattle => true,
  },

  :TM152 => {
    :ID => 983,
    :name => "TM152",
    :price => 10000,
    :tm => :MISTYTERRAIN,
    :noUseInBattle => true,
  },

  :TM153 => {
    :ID => 984,
    :name => "TM153",
    :price => 10000,
    :tm => :PSYCHICTERRAIN,
    :noUseInBattle => true,
  },

  :TM154 => {
    :ID => 985,
    :name => "TM154",
    :price => 5000,
    :tm => :MYSTICALFIRE,
    :noUseInBattle => true,
  },

  :TM155 => {
    :ID => 986,
    :name => "TM155",
    :price => 15000,
    :tm => :EERIEIMPULSE,
    :noUseInBattle => true,
  },

  :TM156 => {
    :ID => 987,
    :name => "TM156",
    :price => 30000,
    :tm => :AIRSLASH,
    :noUseInBattle => true,
  },

  :TM157 => {
    :ID => 988,
    :name => "TM157",
    :price => 25000,
    :tm => :BREAKINGSWIPE,
    :noUseInBattle => true,
  },

  :CHARIZARDITEG => {
    :ID => 989,
    :name => "Charizardite G",
    :desc => "One variety of Mega Stone. Have Charizard hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BUTTERFREENITE => {
    :ID => 990,
    :name => "Butterfreenite",
    :desc => "One variety of Mega Stone. Have Butterfree hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PIKACHUTITE => {
    :ID => 991,
    :name => "Pikachutite",
    :desc => "One variety of Mega Stone. Have Pikachu hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEOWTHITE => {
    :ID => 992,
    :name => "Meowthite",
    :desc => "One variety of Mega Stone. Have Meowth hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MACHAMPITE => {
    :ID => 993,
    :name => "Machampite",
    :desc => "One variety of Mega Stone. Have Machamp hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GENGARITEG => {
    :ID => 994,
    :name => "Gengarite G",
    :desc => "One variety of Mega Stone. Have Gengar hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :KINGLERITE => {
    :ID => 995,
    :name => "Kinglerite",
    :desc => "One variety of Mega Stone. Have Kingler hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LAPRASITE => {
    :ID => 996,
    :name => "Laprasite",
    :desc => "One variety of Mega Stone. Have Lapras hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :EEVEETITE => {
    :ID => 997,
    :name => "Eeveetite",
    :desc => "One variety of Mega Stone. Have Eevee hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SNORLAXITE => {
    :ID => 998,
    :name => "Snorlaxite",
    :desc => "One variety of Mega Stone. Have Snorlax hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GARBODORNITE => {
    :ID => 999,
    :name => "Garbodornite",
    :desc => "One variety of Mega Stone. Have Garbodor hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MELMETALITE => {
    :ID => 1000,
    :name => "Melmetalite",
    :desc => "One variety of Mega Stone. Have Melmetal hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CORVIKNITE => {
    :ID => 1001,
    :name => "Corviknite",
    :desc => "One variety of Mega Stone. Have Corviknight hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ORBEETLENITE => {
    :ID => 1002,
    :name => "Orbeetlenite",
    :desc => "One variety of Mega Stone. Have Orbeetle hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DREDNAWTITE => {
    :ID => 1003,
    :name => "Drednawtite",
    :desc => "One variety of Mega Stone. Have Drednaw hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :COALOSSALITE => {
    :ID => 1004,
    :name => "Coalossalite",
    :desc => "One variety of Mega Stone. Have Coalossal hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FLAPPLETITE => {
    :ID => 1005,
    :name => "Flappletite",
    :desc => "One variety of Mega Stone. Have Flapple hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :APPLETUNITE => {
    :ID => 1006,
    :name => "Appletunite",
    :desc => "One variety of Mega Stone. Have Appletun hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SANDACONDITE => {
    :ID => 1007,
    :name => "Sandacondite",
    :desc => "One variety of Mega Stone. Have Sandaconda hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TOXTRICITITE => {
    :ID => 1008,
    :name => "Toxtricitite",
    :desc => "One variety of Mega Stone. Have Toxtricity hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CENTISKORCHITE => {
    :ID => 1009,
    :name => "Centiskorchite",
    :desc => "One variety of Mega Stone. Have Centiskorch hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HATTERENITE => {
    :ID => 1010,
    :name => "Hatterenite",
    :desc => "One variety of Mega Stone. Have Hatterene hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GRIMMSNARLITE => {
    :ID => 1011,
    :name => "Grimmsnarlite",
    :desc => "One variety of Mega Stone. Have Grimmsnarl hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ALCREMITE => {
    :ID => 1012,
    :name => "Alcremite",
    :desc => "One variety of Mega Stone. Have Alcremie hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :COPPERAJITE => {
    :ID => 1013,
    :name => "Copperajite",
    :desc => "One variety of Mega Stone. Have Copperajah hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DURALUDONITE => {
    :ID => 1014,
    :name => "Duraludonite",
    :desc => "One variety of Mega Stone. Have Duraludon hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :VENUSAURITEG => {
    :ID => 1015,
    :name => "Venusaurite G",
    :desc => "One variety of Mega Stone. Have Venusaur hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BLASTOISINITEG => {
    :ID => 1016,
    :name => "Blastoisinite G",
    :desc => "One variety of Mega Stone. Have Blastoise hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :RILLABOOMITE => {
    :ID => 1017,
    :name => "Rillaboomite",
    :desc => "One variety of Mega Stone. Have Rillaboom hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CINDERACITE => {
    :ID => 1018,
    :name => "Cinderacite",
    :desc => "One variety of Mega Stone. Have Cinderace hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :INTELEONITE => {
    :ID => 1019,
    :name => "Inteleonite",
    :desc => "One variety of Mega Stone. Have Inteleon hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PHANTOMCANDYS => {
    :ID => 1020,
    :name => "Phantom Candy S",
    :plural => "Phantom Candies S",
    :desc => "Candy that was made by The Puppet Master. It will level up your Pokémon a small amount.",
    :price => 0,
    :medicine => {},
    :noUseInBattle => true,
    :levelup => true,
  },

  :PHANTOMCANDYM => {
    :ID => 1021,
    :name => "Phantom Candy M",
    :plural => "Phantom Candies M",
    :desc => "Candy that was made by The Puppet Master. It will level up your Pokémon an average amount.",
    :price => 0,
    :medicine => {},
    :noUseInBattle => true,
    :levelup => true,
  },

  :MYSTBLACKBOX2 => {
    :ID => 1022,
    :name => "Mysterious Black Box",
    :plural => "Mysterious Black Boxes",
    :desc => "A mysterious black box. It does nothing.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :HPCARD => {
    :ID => 1023,
    :name => "HP Card",
    :desc => "A card that allows the owner to participate in the HP EV center service.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SPEEDCARD => {
    :ID => 1024,
    :name => "Speed Card",
    :desc => "A card that allows the owner to participate in the Speed EV center service.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :THIEVCREST => {
    :ID => 1025,
    :name => "Thievul Crest",
    :desc => "Decreases opponent's Sp. Atk by one stage, increasing Thievul's by one stage on switch.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PROBOCREST => {
    :ID => 1026,
    :name => "Probopass Crest",
    :desc => "Probopass levitates, and Mini-noses do 3-hit 20BP type-based damage after a damaging move.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DRUDDICREST => {
    :ID => 1027,
    :name => "Druddigon Crest",
    :desc => "Heals in the sun and from Fire-type moves. Fire- and Dragon-type moves get boosted by 30%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CINCCREST => {
    :ID => 1028,
    :name => "Cinccino Crest",
    :desc => "All single target moves turn into multi-hit moves (2-5 hits at 40% the BP).",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :NOCCREST => {
    :ID => 1029,
    :name => "Noctowl Crest",
    :desc => "Increases Special Defense upon being hit. Increases Defense by 30%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LUXCREST => {
    :ID => 1030,
    :name => "Luxray Crest",
    :desc => "Gains Dark-type STAB and resistances. Normal-type moves are Galvanized.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BOLTCREST => {
    :ID => 1031,
    :name => "Boltund Crest",
    :desc => "Gain a 1.5x boost to biting moves if Boltund moves before target.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :VESPICREST => {
    :ID => 1032,
    :name => "Vespiquen Crest",
    :desc => "Attack Order and Defend Order grant a 50% boost to Offenses or Defenses, switching around when the other is used.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PHIONECREST => {
    :ID => 1033,
    :name => "Phione Crest",
    :desc => "Phione is granted a 50% increase in defenses and Aqua Ring.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DELCREST => {
    :ID => 1034,
    :name => "Delcatty Crest",
    :desc => "The power of its non-KO'd friends increases Delcatty's stats by 10% each.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SWACREST => {
    :ID => 1035,
    :name => "Swalot Crest",
    :desc => "Stockpiles gained after an attack. Belch always usable and followed by Spit Up.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :INTERCEPTZ => {
    :ID => 1036,
    :name => "Interceptium Z",
    :unit => "piece of Interceptium Z",
    :desc => "Unleash the power of the Interceptor with special Z-Moves and change fate!",
    :price => 0,
    :crystal => true,
    :zcrystal => true,
    :noUseInBattle => true,
  },

  :MASTERKEY => {
    :ID => 1037,
    :name => "Master Key",
    :desc => "A key to open boss doors in various dungeons.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :FAIRYGEM => {
    :ID => 1038,
    :name => "Fairy Gem",
    :desc => "A gem with a mystical essence. When held, it strengthens the power of a Fairy-type move only once.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FAIRY,
    :gem => true,
  },

  :SAMUCREST => {
    :ID => 1039,
    :name => "Samurott Crest",
    :desc => "Gains Fighting-type STAB and resistances. Slicing moves always result in critical hit.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SKYRELIC => {
    :ID => 1040,
    :name => "Sky Relic",
    :desc => "A Relic that is imbued with the power of the sky.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :XENWASTE => {
    :ID => 1041,
    :name => "Xen Waste",
    :plural => "Xen Waste",
    :desc => "Industrial waste created during Team Xen's experiments. It seems to cause Pokémon to mutate...",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
  },

  :NIGHTMAREFUEL => {
    :ID => 1042,
    :name => "Nightmare Fuel",
    :plural => "Nightmare Fuel",
    :desc => "Excess waste from the Ligosomnia Engine. It seems to cause Pokémon to mutate...",
    :price => 0,
    :evoitem => true,
    :noUseInBattle => true,
  },

  :INTERCEPTORWISH => {
    :ID => 1043,
    :name => "Interceptor's Wish",
    :plural => "Interceptor's Wishes",
    :desc => "An item that allows the Interceptor to scatter their strength to aid others.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :INTERCEPTZ2 => {
    :ID => 1044,
    :name => "Interceptium Z (old)",
    :unit => "piece of Interceptium Z (old)",
    :desc => "It converts Z-Power into crystals that allow one to intercept fate!",
    :price => 0,
    :crystal => true,
    :zcrystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :STATSWAPPER => {
    :ID => 1045,
    :name => "Stat Swapper",
    :desc => "Swaps the effort values between two selected stats.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :evup => true,
  },

  :BLKPRISM => {
    :ID => 1046,
    :name => "Black Prism",
    :desc => "A weird prism filled with strange power. Touching it gives a tingling sensation.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :GALARICACUFF => {
    :ID => 1047,
    :name => "Galarica Cuff",
    :desc => "A cuff made from woven-together Galarica Twigs. Giving it to Galarian Slowpoke makes the Pokémon very happy.",
    :price => 6000,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :GALARICAWREATH => {
    :ID => 1048,
    :name => "Galarica Wreath",
    :desc => "A wreath made from woven-together Galarica Twigs. Crowning a Galarian Slowpoke with it makes them very happy.",
    :price => 6000,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :REINSOFUNITY => {
    :ID => 1049,
    :name => "Reins of Unity",
    :unit => "set of Reins of Unity",
    :desc => "Reins that people presented to the king. They enhance Calyrex's power and unite it with its beloved steed.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :BELLMCHN => {
    :ID => 1050,
    :name => "Bell Clapper",
    :desc => "The piece of the bell that causes that beautiful ringing sound.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :TRAINPASS => {
    :ID => 1051,
    :name => "Train Pass",
    :plural => "Train Passes",
    :desc => "A pass that allows for cheaper travel on trains in Grand Dream City.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :important => true,
  },

  :JYNNOBIKEY => {
    :ID => 1052,
    :name => "Lighthouse Key-J",
    :plural => "Lighthouse Keys-J",
    :desc => "A key that opens up the lighthouse located in Jynnobi Pass.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :GLITTERBALL => {
    :ID => 1053,
    :name => "Glitter Ball",
    :desc => "A special Poké Ball that excels at catching shiny Pokémon, or turns a Pokémon shiny on catch.",
    :price => 9000,
    :ball => true,
    :noUse => true,
    :flingdamage => 30,
  },

  :REDORB => {
    :ID => 1054,
    :name => "Red Orb",
    :desc => "A shiny red orb that is said to have a legend tied to it. It's known to have a deep connection with the Hoenn Region.",
    :price => 10000,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BLUEORB => {
    :ID => 1055,
    :name => "Blue Orb",
    :desc => "A shiny blue orb that is said to have a legend tied to it. It's known to have a deep connection with the Hoenn Region.",
    :price => 10000,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MAGNETICLURE => {
    :ID => 1056,
    :name => "Magnetic Lure",
    :desc => "An item to be held. One polarity draws in uncaught species, while the other pushes them away for quick escape.",
    :price => 5000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 30,
  },

  :HPRESETBAG => {
    :ID => 1057,
    :name => "Reset Disc- HP",
    :plural => "Reset Discs- HP",
    :desc => "A reusable special program that causes the Pokémon to forget its training in the HP stat.",
    :price => 10000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :ATKRESETBAG => {
    :ID => 1058,
    :name => "Reset Disc- ATK",
    :plural => "Reset Discs- ATK",
    :desc => "A reusable special program that causes the Pokémon to forget its training in the Attack stat.",
    :price => 10000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :DEFRESETBAG => {
    :ID => 1059,
    :name => "Reset Disc- DEF",
    :plural => "Reset Discs- DEF",
    :desc => "A reusable special program that causes the Pokémon to forget its training in the Defense stat.",
    :price => 10000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :SPARESETBAG => {
    :ID => 1060,
    :name => "Reset Disc- SPATK",
    :plural => "Reset Discs- SPATK",
    :desc => "A reusable special program that causes the Pokémon to forget its training in the Sp. Atk stat.",
    :price => 10000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :SPDRESETBAG => {
    :ID => 1061,
    :name => "Reset Disc- SPDEF",
    :plural => "Reset Discs- SPDEF",
    :desc => "A reusable special program that causes the Pokémon to forget its training in the Sp. Def stat.",
    :price => 10000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :SPERESETBAG => {
    :ID => 1062,
    :name => "Reset Disc- SPEED",
    :plural => "Reset Discs- SPEED",
    :desc => "A reusable special program that causes the Pokémon to forget its training in the Speed stat.",
    :price => 10000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :FULLRESETBAG => {
    :ID => 1063,
    :name => "Reset Disc- ALL",
    :plural => "Reset Discs- ALL",
    :desc => "A reusable special program that causes the Pokémon to forget its training in all stats.",
    :price => 50000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :EVBOOSTER => {
    :ID => 1064,
    :name => "EV Booster",
    :desc => "A super vitamin shot that immediately charges one stat with 252 EVs. Still in clinical trials.",
    :price => 9800,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :PPALL => {
    :ID => 1065,
    :name => "PP All",
    :unit => "bottle of PP All",
    :desc => "A medicine that can optimally raise the maximum PP of all moves known by the target Pokémon.",
    :price => 14700,
    :medicine => {},
    :noUseInBattle => true,
    :flingdamage => 30,
    :evup => true,
  },

  :EVTUNER => {
    :ID => 1066,
    :name => "EV Tuner",
    :desc => "A single-use device that switches a Pokémon's EV totals between two stats.",
    :price => 10000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :PRISONBOTTLE => {
    :ID => 1067,
    :name => "Prison Bottle",
    :desc => "A bottle believed to have been used to seal away the power of a certain Pokémon long, long ago.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :PEATBLOCK => {
    :ID => 1068,
    :name => "Peat Block",
    :desc => "A block of muddy material that can be used as fuel for burning when it is dried. It's loved by a certain Pokémon.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 0,
  },

  :BLACKAUGURITE => {
    :ID => 1069,
    :name => "Black Augurite",
    :unit => "piece of Black Augurite",
    :desc => "A glassy black stone that produces a sharp cutting edge when split. It's loved by a certain Pokémon.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 0,
  },

  :PUPPETCOIN => {
    :ID => 1070,
    :name => "Puppet Doubloon",
    :desc => "A coin with the Puppet Master's face on it. Its use is unknown.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :legendary => true,
  },

  :STABILIZER => {
    :ID => 1071,
    :name => "Stabilizer",
    :desc => "A device that can stabilize a various amount of elements.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :BLKAPRICORN => {
    :ID => 1072,
    :name => "Black Apricorn",
    :desc => "A black Apricorn. It has a scent beyond one's experience.",
    :price => 200,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOOCIBAG => {
    :ID => 1073,
    :name => "Goocci Bag",
    :desc => "Karrina's bag. Only a memory now.",
    :price => 200,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :ROBOCLOAK => {
    :ID => 1074,
    :name => "Robo Ren's Cloak",
    :desc => "A piece of Robo Ren's Sashilan Cloak.",
    :noArticle => true,
    :price => 200,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :CRACKEDPEARL => {
    :ID => 1075,
    :name => "Pearl Core",
    :desc => "Spacea's Orb. Only a memory now.",
    :price => 200,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :CRACKEDDIAMOND => {
    :ID => 1076,
    :name => "Diamond Core",
    :desc => "Tiempa's Diamond. Only a memory now.",
    :price => 200,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :REDGEM => {
    :ID => 1077,
    :name => "Red Gem",
    :desc => "A mysterious red gem.",
    :price => 200,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :REUNICREST => {
    :ID => 1078,
    :name => "Reuniclus Crest",
    :desc => "Move changes user to a Physical Fighting or Special Psychic. First move determines initial form. SpATK -> 1.25x.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ANCIENTTEACH => {
    :ID => 1079,
    :name => "Ancient Teachings",
    :unit => "tome of Ancient Teachings",
    :desc => "An ancient book that has specific teachings about swordsmanship, archery, and necromancy.",
    :price => 2100,
    :noUseInBattle => true,
    :sidequest => true,
  },

  :ELECCREST => {
    :ID => 1080,
    :name => "Electrode Crest",
    :desc => "The target's Defense stat is halved when Electrode is attacking. Non-Speed stats are also boosted by 10% of Speed.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CRABCREST => {
    :ID => 1081,
    :name => "Crabom. Crest",
    :desc => "Powers up moves by 50% if holder takes damage before using them. Defense and Sp. Def are also boosted by 25%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SEARCREST => {
    :ID => 1082,
    :name => "Simisear Crest",
    :desc => "Gains Water-type STAB and resistances. Normal-type moves become Water-type. Attack and Sp. Atk are boosted by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :POURCREST => {
    :ID => 1083,
    :name => "Simipour Crest",
    :desc => "Gains Grass-type STAB and resistances. Normal-type moves become Grass-type. Attack and Sp. Atk are boosted by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SAGECREST => {
    :ID => 1084,
    :name => "Simisage Crest",
    :desc => "Gains Fire-type STAB and resistances. Normal-type moves become Fire-type. Attack and Sp. Atk are boosted by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SAWSCREST => {
    :ID => 1085,
    :name => "Sawsbuck Crest",
    :desc => "Replace's Normal-type with a Seasonal type. Normal-type moves become the Seasonal type and are boosted by 20%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SHIINCREST => {
    :ID => 1086,
    :name => "Shiinotic Crest",
    :desc => "Drains 1/16th of Max HP from statused Pokémon at end of turn. Draining effects and Sp. Def are boosted by 30%. Applies Spotlight on partner on entry.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :AEAMPHCREST => {
    :ID => 1087,
    :name => "A. Ampharos Crest",
    :desc => "Move in first moveslot is boosted by 50%, 20% if STAB. Take 30% less damage from Super Effective moves.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LUVCREST => {
    :ID => 1088,
    :name => "Luvdisc Crest",
    :desc => "The Base Power of all damaging moves matches Luvdisc's happiness, capping at a Base Power of 250.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GIFTCARD => {
    :ID => 1089,
    :name => "Thank-You Card",
    :desc => "A signed card gifted by the PokeStar Studio crew as thanks for your help with the Xenogene movie.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :HDISK => {
    :ID => 1089,
    :name => "H-Disk",
    :desc => "A disk that can be used to activate the lift at The Underground.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :URSHIFITE => {
    :ID => 1090,
    :name => "Urshifite",
    :desc => "One variety of Mega Stone. Have Urshifu hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ZOROCREST => {
    :ID => 1091,
    :name => "Zoroark Crest",
    :desc => "Grants the ability of the copied Pokémon to Zoroark. Additionally gives it STAB on that Pokémon's typing.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CELLIMPRINT => {
    :ID => 1092,
    :name => "Cell Imprint",
    :desc => "Extracted data from a mysterious cell. Using it can increase a Pokémon's natural potential.",
    :price => 20000,
    :medicine => {},
    :noUseInBattle => true,
    :evup => true,
  },

  :LUMINOUSMOSS => {
    :ID => 1093,
    :name => "Luminous Moss",
    :unit => "clump of Luminous Moss",
    :desc => "It boosts Sp. Def if hit with a Water-type attack. It can only be used once.",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :UNOWNCREST => {
    :ID => 1094,
    :name => "Unown Crest",
    :desc => "Filler text.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GLITCHMEMORY => {
    :ID => 1095,
    :name => "??? Memory",
    :desc => "A memory disc that contains ???-type data. It changes the type of the holder if held by a certain Pokémon.",
    :price => 1000,
    :noUseInBattle => true,
    :noUse => true,
    :memory => :QMARKS,
  },

  :GOLDENLANTERN => {
    :ID => 1096,
    :name => "Golden Lantern",
    :desc => "A golden item that allows for the use of Flash without the use of TMs.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
  },

  :REMOTEPC => {
    :ID => 1097,
    :name => "Remote PC",
    :desc => "Allows remote connection to the storage system.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :PINKPETAL => {
    :ID => 1098,
    :name => "Pink Petal",
    :desc => "A petal cultivated from GDC's Botanical Garden. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :GREENPETAL => {
    :ID => 1099,
    :name => "Green Petal",
    :desc => "A petal cultivated from GDC's Botanical Garden. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :ORANGEPETAL => {
    :ID => 1100,
    :name => "Orange Petal",
    :desc => "A petal cultivated from GDC's Botanical Garden. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :BLUEPETAL => {
    :ID => 1101,
    :name => "Blue Petal",
    :desc => "A petal cultivated from GDC's Botanical Garden. It changes the form of certain species of Pokémon.",
    :price => 3000,
    :noUseInBattle => true,
    :nectar => true,
  },

  :MIRRORLURE => {
    :ID => 1102,
    :name => "Mirror Lure",
    :desc => "An item to be held. One polarity draws in identical species to the holder, while the other allows for quick escape.",
    :price => 5000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
  },

  :PUZZLEBOX => {
    :ID => 1103,
    :name => "Puzzle Box",
    :plural => "Puzzle Boxes",
    :desc => "A dusty puzzle box found in Flora's room. It seems to have been manufactured by the Weather Institute.",
    :price => 5000,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :PUMPKIN => {
    :ID => 1104,
    :name => "Pumpkin",
    :desc => "A nicely sized pumpkin wrassled from an angry Gourgeist.",
    :price => 5000,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :TALONSGLOVE => {
    :ID => 1076,
    :name => "Talon's Glove",
    :desc => "Talon's Glove. A symbol of his insecurity. Only a memory now.",
    :noArticle => true,
    :price => 200,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :FLORINSID => {
    :ID => 1076,
    :name => "Florin's ID",
    :desc => "Florin's Gov. ID. Only a memory now.",
    :noArticle => true,
    :price => 200,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :FURRCREST => {
    :ID => 1105,
    :name => "Furret Crest",
    :desc => "Upon switching in, Furret loses 25% of its Max HP to create a substitute.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :XENIDCARD => {
    :name => "Grunt ID Card",
    :desc => "A card key that belongs to Xen Grunt Wilbur... Sorry, Wilbur.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :GOLDENAPPLE => {
    :name => "Golden Apple",
    :desc => "A lustrous Golden Apple. It reminds you of an old children's fairy tale...",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :pokehold => true,
    :sidequest => true,
  },

  :XENEMBLEM => {
    :name => "Xen Emblem",
    :desc => "A pin that has the logo of Team Xen on it.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :XENTRAMKEY => {
    :name => "Xen-Tram Key",
    :desc => "A key used to activate the train owned by Team Xen at the GDC Station.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :keys => true,
  },

  :SHIPPART => {
    :name => "Ship Part",
    :desc => "A heavy mechanical part that seems to be part of some generator?",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :POLICEKEY => {
    :name => "Police Department Key",
    :desc => "A key for the backdoor to the Police Department. Can't reach it, though...",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :POLICEKEYRING => {
    :name => "Police Master Key",
    :desc => "The master key for the backdoor in the Police Department. Can't reach it, though...",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HOTELKEY => {
    :name => "Oblitus Hotel Key",
    :desc => "A key for your room at the Oblitus Hotel. No one can reach your room without it.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ORIGINESSENCEZYG => {
    :name => "Origin Essence (Cell)",
    :unit => "core of Origin Essence (Cell)",
    :desc => "A core of Zygarde's Origin Essence. You can feel its pulse just by being near it. What will become of it...? ",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CACHEKEY => {
    :name => "Cache Key",
    :desc => "A key used to open cache chests. ",
    :price => 500,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MAGICMOOMILK => {
    :name => "Magic Moo Milk",
    :unit => "bottle of Magic Moo Milk",
    :desc => "Extremly nutritious milk. It restores the HP of one Pokémon by 130 points and restores 10 PP to a selected move.",
    :price => 1500,
    :medicine => {
      :hp => 130,
    },
    :healing => true,
    :pprestore => true,
  },

  :JEWELOFLIFE => {
    :name => "Jewel of Life",
    :plural => "Jewels of Life",
    :desc => "A rare green jewel said to hold the power of life inside of its core. It seems to have been a piece of a bigger deposit.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DEAGANSLETT => {
    :name => "Letter for Deagan",
    :plural => "Letters for Deagan",
    :desc => "Amber's letter repurposed for Deagan. It's all written in your handwriting. These are Amber's final words.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PERCIVALID => {
    :name => "Percival's ID",
    :desc => "An ID that belonged to a supposed Xen Admin named Percival.",
    :noArticle => true,
    :price => 7500,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :THINMINTS => {
    :name => "Thin-Mints",
    :unit => "pack of Thin-Mints",
    :desc => "A minty fresh candy. Heals for 50 points.",
    :price => 850,
    :medicine => {
      :hp => 50,
    },
    :flingdamage => 50,
    :healing => true,
  },

  :CHARGEDSTONE => {
    :name => "Charged Stone",
    :desc => "Partially Heals the entire party during a gauntlet. 1 charge per crystal.",
    :price => 0,
    :medicine => {},
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHARGEDCRYSTAL => {
    :name => "Charged Crystal",
    :desc => "Fully restores the entire party during a gauntlet. 1 charge per crystal and only one can be used per gauntlet.",
    :price => 0,
    :medicine => {},
    :noUseInBattle => true,
    :noUse => true,
  },

  :HQELEVATORKEY => {
    :name => "Elevator Pass",
    :plural => "Elevator Passes",
    :desc => "A pass that activates the elevators in the Xen HQ.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HQDATACHIP => {
    :name => "HQ Data Chip",
    :desc => "A chip that has internal data found in the Xen HQ.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DAMIENSCARF => {
    :name => "Damien's Scarf",
    :plural => "Damien's Scarves",
    :desc => "Damien's red scarf. It was given to him by his father, Chief Zalos. Now ours.",
    :noArticle => true,
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SCROLLOFWATERS => {
    :name => "Scroll of Waters",
    :plural => "Scrolls of Waters",
    :desc => "A scroll that makes certain Pokémon evolve. Written upon it are the true secrets of the path of water.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :SCROLLOFDARKNESS => {
    :name => "Scroll of Darkness",
    :plural => "Scrolls of Darkness",
    :desc => "A scroll that makes certain Pokémon evolve. Written upon it are the true secrets of the path of darkness.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :AUSPICIOUSARMOR => {
    :name => "Auspicious Armor",
    :unit => "set of Auspicious Armor",
    :desc => "A peculiar set of armor that can make a certain Pokémon evolve. Auspicious wishes live within it.",
    :price => 1500,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :MALICIOUSARMOR => {
    :name => "Malicious Armor",
    :unit => "set of Malicious Armor",
    :desc => "A peculiar set of armor that can make a certain Pokémon evolve. Malicious will lurks within it.",
    :price => 1500,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :LEADERSCREST => {
    :name => "Leader's Crest",
    :desc => "A shard of what appears to be an old blade of some sort. It is held only by a head of certain Pokémon groups.",
    :price => 1500,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 30,
    :justsell => true,
  },

  :BOOSTERENERGY => {
    :name => "Booster Energy",
    :unit => "capsule of Booster Energy",
    :desc => "An item to be held by Pokémon with certain Abilities. The energy that fills this capsule boosts their strength.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :ABILITYSHIELD => {
    :name => "Ability Shield",
    :desc => "This cute and rather unique-looking shield protects the holder from having its Ability changed by others.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :CLEARAMULET => {
    :name => "Clear Amulet",
    :desc => "This clear, sparkling amulet protects the holder from having its stats lowered by other Pokémon.",
    :price => 15000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :MIRRORHERB => {
    :name => "Mirror Herb",
    :desc => "This herb will allow the holder to mirror an opponent's stat increases to boost its own stats—but only once.",
    :price => 15000,
    :noUseInBattle => true,
    :noUse => true,
    :consumehold => true,
    :flingdamage => 30,
  },

  :PUNCHINGGLOVE => {
    :name => "Punching Glove",
    :desc => "This protective glove boosts the power of the holder's punching moves and prevents direct contact with targets.",
    :price => 7500,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :COVERTCLOAK => {
    :name => "Covert Cloak",
    :desc => "This hooded cloak conceals the holder, tricking its enemies and protecting it from the additional effects of moves.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :LOADEDDICE => {
    :name => "Loaded Dice",
    :plural => "Loaded Dice",
    :desc => "This loaded dice always rolls a good number, and ensures that the holder's multistrike moves hit more times.",
    :price => 10000,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
    :flingdamage => 30,
  },

  :GIMMIGHOULCOIN => {
    :name => "Gimmighoul Coin",
    :desc => "Material accidentally dropped by a Pokémon. It seems that Gimmighoul treasure and hoard these.",
    :price => 400,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 10,
    :justsell => true,
  },

  :SYRUPYAPPLE => {
    :name => "Syrupy Apple",
    :desc => "A peculiar apple that can make a certain species of Pokémon evolve. It's exceptionally syrupy.",
    :price => 1100,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :UNREMARKABLETEACUP => {
    :name => "Unremarkable Teacup",
    :shortname => "Unremarkable Cup",
    :desc => "A peculiar cracked teacup that can make a certain species of Pokémon evolve. It makes delicious tea.",
    :price => 800,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 80,
  },

  :MASTERPIECETEACUP => {
    :name => "Masterpiece Teacup",
    :shortname => "Masterpiece Cup",
    :desc => "A peculiar chipped teacup that can make a certain species of Pokémon evolve. It makes delicious tea.",
    :price => 19000,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 80,
  },

  :ADAMANTCRYSTAL => {
    :name => "Adamant Crystal",
    :desc => "An item to be held by Dialga. This large, glowing gem wells with power and allows the Pokémon to change form.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :legendhold => true,
  },

  :LUSTROUSGLOBE => {
    :name => "Lustrous Globe",
    :desc => "An item to be held by Palkia. This large, glowing orb wells with power and allows the Pokémon to change form.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :legendhold => true,
  },

  :GRISEOUSCORE => {
    :name => "Griseous Core",
    :desc => "An item to be held by Giratina. This large, glowing gem wells with power and allows the Pokémon to change form.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :legendhold => true,
  },

  :TEALMASK => {
    :name => "Teal Mask",
    :desc => "A teal mask patterned after the face of an ogre.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :important => true,
  },

  :WELLSPRINGMASK => {
    :name => "Wellspring Mask",
    :desc => "A carved wooden mask to be held by Ogerpon. It allows Ogerpon to wield the Water type during battle.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 60,
    :legendhold => true,
  },

  :HEARTHFLAMEMASK => {
    :name => "Hearthflame Mask",
    :desc => "A carved wooden mask to be held by Ogerpon. It allows Ogerpon to wield the Fire type during battle.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 60,
    :legendhold => true,
  },

  :CORNERSTONEMASK => {
    :name => "Cornerstone Mask",
    :desc => "A carved wooden mask to be held by Ogerpon. It allows Ogerpon to wield the Rock type during battle.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :flingdamage => 60,
    :legendhold => true,
  },

  :METALALLOY => {
    :name => "Metal Alloy",
    :unit => "hunk of Metal Alloy",
    :desc => "A peculiar metal that can make certain species of Pokémon evolve. It is composed of many layers.",
    :price => 3000,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 0,
  },

  :TERAORB => {
    :name => "Tera Orb",
    :desc => "An orb with the power to crystallize. When it is charged with energy, it can be used to cause Pokémon to Terastallize.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :BLACKLANTERN => {
    :name => "Black Lantern",
    :desc => "A lantern crafted with Opportunity in mind. Seemingly has no use, but it's said that it may just keep the moths away.",
    :price => 0,
    :noUseInBattle => true,
    :noUse => true,
    :battlehold => true,
  },

  :POKEBALLBELT => {
    :name => "Poké Ball Belt",
    :desc => "A belt with 6 Poké Balls latched to the side. They seem to all contain Pokémon... Their owners are no longer around.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :FAIRYFEATHER => {
    :name => "Fairy Feather",
    :desc => "An item to be held by a Pokémon. This feather boosts the power of the holder's Fairy-type moves. ",
    :price => 999,
    :noUseInBattle => true,
    :noUse => true,
    :typeboost => :FAIRY,
    :flingdamage => 10,
  },

  :LIGHTSTONE => {
    :name => "Light Stone",
    :desc => "Reshiram's destroyed body. It was supposed to be hidden away, yet... ",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :UMBRALSHARD => {
    :name => "Umbral Shard",
    :desc => "A dark shard filled with umbral energy. Shayda seems particularly interested in this.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ZSPLICER => {
    :name => "Z-Splicer",
    :desc => "Zygarde's gift. Using this will channel Zygarde's power through the host and act upon its Opportunity.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :legendary => true,
  },

  :CLEFABLITE => {
    :name => "Clefablite",
    :desc => "One variety of Mega Stone. Have Clefable hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :VICTREEBELITE => {
    :name => "Victreebelite",
    :desc => "One variety of Mega Stone. Have Victreebel hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :STARMINITE => {
    :name => "Starminite",
    :desc => "One variety of Mega Stone. Have Starmie hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DRAGONINITE => {
    :name => "Dragoninite",
    :desc => "One variety of Mega Stone. Have Dragonite hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEGANIUMITE => {
    :name => "Meganiumite",
    :desc => "One variety of Mega Stone. Have Meganium hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FERALIGITE => {
    :name => "Feraligite",
    :desc => "One variety of Mega Stone. Have Feraligatr hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BARBARACITE => {
    :name => "Barbaracite",
    :desc => "One variety of Mega Stone. Have Barbaracle hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SKARMORITE => {
    :name => "Skarmorite",
    :desc => "One variety of Mega Stone. Have Skarmory hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FROSLASSITE => {
    :name => "Froslassite",
    :desc => "One variety of Mega Stone. Have Froslass hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :EMBOARITE => {
    :name => "Emboarite",
    :desc => "One variety of Mega Stone. Have Emboar hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :EXCADRITE => {
    :name => "Excadrite",
    :desc => "One variety of Mega Stone. Have Excadrill hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SCOLIPITE => {
    :name => "Scolipite",
    :desc => "One variety of Mega Stone. Have Scolipede hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SCRAFTINITE => {
    :name => "Scraftinite",
    :desc => "One variety of Mega Stone. Have Scrafty hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :EELEKTROSSITE => {
    :name => "Elektrossite",
    :desc => "One variety of Mega Stone. Have Eelektross hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHANDELURITE => {
    :name => "Chandelurite",
    :desc => "One variety of Mega Stone. Have Chandelure hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHESNAUGHTITE => {
    :name => "Chesnaughtite",
    :desc => "One variety of Mega Stone. Have Chesnaught hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DELPHOXITE => {
    :name => "Delphoxite",
    :desc => "One variety of Mega Stone. Have Delphox hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GRENINJITE => {
    :name => "Greninjite",
    :desc => "One variety of Mega Stone. Have Greninja hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FLOETTITE => {
    :name => "Floettite",
    :desc => "One variety of Mega Stone. Have Eternal Flower Floette hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MALAMARITE => {
    :name => "Malamarite",
    :desc => "One variety of Mega Stone. Have Malamar hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DRAGALGITE => {
    :name => "Dragalgite",
    :desc => "One variety of Mega Stone. Have Dragalge hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HAWLUCHANITE => {
    :name => "Hawluchanite",
    :desc => "One variety of Mega Stone. Have Hawlucha hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ZYGARDITE => {
    :name => "Zygardite",
    :desc => "One variety of Mega Stone. Have Zygarde hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :DRAMPANITE => {
    :name => "Drampanite",
    :desc => "One variety of Mega Stone. Have Drampa hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :FALINKSITE => {
    :name => "Falinksite",
    :desc => "One variety of Mega Stone. Have Falinks hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :PYROARITE => {
    :name => "Pyroarite",
    :desc => "One variety of Mega Stone. Have Pyroar hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SALTKEY => {
    :name => "Salt Key",
    :desc => "A key that is made of salt and some sort of other fiber...",
    :price => 999,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :PERCIVALGLASS => {
    :name => "Percival's Glasses",
    :desc => "Glasses that seem to have belonged to Percival. The frame and eyeglass is cracked.",
    :noArticle => true,
    :price => 999,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :RAICHUNITEX => {
    :name => "Raichunite X",
    :desc => "One of a variety of mysterious Mega Stones. A Raichu holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :RAICHUNITEY => {
    :name => "Raichunite Y",
    :desc => "One of a variety of mysterious Mega Stones. A Raichu holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CHIMECHITE => {
    :name => "Chimechite",
    :desc => "One of a variety of mysterious Mega Stones. A Chimecho holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ABSOLITEZ => {
    :name => "Absolite Z",
    :desc => "One of a variety of mysterious Mega Stones. An Absol holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :STARAPTITE => {
    :name => "Staraptite",
    :desc => "One of a variety of mysterious Mega Stones. A Staraptor holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TATSUGIRINITE => {
    :name => "Tatsugirinite",
    :desc => "One of a variety of mysterious Mega Stones. A Tatsugiri holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEOWSTICITE => {
    :name => "Meowsticite",
    :desc => "One of a variety of mysterious Mega Stones. A Meowstic holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MAGEARNITE => {
    :name => "Magearnite",
    :desc => "One of a variety of mysterious Mega Stones. A Magearna holding this stone will be able to Mega Evolve during battle. ",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :LUCARIONITEZ => {
    :name => "Lucarionite Z",
    :desc => "One variety of Mega Stone. Have Lucario hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :HEATRANITE => {
    :name => "Heatranite",
    :desc => "One variety of Mega Stone. Have Heatran hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLURKITE => {
    :name => "Golurkite",
    :desc => "One variety of Mega Stone. Have Golurk hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CRABOMINITE => {
    :name => "Crabominite",
    :desc => "One variety of Mega Stone. Have Crabominite hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BAXCALIBRITE => {
    :name => "BAXCALIBRITE",
    :desc => "One variety of Mega Stone. Have Baxcalibur hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GLIMMORANITE => {
    :name => "Glimmoranite",
    :desc => "One variety of Mega Stone. Have Glimmora hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GOLISOPITE => {
    :name => "Golisopite",
    :desc => "One variety of Mega Stone. Have Alolan Golisopod hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ZERAORITE => {
    :name => "Zeraorite",
    :desc => "One variety of Mega Stone. Have Zeraora hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SCOVILLAINITE => {
    :name => "Scovillainite",
    :desc => "One variety of Mega Stone. Have Scovillain hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :XENBALL => {
    :name => "Xen Ball",
    :desc => "A special Poké Ball connected to the Hearth. It used to have the power to bring Pokémon back through memories.",
    :price => 1200,
    :ball => true,
  },

  :SECRETPATENT => {
    :name => "Secret Patent",
    :desc => "A secret parchment with details about an item called the Mega Bangle.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :justsell => true,
    :sidequest => true,
  },

  :UPDATEDPATENT => {
    :name => "Updated Patent",
    :desc => "An updated parchment with very, very modern details about an item called the Omni Bangle.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :justsell => true,
    :sidequest => true,
  },

  :GOLISOPODITEA => {
    :name => "Golisopite-A",
    :desc => "One variety of Mega Stone. Have Aevian Golisopod hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :GLIMMORANITEA => {
    :name => "Glimmoranite-A",
    :desc => "One variety of Mega Stone. Have Aevian Glimmora hold it, and this stone will enable it to Mega Evolve in battle.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :BUSTERSHARD => {
    :name => "Buster Shard",
    :desc => "A piece of Allen's Unown Buster. Only a memory now.",
    :price => 999,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :MOSELYSBEANIE => {
    :name => "Mosely's Beanie",
    :desc => "Mosely's favorite hat. Only a memory now.",
    :noArticle => true,
    :price => 999,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :BLACKKEY => {
    :name => "Black Key",
    :desc => "A key to a door in Melia's room. This key will destroy itself once you meet Keta in his home.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :story => true,
  },

  :PLUSLECREST => {
    :name => "Plusle Crest",
    :desc => "Activates Plus. Raises the power of physical moves of the user and its partner by 33%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MINUNCREST => {
    :name => "Minun Crest",
    :desc => "Activates Minus. Weakens the power of physical moves targetting the user and its partner by 33%.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TM158 => {
    :name => "TM158",
    :price => 25000,
    :tm => :NASTYPLOT,
    :noUseInBattle => true,
  },

  :TM159 => {
    :name => "TM159",
    :price => 25000,
    :tm => :LEAFSTORM,
    :noUseInBattle => true,
  },

  :TM160 => {
    :name => "TM160",
    :price => 25000,
    :tm => :HURRICANE,
    :noUseInBattle => true,
  },

  :TM161 => {
    :name => "TM161",
    :price => 25000,
    :tm => :DRAGONDANCE,
    :noUseInBattle => true,
  },

  :TM162 => {
    :name => "TM162",
    :price => 25000,
    :tm => :ACIDSPRAY,
    :noUseInBattle => true,
  },

  :TM163 => {
    :name => "TM163",
    :price => 25000,
    :tm => :CLOSECOMBAT,
    :noUseInBattle => true,
  },

  :TM164 => {
    :name => "TM164",
    :price => 25000,
    :tm => :PLAYROUGH,
    :noUseInBattle => true,
  },

  :FLYGONCREST => {
    :name => "Flygon Crest",
    :desc => "Boosts own-side Sound moves by 50%. Own side immune to each other's Sound moves. Sound moves scale off Attack.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :MEGAARCHAICDIAMOND => {
    :name => "Mega Archaic Diamond",
    :desc => "A diamond that acts as a Key Stone.",
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :general => true,
  },

  :MIRRORSPRIG => {
    :name => "Mirror Sprig",
    :desc => "A tiny herb that isn't fully grown. A Pokémon may use it to learn an Egg Move from another Pokémon at the Day-Care.",
    :price => 3000,
    :noUseInBattle => true,
    :noUse => true,
    :utilityhold => true,
    :flingdamage => 30,
  },

  :HAUNTEDCHALICE => {
    :name => "Golden Chalice",
    :desc => "A golden Chalice with rubies set in it. Found in a haunted Castle spilling Wine on the floor. Surely this is safe?",
    :price => 1000000,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :SOULSTONEHELD => {
    :name => "Soul Stone",
    :desc => "A stone to be held by Yveltal. Boosts Dark- and Flying-type moves by 20%, healing the user for 25% of damage dealt.",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
    :legendhold => true,
  },

  :MYSTERIOUSKEY => {
    :name => "Mysterious Key",
    :desc => "A strange key held by even stranger individuals. Where does it go...",
    :price => 999,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :SUNFLORACREST => {
    :name => "Sunflora Crest",
    :desc => "An item to be held by Sunflora. User behaves as if Sun is active and heals 10% HP every turn.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :TM165 => {
    :name => "TM165",
    :price => 25000,
    :tm => :SCALESHOT,
    :noUseInBattle => true,
  },

  :REBORNFLOWER => {
    :ID => 12,
    :name => "Reborn Flower",
    :desc => "A revitalized flower from the Reborn Region. Floette seems to be drawn to this flower.",
    :price => 2100,
    :evoitem => true,
    :noUseInBattle => true,
    :flingdamage => 30,
  },

  :SHAYDASCHARM => {
    :name => "Shayda's Charm",
    :desc => "A charm that symbolizes your friendship with Shayda. Increases the chance of finding Prism Pokémon by a little.",
    :noArticle => true,
    :price => 1000000,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
    :sidequest => true,
  },

  :PORTKEY => {
    :name => "Port Key",
    :desc => "A weathered old key found in the port of Xen HQ. Where does it go...",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CLEFABLITEQ => {
    :name => "Clefablite..?",
    :desc => "Appears to be a Mega Stone but there's something off about it. Found in #####'s room.",
    :price => 999,
    :crystal => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :ENTEICREST => {
    :name => "Entei Crest",
    :desc => "Fire moves become spread moves, all moves scale in BP based on how much HP Entei has.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :SUICREST => {
    :name => "Suicune Crest",
    :desc => "Holder ignores the negative effects of status conditions. Heals passively, and sets a 1 Turn Tailwind on entry.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :RAICREST => {
    :name => "Raikou Crest",
    :desc => "Holder and any possible partners act as if Rain and Electric Terrain are present.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },

  :CELECREST => {
    :name => "Celebi Crest",
    :desc => "Holder makes time pass quicker, doubling the amount of turns that pass.",
    :price => 0,
    :crest => true,
    :noUseInBattle => true,
    :noUse => true,
  },


  :SAFEKEY => {
    :name => "Battered Key",
    :desc => "A battered old key found in the depths of Zone Zero. The worn inscription on its side reads 'Ny...'",
    :price => 0,
    :keyitem => true,
    :noUseInBattle => true,
    :noUse => true,
  },
:CASSHELL => {
	:name => "Dusk Shell",
	:desc => "Use on Wurmple to evolve it into Cascoon.",
	:price => 0,
	:evoitem => true,
	:noUseInBattle => true,
},
:SILSHELL => {
	:name => "Silk Shell",
	:desc => "Use on Wurmple to evolve it into Silcoon.",
	:price => 0,
	:evoitem => true,
	:noUseInBattle => true,
},
:PIXIEDUST => {
	:name => "Pixie Dust",
	:desc => "An item to be held by a Pokémon. Boosts the power of Fairy-type moves by 20%.",
	:price => 800,
	:noUseInBattle => true,
  :noUse => true,
  :typeboost => :FAIRY,
  :flingdamage => 30,
},
}
