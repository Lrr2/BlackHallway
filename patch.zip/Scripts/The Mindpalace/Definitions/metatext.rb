METAHASH = {
  :home => [304, 19, 14, 8],
  :TrainerVictory => "Victory!.ogg",
  :WildVictory => "Victory!.mp3",
  :TrainerBattle => "Battle - Trainers.mp3",
  :WildBattle => "Wild Battle - Regular.ogg",
  :Surf => "Music - Surf.mp3",
  :LavaSurf => "Feeling - Hotheaded",
  :Bicycle => "Music - Bike.mp3",

  :player0 => {
    :name => "Aevis",
    :tclass => :TRAINER_AEVIS,
    # sprites,
    :walk => "trchar000",
    :run => "boy_run",
    :bike => "boy_bike",
    :surf => "boy_surf",
    :dive => "boy_dive_offset",
    :fishing => "boy_fish_offset",
    :surffish => "boy_fishsurf_offset",
  },

  :player1 => {
    :name => "Aevia",
    :tclass => :TRAINER_AEVIA,
    # sprites,
    :walk => "trchar001",
    :run => "girl_run",
    :bike => "girl_bike",
    :surf => "girl_surf",
    :dive => "girl_dive_offset",
    :fishing => "girl_fish_offset",
    :surffish => "girl_fishsurf_offset",
  },

  :player2 => {
    :name => "Marianette",
    :tclass => :LEADER_MARIANETTE,
    # sprites,
    :walk => "trchar091",
    :run => "trchar091run",
    :bike => "trchar091_bike",
    :surf => "trchar091_surf",
    :dive => "DupeTrainerDive",
    :fishing => "trchar091",
    :surffish => "trchar091",
  },

  :player3 => {
    :name => "Maria",
    :tclass => :CHILDOFLIGHT,
    # sprites,
    :walk => "trchar00001",
    :run => "trchar00001_run",
    :bike => "trchar00001",
    :surf => "trchar00001",
    :dive => "trchar00001",
    :fishing => "trchar00001",
    :surffish => "xxx",
  },

  :player4 => {
    :name => "Ariana",
    :tclass => :TRAINER_ARIA,
    # sprites,
    :walk => "trchar003",
    :run => "BGirlRun",
    :bike => "girl_bike2",
    :surf => "girl_surf2",
    :dive => "girl_dive_offset2",
    :fishing => "BGirl_Fish_Offset",
    :surffish => "BGirl_fishsurf_offset",
  },

  :player5 => {
    :name => "Axel",
    :tclass => :TRAINER_AXEL,
    # sprites,
    :walk => "trchar004",
    :run => "Boy_Run2",
    :bike => "boy_bike2",
    :surf => "boy_surf2",
    :dive => "boy_dive2",
    :fishing => "boy_fish_offset2",
    :surffish => "boy_fishsurf_offset2",
  },

  :player6 => {
    :name => "Alain",
    :tclass => :TRAINER_ALAIN,
    # sprites,
    :walk => "nb_walk2",
    :run => "nb_run2",
    :bike => "Nb2_Bike",
    :surf => "Nb2_Surf",
    :dive => "Nb2_Dive",
    :fishing => "nb_fish_offset",
    :surffish => "Nb2_surf_Fish",
  },

  :player7 => {
    :name => "Aero",
    :tclass => :TRAINER_AERO,
    # sprites,
    :walk => "nb_walk",
    :run => "nb_run",
    :bike => "Nb_Bike",
    :surf => "nb_surf",
    :dive => "nb_dive",
    :fishing => "Nb_fish",
    :surffish => "nb_surf_fish",
  },

  :player8 => {
    :name => "Ana",
    :tclass => :TRAINER_ANA,
    # sprites,
    :walk => "BGirlwalk",
    :run => "BGirlrun2",
    :bike => "BgirlAerialDrive",
    :surf => "BgirlAquaDrive",
    :dive => "BgirlDiveDrive",
    :fishing => "BgirlFishingDrive",
    :surffish => "BgirlSurfFishDrive",
  },

  :player9 => {
    :name => "Melia",
    :tclass => :TRAINER_MELIA1,
    # sprites,
    :walk => "NPC 30",
    :run => "NPC 30",
    :bike => "BGirlAerialDrive",
    :surf => "BGirlAquaDrive",
    :dive => "XXX",
    :fishing => "BgirlFishingDrive",
    :surffish => "BgirlFishingDrive",
  },

  :player10 => {
    :name => "Emma",
    :tclass => :HOOD,
    # sprites,
    :walk => "trchar091_2",
    :run => "trchar091run_2",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player11 => {
    :name => "Lavender",
    :tclass => :LEADER_LAVENDER,
    # sprites,
    :walk => "trchar209_2",
  },

  :player12 => {
    :name => "Melia 2",
    :tclass => :ENIGMA_2,
    # sprites,
    :walk => "VMeliaRed_6",
    :run => "VMeliaRed_6_1",
    :bike => "pkmn_togekisse",
    :surf => "xxx",
  },

  :player13 => {
    :name => "Ren",
    :tclass => :OUTCAST,
    # sprites,
    :walk => "trchar002_1",
    :run => "trchar002_run",
    :bike => "trchar002_bike",
    :surf => "trchar002_surf",
  },

  :player14 => {
    :name => "Melia 3",
    :tclass => :ENIGMA_2,
    # sprites,
    :walk => "VMeliaRed_7",
  },

  :player15 => {
    :name => "Aelita",
    :tclass => :STUDENT_3,
    # sprites,
    :walk => "Aelita_7",
    :run => "Aelita_7_run",
    :bike => "Aelita_7_2",
    :surf => "xxx",
  },

  :player16 => {
    :name => "Alexandra",
    :tclass => :ELITE_ALEXANDRA,
    # sprites,
    :walk => "trchar109",
    :run => "trchar109_run",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player17 => {
    :name => "Erin",
    :tclass => :CANDIDGIRL2,
    # sprites,
    :walk => "trchar117_10",
    :run => "trchar091run_9",
    :bike => "xxx",
    :surf => "trchar117_dive",
    :dive => "trchar117_dive",
  },

  :player18 => {
    :name => "Aelita 2",
    :tclass => :STUDENT_2,
    # sprites,
    :walk => "Aelita_3",
  },

  :player19 => {
    :name => "Amber",
    :tclass => :LEADER_AMBER2,
    # sprites,
    :walk => "trchar099_6",
    :run => "trchar099_6_run",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player20 => {
    :name => "Saki",
    :tclass => :LEADER_SAKI2,
    # sprites,
    :walk => "trchar087_4",
    :run => "trchar087_4_run",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player21 => {
    :name => "Huey",
    :tclass => :OPTKID,
    # sprites,
    :walk => "trchar250",
    :run => "trchar250_run",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player22 => {
    :name => "Lavender 2",
    :tclass => :LEADER_LAVENDER,
    # sprites,
    :walk => "trchar091",
    :run => "trchar091run",
    :bike => "XXX",
    :surf => "XXX",
  },

  :player23 => {
    :name => "Melia 4",
    :tclass => :ENIGMA_1,
    # sprites,
    :walk => "NPC 30_1_3",
    :run => "NPC 30_1_3_run",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player24 => {
    :name => "Adam",
    :tclass => :LEADER_ADAM,
    # sprites,
    :walk => "trchar86",
  },

  :player25 => {
    :name => "Odessa",
    :tclass => :PRINCESS_ODESSA,
    # sprites,
    :walk => "trchar162",
    :run => "trchar162_run",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player26 => {
    :name => "Melia 5",
    :tclass => :ENIGMA_2,
    # sprites,
    :walk => "VMeliaRed_10",
    :run => "VMeliaRed_10",
  },

  :player27 => {
    :name => "Aelita 3",
    :tclass => :STUDENT,
    # sprites,
    :walk => "Aelita",
    :run => "Aelita",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player28 => {
    :name => "Saber",
    :tclass => :XG_SABER,
    # sprites,
    :walk => "xgene_Player",
    :run => "xgene_Player",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player29 => {
    :name => "Interceptor",
    :tclass => :ENDBRINGER,
    # sprites,
    :walk => "Arc_Player_Full",
    :run => "Arc_Player_Full",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player30 => {
    :name => "Melia 6",
    :tclass => :MELIA_AWAKEN,
    # sprites,
    :walk => "VMeliaRed_5",
    :run => "VMeliaRed_5",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player31 => {
    :name => "Ana 2",
    :tclass => :NANO,
    # sprites,
    :walk => "BGirlwalk",
    :run => "BGirlrun2",
    :bike => "BGirlAerialDrive",
    :surf => "BGirlAquaDrive",
    :dive => "BgirlDiveDrive",
    :fishing => "BgirlFishingDrive",
    :surffish => "BgirlFishingDrive",
  },

  :player32 => {
    :name => "Ana 3",
    :tclass => :NANO,
    # sprites,
    :walk => "trchar141_10",
    :run => "trchar141_10",
  },

  :player33 => {
    :name => "Ren 2",
    :tclass => :OUTCAST,
    # sprites,
    :walk => "trchar002_5",
    :run => "trchar002_5",
  },

  :player35 => {
    :name => "M2",
    :tclass => :TRAINER_M2_1,
    # sprites,
    :walk => "VMeliaRed_10_1",
    :run => "VMeliaRed_10_1_run",

  },

  :player36 => {
    :name => "Erin",
    :tclass => :CANDIDGIRL2,
    # sprites,
    :walk => "trchar117_12_3",
    :run => "trchar117_12_3",

  },

  :player37 => {
    :name => "Storm-Nym",
    :tclass => :STORMNYM,
    # sprites,
    :walk => "storm9_Nym",
    :run => "storm9_Nym_11",

  },

  :player38 => {
    :name => "Aelita",
    :tclass => :STUDENT_3,
    # sprites,
    :walk => "Aelita_7",
    :run => "Aelita_7_run",
    :bike => "Aelita_7_2",
    :surf => "xxx",
  },

  :player39 => {
    :name => "Venam",
    :tclass => :LEADER_VENAM3,
    # sprites,
    :walk => "Venam_4",
    :run => "Venam_4",
    :bike => "xxx",
    :surf => "xxx",
  },

  :player40 => {
    :name => "Zenos",
    :tclass => :ENDBRINGER,
    # sprites,
    :walk => "Arc_Renegade_Walk",
    :run => "Arc_Renegade_Run",
    :bike => "Arc_Renegade_Dash",
    :surf => "xxx",
  },

  :player41 => {
    :name => "A-Gang",
    :tclass => :INTERTWINEDFATE,
    # sprites,
    :walk => "Arc_Renegade_Walk",
    :run => "Arc_Renegade_Run",
    :bike => "Arc_Renegade_Dash",
    :surf => "xxx",
  },

  :player42 => {
    :name => "Venam",
    :tclass => :LEADER_VENAM3,
    # sprites,
    :walk => "Venam_Seviper",
    :run => "Venam_Seviper",
    :bike => "xxx",
    :surf => "xxx",
  },
}
