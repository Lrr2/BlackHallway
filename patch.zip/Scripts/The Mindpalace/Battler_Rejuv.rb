class PokeBattle_Battler
    attr_accessor :shieldCount
    attr_accessor :barGraphic
    attr_accessor :entryText
    attr_accessor :sosDetails
    attr_accessor :randomSetChanges
    attr_accessor :shieldsBroken
    attr_accessor :shieldsBrokenThisTurn
    attr_accessor :currentSOS
    attr_accessor :zorotransform
    attr_accessor :reconstructcounter
    def pbInitBoss(pkmn,index)
        bossdata = $cache.bosses
        boss = bossdata[pkmn.bossId]
        if boss.immunities
          @immunities = {
            :moves => [],
            :fieldEffectDamage => [],
          }
          immunitiesarray = []
          if boss.immunities[:moves]
            for i in boss.immunities[:moves]
              immunitiesarray.push(i)
            end
          end
          @immunities[:moves] = immunitiesarray
          immunitiesarray = []
          if boss.immunities[:fieldEffectDamage]
            for i in boss.immunities[:fieldEffectDamage]
              immunitiesarray.push(i)
            end
          end
          @immunities[:fieldEffectDamage] = immunitiesarray
        else
          @immunities = {
            :moves => [],
            :fieldEffectDamage => [],
          }
        end
        @onBreakEffects = boss.onBreakEffects
        @onEntryEffects = boss.onEntryEffects
        @barGraphic    = boss.barGraphic
        @entryText    = boss.entryText ? boss.entryText : nil
        if boss.chargeAttack
          @chargeAttack  = {}
          boss.chargeAttack.each do |key,value|
            @chargeAttack[key] = value
          end
        else
          @chargeAttack = nil
        end
        if boss.sosDetails
          @sosDetails = {}
          boss.sosDetails.each do |key,value|
            @sosDetails[key] = value
          end
        else
          @sosDetails = nil
        end
        if boss.randomSetChanges
          @randomSetChanges = {}
          boss.randomSetChanges.each do |key,value|
            @randomSetChanges[key] = value
          end
        else
          @randomSetChanges = nil
        end
        @name = boss.name unless boss.name == ""
        @shieldCount = pkmn.shieldCount
        @reconstructcounter = 0
        @shieldsBroken = Array.new(pkmn.shieldCount,false)
        @shieldsBrokenThisTurn = [0,0,0,0]
        @currentSOS = 0
        @battle.typesequence = 0
        @capturable = boss.capturable ? boss.capturable : false
        @canrun = boss.canrun ? boss.canrun : false
        @battle.cantescape=true if !@canrun
    end

    def pbInitialize(pkmn,index,batonpass)
        # Cure status of previous Pokemon with Natural Cure
        if self.ability== :NATURALCURE || (self.ability== :TRACE &&
          self.effects[:TracedAbility]==:NATURALCURE) && @pokemon
          self.status=nil
        end
        if (self.ability== :REGENERATOR || (self.ability== :TRACE &&
          self.effects[:TracedAbility]==:REGENERATOR)) && @pokemon && @hp>0
            self.pbRecoverHP((totalhp/3.0).floor)
        end
        # Gen 9 Mod - Zero To Hero - Change base Palafin for someone else
        if self.species == :PALAFIN && self.ability== :ZEROTOHERO && self.form == 0
          self.form=1
          self.pokemon.justTransformed = 0 if !self.pokemon.justTransformed
          self.pokemon.justTransformed = 1
          pbUpdate(true)
        end
        # lawds psych up change
        for i in 0...4
          @battle.battlers[i].effects[:PsychUp]=-1 if @battle.battlers[i].effects[:PsychUp]==index
        end
        # LAWDS - reset hit count when switching to reset Rage Fist power
        @battle.resetBattlerHit(self)
        # LAWDS - Little King Mark goes away when Little King switches out
        if self.ability== :LITTLEKING && (!(@battle.doublebattle) || self.pbPartner.isFainted? || self.pbPartner.ability != :LITTLEKING)
          pbOppositeOpposing.effects[:LittleKingTarget]=false
          pbOppositeOpposing.pbPartner.effects[:LittleKingTarget]=false
        end
        pbInitPokemon(pkmn,index)
        pbInitEffects(batonpass)
        pbInitBoss(pkmn,index) if self.isbossmon
        @zorotransform = (self.crested == :ZOROARK && self.effects[:Illusion]!=nil && self.ability== :STANCECHANGE) ? 0 : nil
    end

    
    def rejuvAbilities(onactive)
      if self.ability== :PRISMPOWER && onactive
          self.pokemon.prismPower = true
          #@battle.scene.pbChangePokemon(self,@pokemon) if !(@effects[:Transform])
          @battle.pbDisplay(_INTL("{1}'s {2} activated!", pbThis,getAbilityName(ability)))
          worked=false
          for stat in 1..5
            if self.pbCanIncreaseStatStage?(stat,false)
              worked=true
              self.pbIncreaseStatBasic(stat,1)
            end
          end
          if worked
            @battle.pbCommonAnimation("StatUp",self,nil)
            @battle.pbDisplay(_INTL("{1}'s stats rose!",pbThis))
          end
      end
    end

    def pbBeginTurn(choice)
      # Cancel some lingering effects which only apply until the user next moves
      @effects[:DestinyBond]=false
      @effects[:Grudge]=false
      # Encore's effect ends if the encored move is no longer available
      if @effects[:Encore]>0 &&
         @moves[@effects[:EncoreIndex]].move!=@effects[:EncoreMove]
        PBDebug.log("[Resetting Encore effect]") if $INTERNAL
        @effects[:Encore]=0
        @effects[:EncoreIndex]=0
        @effects[:EncoreMove]=0
      end
      # Wake up in an uproar
      if self.status== :SLEEP && self.ability != :SOUNDPROOF
        for i in 0...4
          if @battle.battlers[i].effects[:Uproar]>0
            pbCureStatus(false)
            @battle.pbDisplay(_INTL("{1} woke up in the uproar!",pbThis))
          end
        end
      end
      if self.isbossmon
        @shieldsBrokenThisTurn = [0,0,0,0]
      end
    end
    # lawds endofturn parameter for new stance change mechanic
    def pbZoroCrestForms(basemove = nil,endofturn=false)    # LAWDS - zoroark loses ability when illusion goes away. also changes between p3 forms
      if (self.pokemon && self.crested == :ZOROARK && self.effects[:Illusion]!=nil) && !self.isFainted?
        transformed=false
        if (self.ability== :STANCECHANGE && !@effects[:Transform])
          if @zorotransform == 0 && !basemove.nil? && basemove.basedamage > 0
            @zorotransform = 1; transformed = true
            if self.PULSE3 && self.effects[:Illusion].PULSE3 
              self.ability= [:STANCECHANGE,:JUSTIFIED,:SHARPNESS]
              self.effects[:Illusion].ability= [:STANCECHANGE,:JUSTIFIED,:SHARPNESS]
            end
          elsif @zorotransform == 1 && ((!basemove.nil? && basemove.move == :KINGSSHIELD) || endofturn)
            @zorotransform = 0; transformed = true
            if self.PULSE3 && self.effects[:Illusion].PULSE3 
              self.ability= [:STANCECHANGE,:JUSTIFIED,:MIRRORARMOR]
              self.effects[:Illusion].ability= [:STANCECHANGE,:JUSTIFIED,:MIRRORARMOR]
            end
          end
          if self.effects[:Illusion] != nil
            self.effects[:Illusion].form = @zorotransform
          end
          if transformed
            if self.effects[:Illusion] != nil
              if self.effects[:Illusion].form == 1
                @battle.pbCommonAnimation("StanceAttack",self,nil)
              else
                if self.index == 0 || self.index == 2
                  @battle.pbCommonAnimation("StanceProtect",self,nil)
                else
                  @battle.pbCommonAnimation("StanceProtectOpp",self,nil)
                end
              end
              pbUpdate(true)
              @battle.scene.pbChangePokemon(self,self.effects[:Illusion])
              @battle.pbDisplay(_INTL("{1} transformed!",pbThis))
            end
            if (self.ability== :STANCECHANGE) && (@battle.FE == :FAIRYTALE || (Rejuv && @battle.FE == :CHESS)) 
              if (@zorotransform== 0)
                self.pbReduceStat(PBStats::ATTACK,1,abilitymessage:false)
                self.pbIncreaseStat(PBStats::DEFENSE,1,abilitymessage:false)
              else
                self.pbReduceStat(PBStats::DEFENSE,1,abilitymessage:false)
                self.pbIncreaseStat(PBStats::ATTACK,1,abilitymessage:false)
              end
            end
          end
        end
      end # end of update
    end

    def pbUseMoveSimpleBoss(move,index=-1,target=-1,danced=false)
      choice=[]
      choice[0]=1       # "Use move"
      choice[1]=index   # Index of move to be used in user's moveset
      choice[2]=move
      choice[2].pp=-1
      choice[3]=target  # Target (-1 means no target yet)
      @simplemove=(danced==false) ? true : false
      if index>=0
        @battle.choices[@index][1]=index
      end
      @usingsubmove=true
      side=(@battle.pbIsOpposing?(self.index)) ? 1 : 0
      owner=@battle.pbGetOwnerIndex(self.index)
      if @battle.zMove[side][owner]==self.index && choice[2].basedamage>0 && !danced
        crystal = pbZCrystalFromType(choice[2].type)
        zmoveID = PBStuff::CRYSTALTOZMOVE[crystal]
        choice[2]=PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(zmoveID),self,choice[2])
      end
      pbUseMove(choice, {specialusage: true, danced: danced})
      @usingsubmove=false
      @simplemove=false
      return
    end
      # Lawds Mod - changed crest stats for many mons and added new ones
      # also changed these to account for pulse3
      def crestStats
        case @crested
        when :GLACEON
          @defense = @spatk
        when :LEAFEON
          @spdef = @attack
        when :LUXRAY
          @speed *= 1.2
        when :LEDIAN
          @attack *= 1.2
        when :SILVALLY
          ability= PBStuff::SILVALLYCRESTABILITIES.keys.include?(@item) ? PBStuff::SILVALLYCRESTABILITIES[@item] : :SCRAPPY
          # LAWDS p3 silvally. the crest gives each type a different pulse ability, except glitch which has all of the regular silvally abilities
          if self.PULSE3
            ability = [:RKSSYSTEM, ability]
            ability.push(:HYPERCUTTER)
            if @item==:GLITCHMEMORY
              ability = ability + [:SCRAPPY,:FLOWERVEIL,:MOXIE,:MARVELSCALE,:DEFIANT,:GALEWINGS,
                                  :SOLIDROCK,:MOTORDRIVE,:MAGICGUARD,:MUMMY,:REGENERATOR, # like a third of these dont even really benefit the thing lmfao
                                  :MULTISCALE,:SHEERFORCE,:HEATPROOF,:STRONGJAW,:THERMALEXCHANGE,
                                  :TINTEDLENS,:UNAWARE]
            else
              pulseAbility = PBStuff::SILVALLYCRESTPULSES.keys.include?(@item) ? PBStuff::SILVALLYCRESTPULSES[@item] : :EARLYBIRD
              ability.push(pulseAbility)
            end
          end
          self.ability= PokeAbility.new(ability)
        when :INFERNAPE
          @attack,@defense = @defense,@attack
          @spatk,@spdef = @spdef,@spatk
        when :MAGCARGO
          @defense,@speed = @speed,@defense
          @spatk *= 1.1
        when :TYPHLOSION
          @attack = @spatk
        when :DACHSBUN
          @attack = @defense
        when :CLAYDOL
          @spatk = @defense
        when :DEDENNE
          @attack = @speed
        when :RELICANTH
          @attack *=1.2
          @spdef *= 1.3
        when :SKUNTANK
          @attack *=1.2
          @spatk *= 1.2
        when :HYPNO
          @spatk *= 1.5
        when :BEHEEYEM # lawds
          @defense *= 1.1
          @spdef *= 1.1
        when :STANTLER
          @attack *= 1.5
          @spatk *= 1.5
        when :WYRDEER
          @attack *= 1.3
          @spatk *= 1.3
        when :ORICORIO
          @spatk *= 1.25
          @speed *= 1.25
        when :SEVIPER
          @speed *=1.5
        # Lawds Mod - Dusknoir and Cofagrigus Crest effects are changed
        #when :DUSKNOIR
          #@attack *= 1.2
        when :COFAGRIGUS
          @spatk*=1.25
          #@spdef*=1.25
        when :ARIADOS
          @speed *= 1.75
        when :PHIONE
          @defense *= 1.5
          @spdef *= 1.5
        when :DELCATTY
          party = @battle.pbParty(@index)
          boost = false
          for mon in party
            if !mon || mon==self || mon.hp <= 0
              next
            end
            @attack += (0.1 * mon.attack)
            @defense += (0.1 * mon.defense)
            @speed += (0.1 * mon.speed)
            @spatk += (0.1 * mon.spatk)
            @spdef += (0.1 * mon.spdef)
            boost = true
          end
        when :WHISCASH
          @attack *= 1.2
          @spatk *= 1.2
        when :NOCTOWL
          @defense *= 1.2
        when :CRABOMINABLE
          @defense *= 1.2
          @spdef *= 1.2
        when :REUNICLUS
          if @battle.choices[@index][0]==1 && @battle.choices[@index][1]>=0  
            @attack, @spatk = @spatk, @attack if self.moves[@battle.choices[@index][1]].pbIsPhysical?
          end
        when :SAWSBUCK
          @type1 = :WATER  if @form == 0
          @type1 = :FIRE   if @form == 1
          @type1 = :GROUND if @form == 2
          @type1 = :ICE    if @form == 3
        when :PORYGONZ
          @type1 = :QMARKS
        when :SIMISAGE
          @attack *= 1.2
          @spatk *= 1.2
        when :SIMISEAR
          @attack *= 1.2
          @spatk *= 1.2
        when :SIMIPOUR
          @attack *= 1.2
          @spatk *= 1.2
        when :CRYOGONAL
          @spdef *= 1.2
          @attack += @spdef * 0.1
          @defense += @spdef * 0.1
          @spatk += @spdef * 0.1
          @speed += @spdef * 0.1
        when :ZOROARK
          if @effects[:Illusion]!=nil
            blacklist = PBStuff::ABILITYBLACKLIST - [:STANCECHANGE,:TRACE,:QUARKDRIVE,:PROTOSYNTHESIS] # LAWDS zoro crest can copy quark drive and protosynthesis
            self.ability = @effects[:Illusion].ability if !blacklist.include?(@effects[:Illusion].ability)
          end
        # Lawds Mod - Custom Crests
        when :ELECTIVIRE
          @defense *= 1.5
        when :OINKOLOGNE
          @defense *= 1.2
          @spdef *= 1.2
        when :CURSOLA
          @defense *= 1.3
        when :BRAVIARY
          @defense *= 1.3
          @spdef *= 1.3
        when :PERRSERKER
          @spdef *= 1.50
          @speed *= 1.20
        when :KLINKLANG
          @defense *= 1.2
          @spdef *= 1.2
        when :TINKATON
          multiplier = 1.5
          @attack *= multiplier
	        if $game_variables[:DifficultyModes]==2
		        @defense *= 1.3
		        @spdef *= 1.3
	        end
        when :WORMADAM
          higher = @defense
          higher = @spdef if @spdef > @defense
          @attack = higher
          @spatk = higher
        when :MOTHIM
          higher = @attack
          higher = @spatk if @spatk > @attack
          @defense = higher
          @spdef = higher
        end #/lawds
      end

      def pbFaint(showMessage=true)
        if !self.isFainted?
          PBDebug.log("!!!***Can't faint with HP greater than 0") if $INTERNAL
          return true
        end
        if @fainted
          return true
        end
        # LAWDS - Little King's Mark goes away when it leaves the field
        if self.ability== :LITTLEKING && self.pbPartner.ability != :LITTLEKING
          pbOppositeOpposing.effects[:LittleKingTarget] = false
          pbOppositeOpposing.pbPartner.effects[:LittleKingTarget] = false
        end
        if self.isbossmon
          if self.shieldCount > 0 && self.onBreakEffects
            onBreakdata = self.onBreakEffects[self.shieldCount]
            if !@battle.snapshot.nil?
              if @battle.snapshot[1]
                if @battle.snapshot[1][5]==0
                  onBreakdata = self.onBreakEffects[self.shieldCount*(-1)]
                end
              end
            end
            hpthreshold = (onBreakdata && onBreakdata[:threshold]) ? onBreakdata[:threshold] : 0
            #self.pbRecoverHP(self.totalhp,true) if self.hp==0
            case hpthreshold
            when 0
              boss = @battle.battlers[self.index] 
              self.pbRecoverHP(self.totalhp,true)
              @battle.pbShieldEffects(self,onBreakdata) if onBreakdata
              self.shieldCount-=1 if self.shieldCount>0 
              @battle.scene.pbUpdateShield(boss.shieldCount,self.index)
              if boss.sosDetails
                @battle.pbBossSOS(@battle.battlers,shieldbreak=true)
              end
            when 0.1
              self.pbRecoverHP(self.totalhp,true)
              if onBreakdata
                if onBreakdata[:thresholdmessage] && onBreakdata[:thresholdmessage] != ""
                  if onBreakdata[:thresholdmessage].start_with?("{1}") 
                    pbDisplay(_INTL(onBreakdata[:thresholdmessage],self.pbThis))
                  else
                    pbDisplay(_INTL(onBreakdata[:thresholdmessage],self.pbThis(true)))
                  end
                end
                @battle.pbShieldEffects(self,onBreakdata,false,false,true) if onBreakdata
                self.reconstructcounter += 1
                if self.reconstructcounter >=100      
                  if $game_variables[731] < 122 && $game_variables[756] < 85
                  @battle.pbDisplayBrief(_INTL("???: You are wasting your time, Interceptor.",self.pbThis))
                  else
                    @battle.pbDisplayBrief(_INTL("A lost voice echoed in your head...",self.pbThis))
                    @battle.pbDisplayBrief(_INTL("???: You are wasting your time, Interceptor.",self.pbThis))
                  end
                  @battle.pbAnimation(:ROAROFTIME,self,nil)
                  @battle.decision = 2
                  @battle.pbJudge()
                  # if @battle.decision > 0
                  #   return
                  # end
                elsif self.reconstructcounter >=3
                  pbDisplayBrief(_INTL("{1} seems indestructible...",self.pbThis))
                end
              end
            end
            return false
          end
        end
        @battle.returnStolenPokemon(false,self,self.lastAttacker) if self.issossmon
        if ((@species==:PARAS && @pokemon.form==1 || @species==:PARASECT && @pokemon.form==1) && @ability== :RESUSCITATION)
          @battle.scene.pbFakeOutFainted(self)
          #@effects[PBEffects::Resusitated]=true
          pbUpdate(true)
          self.pbRecoverHP((self.totalhp).floor,true)
          @battle.pbDisplayPaused(_INTL("{1} was resuscitated!",self.pbThis))
          if @battle.FE==:HAUNTED
            for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
              PBStats::SPATK,PBStats::SPDEF,PBStats::EVASION,PBStats::ACCURACY]
              @stages[i]=0 if @stages[i]<0
            end
          end
          return false
        elsif (@species==:DIALGA && @pokemon.form==0 && @battle.FE==:DEEPEARTH) # lawds timey wimey shit
          @battle.scene.pbFakeOutFainted(self)
          @battle.timewarp(self, 0)
          return false
        else
          @battle.scene.pbFainted(self)     
        end
        # lawds static rework
        if self.ability==:STATIC && !self.pbOwnSide.effects[:StaticCharge]
	        @battle.pbAnimation(:IONDELUGE,self,self)
	        @battle.pbDisplay(_INTL("{1}'s Static left behind a charge!",pbThis))
	        self.pbOwnSide.effects[:StaticCharge]=true
        end
        @battle.neutralizingGasDisable(self.index) if self.ability== :NEUTRALIZINGGAS
        if (pbPartner.ability==:POWEROFALCHEMY || pbPartner.ability==:RECEIVER) && pbPartner.item != :ABILITYSHIELD && pbPartner.hp > 0
          if PBStuff::ABILITYBLACKLIST.none? {|forbidden_ability| forbidden_ability==@ability}
          # lawds p3
            abilityindex=-1
            if pbPartner.ability.is_a?(PokeAbility)
              if pbPartner.ability.ability.is_a?(Array)
                abilityindex=0
                for i in 0...pbPartner.ability.ability.length # partner has multiple abilities
                  if [:POWEROFALCHEMY,:RECEIVER].include?(pbPartner.ability.ability[i])
                    abilityindex=i 
                    break
                  end
                end
              end
            end
            partnerability=self.ability
            if self.ability.is_a?(PokeAbility)
              if self.ability.ability.is_a?(Array)
                copiedabil=self.ability.ability # self has multiple abilities
              else
                copiedabil=[self.ability.ability] # self has one ability
              end
              if abilityindex==-1 # partner has one ability
                partnerability = copiedabil
                partnerability=copiedabil[0] if copiedabil.length==1 
              else
                abilarray = []
                for abil in copiedabil # add every copyable ability to the array
                  abilarray.push(abil) if !PBStuff::ABILITYBLACKLIST.include?(abil)
                end
                copiedabil=abilarray.clone # save all the abilities we've copied for later
                for i in 0...pbPartner.ability.ability.length # add every ability had by the partner to the array, except receiver/alchemy
                   if i != abilityindex && !abilarray.include?(i)
                    abilarray.push(pbPartner.ability.ability[i])
                   end
                end
                partnerability=abilarray
              end
            end
            oldability= pbPartner.ability
            pbPartner.ability=copiedabil # assign copied abilities to partner
            abilityname=getAbilityName(partnerability)
            abilityname= "Abilities" if partnerability.is_a?(Array) || (partnerability.is_a?(PokeAbility) && partnerability.ability.is_a?(Array))
            if oldability==:POWEROFALCHEMY
              @battle.pbDisplay(_INTL("{1} took on {2}'s {3}!",pbPartner.pbThis(true),pbThis,abilityname))
            else
              @battle.pbDisplay(_INTL("{1} received {2}'s {3}!",pbPartner.pbThis(true),pbThis,abilityname))
            end
            pbPartner.pbAbilitiesOnSwitchIn(true,true) # run abilities on switch in for the new abilities, then assign the full ability array
            pbPartner.ability=partnerability
          end
          # end lawds p3 stuff
        end
        for i in @battle.battlers
          next if i.isFainted?
          if i.ability== :SOULHEART && !i.pbTooHigh?(PBStats::SPATK)
            @battle.pbDisplay(_INTL("{1}'s Soul-heart activated!",i.pbThis))
            i.pbIncreaseStat(PBStats::SPATK,1)
            if (@battle.FE==:MISTY || @battle.FE==:RAINBOW || @battle.FE==:FAIRYTALE || @battle.state.effects[:MISTY]>0) && !i.pbTooHigh?(PBStats::SPDEF) # lawds overlays
              i.pbIncreaseStat(PBStats::SPDEF,1)
            end
          end
        end
        droprelease = self.effects[:SkyDroppee]
        #if locked in sky drop while fainting
        if self.effects[:SkyDrop]
          for i in @battle.battlers
            next if i.isFainted?
            if i.effects[:SkyDroppee]==self
              @battle.scene.pbUnVanishSprite(i)
              i.effects[:TwoTurnAttack] = 0
              i.effects[:SkyDroppee] = nil
            end
          end
        end
        # Gen 9 Mod - Get Tatsugiri out of Dondozo's mouth when Dondozo faints
        if self.effects[:Commandee] && self.pbPartner.effects[:Commander]
          self.pbPartner.effects[:Commander] = false
          @battle.scene.pbUnVanishSprite(self.pbPartner,true)
        end
        @battle.pbDisplayPaused(_INTL("{1} fainted!",pbThis)) if showMessage
        pbInitEffects(false)
        self.bossdelayedeffect = nil
        self.bossdelaycounter = nil
        self.onEntryEffects = nil
        self.vanished=false
        # reset status
        self.status=nil
        self.statusCount=0
        if @pokemon && @battle.internalbattle
          @pokemon.changeHappiness("faint")
        end
        if self.isMega?
          @pokemon.makeUnmega
        end
        if self.isUltra?
          @pokemon.makeUnultra(@startform)
        end
        @fainted=true
        # reset choice
        @battle.choices[@index]=[0,0,nil,-1]
        if @userSwitch
          @userSwitch = false
        end
        #reset mimikyu form if it faints
        if (@species==:MIMIKYU || @species==:EISCUE || @species==:CARNIVINE) && @pokemon.form==1
          self.form=0
        end
        if ((@species == :PARAS || @species == :PARASECT) && @pokemon.form == 2)
          self.form=1 
        end
        #stops being in middle of a spread move
        @midwayThroughMove = false
        #deactivate ability
        self.ability=nil
        self.crested=false
        if droprelease!=nil
          oppmon = droprelease
          oppmon.effects[:SkyDrop]=false
          @battle.scene.pbUnVanishSprite(oppmon)
          @battle.pbDisplay(_INTL("{1} is freed from Sky Drop effect!",oppmon.pbThis))
        end
        @battle.party2.pop if self.issossmon
        # set ace message flag
        if (self.index==1 || self.index==3) && !@battle.pbIsWild? && !@battle.opponent.is_a?(Array) && @battle.pbPokemonCount(@battle.party2)==1 && !@battle.ace_message_handled
          @battle.ace_message=true
        end
        @battle.scene.partyBetweenKO1(self.index==1 || self.index==3) unless (@battle.doublebattle || pbNonActivePokemonCount==0)
        PBDebug.log("[#{pbThis} fainted]") if $INTERNAL
        return true
      end
end

class PokeBattle_BossMove < PokeBattle_Move	#Fake move used by AI to determine damage if no damaging AI memory move
	def initialize(battle,user,bossmove)
		type = bossmove[:type] ? bossmove[:type] : :QMARKS 
		@move = bossmove[:move]
		@battle = battle
		@name 			 = bossmove[:name]
    @longname    = bossmove[:longname] ? bossmove[:longname] : bossmove[:name]
		@function    = bossmove[:function]
		@basedamage  = bossmove[:basedamage]
		@type        = type
		@category    = (bossmove[:category])
		@accuracy    = 100
		@target      = bossmove[:target]
		@maxpp       = 15
		@priority    = 0
		@zmove       = false
		@user        = user
    @effect      = bossmove[:effect] ? bossmove[:effect] : 0
    @moreeffect  = bossmove[:moreeffect] ? bossmove[:moreeffect] : @effect
		# @data				 = MoveData.new(@move,hash)
	end
end