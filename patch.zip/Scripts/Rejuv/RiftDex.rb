# Rift Dex class. Based on xLed's Jukebox Scene class.
class Scene_RiftDex
  #-----------------------------------------------------------------------------
  # * Object Initialization
  #     menu_index : command cursor's initial position
  #-----------------------------------------------------------------------------
  def initialize(menu_index = 0)
    @menu_index = menu_index
    @riftNotes = riftNotes
  end

  #-----------------------------------------------------------------------------
  # * Main Processing
  #-----------------------------------------------------------------------------
  def main
    # Makes the text window
    @sprites = {}
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites["background"] = IconSprite.new(0, 0)
    @sprites["background"].setBitmap("Graphics/Pictures/navbg")
    @sprites["background"].z = 255
    @choices = riftNotesObtained
    @sprites["command_window"] = Window_CommandPokemonWhiteArrow.newWithSize(@choices, 94, 63, 324, 288)
    @sprites["command_window"].windowskin = nil
    @sprites["command_window"].baseColor = Color.new(248, 248, 248)
    @sprites["command_window"].shadowColor = Color.new(0, 0, 0)
    @sprites["command_window"].index = @menu_index
    @sprites["command_window"].z = 256
    render_header
    # Execute transition
    Graphics.transition
    # Main loop
    loop do
      # Update game screen
      Graphics.update
      # Update input information
      Input.update
      # Frame update
      update
      # Abort loop if screen is changed
      if $scene != self
        break
      end
    end
    # Prepares for transition
    Graphics.freeze
    # Disposes the windows
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end

  def render_header
    @sprites["header"] = Window_UnformattedTextPokemon.newWithSize(_INTL("Rift Dex"), 2, -18, 128, 64, @viewport)
    @sprites["header"].baseColor = Color.new(248, 248, 248)
    @sprites["header"].shadowColor = Color.new(0, 0, 0)
    @sprites["header"].windowskin = nil
  end

  #-----------------------------------------------------------------------------
  # * Frame Update
  #-----------------------------------------------------------------------------  #-----------------------------------------------------------------------------
  def update
    pbUpdateSpriteHash(@sprites)

    # update command window and the info if it's active
    if @sprites["command_window"].active
      update_command
      return
    end
  end

  #-----------------------------------------------------------------------------
  # * Command controls
  #-----------------------------------------------------------------------------
  def update_command
    index = @sprites["command_window"].index
    # If B button was pressed
    if Input.trigger?(Input::B) || (Input.trigger?(Input::C) && index == @choices.length - 1)
      # Switch to map screen
      pbPlayCancelSE()
      $scene = Scene_Pokegear.new(:rift)
      return
    end
    # If C button was pressed
    if Input.trigger?(Input::C)
      rift = @riftNotes[index]
      if $game_switches[rift]
        pbPlayDecisionSE()
        $scene = Scene_RiftDex_Info.new(rift, index, @riftNotes)
      end
      return
    end
  end

  #-----------------------------------------------------------------------------
  # * Determines which Rifts the trainer has data for
  #-----------------------------------------------------------------------------
  def riftNotesObtained
    riftNotes = []
    for rift in @riftNotes
      riftNotes.push($game_switches[rift] ? RIFTDATA[rift][:name] : ColorTags[:Gray2] + "???")
    end
    riftNotes.push(ColorTags[:Gray2] + _INTL("Back"))
    return riftNotes
  end

  #-----------------------------------------------------------------------------
  # * Determines which Rift notes should be in the menu
  #-----------------------------------------------------------------------------
  def riftNotes
    rifts = []
    for rift in RIFTDATA.keys
      next if [:RIFTWEAVILE, :RIFTNIHILEGO].include?(rift)
      rifts.push(rift)
    end
    return rifts
  end
end

# :x and :y control the positioning of the sprite in Rift Dex
# :x and :y are handled as negative number offsets.
# :spriteSwitch gets turned on when the respective rift is first seen in battle
# :seen indicates having beaten the first battle against the respective rift, needed for legacy save files
RIFTDATA = {
  :RIFTFERROTHORN => {
    :name => _INTL("Code: Drifio"),
    :desc => _INTL("In its Suspended Form, it likes to manuever itself similar to what is called a \"yo-yo\".\nIn this form it is not very powerful, but when angered, it shifts into its true form. It will roll around the walls endlessly and run over all in its path.\nClosed quarters is its best environment for combat."),
    :notes => _INTL("Ferrothorn volunteered itself to become a rift. Though, it probably did not know what it was getting itself into.\nWhile the transformation was painful, it quite likes its new form. It uses its body as a wheel and playfully drives itself across all kinds of terrain.\nIt was abandoned by Flora when it stopped obeying her commands in favor of playing around. It seems to have been quite annoyed that you found and defeated it."),
    :species => :FERROTHORN,
    :form => "Unleashed Rift Form",
    :dexForms => ["Suspended Rift Form"],
    :x => 4,
    :y => 36,
  },
  :RIFTCHANDELURE => {
    :name => _INTL("Code: Feris"),
    :desc => _INTL("A being made completely of fire and spectral energy. Its origins are a mystery, but there's one thing that is known.\nIt holds deep regrets over failing to protect its Trainer.\nIt can't keep one Type down. Maybe that's why it couldn't do something basic like protect its Trainer."),
    :notes => _INTL("Chandelure turning into a Rift is a special case. It was not originally in contact with Rift Matter at all... Perhaps holding on to so much regret in death can have adverse effects. There are legends of people turning into monsters if they die with massive amounts of lingering anger or regrets. Perhaps the same is true for Pokémon. If Narcissa found Chandelure in this state, I wonder if it would stay this way?\nOddly, the sphere holding the flame in the center is completely still while the rest of its body revolves around it."),
    :species => :CHANDELURE,
    :form => "Rift Form",
    :x => 6,
    :y => 18,
  },
  :RIFTGYARADOS => {
    :name => _INTL("Code: Evo"),
    :desc => _INTL("This being was created by Team Xen Executive Zetta.\n\nA conglomerate of Magikarp fused together to create this chaotic beast.\n\nIt lacks individual thought. Gyarados constantly shifts through dimensions without cause or direction."),
    :notes => _INTL("The Magikarp used to make this creature had absolutely no dreams or aspirations in life. They were simple Magikarp...that's what you would think at face value, but this could not be any farther from the truth. Each Magikarp dreamed of one day becoming a Gyarados. They say be careful what you wish for and that's true in this case. Now all these Magikarp are fighting for individuality, but that will never come. If it were to be left unattended, it would endlessly hop through dimensions without reason or purpose. Just a sad waste of space."),
    :species => :GYARADOS,
    :form => "Rift Form",
    :x => 6,
    :y => 48,
    :hideShadow => true
  },
  :RIFTGALVANTULA => {
    :name => _INTL("Code: Materna"),
    :desc => _INTL("Galvantula's heart is completely closed due to her untimely demise.\nHer spirit is tied to this realm entirely by her maternal need to care for her young.\nAttacking her children will anger her greatly."),
    :notes => _INTL("A second one that happens to be a mother... I'm sensing a pattern here. This Galvantula's original home is unknown, but its children now infest Amethyst Cave. There aren't enough to cause any immediate population troubles, but over the next few years there may be a serious change in ecosystem. Regardless, this Galvantula won't see its children thrive-- If they even have that chance."),
    :species => :GALVANTULA,
    :form => "Rift Form",
    :dexForms => ["Rift Egg"],
    :x => 6,
    :y => 18,
  },
  :RIFTVOLCANION => {
    :name => _INTL("Code: Statia"),
    :desc => _INTL("This Volcanion is but a child. It was taken from its mother from deep within Valor Mountain.\n\nIt is constantly in despair over being unable to see its mother ever again.\n\nIt is completely, and quite pathetically, stationary."),
    :notes => _INTL("Volcanion was born in the very core of Valor Mountain. Its said that the entrance to this core is hidden. So how did Team Xen find it? Regardless, it was found, and it was taken by Xen Executive, Madelis. Though this Volcanion being chosen was an error on her part, as this fate was meant for its mother. Not that it matters. It did the job its mother was supposed to do anyways. I wonder what she's thinking now? I bet she's still there in the core of Valor Mountain now. Grieving over the loss of her child."),
    :species => :VOLCANION,
    :form => "Rift Form",
    :x => 6,
    :y => 44,
  },
  :RIFTCARNIVINE => {
    :name => _INTL("Code: Sarpa"),
    :desc => _INTL("This Rift was created long ago through the power of the Cursed Root.\nThere are texts that detail its affinity for music and dancing.\nAlthough it lacks eyes, it is able to use echolocation.\n\nApparently it can also make fresh beats."),
    :notes => _INTL("This Carnivine was once owned by a boy in a nearby village. These two one day wandered into the temple without permission and stumbled upon a sacred tomb. In this tomb laid the Cursed Root. For entering this chamber, they were both punished by Enamorus. The boy was to share the pain the Cursed Root felt. Whenever humans would commit atrocities to nature, the boy would suffer for their sins. In turn, Carnivine would also forever stay within the temple to guard the Cursed Root for eternity. Those who defile Gaia will learn to beg for her mercy."),
    :species => :CARNIVINE,
    :form => "Rift Form",
    :x => 14,
    :y => 66,
  },
  :RIFTGARBODOR => {
    :name => _INTL("Code: Corroso"),
    :desc => _INTL("Garbodor was turned into a Rift by Zetta when it gained the upper hand on him in battle.\nIt is searching endlessly for Melia.\nValidation and praise for protecting its mother is all it wants.\nThough...\nIt's trash, and it knows it."),
    :notes => _INTL("Garbodor had continued to fight both Zetta and Code: Evo all on its own, and fortunately, due to its typing, was able to almost win.\nIn a last ditch effort, Zetta transformed Garbodor into a monster.\nGarbodor had already been born under mysterious circumstances. Its experience in life could not help to resist this curse--the lack of which enhanced its own corruption.\nIt threw itself into the sea in hopes to swim back to East Gearen in hopes of finding Melia, but instead found the lonely depths of the West Gearen Sewers. A fitting place for something so disgusting."),
    :species => :GARBODOR,
    :form => "Rift Form",
    :shiny => true,
    :x => 8,
    :y => 38,
  },
  :RIFTAELITA => {
    :name => _INTL("Code: Bella"),
    :desc => _INTL("Aelita's curse incarnate. Passed down by both Vivian and Taelia, this curse is tired of being chained.\n\nShe wants her perfect world and you are in the way of that.\nHer True Shot increases Ball and Bomb moves by 30%.\nThat's going to hurt.\nYou might die here."),
    :notes => _INTL("Aelita's past is one that has been purposefully hidden from her. Now that truth can be hidden no longer. Though, why does she manifest in this way? To fight from afar, and to hide away in a vast world only a child could love...\nIs this a result of her stubborn nature, or does she truly live for her own self isolation?\nThough the curse has seemingly been \"destroyed\", it will always be a part of her.\nThat is her mark. It is her punishment for acting on forces humans have no business bothering.\nThe blame is not on her, but on Vivian.\nMay her soul be damned."),
    :species => :REGIROCK,
    :form => "Rift Form",
    :x => 6,
    :y => 46,
  },
  :ANGELOFDEATH => {
    :name => _INTL("Code: Angelus"),
    :desc => _INTL("Corruption found its way into this one at a young age, but \"Master Indriad\" was able to release it.\nHer DNA holds traces of Gallade, which gave birth to the glaive on her right arm.\n\nHer ability, Execution, will lay waste to Pokémon with low health.\nBehold, the Angel of Death."),
    :species => :GARDEVOIR,
    :form => "Angel of Death",
    :x => 8,
    :y => 20,
    :hideShadow => true,
    :hideNotes => true
  },
  :RIFTHIPPOWDON => {
    :name => _INTL("Code: Garna"),
    :desc => _INTL("She was once thought to be lost to the calamity, but she bided her time within the depths of Zone Zero.\n\nFlora, \"regrettably\", used her power to ward people away from Zone Zero.\n\nWith her ability, she will keep Stockpiling every turn. Don't get eaten now..."),
    :notes => _INTL("Gloria was a Hippopotas that survived the Calamity. It burrowed itself within the ground when the land was torn apart. How it became corrupted is unknown. Perhaps it fell into one of the many craters leading to the abyss? It's impossible to say, but one thing is to be certain. It lived so that it could find its Trainer again one day. She won't die until she does. Unless, of course, she is killed.\n...\nShe says she's looking for that girl with pink hair again. The one that played piano so ''beautifully''?\nDo you happen to know who she is referring to? "),
    :species => :HIPPOWDON,
    :form => "Rift Form",
    :gender => :F,
    :x => 4,
    :y => 14,
  },
  :DUFAUX => {
    :name => _INTL("Code: Rembrence"),
    :desc => _INTL("Its true body hides within the degraded vessel of Celesia's Clefairy Doll.\n\nIts trickery should not be underestimated.\nWith its electric currents, it can mess with the flow of time.\nThis one feels a bit scary, doesn't it? Lowering its stats is useless."),
    :notes => _INTL("This one is a bit interesting. It has been corrupted without the use of Rift Matter, and it also seems to havea gained a bit of sentience. I have to wonder if that's due to the Pokémon's own intellect, or the girl who died with it? Perhaps both? Either way, Dufaux, as it calls itself, is able to hold itself a bit higher due to its ability to communicate. Its power to travel through time also piques my interest... Its electricity is able to pierce through the world? Or maybe it's communicating and giving commands to the Core? I will study this one for future use, I think."),
    :species => :FROSLASS,
    :form => "Rift Form",
    :x => 0,
    :y => 0,
    :spriteOverride => "Graphics/Pictures/RiftDex/DUFAUXSprite"
  },
  :EARTHSHATTERER => {
    :name => _INTL("Code: Firma"),
    :desc => _INTL("In its initial form, its true power lies dormant, but do not underestimate this one. It will shake your world to its core.\nAnd without your core...\nYou're nothing.\nAs always.\nAll those who threaten the Earth shall burn."),
    :notes => _INTL("Torterra, as a Turtwig, was present during the attack on Alamissa. It was brought back by one of the surviving members of the attack, who would later go to become an Admin. Torterra's bitterness towards the attack on Alamissa has influenced its current form. The fires that scared it do so no more. When its power is unleashed, it controls the flames now. If Torterra was never destroyed, one may imagine that it would abandon its tower and hunt down the ones who destroyed its home. Unfortunately for it, that will never happen. "),
    :species => :TORTERRA,
    :form => "Rift Form",
    :altForm => "Rift Form 2",
    :x => -2,
    :y => 36,
    :formOverride => "Rift Form 2"
  },
  :CHITWO => {
    :name => _INTL("Code: Dos"),
    :desc => _INTL("This Finneon once belonged to a Trainer, now deceased, from Artrica Island!\nIt wants nothing more than to fight!\nAlly!\nFoe!\nNo such words matter to it when the fight begins! Better be ready to put the dukes up!"),
    :notes => _INTL("This fish does not care about Team Xen. All it wants to do is constantly fight tough opponents. The opponents it faced down in The Underground weren't much to write home about. Before the Interceptor appeared, it was planning on leaving its tower so that it could face its toughest opponent yet: The Xenpurgis. It's unknown whether or not it could defeat the Xenpurgis, but it doesn't care. Fighting a worthy opponent and dying is a noble way to die in its eyes. From fists to fury and from fury to death."),
    :species => :FINNEON,
    :form => "Xenpurgis Guardian 2",
    :x => -2,
    :y => 12,
  },
  :TWINDANCERS => {
    :name => _INTL("Code: Sapphie"),
    :desc => _INTL("Both danced underneath the large cherry blossom tree on Route 2.\nWhen one was taken, the other followed.\nNever separated.\nThey dance forever, together,\nunderneath the pale shadow of the moon.\nThose who dare to separate them shall know true wrath."),
    :notes => _INTL("Both Petilil are native to Route 2. When the moon would come out, both would practice dancing together. This is a secret, so tell no one. These two are lovers that have died and were reborn as Pokémon. They were killed in the ancient war that involved all 7 kingdoms during a performance.\nThey say that their dances could ease the hearts of all who gazed upon them. This was later proven to be false, as the Queen of the Ghovora held their performance as nothing more than a cheap attempt to gain her favor."),
    :species => :LILLIGANT,
    :form => "Rift Form",
    :altForm => "Rift Form 2",
    :x => 0,
    :y => 0,
    :spriteOverride => "Graphics/Pictures/RiftDex/TWINDANCERSSprite",
  },
  :KINGSOFAPPLES => {
    :name => _INTL("Code: Vinra"),
    :desc => _INTL("Rumor has it that this apple was picked during Team Xen's invasion of Terajuma Island.\n\nThis tree wants nothing more than to spread its vines and feed its young.\nHey.\nYou look kind of tasty. Wanna be its first meal?\nI hear it's an honor to die to a Dragon."),
    :notes => _INTL("This Applin hails from Jirukala Cavern on Terajuma Island. It was captured by a regular Grunt and brought back to the Xen HQ. The previous specimen meant to take its slot for the Xenpurgis could not reach the potential it wanted. With Applin's tie to Hydrapple, it was taken and used as its replacement. Hydrapple unfortunately found itself in a situation that could not be worse. As a pacifist, it refuses to fight. When the scientists at the Xen Lab noticed this, they enhanced its Rift Matter to force it to obey and fight."),
    :species => :HYDRAPPLE,
    :form => "Rift Form",
    :x => 0,
    :y => 26,
  },
  :QUEENNIHILEGO => {
    :name => _INTL("Code: Regalia"),
    :desc => _INTL("The Queen of all Rift Pokémon. All forms of corruption are born from her. Additionally, all forms of corruption are at her disposal. She connects her appendages to all corners of the world to release her young. Then, in turn, they harvest data from all living things."),
    :notes => _INTL("The Queen's power has been amplified using the aura of Anju and the physical husk of Vitus. Her purpose is to gather as much data from all corners of the world for her own Queen, Storm-Nym. Her appendages have the same properties as Rift Gyarados: they can extend themselves, shift into other dimensions and worlds, and release her offspring. Because of this power, the Queen is completely stationary. Not that it matters, though. Her defenses cannot be penetrated. No Pokémon is strong enough to shatter this gem. I have to hand it to Lorna...she knew what she was doing with this one. Regardless, her best is my worst, after all. She laid out her Queen. Just wait for my King."),
    :species => :NIHILEGO,
    :form => "Queen Form",
    :x => 70,
    :y => 80,
    :hideShadow => true,
  },
  :RIFTWEAVILE => {
    :name => _INTL("Code: ???"),
    :desc => _INTL(""),
    :species => :WEAVILE,
    :form => "Rift Form",
    :x => 10,
    :y => 35,
    :hideShadow => true,
    :hideNotes => true
  },
  :RIFTNIHILEGO => {
    :name => _INTL("Code: Scypo"),
    :desc => _INTL("These forms of Nihilego lacks individuality. They all work together in a hive-mind to harvest data to bring back to the Queen. Its shell is hard and hard to scratch. For the normal person, running is the only option."),
    :species => :NIHILEGO,
    :form => "Rift Form",
    :x => -30,
    :y => -35,
    :hideShadow => true,
    :hideNotes => true
  },
}

def getRiftSpriteSwitch(sym)
  return (sym.to_s + "Sprite").to_sym
end

def getRiftDefeatedSwitch(sym)
  return (sym.to_s + "Defeated").to_sym
end

class Pokedex
  alias _riftDex_setSeen setSeen unless method_defined?(:_riftDex_setSeen)
  def setSeen(pokemon)
    _riftDex_setSeen(pokemon)
    if pokemon.isRift?
      formname = $cache.pkmn[pokemon.species].forms[pokemon.form]
      RIFTDATA.each do |rift, riftData|
        if riftData[:species] == pokemon.species && (riftData[:form] == formname || riftData[:altForm] == formname)
          $game_switches[getRiftSpriteSwitch(rift)] = true
        end
      end
    end
  end
end

# Class for information screen

class Scene_RiftDex_Base

  PATH = "Graphics/Pictures/RiftDex/"

  def prepareRiftDexInfo(page = 0)
    @riftData = RIFTDATA[@rift].clone

    @sprites = {}
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites["background"] = IconSprite.new(0, 0, @viewport)
    if page == 2
      graphic = PATH + "#{@rift}Notes"
      graphic = PATH + "notes" if !pbResolveBitmap(graphic)
    else
      graphic = PATH + "#{@rift}"
      graphic = PATH + "Rift" if !pbResolveBitmap(graphic)
    end
    @sprites["background"].setBitmap(graphic)
    @sprites["background"].z = 255
    @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
    @sprites["overlay"].z = 256

    mon = $cache.pkmn[@riftData[:species], @riftData[:form]]
    if page == 2
      drawNotes(mon)
    else
      drawSprite
      drawAbilities(mon) if page == 0
      drawText(mon) if page == 1
    end

    prepareRiftDexHeader(page)
  end

  def prepareRiftDexHeader(page = 0)
    return if @riftData[:hideNotes] && page == 2
    @sprites["heading"] = IconSprite.new(0, 0, @viewport)
    @sprites["heading"].setBitmap(PATH + "pageHeading#{$game_switches[:RiftNotes] ? "Notes" : ""}Blank")
    @sprites["heading"].z = 255
    @sprites["curpage"] = IconSprite.new(0, 0, @viewport)
    @sprites["curpage"].setBitmap(PATH + "pageHeading#{page}")
    @sprites["curpage"].z = 255
  end

  def drawAbilities(mon)
    bitmap = @sprites["overlay"].bitmap
    pbSetSystemFont(bitmap)

    x = 230
    y = 68
    width = 250
    lineheight = 32
    bossspecies = @rift
    bossspecies = (@rift.to_s + "1").intern if @rift == :RIFTGYARADOS
    bossdata = $cache.bosses[bossspecies]
    @shieldCount = (bossdata&.shieldCount || 0).to_s
    text = "<c=" + colorToRgb16(Color.new(200, 125, 55)) + ">" + _INTL("Shield Strength: ") + "</c>" + "<c=" + colorToRgb16(Color.new(252, 226, 131)) + ">" + @shieldCount + "</c>"
    chars = getFormattedText(bitmap, x, y, width, -1, text, lineheight)
    drawFormattedChars(bitmap, chars)
    y = chars[-1][2] + lineheight
    @abilityText = []

    abilities = [mon.Abilities[0]]
    abilities.push($cache.pkmn[@riftData[:species], @riftData[:altForm]].Abilities[0]) if @riftData[:altForm]
    abilities.each { |ability|
      next if @abilityText.any? { |m| m[0] == ability }
      name = getAbilityName(ability)
      desc = getAbilityDesc(ability)

      pbSetSystemFont(bitmap)
      lineheight = 32
      text = "<c=" + colorToRgb16(Color.new(200, 125, 55)) + ">" + name + "</c>"
      chars = getFormattedText(bitmap, x, y, width, -1, text, lineheight)
      drawFormattedChars(bitmap, chars)
      y = chars[-1][2] + lineheight

      pbSetSmallFont(bitmap)
      lineheight = 24
      text = "<c=" + colorToRgb16(Color.new(252, 226, 131)) + ">" + desc + "</c>"
      chars = getFormattedText(bitmap, x, y, width, -1, text, lineheight)
      drawFormattedChars(bitmap, chars)
      y = chars[-1][2] + lineheight

      @abilityText.push([name, desc])
    }
  end

  def drawText(mon)
    bitmap = @sprites["overlay"].bitmap
    pbSetSmallFont(bitmap)

    @curtext = $game_switches[getRiftDefeatedSwitch(@rift)] ? @riftData[:desc] : _INTL("[Attached text file could not be parsed. Please check back later.]")
    drawFormattedTextEx(bitmap, 230, 72, 250, @curtext, Color.new(252, 226, 131), Color.new(0, 0, 0, 0), 24)
  end

  def drawTypes(mon)
    bitmap = @sprites["overlay"].bitmap
    rect = Rect.new(0, 0, 64, 28)
    type1image = Bitmap.new(sprintf(PATH + "type%s", mon.Type1))
    if mon.Type2.nil?
      if mon.species == :ARCEUS
        type1image = Bitmap.new(PATH + "normal")
        bitmap.blt(260, 132, type1image, rect)
      else
        bitmap.blt(240, 136, type1image, rect)
      end
    else
      type2image = Bitmap.new(sprintf(PATH + "type%s", mon.Type2))
      bitmap.blt(240, 126, type1image, rect)
      bitmap.blt(240, 146, type2image, rect)
    end
  end

  def drawStats(mon)
    bitmap = @sprites["overlay"].bitmap
    stats = mon.BaseStats
    for i in 0..5
      colors = [Color.new(84, 179, 36), Color.new(46, 115, 24)]
      colors = [Color.new(179, 143, 36), Color.new(127, 93, 26)] if stats[i] < 192
      colors = [Color.new(179, 95, 36), Color.new(127, 60, 26)] if stats[i] < 128
      colors = [Color.new(179, 54, 54), Color.new(127, 38, 38)] if stats[i] < 64 || mon.species == :ARCEUS
      width = (stats[i] * 90 / 255).to_grid
      statbitmap = BitmapWrapper.new(90, 8)
      statbitmap.fill_rect(Rect.new(0, 2, width, 6), colors[0])
      statbitmap.fill_rect(Rect.new(0, 0, width, 2), colors[1])
      x = 262 + 120 * (i / 3)
      y = 176 + 18 * (i % 3)
      if mon.species == :ARCEUS
        x -= 6 if i % 2 == 0
        y += 4 if i % 2 == 1
        y += 2 if i % 3 == 0
        x -= 2 if i % 3 == 1
      end
      bitmap.blt(x, y, statbitmap, statbitmap.rect)
    end
  end

  def drawSprite
    bitmap = @sprites["overlay"].bitmap
    species = @riftData[:species]
    form = @riftData[:formOverride] || @riftData[:form]
    shiny = @riftData[:shiny]
    gender = @riftData[:gender]
    if !$game_switches[getRiftSpriteSwitch(@rift)]
      sprite = Bitmap.new(PATH + "nodata")
      bitmap.blt(24, 68, sprite, sprite.rect)
    else
      if !@riftData[:hideShadow]
        shadowbitmap = PokemonShadowSprite.new(@viewport)
        shadowbitmap = shadowbitmap.drawEllipse(36, Color.new(33, 33, 33))
        bitmap.blt(48, 194, shadowbitmap, Rect.new(0, 0, shadowbitmap.width, shadowbitmap.height - 2))
      end
      if @riftData[:spriteOverride]
        sprite = Bitmap.new(@riftData[:spriteOverride])
        bitmap.blt(24, 68, sprite, sprite.rect)
      else
        riftbitmap = pbPokemonBitmap(species, shiny, false, gender, form)
        bitmap.blt(24, 68, riftbitmap, Rect.new(@riftData[:x], @riftData[:y], 188, 150))
      end
    end
  end

  def drawNotes(mon)
    return if @riftData[:hideNotes]
    bitmap = @sprites["overlay"].bitmap
    pbSetSmallFont(bitmap)

    @curtext = $game_switches[getRiftDefeatedSwitch(@rift)] ? @riftData.fetch(:notes, _INTL("[No additional text found.]")) : _INTL("[Attached text file could not be parsed. Please check back later.]")
    drawFormattedTextEx(bitmap, 18, 50, 480, @curtext, Color.new(252, 226, 131), Color.new(13, 13, 28, 0), 24)
  end

  def ttsRift(ttsIndex, interrupt = false)
    text = ""
    if ttsIndex != 2
      species = @riftData[:species]
      form = @riftData[:form]
      name = getMonName(species)
      mon = $cache.pkmn[species, form]
      type1 = mon.Type1
      type2 = mon.Type2
      type2 = :QMARKS if @rift == :RIFTCHANDELURE
      basestats = mon.BaseStats.clone
      for i in 0...basestats.length
        basestats[i] = (basestats[i] / 255.0 * 100).round(0)
        basestats[i] = 1 if basestats[i] == 0
      end
      text = _INTL("Rift {1}. {5}. Shield Count: {6}. {2}{3} type. {4} abilities. ", name, type1, type2 ? _INTL(" and {1}", type2) : "", @abilityText.length, @riftData[:name], @shieldCount) if ttsIndex == 0
      text = _INTL("HP: {1} %, Attack: {2} %, Defense: {3} %, Special Attack: {4} %, Special Defense: {5} %, Speed: {6} %", basestats[0], basestats[1], basestats[2], basestats[3], basestats[4], basestats[5]) if ttsIndex == 1
    else
      if @page == 0
        text = ""
        abil = 1
        @abilityText.each { |a|
          name, desc = a
          text += _INTL("Ability {1}: {2}. Description: {3} ", abil, name, desc)
          abil += 1
        }
      else
        text = @curtext
      end
    end
    tts(text, interrupt)
  end
end

class Scene_RiftDex_Info < Scene_RiftDex_Base
  attr_accessor :background
  attr_accessor :index

  def initialize(rift, index, riftNotes)
    @rift = rift
    @index = index
    @riftNotes = riftNotes
    @page = 0
    @ttsIndex = -1
  end

  def main
    prepareRiftDexInfo(@page)
    tts(_INTL("Rift Dex Screen: Use Up or Down keys to switch entries. Use Left or Right keys to switch pages. Use Ctrl + Up or Down keys to navigate between lines."))
    Graphics.transition
    tts(_INTL("Rift {1} of {2}: {3}.", @index + 1, @riftNotes.length, RIFTDATA[@rift][:name])) if @riftNotes.length > 1
    loop do
      Graphics.update
      Input.update
      update
      if $scene != self
        break
      end
    end
    Graphics.freeze
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end

  def update
    pbUpdateSpriteHash(@sprites)
    if Input.press?(Input::CTRL) && Input.trigger?(Input::DOWN) # Next TTS line
      changeTTS(1)
    elsif Input.press?(Input::CTRL) && Input.trigger?(Input::UP) # Prev TTS line
      changeTTS(-1)
    elsif Input.trigger?(Input::DOWN)
      changeRift(1)
    elsif Input.trigger?(Input::UP)
      changeRift(-1)
    elsif Input.trigger?(Input::RIGHT)
      changePage(1)
    elsif Input.trigger?(Input::LEFT)
      changePage(-1)
    end
    if Input.trigger?(Input::B)
      # Switch to map screen
      pbPlayCancelSE()
      $scene = Scene_RiftDex.new(@index)
      return
    end
  end

  def redrawPage
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
    @rift = @riftNotes[@index]
    prepareRiftDexInfo(@page)
    $tts&.clear
  end

  def changeRift(increment)
    oldindex = @index
    loop do
      @index += increment
      if @index >= @riftNotes.length
        @index = 0
      elsif @index < 0
        @index = @riftNotes.length - 1
      end
      break unless !$game_switches[@riftNotes[@index]]
    end
    return if @index == oldindex

    pbPlayDecisionSE()
    redrawPage
    @ttsIndex = -1
    tts(_INTL("Rift {1} of {2}: {3}.", @index + 1, @riftNotes.length, RIFTDATA[@rift][:name])) if @riftNotes.length > 1
  end

  def changePage(increment)
    @page += increment
    maxPage = $game_switches[:RiftNotes] ? 2 : 1
    if @page > maxPage
      @page = 0
    end
    if @page < 0
      @page = maxPage
    end
    @ttsIndex = -1

    pbPlayDecisionSE
    redrawPage
    if @page != 0
      ttsRift(2, true)
    end
  end

  def changeTTS(increment)
    oldindex = @ttsIndex
    @ttsIndex += increment
    if @ttsIndex > 2
      @ttsIndex = 0
    end
    if @ttsIndex < 0
      @ttsIndex = 2
    end
    @ttsIndex = 0 if @page == 2 || oldindex == -1
    return if @ttsIndex == oldindex

    ttsRift(@ttsIndex, true)
  end
end

class Scene_BossDex_Battle < Scene_RiftDex_Base
  def pbStartScene(rifts)
    @index = 0
    @page = 0
    @rifts = rifts
    @ttsIndex = -1
    pbDrawPage
    tts(_INTL("Rift Dex Screen: Use Up or Down keys to switch entries. Use Left or Right keys to switch pages. Use Ctrl + Up or Down keys to navigate between lines."))
    pbFadeInAndShow(@sprites)
    tts(_INTL("Rift {1} of {2}: {3}.", @index + 1, @rifts.length, RIFTDATA[@rift][:name])) if @rifts.length > 1
    loop do
      Graphics.update
      Input.update
      update
      break if @close
    end
  end

  def pbEndScene
    pbFadeOutAndHide(@sprites)
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end

  def pbSwitchRiftNotes
    pbPlayDecisionSE()
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
    pbDrawPage
    $tts&.clear
  end

  def pbDrawPage
    @rift = @rifts[@index]
    prepareRiftDexInfo(@page)
    pbAddArrows
  end

  def pbAddArrows
    if @index != 0
      @sprites["uparrow"] = AnimatedSprite.new("Graphics/Pictures/uparrow", 8, 28, 40, 2, @viewport)
      @sprites["uparrow"].x = Graphics.width / 2 - @sprites["uparrow"].framewidth / 2
      @sprites["uparrow"].y = 32
      @sprites["uparrow"].z = 256
      @sprites["uparrow"].play
    end
    if @index != @rifts.length - 1
      @sprites["downarrow"] = AnimatedSprite.new("Graphics/Pictures/downarrow", 8, 28, 40, 2, @viewport)
      @sprites["downarrow"].x = Graphics.width / 2 - @sprites["downarrow"].framewidth / 2
      @sprites["downarrow"].y = Graphics.height - @sprites["downarrow"].frameheight
      @sprites["downarrow"].z = 256
      @sprites["downarrow"].play
    end
  end

  def update
    pbUpdateSpriteHash(@sprites)
    if Input.press?(Input::CTRL) && Input.trigger?(Input::DOWN) # Next TTS line
      changeTTS(1)
    elsif Input.press?(Input::CTRL) && Input.trigger?(Input::UP) # Prev TTS line
      changeTTS(-1)
    elsif Input.trigger?(Input::UP)
      changeRift(-1)
    elsif Input.trigger?(Input::DOWN)
      changeRift(1)
    elsif Input.trigger?(Input::LEFT)
      changePage(-1)
    elsif Input.trigger?(Input::RIGHT)
      changePage(1)
    elsif Input.trigger?(Input::B) || Input.trigger?(Input::Z)
      pbPlayCancelSE()
      @close = true
    end
  end

  def changeRift(increment)
    oldindex = @index
    loop do
      @index += increment
      if @index >= @rifts.length
        @index = 0
      elsif @index < 0
        @index = @rifts.length - 1
      end
      break unless !$game_switches[@rifts[@index]]
    end
    return if @index == oldindex

    pbSwitchRiftNotes
    @ttsIndex = -1
    tts(_INTL("Rift {1} of {2}: {3}.", @index + 1, @rifts.length, RIFTDATA[@rift][:name])) if @rifts.length > 1
  end

  def changePage(increment)
    @page += increment
    maxPage = $game_switches[:RiftNotes] ? 2 : 1
    if @page > maxPage
      @page = 0
    end
    if @page < 0
      @page = maxPage
    end
    @ttsIndex = -1

    pbSwitchRiftNotes
    if @page != 0
      ttsRift(2, true)
    end
  end

  def changeTTS(increment)
    oldindex = @ttsIndex
    @ttsIndex += increment
    if @ttsIndex > 2
      @ttsIndex = 0
    end
    if @ttsIndex < 0
      @ttsIndex = 2
    end
    @ttsIndex = 0 if @page == 2
    return if @ttsIndex == oldindex || oldindex == -1

    ttsRift(@ttsIndex, true)
  end
end

def receiveRiftReadout(sym)
  if !$game_switches[:RiftDex]
    pbFlash(Color.new(255, 255, 255, 255), 10)
    pbSEPlay("PRSFX- Aura Sphere1")
    Kernel.pbMessage(_INTL("The CyberNav is now able to receive data on Dimensional Rift Pokémon."))
    $game_switches[:RiftDex] = true
  end

  data = RIFTDATA.find { |key, value| key == sym }[1]
  if !data
    dp("Could not find Rift Dex data for entry #{sym.inspect}. please report thx <3")
    return
  end

  3.times { Kernel.pbMessage(_INTL("Downloading...")) }
  pbSEPlay("PRSFX- Foresight2")
  Kernel.pbMessage(_INTL("This data file contains data for {1}.", data[:name]))
  Kernel.pbMessage(_INTL("More info on {1} is located in the Rift Dex.", data[:name]))

  if !$game_switches[$cache.FEData[:DIMENSIONAL].fieldAppSwitch]
    Kernel.pbMessage(_INTL("Additional data found."))
    pbReceiveFieldReadout(:DIMENSIONAL)
  end
  pbSetSwitch(Switches[sym], true)
end
