def passwordHelloEizen
  Kernel.pbMessage(_INTL("This is not a valid password!"))
  pbCommonEvent(134)
  pbSEPlay("microsam", 100, 100)
  Kernel.pbMessage(_INTL("G R E E T I N G S"))
end

def passwordMintPack
  return if $game_switches[:GameStartPasswords]
  items_to_give = {
    :SERIOUSMINT => 5,
    :LONELYMINT => 5,
    :ADAMANTMINT => 5,
    :NAUGHTYMINT => 5,
    :BRAVEMINT => 5,
    :BOLDMINT => 5,
    :IMPISHMINT => 5,
    :LAXMINT => 5,
    :RELAXEDMINT => 5,
    :MODESTMINT => 5,
    :MILDMINT => 5,
    :RASHMINT => 5,
    :QUIETMINT => 5,
    :CALMMINT => 5,
    :GENTLEMINT => 5,
    :CAREFULMINT => 5,
    :SASSYMINT => 5,
    :TIMIDMINT => 5,
    :HASTYMINT => 5,
    :JOLLYMINT => 5,
    :NAIVEMINT => 5
  }
  items_to_give.each_pair { |item, quantity|
    $PokemonBag.pbStoreItem(item, quantity)
  }
  Kernel.pbMessage(_INTL("\\PN received a package of mints."))
end

def passwordExpAll
  return if $game_switches[:GameStartPasswords]
  $PokemonBag.pbStoreItem(:EXPALL, 1)
  $game_switches[:Exp_All_On] = true
  Kernel.pbMessage(_INTL("\\PN received {1}.", getItemName(:EXPALL, :a)))
end

def passwordShinyCharm
  return if $game_switches[:GameStartPasswords]
  $PokemonBag.pbStoreItem(:SHINYCHARM, 1)
  Kernel.pbMessage(_INTL("\\PN received {1}.", getItemName(:SHINYCHARM, :a)))
end

def passwordGoldenTools
  return if $game_switches[:GameStartPasswords]
  items_to_give = {
    :GOLDENHAMMER => 1,
    :GOLDENAXE => 1,
    :GOLDENLANTERN => 1,
    :GOLDENSURFBOARD => 1,
    :GOLDENCLAWS => 1,
    :GOLDENDRIFTBOARD => 1,
    :GOLDENGAUNTLET => 1,
    :GOLDENWINGS => 1,
    :GOLDENSCUBAGEAR => 1,
    :GOLDENJETPACK => 1,
  }
  items_to_give.each_pair { |item, quantity|
    $PokemonBag.pbStoreItem(item, quantity)
  }
  Kernel.pbMessage(_INTL("\\PN received a set of shiny tools to traverse difficult terrain."))
end

def passwordMegaZRing
  return if $game_switches[:GameStartPasswords]
  $PokemonBag.pbStoreItem(:MEGARING, 1)
  Kernel.pbMessage(_INTL("\\PN received {1}!", getItemName(:MEGARING, :a)))
end

def passwordRemotePC
  return if $game_switches[:GameStartPasswords]
  $PokemonBag.pbStoreItem(:REMOTEPC, 1)
  Kernel.pbMessage(_INTL("\\PN received {1}.", getItemName(:REMOTEPC, :a)))
end

def passwordPowerPack
  return if $game_switches[:GameStartPasswords]
  items_to_give = {
    :HPCARD => 1,
    :ATKCARD => 1,
    :DEFCARD => 1,
    :SPATKCARD => 1,
    :SPDEFCARD => 1,
    :SPEEDCARD => 1,
    :MACHOBRACE => 1,
  }
  items_to_give.each_pair { |item, quantity|
    $PokemonBag.pbStoreItem(item, quantity)
  }
  Kernel.pbMessage(_INTL("\\PN received a package of EV-training gear."))
end

def addPasswordsUserShouldKnow
  if $Unidata[:BadgeCount]
    pbLearnPassword('nointro') if $Unidata[:BadgeCount] >= 1
    pbLearnPassword('terajuma') if $Unidata[:BadgeCount] >= 5
  end
end

def runPostPasswordMaintenance
  # flip all the field app switches
  if $game_switches[:All_Field_Notes]
    $game_switches[:Field_Notes] = true
    $cache.FEData.each { |key, data|
      $game_switches[data.fieldAppSwitch] = true
    }
  end
end
