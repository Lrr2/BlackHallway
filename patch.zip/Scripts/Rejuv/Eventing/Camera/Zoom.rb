class ZoomMap
  attr_accessor :goal
  attr_accessor :speed

  def initialize(goal, speed, byFrames = false)
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    self.goal = goal
    self.setSpeed(speed, byFrames)
    @sprites = {}
    @sprites["map"] = Sprite.new(@viewport)
    @sprites["map"].bitmap =  Graphics.snap_to_bitmap
    @sprites["map"].center_origins
    @sprites["map"].x = Graphics.width / 2
    @sprites["map"].y = Graphics.height / 2
    Graphics.update
  end

  def setSpeed(speed, byFrames = false)
    if byFrames
      self.speed = 1.0 / (speed * 2)
    else
      self.speed = speed
    end
  end

  def update
    if @sprites
      @sprites["map"].bitmap.clear
      messagewindow = $game_temp.message_window
      savewindow = $game_temp.save_window
      cmdwindow = $game_temp.cmd_window
      ready_window = $game_temp.ready_window
      pausemenu = $game_temp.pause_menu_scene
      partymenu = $game_temp.party_menu_scene
      vs_window_main = $game_temp.vs_window_main
      vs_window_player = $game_temp.vs_window_player
      vs_window_opp = $game_temp.vs_window_opp
      vs_window_vs = $game_temp.vs_window_vs
      blessings = $game_temp.blessing_overlay if $game_temp.blessing_overlay&.visible
      messagewindow.visible = false if messagewindow
      savewindow.visible = false if savewindow
      cmdwindow.visible = false if cmdwindow
      ready_window.visible = false if ready_window
      pausemenu.pbHideMenu if pausemenu
      partymenu.hideHUD if partymenu
      blessings.pbHideMenu if blessings
      vs_window_main.visible = false if vs_window_main
      vs_window_player.visible = false if vs_window_player
      vs_window_opp.visible = false if vs_window_opp
      vs_window_vs.visible = false if vs_window_vs
      #@sprites["map"].bitmap = self.goal >= 1 ? Graphics.snap_to_bitmap : makeMapScreenshot($game_map.map_id)
      @sprites["map"].bitmap = Graphics.snap_to_bitmap
      @sprites["map"].center_origins
      @sprites["map"].x = Graphics.width / 2
      @sprites["map"].y = Graphics.height / 2
      messagewindow.visible = true if messagewindow
      savewindow.visible = true if savewindow
      cmdwindow.visible = true if cmdwindow
      ready_window.visible = true if ready_window
      pausemenu.pbShowMenu if pausemenu && !savewindow
      partymenu.showHUD if partymenu
      blessings.pbShowMenu if blessings
      vs_window_main.visible = true if vs_window_main
      vs_window_player.visible = true if vs_window_player
      vs_window_opp.visible = true if vs_window_opp
      vs_window_vs.visible = true if vs_window_vs

      if @sprites["map"].zoom != self.goal
        if @sprites["map"].zoom < self.goal
          altspeed = self.goal - @sprites["map"].zoom
          @sprites["map"].zoom += [self.speed, altspeed].min
        else
          altspeed = @sprites["map"].zoom - self.goal
          @sprites["map"].zoom -= [self.speed, altspeed].min
        end
      else
        blessings.redraw if blessings&.need_redraw
      end
      if $game_system&.background_zoom != [@goal, @speed]
        $game_system.background_zoom = [@goal, @speed]
      end

    else
      dispose
    end
  end


  def dispose
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end

  def disposed?
    @viewport.disposed?
  end

end


def pbZoomMap(goal, speed, byFrames = false)
  $game_temp.blessing_overlay&.need_redraw = true
  if !$game_temp.background_zoom
    $game_temp.background_zoom = ZoomMap.new(goal, speed, byFrames)
  else
    $game_temp.background_zoom.goal = goal
    $game_temp.background_zoom.setSpeed(speed, byFrames)
  end
end


def pbDisposeZoomMap
  if $game_temp.background_zoom
    $game_temp.background_zoom.dispose
    $game_temp.background_zoom = nil
  end
  Graphics.update
end

Events.onMapUpdate += proc { |_sender, _e|
  next if !$Trainer
  if $game_temp.background_zoom.is_a?(ZoomMap) && !pbIsFaded?
    $game_temp.background_zoom.update
    sprites = $game_temp.background_zoom.instance_variable_get(:@sprites)
    if $game_temp.background_zoom.goal == 1 && sprites["map"].zoom == 1
      pbDisposeZoomMap
    end
  end
}

#===============================================================================
#Pause Menu Rewriting
#===============================================================================
#If you're using an alternate pause UI,
#you should probably delete this whole section.


class Scene_Map

  def call_menu
    $game_screen.getTimeCurrent
    $game_player.straighten
    $game_map.update
    $game_temp.pause_menu_scene = PokemonMenu_Scene.new
    pause_menu_screen = PokemonMenu.new($game_temp.pause_menu_scene)
    pause_menu_screen.pbStartPokemonMenu
    $game_temp.menu_calling = false
    $game_screen.getTimeCurrent(true)
    $game_map.refresh
    $game_temp.pause_menu_scene = nil
    $game_screen.getTimeCurrent
  end

end

class PokemonMenu_Scene
  def pbShowMenu
    pbStartScene if @sprites["cmdwindow"] && @sprites["cmdwindow"].disposed?
    @sprites["cmdwindow"].visible = true if @sprites["cmdwindow"]
    @sprites["infowindow"].visible = @infostate if @sprites["infowindow"]
    @sprites["helpwindow"].visible = @helpstate if @sprites["helpwindow"]
  end

  def pbHideMenu
    @sprites["cmdwindow"].visible = false if @sprites["cmdwindow"]
    @sprites["infowindow"].visible = false if @sprites["infowindow"]
    @sprites["helpwindow"].visible = false if @sprites["helpwindow"]
  end
end

class PokemonReadyMenu_Scene
  alias __zoom_readyMenu pbStartScene unless method_defined?(:__zoom_readyMenu)
  def pbStartScene(*args)
    __zoom_readyMenu(*args)
    $game_temp.ready_window = @sprites["cmdwindow"]
  end
end

class Spriteset_Map

  def update
    updateOldFL
    if !@@hud
      $game_temp.party_menu_scene = HUD.new(@viewport1b)
      @@hud = $game_temp.party_menu_scene
    end
    @@hud.update
  end

  class HUD
    def showHUD
      @sprites.each { |name, spr| spr.visible = true if spr }
    end

    def hideHUD
      @sprites.each { |name, spr| spr.visible = false if spr }
    end
  end
end

#===============================================================================
#Sprite Utilities
#===============================================================================
#If you have these utilities defined elsewhere, you can delete this section.
class Sprite
  #Utility from Marin
  # Centers the sprite by setting the origin points to half the width and height
  def center_origins
    return if !self.bitmap
    self.ox = self.bitmap.width / 2
    self.oy = self.bitmap.height / 2
  end

  #Utility from Luka
  #-----------------------------------------------------------------------------
  #  gets zoom
  #-----------------------------------------------------------------------------
  def zoom
    return self.zoom_x
  end
  #-----------------------------------------------------------------------------
  #  sets all zoom values
  #-----------------------------------------------------------------------------
  def zoom=(val)
    self.zoom_x = val
    self.zoom_y = val
  end

end


#===============================================================================
#Game Temp and Message Window rewriting
#===============================================================================
#This code is to allow the ZoomMap class to hide these windows
#when taking a screenshot, so that the text won't be zoomed in.
class Game_System
  attr_accessor :background_zoom
end

class Game_Temp
  attr_accessor :background_zoom
  attr_accessor :message_window
  attr_accessor :cmd_window
  attr_accessor :save_window
  attr_accessor :ready_window
  attr_accessor :pause_menu_scene
  attr_accessor :pause_menu_screen
  attr_accessor :party_menu_scene
  attr_accessor :vs_window_main
  attr_accessor :vs_window_player
  attr_accessor :vs_window_opp
  attr_accessor :vs_window_vs
  attr_accessor :blessing_overlay

  def zoom_amount
    @background_zoom ? @background_zoom.goal : 1
  end

  def vs_window_main
    return @vs_window_main if !@vs_window_main&.disposed?
  end

  def vs_window_player
    return @vs_window_player if !@vs_window_player&.disposed?
  end

  def vs_window_opp
    return @vs_window_opp if !@vs_window_opp&.disposed?
  end

  def vs_window_vs
    return @vs_window_vs if !@vs_window_vs&.disposed?
  end
end

def Kernel.pbCreateMessageWindow(viewport = nil, skin = nil)
  $game_temp.message_window = Window_AdvancedTextPokemon.new("")
  msgwindow = $game_temp.message_window
  if !viewport
    msgwindow.z = 99999
  else
    msgwindow.viewport = viewport
  end
  msgwindow.visible = true
  msgwindow.letterbyletter = true
  msgwindow.back_opacity = MessageConfig::WindowOpacity
  pbBottomLeftLines(msgwindow, 2)
  $game_temp.message_window_showing = true if $game_temp
  $game_message.visible = true if $game_message
  skin = MessageConfig.pbGetSpeechFrame() if !skin
  msgwindow.setSkin(skin)
  return msgwindow
end

def Kernel.pbDisposeMessageWindow(msgwindow)
  $game_temp.message_window_showing = false if $game_temp
  $game_message.visible = false if $game_message && $game_temp.message_window
  msgwindow.dispose if msgwindow
end

def pbBattleAnimation(bgm = nil, trainerid = -1, trainername = "", switch_sprites = false, vsoutfit = 0)
  handled = false
  savedBGS, savedBGM, savedBGMpos = pbPauseMusicToResumeLater
  pbMEFade(0.25)
  pbWait(10)
  pbMEStop
  bgm ? pbBGMPlay(bgm) : pbBGMPlay(pbGetWildBattleBGM(0))
  $game_temp.vs_window_main = Viewport.new(0, 0, Graphics.width, Graphics.height)
  viewport = $game_temp.vs_window_main
  viewport.z = 99999
  # Fade to gray a few times.
  if $Settings.photosensitive == 0 && !$game_switches[:SpeedSkip_Password] && !$game_switches[:Blindstep]
    viewport.color = Color.new(17 * 8, 17 * 8, 17 * 8)
    2.times do
      viewport.color.alpha = 0
      4.times do
        viewport.color.alpha += 45
        Graphics.update
        Input.update
        pbUpdateSceneMap
      end
      4.times do
        viewport.color.alpha -= 45
        Graphics.update
        Input.update
        pbUpdateSceneMap
      end
    end
  end
  ################################################################################
  # VS. animation, by Luka S.J.
  # Tweaked by Maruno.
  # Tweaked by Perry to allow for doubles!
  ###############################################################################
  if vsoutfit != 0 && vsoutfit != [0, 0]
    if trainerid.is_a?(Array)
      tbargraphic = sprintf("Graphics/Transitions/vsBar%s_%d", $cache.trainertypes[trainerid[0]].checkFlag?(:ID), vsoutfit[0])
      tbargraphic2 = sprintf("Graphics/Transitions/vsBar%s_%d", $cache.trainertypes[trainerid[1]].checkFlag?(:ID), vsoutfit[1])
      tbargraphic = sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid[0]].checkFlag?(:ID)) if !pbResolveBitmap(tbargraphic)
      tbargraphic2 = sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid[1]].checkFlag?(:ID)) if !pbResolveBitmap(tbargraphic2)
      tgraphic, mirrorOpp = getVsTrainerSprite(trainerid[0], vsoutfit[0])
      tgraphic2, mirrorOpp2 = getVsTrainerSprite(trainerid[1], vsoutfit[1])
    elsif !$cache.trainertypes[trainerid].nil?
      tbargraphic = sprintf("Graphics/Transitions/vsBar%s_%d", $cache.trainertypes[trainerid].checkFlag?(:ID), vsoutfit)
      tbargraphic = sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid].checkFlag?(:ID)) if !pbResolveBitmap(tbargraphic)
      tgraphic, mirrorOpp = getVsTrainerSprite(trainerid, vsoutfit)
    end
  else
    if trainerid.is_a?(Array)
      tbargraphic = sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid[0]].checkFlag?(:ID))
      tbargraphic2 = sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid[1]].checkFlag?(:ID))
      tgraphic, mirrorOpp = getVsTrainerSprite(trainerid[0])
      tgraphic2, mirrorOpp2 = getVsTrainerSprite(trainerid[1])
    elsif !$cache.trainertypes[trainerid].nil?
      tbargraphic = sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid].checkFlag?(:ID))
      if Reborn && AlterEgos.include?(trainerid)
        player = $cache.metadata[:Players].find { |player| player[:tclass] == $Trainer.trainertype }
        tgraphic = sprintf("Graphics/Characters/%s/%s%s", player[:directory], player[:vstrainer], "Alt")
        mirrorOpp = false
      else
        tgraphic, mirrorOpp = getVsTrainerSprite(trainerid)
      end
    end
  end
  if $PokemonGlobal.partner
    partnergraphic, mirrorPartner = getVsTrainerSprite($PokemonGlobal.partner[0], playersided: true)
  end
  if ((trainerid.is_a?(Array) && ((pbResolveBitmap(tbargraphic) && pbResolveBitmap(tgraphic)) ||
    (pbResolveBitmap(tbargraphic2) && pbResolveBitmap(tgraphic2)))) ||
    (pbResolveBitmap(tbargraphic) && pbResolveBitmap(tgraphic))) && !$game_switches[:VSGraphicOff]
    outfit = $Trainer ? $Trainer.outfit : 0
    # Set up
    $game_temp.vs_window_player = Viewport.new(0, Graphics.height / 3, Graphics.width / 2, 128)
    viewplayer = $game_temp.vs_window_player
    viewplayer.z = viewport.z
    $game_temp.vs_window_opp = Viewport.new(Graphics.width / 2, Graphics.height / 3, Graphics.width / 2, 128)
    viewopp = $game_temp.vs_window_opp
    viewopp.z = viewport.z
    $game_temp.vs_window_vs = Viewport.new(0, 0, Graphics.width, Graphics.height)
    viewvs = $game_temp.vs_window_vs
    viewvs.z = viewport.z
    xoffset = (Graphics.width / 2) / 10
    xoffset = xoffset.round
    xoffset = xoffset * 10

    fade = Sprite.new(viewport)
    fade.bitmap = RPG::Cache.transition("Graphics/Transitions/vsFlash")
    fade.tone = Tone.new(-255, -255, -255)
    fade.opacity = 100
    overlay = Sprite.new(viewport)
    overlay.bitmap = Bitmap.new(Graphics.width, Graphics.height)
    pbSetSystemFont(overlay.bitmap)

    bar1 = Sprite.new(viewplayer)
    pbargraphic = sprintf("Graphics/Transitions/vsBar%d_%d", $cache.trainertypes[$Trainer.trainertype].checkFlag?(:ID), outfit)
    pbargraphic = sprintf("Graphics/Transitions/vsBar%d", $cache.trainertypes[$Trainer.trainertype].checkFlag?(:ID)) if !pbResolveBitmap(pbargraphic)
    pbargraphic = sprintf("Graphics/Transitions/vsBar263") if Rejuv && $cache.trainertypes[$Trainer.trainertype].checkFlag?(:player) && outfit == 8
    bar1.bitmap = RPG::Cache.transition(pbargraphic)
    bar1.x = -xoffset
    bar2 = Sprite.new(viewopp)
    if trainerid.is_a?(Array) && !pbResolveBitmap(tgraphic)
      bar2.bitmap = RPG::Cache.transition(tbargraphic2)
    else
      bar2.bitmap = RPG::Cache.transition(tbargraphic)
    end
    bar2.x = xoffset

    vs = Sprite.new(viewvs)
    vs.bitmap = RPG::Cache.transition("Graphics/Transitions/vs")
    vs.ox = vs.bitmap.width / 2
    vs.oy = vs.bitmap.height / 2
    vs.x = Graphics.width / 2
    vs.y = Graphics.height / 1.5
    vs.visible = false
    flash = Sprite.new(viewvs)
    flash.bitmap = RPG::Cache.transition("Graphics/Transitions/vsFlash")
    flash.opacity = 0

    # Animation
    10.times do
      bar1.x += xoffset / 10
      bar2.x -= xoffset / 10
      pbWait(1)
    end
    pbSEPlay("PRSFX- Counter2")
    pbSEPlay("PRSFX- Flash")
    flash.opacity = 255 if $Settings.photosensitive == 0
    bar1.dispose
    bar2.dispose

    bar1 = AnimatedPlane.new(viewplayer)
    bar1.bitmap = RPG::Cache.transition(pbargraphic)
    player = Sprite.new(viewplayer)
    if Reborn
      type = $cache.metadata[:Players].find { |value| value[:tclass] == $cache.trainertypes[$Trainer.trainertype].ttype }
      pgraphic = sprintf(
        "Graphics/Characters/%s/%s",
        type[:directory] + ($Trainer.outfit > 0 ? " " + $Trainer.outfit.to_s : ""),
        type[:vstrainer],
      )
      mirrorPlayer = false
    else
      pgraphic, mirrorPlayer = getVsTrainerSprite($Trainer.trainertype, outfit, playersided: true)
      if Rejuv && $cache.trainertypes[$Trainer.trainertype].checkFlag?(:player)
        case outfit
          when 8 then pgraphic, mirrorPlayer = getVsTrainerSprite(:INTERCEPTORARMOR, 8, playersided: true)
          when 10, 11 then pgraphic, mirrorPlayer = getVsTrainerSprite(:INTERCEPTORARMOR, 1, playersided: true)
        end
      end
    end
    player.bitmap = RPG::Cache.transition(pgraphic)
    player.x = -xoffset
    player.mirror = true if mirrorPlayer
    partner = nil
    if $PokemonGlobal.partner && pbResolveBitmap(partnergraphic)
      partner = Sprite.new(viewplayer)
      partner.bitmap = RPG::Cache.transition(partnergraphic)
      partner.x = -xoffset + partner.width / 30
      player.x -= partner.width / 4.5
      partner.mirror = true if mirrorPartner
    end
    bar2 = AnimatedPlane.new(viewopp)
    if trainerid.is_a?(Array) && !pbResolveBitmap(tgraphic)
      bar2.bitmap = RPG::Cache.transition(tbargraphic2)
    else
      bar2.bitmap = RPG::Cache.transition(tbargraphic)
    end
    if pbResolveBitmap(tgraphic)
      trainer = Sprite.new(viewopp)
      trainer.bitmap = RPG::Cache.transition(tgraphic)
      trainer.x = xoffset
      trainer.mirror = true if mirrorOpp
      trainer.tone = Tone.new(-255, -255, -255)
      trainer.visible = false if trainer
    end
    if trainerid.is_a?(Array) && pbResolveBitmap(tgraphic2)
      trainer2 = Sprite.new(viewopp)
      trainer2.bitmap = RPG::Cache.transition(tgraphic2)
      trainer2.x = xoffset
      trainer2.mirror = true if mirrorOpp2
      trainer2.tone = Tone.new(-255, -255, -255)
      trainer2.visible = false if trainer2
    end
    if trainerid.is_a?(Array) && pbResolveBitmap(tgraphic) && pbResolveBitmap(tgraphic2)
      if switch_sprites
        trainer.x += trainer2.width / 4.5
        trainer2.x += trainer2.width / 30
      else
        trainer.x += trainer2.width / 30
        trainer2.x += trainer2.width / 4.5
      end
    end
    partner.visible = false if partner

    25.times do
      flash.opacity -= 51 if flash.opacity > 0
      bar1.ox -= 16
      bar2.ox += 16
      pbWait(1)
    end
    trainer.visible = true if trainer
    trainer2.visible = true if trainer2
    partner.visible = true if partner
    11.times do
      bar1.ox -= 16
      bar2.ox += 16
      player.x += xoffset / 10
      partner.x += xoffset / 10 if partner
      trainer.x -= xoffset / 10 if trainer
      trainer2.x -= xoffset / 10 if trainer2
      pbWait(1)
    end
    2.times do
      bar1.ox -= 16
      bar2.ox += 16
      player.x -= xoffset / 20
      partner.x += xoffset / 20 if partner
      if switch_sprites && trainer && trainer2
        trainer.x += xoffset / 20
        trainer2.x -= xoffset / 20
      elsif trainer && !trainer2
        trainer.x += xoffset / 20
      elsif trainer2 && !trainer
        trainer2.x += xoffset / 20
      else
        trainer.x -= xoffset / 20 if trainer
        trainer2.x += xoffset / 20 if trainer2
      end
      pbWait(1)
    end
    10.times do
      bar1.ox -= 16
      bar2.ox += 16
      pbWait(1)
    end
    val = 2
    flash.opacity = 255 if $Settings.photosensitive == 0
    vs.visible = true
    trainer.tone = Tone.new(0, 0, 0) if trainer
    trainer2.tone = Tone.new(0, 0, 0) if trainer2
    # Opponents name
    if trainerid.is_a?(Array) && pbResolveBitmap(tgraphic) && pbResolveBitmap(tgraphic2)
      trainername = _INTL("{1} & {2}", trainername[0], trainername[1])
    elsif trainerid.is_a?(Array) && pbResolveBitmap(tgraphic)
      trainername = trainername[0]
    elsif trainerid.is_a?(Array) && pbResolveBitmap(tgraphic2)
      trainername = trainername[1]
    end
    trainername2 = ""
    if trainername.length > 16
      splits = trainername.split(/ /, trainername[0, 16].split(/ /).length)
      trainername2 = splits.delete_at(-1)
      trainername = splits.join(" ")
    end

    # player name
    playername = $Trainer.name
    if $PokemonGlobal.partner && pbResolveBitmap(partnergraphic)
      playername =  _INTL("{1} & {2}", $Trainer.name, $PokemonGlobal.partner[1])
    end
    playername2 = ""
    if playername.length > 16
      splits = playername.split(/ /, playername[0, 16].split(/ /).length)
      playername2 = splits.delete_at(-1)
      playername = splits.join(" ")
    end
    # placing names
    textpos = [
      [playername, Graphics.width / 4 - 16, (Graphics.height / 1.5) + 10, 2, Color.new(248, 248, 248), Color.new(72, 72, 72)],
      [trainername, (3 * Graphics.width / 4) + 16, (Graphics.height / 1.5) + 10, 2, Color.new(248, 248, 248), Color.new(72, 72, 72)]
    ]
    textpos.push([trainername2, (3 * Graphics.width / 4) + 16, (Graphics.height / 1.5) + 42, 2, Color.new(248, 248, 248), Color.new(72, 72, 72)]) if trainername2 != ""
    textpos.push([playername2, Graphics.width / 4 - 16, (Graphics.height / 1.5) + 42, 2, Color.new(248, 248, 248), Color.new(72, 72, 72)]) if playername2 != ""
    pbDrawTextPositions(overlay.bitmap, textpos)

    pbSEPlay("Sword2")
    70.times do
      bar1.ox -= 16
      bar2.ox += 16
      flash.opacity -= 25.5 if flash.opacity > 0
      vs.x += val
      vs.y -= val
      val = 2 if vs.x <= (Graphics.width / 2) - 2
      val = -2 if vs.x >= (Graphics.width / 2) + 2
      pbWait(1)
    end
    30.times do
      bar1.ox -= 16
      bar2.ox += 16
      vs.zoom_x += 0.2
      vs.zoom_y += 0.2
      pbWait(1)
    end
    flash.tone = Tone.new(-255, -255, -255)
    10.times do
      bar1.ox -= 16
      bar2.ox += 16
      flash.opacity += 25.5
      pbWait(1)
    end
    # End
    player.dispose
    partner.dispose if partner
    trainer.dispose if trainer
    trainer2.dispose if trainer2
    flash.dispose
    vs.dispose
    bar1.dispose
    bar2.dispose
    overlay.dispose
    fade.dispose
    viewvs.dispose
    viewopp.dispose
    viewplayer.dispose
    viewport.color = Color.new(0, 0, 0, 255)
    handled = true
  end
  Events.onStartBattle.trigger(nil, nil)
  # End of VS. sequence script
  if !handled && !$game_switches[:Blindstep]
    if Sprite.method_defined?(:wave_amp) && rand(15) == 0
      viewport.color = Color.new(0, 0, 0, 255)
      sprite = Sprite.new
      bitmap = Graphics.snap_to_bitmap
      bm = bitmap.clone
      sprite.z = 99999
      sprite.bitmap = bm
      sprite.wave_speed = 500
      for i in 0..25
        sprite.opacity -= 10
        sprite.wave_amp += 60
        sprite.update
        sprite.wave_speed += 30
        Graphics.update
      end
      bitmap.dispose
      bm.dispose
      sprite.dispose
    elsif Bitmap.method_defined?(:radial_blur) && rand(15) == 0
      viewport.color = Color.new(0, 0, 0, 255)
      sprite = Sprite.new
      bitmap = Graphics.snap_to_bitmap
      bm = bitmap.clone
      sprite.z = 99999
      sprite.bitmap = bm
      for i in 0..15
        bm.radial_blur(i, 2)
        sprite.opacity -= 15
        Graphics.update
      end
      bitmap.dispose
      bm.dispose
      sprite.dispose
    else
      transitions = [
        "021-Normal01", "022-Normal02",
        "Battle", "battle1", "battle2", "battle3", "battle4",
        "computertr", "computertrclose",
        "hexatr", "hexatrc", "hexatzr",
      ]

      Graphics.freeze
      viewport.color = Color.new(0, 0, 0, 255)
      Graphics.transition(20, sprintf("Graphics/Transitions/%s", transitions.sample))
    end
    5.times do
      Graphics.update
      Input.update
      pbUpdateSceneMap
    end
  end
  pbPushFade
  continue = yield if block_given?
  pbPopFade
  if continue
    pbResumePausedMusic(savedBGS, savedBGM, savedBGMpos)
  else
    $game_system.bgm_unpause
    $game_system.bgs_unpause
    Kernel.pbStartOver
  end
  $PokemonGlobal.nextBattleBGM = nil
  $PokemonGlobal.nextBattleVictoryBGM = nil
  $PokemonGlobal.nextBattleBack = nil
  $PokemonEncounters.clearStepCount
  for j in 0..17
    viewport.color = Color.new(0, 0, 0, (17 - j) * 15)
    Graphics.update
    Input.update
    pbUpdateSceneMap
  end
  viewport.dispose
end
