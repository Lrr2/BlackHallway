class FancyCamera
  # Default camera speed (Default: 1)
  DEFAULT_SPEED = 1

  # Default camera shake speed (Default: 10)
  SHAKE_STRENGTH = 30

  # Increase camera speed when running (Default: true)
  INCREASE_WHEN_RUNNING = true
end
