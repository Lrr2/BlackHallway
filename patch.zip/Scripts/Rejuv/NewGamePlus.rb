def getNGPData
  cprint "Checking for WLL save..."
  if findWLLSave()
    $Unidata[:WLL] = $game_switches[:Finished_WLL] if !$Unidata[:WLL]
  end
  $Unidata[:WLL] ||= false
  cprint "done.\n"
  cprint "Checking for Reborn save..."
  if findRebornSave()
    $Unidata[:Reborn] = $game_switches[:Reborn_Save] if !$Unidata[:Reborn]
    $Unidata[:RebornPlayerName] = $game_variables[:RebornPlayerName] if !$Unidata[:RebornPlayerName]
  end
  $Unidata[:Reborn] ||= false
  $Unidata[:RebornPlayerName] ||= ["Alice", "Lucia", "Kuro", "Vero", "Ari", "Decibel"].sample
  cprint "done.\n"
  cprint "Checking for Deso save..."
  if findDesoSave()
    $Unidata[:Deso] = $game_switches[:Deso_Save] if !$Unidata[:Deso]
    $Unidata[:DesoPlayerName] = $game_variables[:DesoPlayerName] if !$Unidata[:DesoPlayerName]
  end
  $Unidata[:Deso] ||= false
  cprint "done.\n"
  if $Trainer
    $Trainer.badges = $game_variables[:LevelCap]
#    $Unidata[:ViewedPrologue] = $game_variables[16] > 4 || $Trainer.numbadges > 1 if !$Unidata[:ViewedPrologue]
#    $Unidata[:NewGamePlus] = $game_variables[659] > 20 || $Trainer.numbadges > 1 if !$Unidata[:NewGamePlus]
#    $Unidata[:BadgeCount] = $Trainer.numbadges if !$Unidata[:BadgeCount] || $Trainer.numbadges > $Unidata[:BadgeCount]
  end
  $Unidata[:ViewedPrologue] ||= false
  $Unidata[:NewGamePlus] ||= false
  $Unidata[:BadgeCount] ||= 0
  $Unidata[:FinishedV14Story] = $game_variables[812] >= 154 if !$Unidata[:FinishedV14Story]
  $Unidata[:FinishedV14StoryRene] = $game_variables[912] >= 120 if !$Unidata[:FinishedV14StoryRene]
  $Unidata[:EizenTowerSkip] = $game_variables[920] == 6 if !$Unidata[:EizenTowerSkip]
  $Unidata[:AquariumQuestSkip] = $game_variables[691] == 4 if !$Unidata[:AquariumQuestSkip]
  $Unidata[:NecrozmaSkip] = $game_variables[474] == 999 if !$Unidata[:NecrozmaSkip]
  $Unidata[:NarcyQuestComplete] = $game_variables[274] >= 42 if !$Unidata[:NarcyQuestComplete]
  $Unidata[:SpiritShogunBeaten] = $game_switches[2205] if !$Unidata[:SpiritShogunBeaten]
  $Unidata[:NullQuestComplete] = $game_variables[431] >= 16 if !$Unidata[:NullQuestComplete]
  $Unidata[:RaiCrest] = $game_switches[1662] if !$Unidata[:RaiCrest]
  $Unidata[:SuiCrest] = $game_switches[1661] if !$Unidata[:SuiCrest]
  $Unidata[:EntCrest] = $game_switches[1663] if !$Unidata[:EntCrest]
  $Unidata[:CeleCrest] = $game_switches[1936] if !$Unidata[:CeleCrest]
  $Unidata[:GlimmoraniteA] = $game_switches[2211] if !$Unidata[:GlimmoraniteA]

  saveClientData
end

def findWLLSave(path = getSavedGamesFolder)
  return true if $game_switches[:Finished_WLL] && $Unidata[:WLL]

  Dir.each_child(path) { |file|
    next if !File.directory?(path + file)
    next if !file.include?("Where Love Lies")

    newpath = path + file + "/"
    Dir.each_child(newpath) { |save|
      if save.include?(".rxdata")
        return true if checkForCompletion(newpath + save, :WLL)
      end
    }
  }
  return false
end

def findRebornSave(path = getSavedGamesFolder)
  return true if $Unidata[:Reborn] && $Unidata[:RebornPlayerName]

  Dir.each_child(path) { |file|
    next if !File.directory?(path + file)
    next if !file.include?("Reborn")

    newpath = path + file + "/"
    Dir.each_child(newpath) { |save|
      if save.include?(".rxdata")
        return true if checkForCompletion(newpath + save, :Reborn)
      end
    }
  }
  return false
end

def findDesoSave(path = getSavedGamesFolder)
  return true if $Unidata[:Deso] && $Unidata[:DesoPlayerName]

  Dir.each_child(path) { |file|
    next if !File.directory?(path + file)
    next if !file.include?("Desolation")

    newpath = path + file + "/"
    Dir.each_child(newpath) { |save|
      if save.include?(".rxdata")
        return true if checkForCompletion(newpath + save, :Deso)
      end
    }
  }
  return false
end

def getSavedGamesFolder
  if RTP.isPortable
    savefolder = "Save Data/"
    Dir.mkdir(savefolder) unless File.exist?(savefolder)
    return savefolder
  elsif System.platform[/Windows/]
    savefolder = ENV['USERPROFILE'] + "/Saved Games/"
    Dir.mkdir(savefolder) unless File.exist?(savefolder)
    return savefolder
  else
    # MKXP makes sure that this folder has been created
    # once it starts. The location differs depending on
    # the operating system:
    # Windows: %APPDATA%
    # Linux: $HOME/.local/share
    # macOS (unsandboxed): $HOME/Library/Application Support
    require 'pathname'
    return Pathname.new(System.data_directory).parent.to_s
  end
end

def checkForCompletion(file, game)
  return false if !game

  File.open("Scripts/ConversionClasses.rb") { |f| eval(f.read) }
  # file needed to check old classes
  trainer = nil
  framecount = nil
  game_system = nil
  pokemonSystem = nil
  mapid = nil
  switches = []
  variables = []
  oldSaveFormat = false
  begin
    File.open(file) { |f|
      t = Marshal.load(f)
      if !t.is_a?(Hash)
        return false if game == :Deso
        trainer = t
        oldSaveFormat = true
        framecount = Marshal.load(f)
        game_system = Marshal.load(f)
        pokemonSystem = Marshal.load(f)
        mapid = Marshal.load(f)
        switches = Marshal.load(f)
        variables = Marshal.load(f)
      else
        save = t
        trainer = save[:Trainer]
        framecount = save[:playtime]
        game_system = save[:system]
        mapid = save[:map_id]
        switches = save[:switches]
        variables = save[:variables]
      end
    }
    return false if !trainer.is_a?(PokeBattle_Trainer)
    return false if !framecount.is_a?(Numeric)
    return false if !game_system.is_a?(Game_System)
    return false if !mapid.is_a?(Numeric)
  rescue
    return false
  end

  case game
    when :WLL
      if switches[88] || variables[7] >= 139
        $game_switches[:Finished_WLL] = true
        return true
      end
    when :Reborn
      if switches[1305]
        $game_switches[:Reborn_Save] = true
        $game_variables[:RebornPlayerName] = trainer.name
        return true
      end
    when :Deso
      if switches[796]
        $game_switches[:Deso_Save] = true
        $game_variables[:DesoPlayerName] = trainer.name
        return true
      end
  end
  return false
end

#class Battle_Data; end # required to load deso save
class RegionalWeather; end # required to load reborn save
class ControlConfig; end # required to load WLL saves
