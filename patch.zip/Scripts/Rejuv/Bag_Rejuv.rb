class Window_PokemonBag < Window_DrawableCommand

  def drawCursor(index, rect)
    if self.index == index
      pbCopyBitmap(self.contents, @selarrow.bitmap, rect.x, rect.y + 14) # rect.x -> rect.x - 26
      # MODDED
      if index < @bag.getPocketItems(@pocket).length
        faviconOnPath = 'Graphics/Pictures/Bag/favicon_on'
        faviconOffPath = 'Graphics/Pictures/Bag/favicon_off'
        pbDrawImagePositions(self.contents, [
            # selected item
          [@bag.isFavorite?(item) ? faviconOnPath : faviconOffPath, rect.x + 10, rect.y + 22, 0, 0, -1, -1]
        ])
      end
      # END MODDED
    end
    return Rect.new(rect.x + 16, rect.y + 16, rect.width - 16, rect.height)
  end

  def drawItem(index, count, rect)
    textpos = []
    rect = drawCursor(index, rect)
    ypos = rect.y + 4
    pocketItems = @bag.getPocketItems(@pocket)
    if index == pocketItems.length
      textpos.push([_INTL("CLOSE BAG"), rect.x, ypos, false, self.baseColor, self.shadowColor])
    else
      item = pocketItems[index]
      qty = _ISPRINTF("x{1: 2d}", @bag.contents[item])
      # Use short item name unless the qty is single digit (works for Blue Moon Ice Cream which is the only use case right now)
      itemname = @adapter.getDisplayName(item, bag: true, short: @bag.contents[item] > 9)
      sizeQty = self.contents.text_size(qty).width
      xQty = rect.x + 4 + rect.width - sizeQty - 16
      baseColor = (index == @sortIndex) ? Color.new(224, 0, 0) : self.baseColor
      shadowColor = (index == @sortIndex) ? Color.new(248, 144, 144) : self.shadowColor
      textpos.push([itemname, rect.x + 28, ypos, false, baseColor, shadowColor])
      if !pbIsImportantItem?(item) || item == :UMBRALSHARD  # Not a Key item or HM (or infinite TM)
        textpos.push([qty, xQty, ypos, false, baseColor, shadowColor])
      end
    end
    pbDrawTextPositions(self.contents, textpos)
    if index != pocketItems.length
      if @bag.pbIsRegistered?(item)
        pbDrawImagePositions(
          self.contents,
          [
            ["Graphics/Pictures/Bag/bagReg", rect.x + rect.width - 60, ypos + 4, 0, 0, -1, -1]
          ]
        )
      end
      # MODDED
      if self.index != index
        faviconOnPath = 'Graphics/Pictures/Bag/favicon_on'
        faviconOffPath = 'Graphics/Pictures/Bag/favicon_off'
        pbDrawImagePositions(self.contents, [
            # unselected items
          [@bag.isFavorite?(item) ? faviconOnPath : faviconOffPath, rect.x - 6, ypos + 2, 0, 0, -1, -1]
        ])
      end
      # END MODDED
    end
  end
end

