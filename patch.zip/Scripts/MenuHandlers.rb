# MenuHandlers Registry for modular menu generation
module MenuHandlers
  @@registry = {}

  # Registers a new option to a specific menu.
  #
  # MODDING GUIDELINES:
  # - ALWAYS use a unique option_id (e.g., :your_mod_name_option) to avoid
  #   overwriting other mods.
  # - To add an option to the END of the menu, simply omit the order key.
  # - Only use order if you explicitly need your option inserted between
  #   vanilla options (e.g., between Pokemon (20) and Bag (30)).
  #
  # OPTION KEYS:
  # - name      : (Proc) The label displayed in the visual menu. Needs to be a
  #               proc even for static labels so as to work with translations
  #               (makes the _INTL call happen at runtime instead of on load).
  # - effect    : (Proc) The code executed when the player selects this option.
  #               Use `next :break` if the menu should completely close after.
  # - order     : (Integer) Determines list position. Defaults to 99999.
  # - condition : (Proc) Optional. Determines whether the option should be shown.
  #               Should evaluate to true/false.
  def self.add(menu_id, option_id, name:, order: 99999, color: nil, condition: nil, effect:)
    @@registry[menu_id] ||= {}
    @@registry[menu_id][option_id] = {
      name:      name,
      order:     order,
      color:     color,
      condition: condition,
      effect:    effect,
    }
  end

  # Helper to build the final commands and actions for any menu.
  # Eliminates code repetition in PauseMenu, Party, and Storage.
  def self.build(menu_id, *args)
    return [], [] unless @@registry[menu_id]

    commands = []
    actions = []

    # Sort by the order key
    sorted_options = @@registry[menu_id].sort_by { |_, v| v[:order] }

    colortags = isCurrentWindowskinDark ? ColorTags : LightColorTags
    sorted_options.each do |_, option|
      # Evaluate condition if it exists
      if option[:condition].nil? || option[:condition].call(*args)
        label = option[:name].call(*args)
        colortag = option[:color] ? colortags[option[:color]] : ""
        commands.push(colortag + label)
        actions.push(option[:effect])
      end
    end

    return commands, actions
  end
end
